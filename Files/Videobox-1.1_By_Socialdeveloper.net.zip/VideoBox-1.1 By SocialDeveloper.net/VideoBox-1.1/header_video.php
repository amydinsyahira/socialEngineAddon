<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE VIDEO FUNCTIONS FILE
include "./include/class_playlist.php";

// INCLUDE EXAMPLE LANGUAGE FILE
include "./lang/lang_english_video.php";

// INCLUDE VIDEO FUNCTION FILE
include "./include/functions_video.php";
//require_once($_SERVER['DOCUMENT_ROOT'] . '/InstallationChecker.php');

$clientLibraryPath = dirname($_SERVER['SCRIPT_FILENAME']) . '/ZendGdata/library';
$oldPath = set_include_path(get_include_path() . PATH_SEPARATOR . $clientLibraryPath);
//$installationChecker = new InstallationChecker(); exit;

require_once $clientLibraryPath . '/Zend/Loader.php'; // the Zend dir must be in your include_path
Zend_Loader::loadClass('Zend_Gdata_YouTube');


// PRELOAD LANGUAGE
SE_Language::_preload_multi(5000000, 5000185);

// SET MAIN MENU VARS
$plugin_vars[menu_main] = Array('file' => 'browse_video.php', 'title' => 5000000);

// SET USER MENU VARS
if($user->level_info[level_playlist_allow] == 1)
{
	$plugin_vars[menu_user] = Array('file' => 'user_video.php', 'icon' => 'video.gif', 'title' => 5000000);
}

// SET PROFILE MENU VARS
if($owner->level_info[level_playlist_allow] == 1 && $page == "profile")
{
	// START PLAYLIST
  	$playlist = new se_playlist($owner->user_info[user_id]);
	$sort = "playlist_id DESC";

	// GET PRIVACY LEVEL AND SET WHERE
	$playlist_privacy_max = $owner->user_privacy_max($user);
	$where = "(playlist_privacy & $playlist_privacy_max)";
	
	// GET TOTAL PLAYLISTS
	$total_playlists = $playlist->playlist_total($where);
	
	// GET PLAYLIST ARRAY
	//$playlists = $playlist->playlist_list(0, $total_playlists, $sort, $where);
	$playlists = $playlist->playlist_list(0, 4, $sort, $where);
	
	// ASSIGN PLAYLISTS SMARY VARIABLE
	$smarty->assign('playlists', $playlists);
	$smarty->assign('total_playlists', $total_playlists);

	// DETERMINE WHERE TO SHOW ALBUMS
	$level_playlist_profile = explode(",", $owner->level_info[level_playlist_profile]);
	if(!in_array($owner->user_info[user_profile_playlist], $level_playlist_profile))
	{
		$user_profile_playlist = $level_playlist_profile[0];
	}
	else
	{
		$user_profile_playlist = $owner->user_info[user_profile_playlist];
	}
	
	$fav_sort = " video_id DESC ";
	$fav_where = "";
	
	// GET TOTAL FAVOURITES
	$total_favourites = total_favourites();
	
	// GET FAVOURITES ARRAY
	$favourites = favourites_list(0, 4, $fav_sort, $fav_where);
	
	// ASSIGN PLAYLISTS SMARY VARIABLE
	$smarty->assign('favourites', $favourites);
	$smarty->assign('total_favourites', $total_favourites);
	
	// SHOW PLAYLIST IN APPROPRIATE LOCATION
	if($user_profile_playlist == "tab")
	{
		$plugin_vars[menu_profile_tab] = Array('file'=> 'profile_video_tab.tpl', 'title' => 5000185);
	}
	else
	{
		$plugin_vars[menu_profile_side] = Array('file'=> 'profile_video_side.tpl', 'title' => 5000185);
	}
	
	// CHECK TO SEE IF USER HAS BEEN TAGGED IN ANY PHOTOS
	$tagged = $database->database_num_rows($database->database_query("SELECT videotag_id FROM se_videotags WHERE videotag_user_id={$owner->user_info[user_id]} GROUP BY videotag_video_id"));
	if($tagged > 0)
	{
		$plugin_vars[menu_profile_menu] = Array('file' => "video.php?user=".$owner->user_info[user_username], 'icon' => 'playlist_playlist16.gif', 'title' => 5000137, 'title_1' => $owner->user_displayname_short, 'title_2' => $tagged);
	}
}

// SET SEARCH HOOK
if($page == "search")
{
	SE_Hook::register("se_search_do", search_video);
}

?>