<?php

$page = "video_view";
include "header.php";

$iVideoID = (int)$_GET['video_id'];
$playlist_id = (isset($_REQUEST['playlist_id']) && $_REQUEST['playlist_id'] ? $_REQUEST['playlist_id'] : false);
$fav = (isset($_REQUEST['fav']) && $_REQUEST['fav'] ? $_REQUEST['fav'] : false);

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_playlist] == 0)
{
	$page = "error";
	$smarty->assign('error_header', 639);
	$smarty->assign('error_message', 656);
	$smarty->assign('error_submit', 641);
	include "footer.php";
}

// BE SURE PLAYLIST BELONGS TO THIS USER
$playlist = $database->database_query("SELECT * FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$owner->user_info[user_id]."'");
$playlist_info = $database->database_fetch_assoc($playlist);

// GET PRIVACY SETTINGS
$level_playlist_privacy = unserialize($user->level_info[level_playlist_privacy]);
rsort($level_playlist_privacy);
$level_playlist_comments = unserialize($user->level_info[level_playlist_comments]);
rsort($level_playlist_comments);
$level_playlist_tag = unserialize($user->level_info[level_playlist_tag]);
rsort($level_playlist_tag);
$playlist_privacy = $level_playlist_privacy[0];
$playlist_comments = $level_playlist_comments[0];
$playlist_tag = $level_playlist_tag[0];

// MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
if(!in_array($playlist_privacy, $level_playlist_privacy)) { $playlist_privacy = $level_playlist_privacy[0]; }

// SET VARIABLES
$result = 0;
$is_error = 0;

if($fav)
{
	// CHECK THAT TITLE IS NOT BLANK
	$sql = "
		SELECT favourite_id FROM se_favourite_video WHERE favourite_user_id = '".$user->user_info[user_id]."' AND favourite_video_id = '".$iVideoID."'";
	$fav = $database->database_query($sql);
	if($database->database_num_rows($fav))
		$is_error = 5000210;
	
	// IF NO ERROR, CONTINUE
	if($is_error == 0)
	{

	    // IMPORT VIDEO IN DATABASE
	    $database->database_query("
			INSERT INTO se_favourite_video SET
				favourite_user_id = '".$user->user_info['user_id']."',
				favourite_video_id = '".$iVideoID."'");
	    $result = 1;
	    
	    $sql = "
	    	SELECT `video_title`
	    	FROM `se_videos`
	    	WHERE video_id = '".$iVideoID."'";
	    $video_info = $database->database_fetch_assoc($database->database_query($sql));
	    $actions->actions_add($user, "addtofavorites", Array($user->user_info[user_username], $user->user_displayname, $playlist_id, $iVideoID,  $video_info['video_title']), Array(), 0, FALSE, "user", $user->user_info[user_id], $playlist_privacy);
	}
}



// GET PROFILE COMMENTS
$allowed_to_comment = TRUE;
$comment = new se_comment('videos', 'video_id', $iVideoID);
$total_comments = $comment->comment_total();

$sql = "
	SELECT * FROM se_videos
	WHERE se_videos.video_id = '".$iVideoID."'";
$video = $database->database_query($sql);
$video_info = $database->database_fetch_assoc($video);

$smarty->assign('playlist_info', $playlist_info);
$smarty->assign('playlist_id', $playlist_id);
$smarty->assign('video_embed_str', $video_info['video_embed_str']);
$smarty->assign('video_info', $video_info);

$smarty->assign('allowed_to_comment', $allowed_to_comment);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('video_id', $iVideoID);

$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);

include "footer.php";

?>