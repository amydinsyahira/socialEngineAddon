<?php
$page = "user_video_edit";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_GET['playlist_id'])) { $playlist_id = $_GET['playlist_id']; } elseif(isset($_POST['playlist_id'])) { $playlist_id = $_POST['playlist_id']; } else { exit(); }

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($user->level_info[level_playlist_allow] == 0) { header("Location: user_home.php"); exit(); }

// BE SURE PLAYLIST BELONGS TO THIS USER
$playlist = $database->database_query("SELECT * FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($playlist) != 1) { header("Location: user_playlist.php"); exit(); }
$playlist_info = $database->database_fetch_assoc($playlist);

// SET VARIABLES
$result = 0;
$is_error = 0;


// GET PRIVACY SETTINGS
$level_playlist_privacy = unserialize($user->level_info[level_playlist_privacy]);
rsort($level_playlist_privacy);
$level_playlist_comments = unserialize($user->level_info[level_playlist_comments]);
rsort($level_playlist_comments);
$level_playlist_tag = unserialize($user->level_info[level_playlist_tag]);
rsort($level_playlist_tag);


// SAVE NEW INFO
if($task == "dosave") {
  $playlist_info[playlist_title] = censor($_POST['playlist_title']);
  $playlist_info[playlist_desc] = censor(str_replace("\r\n", "<br>", $_POST['playlist_desc']));
  $playlist_info[playlist_search] = $_POST['playlist_search'];
  $playlist_info[playlist_privacy] = $_POST['playlist_privacy'];
  $playlist_info[playlist_comments] = $_POST['playlist_comments'];
  $playlist_info[playlist_tag] = $_POST['playlist_tag'];
  $playlist_info[playlist_dateupdated] = time();


  // MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
  if(!in_array($playlist_info[playlist_privacy], $level_playlist_privacy)) { $playlist_info[playlist_privacy] = $level_playlist_privacy[0]; }
  if(!in_array($playlist_info[playlist_comments], $level_playlist_comments)) { $playlist_info[playlist_comments] = $level_playlist_comments[0]; }
  if(!in_array($playlist_info[playlist_tag], $level_playlist_tag)) { $playlist_info[playlist_tag] = $level_playlist_tag[0]; }

  // CHECK THAT TITLE IS NOT BLANK
  if(trim($playlist_info[playlist_title]) == "") { $is_error = 1000073; }

  // IF NO ERROR, CONTINUE
  if($is_error == 0) {

    // EDIT PLAYLIST IN DATABASE
    $database->database_query("UPDATE se_playlists SET playlist_title='$playlist_info[playlist_title]',
				    playlist_desc='$playlist_info[playlist_desc]',
				    playlist_search='$playlist_info[playlist_search]',
				    playlist_privacy='$playlist_info[playlist_privacy]',
				    playlist_comments='$playlist_info[playlist_comments]',
				    playlist_tag='$playlist_info[playlist_tag]',
				    playlist_dateupdated='$playlist_info[playlist_dateupdated]' WHERE playlist_id='$playlist_info[playlist_id]'");

    // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
    $user->user_lastupdate();

    $result = 1;
  }
}




// GET PREVIOUS PRIVACY SETTINGS
for($c=0;$c<count($level_playlist_privacy);$c++) {
  if(user_privacy_levels($level_playlist_privacy[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_playlist_privacy[$c]));
    $privacy_options[$level_playlist_privacy[$c]] = user_privacy_levels($level_playlist_privacy[$c]);
  }
}

for($c=0;$c<count($level_playlist_comments);$c++) {
  if(user_privacy_levels($level_playlist_comments[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_playlist_comments[$c]));
    $comment_options[$level_playlist_comments[$c]] = user_privacy_levels($level_playlist_comments[$c]);
  }
}

for($c=0;$c<count($level_playlist_tag);$c++) {
  if(user_privacy_levels($level_playlist_tag[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_playlist_tag[$c]));
    $tag_options[$level_playlist_tag[$c]] = user_privacy_levels($level_playlist_tag[$c]);
  }
}

// RESTORE LINE BREAKS
$playlist_info[playlist_desc] = str_replace("<br>", "\r\n", $playlist_info[playlist_desc]);

// ASSIGN VARIABLES AND SHOW EDIT PLAYLISTS PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('playlist_info', $playlist_info);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
$smarty->assign('tag_options', $tag_options);
include "footer.php";
?>