<?
switch($page)
{
	case "profile":
		$smarty->assign('content', $content);
		break;
	default:
		break;	
}
?>