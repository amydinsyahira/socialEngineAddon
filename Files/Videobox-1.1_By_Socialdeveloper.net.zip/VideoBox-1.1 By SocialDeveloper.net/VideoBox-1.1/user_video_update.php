<?php
$page = "user_video_update";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_GET['playlist_id'])) { $playlist_id = $_GET['playlist_id']; } elseif(isset($_POST['playlist_id'])) { $playlist_id = $_POST['playlist_id']; } else { $playlist_id = 0; }

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($user->level_info[level_playlist_allow] == 0) { header("Location: user_home.php"); exit(); }

// BE SURE PLAYLIST BELONGS TO THIS USER
$playlist = $database->database_query("SELECT * FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($playlist) != 1) { header("Location: user_video.php"); exit(); }
$playlist_info = $database->database_fetch_assoc($playlist);


// SET VARS
$result = 0;
$playlist = new se_playlist($user->user_info[user_id]);



// ROTATE
if($task == "rotate") {
  $video_id = $_GET['video_id'];
  $dir = $_GET['dir'];

  if($dir == "cc") { $dir = 90; } else { $dir = 270; }

  // ROTATE IMAGE
  $playlist->playlist_video_rotate($video_id, $dir);

  // SET THUMBPATH
  $thumb_path = $url->url_userdir($user->user_info[user_id]).$video_id."_thumb.jpg?".rand();

  // SEND AJAX CONFIRMATION
  echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type='text/javascript'>";
  echo "var img = window.parent.document.getElementById('file_$video_id');";
  echo "img.src = '$thumb_path';";
  echo "</script></head><body></body></html>";
  exit();




// UPDATE FILES IN THIS PLAYLIST
} elseif($task == "doupdate") {

  // GET TOTAL FILES
  $total_files = $playlist->playlist_files($playlist_info[playlist_id]);

  // DELETE NECESSARY FILES
  $playlist->playlist_video_delete(0, $total_files, "video_id ASC", "(video_playlist_id='$playlist_info[playlist_id]')");

  // UPDATE NECESSARY FILES
  $video_array = $playlist->playlist_video_update(0, $total_files, "video_id ASC", "(video_playlist_id='$playlist_info[playlist_id]')");

  // SET PLAYLIST COVER AND UPDATE DATE
  $newdate = time();
  $playlist_info[playlist_cover] = $_POST['playlist_cover'];
  if(!in_array($playlist_info[playlist_cover], $video_array)) { $playlist_info[playlist_cover] = $video_array[0]; }
  $database->database_query("UPDATE se_playlists SET playlist_cover='$playlist_info[playlist_cover]', playlist_dateupdated='$newdate' WHERE playlist_id='$playlist_info[playlist_id]'");

  // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
  $user->user_lastupdate();

  // SHOW SUCCESS MESSAGE
  $result = 1;



// MOVE VIDEO UP
} elseif($task == "moveup") {
  $video_id = $_GET['video_id'];

  $video_query = $database->database_query("SELECT video_id, video_order, video_playlist_id FROM se_video LEFT JOIN se_playlists ON se_video.video_playlist_id=se_playlists.playlist_id WHERE video_id='$video_id' AND se_playlists.playlist_user_id='".$user->user_info[user_id]."'");
  if($database->database_num_rows($video_query) == 1) { 

    $video_info = $database->database_fetch_assoc($video_query);

    $prev_query = $database->database_query("SELECT video_id, video_order FROM se_video LEFT JOIN se_playlists ON se_video.video_playlist_id=se_playlists.playlist_id WHERE se_video.video_playlist_id='$video_info[video_playlist_id]' AND se_playlists.playlist_user_id='".$user->user_info[user_id]."' AND video_order<$video_info[video_order] ORDER BY video_order DESC LIMIT 1");
    if($database->database_num_rows($prev_query) == 1) {

      $prev_info = $database->database_fetch_assoc($prev_query);

      // SWITCH ORDER
      $database->database_query("UPDATE se_video SET video_order=$prev_info[video_order] WHERE video_id=$video_info[video_id]");
      $database->database_query("UPDATE se_video SET video_order=$video_info[video_order] WHERE video_id=$prev_info[video_id]");

      // SEND AJAX CONFIRMATION
      echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type='text/javascript'>";
      echo "window.parent.reorderVideo('$video_info[video_id]', '$prev_info[video_id]');";
      echo "</script></head><body></body></html>";
      exit();

    } 
  }
}




// SHOW FILES IN THIS PLAYLIST
$total_files = $playlist->playlist_files($playlist_info[playlist_id]);
$file_array = $playlist->playlist_video_list(0, $total_files, "video_order ASC", "(video_playlist_id='$playlist_info[playlist_id]')");


// GET LIST OF OTHER PLAYLISTS
$total_playlists = $playlist->playlist_total("playlist_id<>'$playlist_info[playlist_id]'");
$playlist_array = $playlist->playlist_list(0, $total_playlists, "playlist_order ASC", "playlist_id<>'$playlist_info[playlist_id]'");


// ASSIGN VARIABLES AND SHOW UDPATE PLAYLISTS PAGE
$smarty->assign('result', $result);
$smarty->assign('files', $file_array);
$smarty->assign('files_total', $total_files);
$smarty->assign('playlist_info', $playlist_info);
$smarty->assign('playlists', $playlist_array);
$smarty->assign('playlists_total', $total_playlists);
include "footer.php";
?>