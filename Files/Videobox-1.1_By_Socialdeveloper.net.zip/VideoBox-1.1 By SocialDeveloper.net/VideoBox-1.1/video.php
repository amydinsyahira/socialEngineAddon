<?php

$page = "video";
include "header.php";

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_playlist] == 0)
{
	$page = "error";
	$smarty->assign('error_header', 639);
	$smarty->assign('error_message', 656);
	$smarty->assign('error_submit', 641);
	include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if($owner->user_exists == 0)
{
	$page = "error";
	$smarty->assign('error_header', 639);
	$smarty->assign('error_message', 828);
	$smarty->assign('error_submit', 641);
	include "footer.php";
}

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($owner->level_info[level_playlist_allow] == 0) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }
if(isset($_POST['v'])) { $v = $_POST['v']; } elseif(isset($_GET['v'])) { $v = $_GET['v']; } else { $v = 0; }
$playlist_id = (isset($_REQUEST['playlist_id']) && $_REQUEST['playlist_id'] ? $_REQUEST['playlist_id'] : false);
$user_name = (isset($_REQUEST['playlist_id']) && $_REQUEST['playlist_id'] ? $_REQUEST['playlist_id'] : false);
$delete_video = (isset($_REQUEST['delete_video']) && $_REQUEST['delete_video'] ? $_REQUEST['delete_video'] : false);

// IF PLAYLIST ID IS 0, GET TAGGED PHOTOS OF OWNER
if($playlist_id == 0)
{

	// SET PLAYLIST VARS
	$playlist_info[playlist_id] = 0;

	// CHECK PRIVACY
	$privacy_max = $owner->user_privacy_max($user);
	if(!($owner->user_info[user_privacy] & $privacy_max)) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

// OTHERWISE BE SURE PLAYLIST BELONGS TO THIS USER
}
else
{
	// GET PLAYLIST INFO
	$playlist_query = $database->database_query("SELECT * FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$owner->user_info[user_id]."'");
	if($database->database_num_rows($playlist_query) != 1) { header("Location: ".$url->url_create('videos', $owner->user_info[user_username])); exit(); }
	$playlist_info = $database->database_fetch_assoc($playlist_query);
  
	// GET CUSTOM PLAYLIST STYLE IF ALLOWED
	if($owner->level_info[level_playlist_style] != 0)
	{
		$playliststyle_info = $database->database_fetch_assoc($database->database_query("SELECT playliststyle_css FROM se_playliststyles WHERE playliststyle_user_id='".$owner->user_info[user_id]."' LIMIT 1"));
		$global_css = $playliststyle_info[playliststyle_css];
	}
	
	// CHECK PRIVACY
	$privacy_max = $owner->user_privacy_max($user);
	if(!($playlist_info[playlist_privacy] & $privacy_max))
	{
		$page = "error";
		$smarty->assign('error_header', 639);
		$smarty->assign('error_message', 1000125);
		$smarty->assign('error_submit', 641);
		include "footer.php";
	}

	// UPDATE PLAYLIST VIEWS
	if($user->user_info[user_id] != $owner->user_info[user_id])
	{
		$playlist_views_new = $playlist_info[playlist_views] + 1;
		$database->database_query("UPDATE se_playlists SET playlist_views='$playlist_views_new' WHERE playlist_id='$playlist_info[playlist_id]' LIMIT 1");
	}
	
	if($delete_video)
	{
		$video_id = (isset($_REQUEST['video_id']) && $_REQUEST['video_id'] ? $_REQUEST['video_id'] : false);
		$sql = "
			DELETE FROM se_videos
			WHERE video_id = '".$video_id."' AND video_user_id = '".$user->user_info[user_id]."'";
		if($database->database_query($sql))
		{
			$query = "
				DELETE FROM se_favourite_video
				WHERE favourite_video_id = '".$video_id."'";
			$database->database_query($query);
		}
	}
	
	$videos_query = "
		SELECT * FROM se_videos
		WHERE video_playlist_id = '".$playlist_id."' AND video_user_id = '".$owner->user_info[user_id]."'
		ORDER BY se_videos.video_track_num ASC";
	$videos = $database->database_query($videos_query);
	$videos_array = array();
	$cnt = 0;
	//$yt = new Zend_Gdata_YouTube(); 
	
	while($video_info = $database->database_fetch_assoc($videos))
	{
		$cnt ++;
		$videos_array[$cnt] = $video_info;
		// video entry to be added
		/*
		$videoEntry = $yt->getVideoEntry($video_info['video_video_id']);
		
		$videoThumbnails = $videoEntry->getVideoThumbnails();
		foreach($videoThumbnails as $videoThumbnail)
		{
			// time: $videoThumbnail['time']
			// url: $videoThumbnail['url']
			// height: $videoThumbnail['height']
			// width: $videoThumbnail['width']
			if(isset($videoThumbnail['url']) && $videoThumbnail['url'])
			{
				$videoThumbnailUrl = $videoThumbnail['url'];
				$videoThumbnailWidth = $videoThumbnail['width'];
				$videoThumbnailHeight = $videoThumbnail['height'];
				break;
			}
		}
		*/
		$videoThumbnailUrl = 'get_video_thumbnail.php?video_id='.$video_info['video_id'];
		$videoThumbnailWidth = $video_info['video_thumbnail_width'];
		$videoThumbnailHeight = $video_info['video_thumbnail_height'];
		
		// GET PATH OF PLAYLIST  
		/*
		$playlist_cover_id = 0;
		$playlist_cover_ext = "";
		$sExtension = substr( $videoThumbnailUrl, ( strrpos($videoThumbnailUrl, '.') + 1 ) ) ;
		$sExtension = strtolower( $sExtension ) ;
				
		if($videoThumbnailUrl)
		{
			$playlist_cover_id = $cnt;
			$playlist_cover_ext = $sExtension;
		}
		*/
		// GET PATH OF PLAYLIST  
		$playlist_cover_id = 0;
		$playlist_cover_ext = "";
		$sExtension = $video_info['video_thumbnail_extension'];
						
		if($videoThumbnailUrl)
		{
			$playlist_cover_id = $video_info['video_id'];
			$playlist_cover_ext = $sExtension;
		}
		
		$query = "SELECT user_username, CONCAT_WS(' ', user_fname, user_lname) as user_displayname FROM se_users WHERE user_id = '".$video_info['video_user_id']."'";
		$resource = $database->database_query($query);
		$userinfo = $database->database_fetch_assoc($resource);
			
		$fav_query = "SELECT COUNT(*) as cnt FROM se_favourite_video WHERE favourite_video_id = '".$video_info['video_id']."'";
		$fav_res = $database->database_query($fav_query);
		$fav_info = $database->database_fetch_assoc($fav_res);
		
		$videos_array[$cnt]['favorites'] = $fav_info['cnt'];
		$videos_array[$cnt]['video_video_thumbnail_url'] = $videoThumbnailUrl; 
		$videos_array[$cnt]['video_video_thumbnail_width'] = $videoThumbnailWidth;
		$videos_array[$cnt]['video_video_thumbnail_height'] = $videoThumbnailHeight;
		$videos_array[$cnt]['video_cover_id'] = $playlist_cover_id;
		$videos_array[$cnt]['video_cover_ext'] = $playlist_cover_ext;
		$videos_array[$cnt]['video_files'] = 1;
		$videos_array[$cnt]['video_updated'] = strtotime($video_info['video_updated']);
		$videos_array[$cnt]['video_duration'] = floor($video_info['video_duration'] / 60) . ':' . $video_info['video_duration'] % 60;
		$videos_array[$cnt]['playlist_author'] = array('user_info' => array('user_username' => $userinfo['user_username'], 'user_displayname' => $userinfo['user_displayname']));
	}
	
	// GET TOTAL VIDEOS
	$videos_total = $database->database_num_rows($database->database_query($videos_query));
	
	// MAKE ENTRY PAGES
	$videos_per_page = 10;
	$page_vars = make_page($videos_total, $videos_per_page, $p);
	
	// GET PLAYLIST ARRAY
	$tmp_arr = array_chunk($videos_array, $videos_per_page);
	$videos_array = $tmp_arr[$p-1];
	
	
	// BE SURE PLAYLIST BELONGS TO THIS USER
	$playlist = $database->database_query("SELECT * FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$owner->user_info[user_id]."'");
	if($database->database_num_rows($playlist) != 1) { header("Location: user_video.php"); exit(); }
	$playlist_info = $database->database_fetch_assoc($playlist);
	
	$sql = "
		SELECT COUNT(*) as cnt
		FROM se_playlists
		WHERE playlist_user_id = '".$user->user_info[user_id]."'";
	$tmp = $database->database_fetch_array($database->database_query($sql));
	$is_import = $tmp['cnt'];
	
	$playlist = new se_playlist($user->user_info[user_id]);
	$playlists_for_select = $playlist->playlist_list(0, $is_import, "playlist_order ASC", '');
	foreach ($playlists_for_select as $key => $val)
	{
		if($val['playlist_id'] == $playlist_id)
		{
			unset($playlists_for_select[$key]);
			$tmp_arr = array();
			$playlists_for_select = array_merge($tmp_arr, $playlists_for_select);
			break;
		}
	}
	
	
	// ASSIGN SMARTY VARIABLES AND DISPLAY PLAYLISTS PAGE
	$smarty->assign('playlist_info', $playlist_info);
	$smarty->assign('is_import', $is_import);
	$smarty->assign('playlist_id', $playlist_id);
	$smarty->assign('videos', $videos_array);
	$smarty->assign('videolist', $videos_array);
	$smarty->assign('playlists_for_select', $playlists_for_select);
	$smarty->assign('total_videos', $videos_total);
	$smarty->assign('p', $page_vars[1]);
	$smarty->assign('maxpage', $page_vars[2]);
	$smarty->assign('p_start', $page_vars[0] + 1);
	$smarty->assign('p_end', $page_vars[0] + count($videos_array));
	$smarty->assign('s', $s);
	$smarty->assign('v', $v);
}


include "footer.php";

?>