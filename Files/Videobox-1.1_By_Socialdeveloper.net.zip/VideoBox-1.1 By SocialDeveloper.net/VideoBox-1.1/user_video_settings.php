<?php
$page = "user_video_settings";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($user->level_info[level_playlist_allow] == 0) { header("Location: user_home.php"); exit(); }

// SET VARS
$result = 0;
$level_playlist_profile = explode(",", $user->level_info[level_playlist_profile]);

// SAVE NEW CSS
if($task == "dosave") {
  $style_playlist = addslashes(str_replace("-moz-binding", "", strip_tags(htmlspecialchars_decode($_POST['style_playlist'], ENT_QUOTES))));
  $user_profile_playlist = $_POST['user_profile_playlist'];

  // ENSURE USER SELECTED APPROPRIATE OPTION
  if(!in_array($user_profile_playlist, $level_playlist_profile)) { $user_profile_playlist = $level_playlist_profile[0]; }

  $database->database_query("UPDATE se_playliststyles SET playliststyle_css='$style_playlist' WHERE playliststyle_user_id='".$user->user_info[user_id]."'");
  $database->database_query("UPDATE se_users SET user_profile_playlist='$user_profile_playlist' WHERE user_id='".$user->user_info[user_id]."'");
  $user->user_lastupdate();
  $user->user_info[user_profile_playlist] = $user_profile_playlist;
  $result = 1;
}



// GET THIS USER'S PLAYLIST CSS
$style_query = $database->database_query("SELECT playliststyle_css FROM se_playliststyles WHERE playliststyle_user_id='".$user->user_info[user_id]."' LIMIT 1");
if($database->database_num_rows($style_query) == 1) { 
  $style_info = $database->database_fetch_assoc($style_query); 
} else {
  $database->database_query("INSERT INTO se_playliststyles (playliststyle_user_id, playliststyle_css) VALUES ('".$user->user_info[user_id]."', '')");
  $style_info = $database->database_fetch_assoc($database->database_query("SELECT playliststyle_css FROM se_playliststyles WHERE playliststyle_user_id='".$user->user_info[user_id]."' LIMIT 1")); 
}

// ENSURE PROFILE LOCATION IS ALLOWED
if(!in_array($user->user_info[user_profile_playlist], $level_playlist_profile)) { $user->user_info[user_profile_playlist] = $level_playlist_profile[0]; }

// ASSIGN SMARTY VARIABLES AND DISPLAY PLAYLIST STYLE PAGE
$smarty->assign('result', $result);
$smarty->assign('level_playlist_profile', $level_playlist_profile);
$smarty->assign('style_playlist', htmlspecialchars($style_info[playliststyle_css], ENT_QUOTES, 'UTF-8'));
include "footer.php";
?>