<?php
// socialnetwork code	
$page = "browse_video";
include "header.php";

$playlists_per_page = 10;
$is_search = isset($_REQUEST['is_search']) && $_REQUEST['is_search'] ? true : false;
if($is_search)
{
	if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }
	if(isset($_POST['v'])) { $v = $_POST['v']; } elseif(isset($_GET['v'])) { $v = $_GET['v']; } else { $v = 0; }
	
	// ENSURE SORT/VIEW ARE VALID
	if($v != "0" && $v != "1") { $v = 0; }
	
	$search_terms = isset($_REQUEST['search_terms']) && $_REQUEST['search_terms'] ? $_REQUEST['search_terms'] : '';
	$search_select = isset($_REQUEST['search_select']) && $_REQUEST['search_select'] ? $_REQUEST['search_select'] : 'playlists';
	
	$sql = "
		SELECT COUNT(*) as cnt
		FROM se_playlists
		WHERE playlist_user_id = '".$user->user_info[user_id]."'";
	$tmp = $database->database_fetch_array($database->database_query($sql));
	$playlist = new se_playlist($user->user_info[user_id]);
	$tmp_playlists_for_select = $playlist->playlist_list(0, $tmp['cnt'], "playlist_order ASC", '');
	
	switch($search_select)
	{
		case 'youtube':
			$playlists_for_select = $tmp_playlists_for_select;
			$videoFeed = searchInYouTube($search_terms);
			
			$cnt = 0;
			foreach ($videoFeed as $videoEntry)
			{
				$cnt++;
				// the videoEntry object contains many helper functions that access the underlying mediaGroup object
				// Video: $videoEntry->getVideoTitle()
				// Video ID: $videoEntry->getVideoId()
				// Updated: $videoEntry->getUpdated()
				// Description: $videoEntry->getVideoDescription()
				// Category: $videoEntry->getVideoCategory()
				// Tags: implode(", ", $videoEntry->getVideoTags())
				// Watch page: $videoEntry->getVideoWatchPageUrl()
				// Flash Player Url: $videoEntry->getFlashPlayerUrl()
				// Duration: $videoEntry->getVideoDuration()
				// View count: $videoEntry->getVideoViewCount()
				// Rating: $videoEntry->getVideoRatingInfo()
				// Geo Location: $videoEntry->getVideoGeoLocation()
  				
				// see the paragraph above this function for more information on the 'mediaGroup' object
				// here we are using the mediaGroup object directly to its 'Mobile RSTP link' child
				foreach ($videoEntry->mediaGroup->content as $content)
				{
					if ($content->type === "video/3gpp")
					{
						// Mobile RTSP link: $content->url
					}
					else if($content->type === "application/x-shockwave-flash")
					{
						
					}
				}
  				
				// Thumbnails
				$videoThumbnailUrl = '';
				$videoThumbnails = $videoEntry->getVideoThumbnails();
				foreach($videoThumbnails as $videoThumbnail)
				{
					// time: $videoThumbnail['time']
					// url: $videoThumbnail['url']
					// height: $videoThumbnail['height']
					// width: $videoThumbnail['width']
					if(isset($videoThumbnail['url']) && $videoThumbnail['url'])
					{
						$videoThumbnailUrl = $videoThumbnail['url'];
						$videoThumbnailWidth = $videoThumbnail['width'];
						$videoThumbnailHeight = $videoThumbnail['height'];
						break;
					}
				}
				
				$videoTitle = $videoEntry->getVideoTitle();
				
				// GET PATH OF PLAYLIST  
				$playlist_cover_id = 0;
				$playlist_cover_ext = "";
				$sExtension = strtolower( substr( $videoThumbnailUrl, ( strrpos($videoThumbnailUrl, '.') + 1 ) ) );
				if($videoThumbnailUrl)
				{
					$playlist_cover_id = $cnt;
					$playlist_cover_ext = $sExtension;
				}
				
				// CREATE ARRAY OF PLAYLIST DATA
				SE_Language::_preload(user_privacy_levels($playlist_info[playlist_privacy]));
				
				$updated = $videoEntry->getUpdated()->getText();
				$query = "SELECT UNIX_TIMESTAMP('".$updated."') as updated";
				$updated_resource = $database->database_query($query);
				$updated_timestamp = $database->database_fetch_assoc($updated_resource);
				
				$duration = $videoEntry->getVideoDuration(); // in the seconds
				$sDuraton = floor($duration / 60) . ':' . $duration % 60;
				
				$playlist_array[] = Array(
					'playlist_id' => $cnt,
					'playlist_user_id' => 0,
					'playlist_author' => array('user_info' => array('user_username' => '', 'user_displayname' => '')),
					'playlist_datecreated' => $updated_timestamp['updated'],
					'playlist_dateupdated' => $updated_timestamp['updated'],
					'playlist_dateupdated_raw' => $updated_timestamp['updated'],
					'playlist_title' => $videoEntry->getVideoTitle(),
					'playlist_desc' => $videoEntry->getVideoDescription(),
					'playlist_files' => 1,
					'playlist_privacy' => user_privacy_levels($playlist_info[playlist_privacy]),
					'playlist_cover_id' => $playlist_cover_id,
					'playlist_cover_ext' => $playlist_cover_ext,
					'playlist_views' => $videoEntry->getVideoViewCount(),
					'playlist_video_thumbnail_url' => $videoThumbnailUrl,
					'playlist_video_thumbnail_width' => $videoThumbnailWidth,
					'playlist_video_thumbnail_height' => $videoThumbnailHeight,
					'playlist_video_watch_page_url' => $videoEntry->getVideoWatchPageUrl(),
					'playlist_duraton' => $sDuraton,
					'playlist_video_id' => $videoEntry->getVideoId(),
					'playlist_is_import' => count($playlists_for_select),
					'playlists_for_select' => $playlists_for_select,
					);
			}
			
			$tmp_arr = array_chunk($playlist_array, $playlists_per_page);
			$playlist_array = $tmp_arr[$p-1];
			
			break;
		case 'playlists':
		case 'friends_playlists':
			if($search_select == 'playlists')
			{
				$sql = "
					SELECT *
					FROM se_videos
					WHERE (se_videos.video_title LIKE '%".$search_terms."%') OR (se_videos.video_description LIKE '%".$search_terms."%') OR (se_videos.video_tags LIKE '%".$search_terms."%')";
			}
			else if($search_select == 'friends_playlists')
			{
				$sql = "
					SELECT count(se_videos.video_id), se_videos.*
					FROM se_videos
					LEFT JOIN se_playlists ON se_playlists.playlist_id = se_videos.video_playlist_id
					WHERE (SELECT TRUE FROM se_friends WHERE friend_user_id1={$user->user_info[user_id]} AND friend_user_id2=se_videos.video_user_id AND friend_status=1)
						AND ((se_videos.video_title LIKE '%".$search_terms."%') OR (se_videos.video_description LIKE '%".$search_terms."%') OR (se_videos.video_tags LIKE '%".$search_terms."%'))
						GROUP BY se_videos.video_id";
			}
			$videos = $database->database_query($sql);
			$cnt = 0;
			//$yt = new Zend_Gdata_YouTube(); 
			while($video_info = $database->database_fetch_assoc($videos))
			{
				$cnt++;
				$playlists_for_select = $tmp_playlists_for_select;
				
				/*
				$videoEntry = $yt->getVideoEntry($video_info['video_video_id']);
				
				$videoThumbnailUrl = '';
				$videoThumbnails = $videoEntry->getVideoThumbnails();
				foreach($videoThumbnails as $videoThumbnail)
				{
					if(isset($videoThumbnail['url']) && $videoThumbnail['url'])
					{
						$videoThumbnailUrl = $videoThumbnail['url'];
						$videoThumbnailWidth = $videoThumbnail['width'];
						$videoThumbnailHeight = $videoThumbnail['height'];
						break;
					}
				}
				*/
				$videoThumbnailUrl = 'get_video_thumbnail.php?video_id='.$video_info['video_id'];
				$videoThumbnailWidth = $video_info['video_thumbnail_width'];
				$videoThumbnailHeight = $video_info['video_thumbnail_height'];
				
				// GET PATH OF PLAYLIST  
				$playlist_cover_id = 0;
				$playlist_cover_ext = "";
				
				$sExtension = $video_info['video_thumbnail_extension'];
						
				if($videoThumbnailUrl)
				{
					$playlist_cover_id = $video_info['video_id'];
					$playlist_cover_ext = $sExtension;
				}
				
				//$duration = $videoEntry->getVideoDuration(); // in the seconds
				$duration = $video_info['video_duration'];
				$sDuraton = floor($duration / 60) . ':' . $duration % 60;
				
				$query = "SELECT user_username, CONCAT_WS(' ', user_fname, user_lname) as user_displayname FROM se_users WHERE user_id = '".$video_info['video_user_id']."'";
				$resource = $database->database_query($query);
				$userinfo = $database->database_fetch_assoc($resource);
				
				$fav_query = "SELECT COUNT(*) as cnt FROM se_favourite_video WHERE favourite_video_id = '".$video_info['video_id']."'";
				$fav_res = $database->database_query($fav_query);
				$fav_info = $database->database_fetch_assoc($fav_res);
		
				$playlist_array[$cnt] = Array(
				    'favorites' => $fav_info['cnt'],
					'video_id' => $video_info['video_id'],
					'playlist_id' => $video_info['video_playlist_id'],
					'playlist_user_id' => 0,
					'playlist_author' => array('user_info' => array('user_username' => $userinfo['user_username'], 'user_displayname' => $userinfo['user_displayname'])),
					'playlist_datecreated' => strtotime($video_info['video_updated']),
					'playlist_dateupdated' => strtotime($video_info['video_updated']),
					'playlist_dateupdated_raw' => strtotime($video_info['video_updated']),
					/*'playlist_title' => $videoEntry->getVideoTitle(),*/
					'playlist_title' => $video_info['video_title'],
					/*'playlist_desc' => $videoEntry->getVideoDescription(),*/
					'playlist_desc' => $video_info['video_description'],
					'playlist_files' => 1,
					'playlist_privacy' => user_privacy_levels($playlist_info[playlist_privacy]),
					'playlist_cover_id' => $playlist_cover_id,
					'playlist_cover_ext' => $playlist_cover_ext,
					/*'playlist_views' => $videoEntry->getVideoViewCount(),*/
					'playlist_video_thumbnail_url' => $videoThumbnailUrl,
					'playlist_video_thumbnail_width' => $videoThumbnailWidth,
					'playlist_video_thumbnail_height' => $videoThumbnailHeight,
					/*'playlist_video_watch_page_url' => $videoEntry->getVideoWatchPageUrl(),*/
					'playlist_video_watch_page_url' => $video_info['video_watch_page_url'],
					'playlist_duraton' => $sDuraton,
					/*'playlist_video_id' => $videoEntry->getVideoId(),*/
					'playlist_video_id' => $video_info['video_video_id'],
					'playlist_is_import' => count($playlists_for_select),
					'playlists_for_select' => $playlists_for_select,
					);
				
				if($search_select == 'playlists')
				{
					foreach ($playlists_for_select as $key => $val)
					{
						if($val['playlist_id'] == $video_info['video_playlist_id'])
						{
							unset($playlists_for_select[$key]);
							$tmp_arr = array();
							$playlists_for_select = array_merge($tmp_arr, $playlists_for_select);
							break;
						}
					}
					$playlist_array[$cnt]['playlist_is_import'] = count($playlists_for_select);
					$playlist_array[$cnt]['playlists_for_select'] = $playlists_for_select;
				}
			}
			
			$tmp_arr = array_chunk($playlist_array, $playlists_per_page);
			$playlist_array = $tmp_arr[$p-1];
			break;
	}
	
	// GET TOTAL PLAYLISTS
	$total_playlists = $cnt;
	
	// MAKE ENTRY PAGES
	$page_vars = make_page($total_playlists, $playlists_per_page, $p);
	
	// ASSIGN SMARTY VARIABLES AND DISPLAY PLAYLISTS PAGE
	$smarty->assign('is_search', $is_search);
	$smarty->assign('is_import', $is_import);
	$smarty->assign('search_terms', $search_terms);
	$smarty->assign('search_select', $search_select);
	$smarty->assign('playlists', $playlist_array);
	$smarty->assign('p', $page_vars[1]);
	$smarty->assign('maxpage', $page_vars[2]);
	$smarty->assign('p_start', $page_vars[0]+1);
	$smarty->assign('p_end', $page_vars[0]+count($playlist_array));
	$smarty->assign('s', $s);
	$smarty->assign('v', $v);
}
else	
{
	if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }
	if(isset($_POST['s'])) { $s = $_POST['s']; } elseif(isset($_GET['s'])) { $s = $_GET['s']; } else { $s = "playlist_datecreated DESC"; }
	if(isset($_POST['v'])) { $v = $_POST['v']; } elseif(isset($_GET['v'])) { $v = $_GET['v']; } else { $v = 0; }
	
	// ENSURE SORT/VIEW ARE VALID
	if($s != "playlist_datecreated DESC" && $s != "playlist_dateupdated DESC") { $s = "playlist_dateupdated DESC"; }
	if($v != "0" && $v != "1") { $v = 0; }
	
	
	// SET WHERE CLAUSE
	$where = "CASE
		    WHEN se_playlists.playlist_user_id={$user->user_info[user_id]}
		      THEN TRUE
		    WHEN ((se_playlists.playlist_privacy & @SE_PRIVACY_REGISTERED) AND {$user->user_exists}<>0)
		      THEN TRUE
		    WHEN ((se_playlists.playlist_privacy & @SE_PRIVACY_ANONYMOUS) AND {$user->user_exists}=0)
		      THEN TRUE
		    WHEN ((se_playlists.playlist_privacy & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_playlists.playlist_user_id AND friend_user_id2={$user->user_info[user_id]} AND friend_status='1' LIMIT 1))
		      THEN TRUE
		    WHEN ((se_playlists.playlist_privacy & @SE_PRIVACY_SUBNET) AND {$user->user_exists}<>0 AND (SELECT TRUE FROM se_users WHERE user_id=se_playlists.playlist_user_id AND user_subnet_id={$user->user_info[user_subnet_id]} LIMIT 1))
		      THEN TRUE
		    WHEN ((se_playlists.playlist_privacy & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM se_friends AS friends_primary LEFT JOIN se_users ON friends_primary.friend_user_id1=se_users.user_id LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE friends_primary.friend_user_id1=se_playlists.playlist_user_id AND friends_secondary.friend_user_id2={$user->user_info[user_id]} AND se_users.user_subnet_id={$user->user_info[user_subnet_id]} LIMIT 1))
		      THEN TRUE
		    ELSE FALSE
		END";
	
	
	// ONLY MY FRIENDS' PLAYLISTS
	if($v == "1" && $user->user_exists) {
	
	  // SET WHERE CLAUSE
	  $where .= " AND (SELECT TRUE FROM se_friends WHERE friend_user_id1={$user->user_info[user_id]} AND friend_user_id2=se_playlists.playlist_user_id AND friend_status=1)";
	
	}
	
	
	// CREATE PLAYLIST OBJECT
	$playlist = new se_playlist();
	
	// GET TOTAL PLAYLISTS
	$total_playlists = $playlist->playlist_total($where);
	
	// MAKE ENTRY PAGES
	$page_vars = make_page($total_playlists, $playlists_per_page, $p);
	
	// GET PLAYLIST ARRAY
	$playlist_array = $playlist->playlist_list($page_vars[0], $playlists_per_page, $s, $where);
	//print_r($playlist_array);exit;
	
	// ASSIGN SMARTY VARIABLES AND DISPLAY PLAYLISTS PAGE
	$smarty->assign('playlists', $playlist_array);
	$smarty->assign('total_playlists', $total_playlists);
	$smarty->assign('p', $page_vars[1]);
	$smarty->assign('maxpage', $page_vars[2]);
	$smarty->assign('p_start', $page_vars[0]+1);
	$smarty->assign('p_end', $page_vars[0]+count($playlist_array));
	$smarty->assign('s', $s);
	$smarty->assign('v', $v);
}

include "footer.php";

?>