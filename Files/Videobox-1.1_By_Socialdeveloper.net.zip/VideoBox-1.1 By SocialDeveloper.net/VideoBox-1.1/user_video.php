<?php
$page = "user_video";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($user->level_info[level_playlist_allow] == 0) { header("Location: user_home.php"); exit(); }


// CREATE PLAYLIST OBJECT
$playlist = new se_playlist($user->user_info[user_id]);

// BE SURE PLAYLIST BELONGS TO THIS USER, DELETE PLAYLIST
if($task == "delete")
{
	$playlist_id = $_GET['playlist_id'];
	if($database->database_num_rows($database->database_query("SELECT playlist_id FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$user->user_info[user_id]."'")) == 1)
	{ 
		$playlist->playlist_delete($playlist_id);    
	}
// MOVE PLAYLIST UP
}
elseif($task == "moveup")
{
	$playlist_id = $_GET['playlist_id'];

	$playlist_query = $database->database_query("SELECT playlist_id, playlist_order FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$user->user_info[user_id]."'");
	if($database->database_num_rows($playlist_query) == 1)
	{ 
		$playlist_info = $database->database_fetch_assoc($playlist_query);
		
		$prev_query = $database->database_query("SELECT playlist_id, playlist_order FROM se_playlists WHERE playlist_user_id='".$user->user_info[user_id]."' AND playlist_order<$playlist_info[playlist_order] ORDER BY playlist_order DESC LIMIT 1");
		if($database->database_num_rows($prev_query) == 1)
		{
			$prev_info = $database->database_fetch_assoc($prev_query);

			// SWITCH ORDER
			$database->database_query("UPDATE se_playlists SET playlist_order=$prev_info[playlist_order] WHERE playlist_id=$playlist_info[playlist_id]");
			$database->database_query("UPDATE se_playlists SET playlist_order=$playlist_info[playlist_order] WHERE playlist_id=$prev_info[playlist_id]");

			// SEND AJAX CONFIRMATION
			echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type='text/javascript'>";
			echo "window.parent.reorderPlaylist('$playlist_info[playlist_id]', '$prev_info[playlist_id]');";
			echo "</script></head><body></body></html>";
			exit();
		} 
	}
}


// GET PLAYLISTS
$total_playlists = $playlist->playlist_total();
$playlist_array = $playlist->playlist_list(0, $total_playlists, "playlist_order ASC");

$space_used = $playlist->playlist_space();
$total_files = $playlist->playlist_files();

// CALCULATE SPACE FREE, CONVERT TO MEGABYTES
if($user->level_info[level_playlist_storage])
	$space_free = $user->level_info[level_playlist_storage] - $space_used;
else
	$space_free = ( $dfs=disk_free_space("/") ? $dfs : pow(2, 32) );
 
$space_free = ($space_free / 1024) / 1024;
$space_free = round($space_free, 2);


// ASSIGN VARIABLES AND SHOW VIEW PLAYLISTS PAGE
$smarty->assign('space_free', $space_free);
$smarty->assign('total_files', $total_files);
$smarty->assign('playlists_total', $total_playlists);
$smarty->assign('playlists', $playlist_array);
include "footer.php";

?>