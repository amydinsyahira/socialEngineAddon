<?php
$page = "user_video_add";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($user->level_info[level_playlist_allow] == 0) { header("Location: user_home.php"); exit(); }
// CHECK THAT MAX playlistS HAVEN'T BEEN REACHED
$playlist = new se_playlist($user->user_info[user_id]);
$total_playlists = $playlist->playlist_total();
if($total_playlists >= $user->level_info[level_playlist_maxnum]) { $task = "main"; }

// GET PRIVACY SETTINGS
$level_playlist_privacy = unserialize($user->level_info[level_playlist_privacy]);
rsort($level_playlist_privacy);
$level_playlist_comments = unserialize($user->level_info[level_playlist_comments]);
rsort($level_playlist_comments);
$level_playlist_tag = unserialize($user->level_info[level_playlist_tag]);
rsort($level_playlist_tag);

// SET VARS
$is_error = 0;
$playlist_title = "";
$playlist_desc = "";
$playlist_search = 1;
$playlist_privacy = $level_playlist_privacy[0];
$playlist_comments = $level_playlist_comments[0];
$playlist_tag = $level_playlist_tag[0];

if($task == "doadd")
{
	$playlist_title = censor($_POST['playlist_title']);
	$playlist_desc = censor(str_replace("\r\n", "<br>", $_POST['playlist_desc']));
	$playlist_search = $_POST['playlist_search'];
	$playlist_privacy = $_POST['playlist_privacy'];
	$playlist_comments = $_POST['playlist_comments'];
	$playlist_tag = $_POST['playlist_tag'];
	$playlist_datecreated = time();

	// MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
	if(!in_array($playlist_privacy, $level_playlist_privacy)) { $playlist_privacy = $level_playlist_privacy[0]; }
	if(!in_array($playlist_comments, $level_playlist_comments)) { $playlist_comments = $level_playlist_comments[0]; }
	if(!in_array($playlist_tag, $level_playlist_tag)) { $playlist_tag = $level_playlist_tag[0]; }

	// CHECK THAT TITLE IS NOT BLANK
	if(trim($playlist_title) == "") { $is_error = 5000073; }

	// IF NO ERROR, CONTINUE
	if($is_error == 0) {

	// GET MAX ORDER
	$max = $database->database_fetch_assoc($database->database_query("SELECT max(playlist_order) AS max FROM se_playlists WHERE playlist_user_id='".$user->user_info[user_id]."'"));
	$playlist_order = $max[max]+1;

	// INSERT NEW playlist INTO DATABASE
	$database->database_query("
		INSERT INTO se_playlists (
			playlist_user_id,
			playlist_datecreated,
			playlist_dateupdated,
			playlist_title, 
			playlist_desc, 
			playlist_search,
			playlist_privacy,
			playlist_comments,
			playlist_tag,
			playlist_order
			) VALUES (
			'".$user->user_info[user_id]."',
			'$playlist_datecreated',
			'$playlist_datecreated',
			'$playlist_title',
			'$playlist_desc',
			'$playlist_search',
			'$playlist_privacy',
			'$playlist_comments',
			'$playlist_tag',
			'$playlist_order')");

	// GET playlist ID
	$playlist_id = $database->database_insert_id();

	// UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
	$user->user_lastupdate();

	// INSERT ACTION
	if(strlen($playlist_title) > 100) { $playlist_title = substr($playlist_title, 0, 97); $playlist_title .= "..."; }
	$actions->actions_add($user, "newplaylist", Array($user->user_info[user_username], $user->user_displayname, $playlist_id, $playlist_title), Array(), 0, FALSE, "user", $user->user_info[user_id], $playlist_privacy);

	// CALL playlist CREATION HOOK
    ($hook = SE_Hook::exists('se_playlist_create')) ? SE_Hook::call($hook, array()) : NULL;
	
    // SEND TO UPLOAD PAGE
    //header("Location: user_video_upload.php?playlist_id=$playlist_id&new_playlist=1");
    header("Location: import_video.php?playlist_id=$playlist_id");
    exit();
  }
}





// GET PREVIOUS PRIVACY SETTINGS
for($c=0;$c<count($level_playlist_privacy);$c++) {
  if(user_privacy_levels($level_playlist_privacy[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_playlist_privacy[$c]));
    $privacy_options[$level_playlist_privacy[$c]] = user_privacy_levels($level_playlist_privacy[$c]);
  }
}

for($c=0;$c<count($level_playlist_comments);$c++) {
  if(user_privacy_levels($level_playlist_comments[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_playlist_comments[$c]));
    $comment_options[$level_playlist_comments[$c]] = user_privacy_levels($level_playlist_comments[$c]);
  }
}

for($c=0;$c<count($level_playlist_tag);$c++) {
  if(user_privacy_levels($level_playlist_tag[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_playlist_tag[$c]));
    $tag_options[$level_playlist_tag[$c]] = user_privacy_levels($level_playlist_tag[$c]);
  }
}



// ASSIGN VARIABLES AND SHOW ADD playlist PAGE
$smarty->assign('is_error', $is_error);
$smarty->assign('total_playlists', $total_playlists);
$smarty->assign('playlist_title', $playlist_title);
$smarty->assign('playlist_desc', str_replace("<br>", "\r\n", $playlist_desc));
$smarty->assign('playlist_search', $playlist_search);
$smarty->assign('playlist_privacy', $playlist_privacy);
$smarty->assign('playlist_comments', $playlist_comments);
$smarty->assign('playlist_tag', $playlist_tag);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
$smarty->assign('tag_options', $tag_options);

include "footer.php";
?>