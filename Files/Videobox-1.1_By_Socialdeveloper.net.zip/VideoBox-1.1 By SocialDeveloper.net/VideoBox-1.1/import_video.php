<?php

$page = "import_video";
include "header.php";

$playlist_id = ((isset($_REQUEST['import_select']) && $_REQUEST['import_select']) ? $_REQUEST['import_select'] : (isset($_REQUEST['playlist_id']) && $_REQUEST['playlist_id'] ? $_REQUEST['playlist_id'] : ''));
$vid = (isset($_REQUEST['vid']) && $_REQUEST['vid'] ? $_REQUEST['vid'] : false);
$video_id = (isset($_REQUEST['video_id']) && $_REQUEST['video_id'] ? $_REQUEST['video_id'] : false);
$submit = (isset($_REQUEST['submit']) && $_REQUEST['submit'] ? $_REQUEST['submit'] : false);
$is_other = (isset($_REQUEST['is_other']) && $_REQUEST['is_other'] ? $_REQUEST['is_other'] : false);
$is_edit = (isset($_REQUEST['is_edit']) && $_REQUEST['is_edit'] ? $_REQUEST['is_edit'] : false);

$redirect_url = (isset($_REQUEST['redirect_url']) && $_REQUEST['redirect_url'] ? $_REQUEST['redirect_url'] : false);
if(!$redirect_url)
{
	$s = (isset($_REQUEST['s']) && $_REQUEST['s'] ? $_REQUEST['s'] : false);
	$v = (isset($_REQUEST['v']) && $_REQUEST['v'] ? $_REQUEST['v'] : false);
	$p = (isset($_REQUEST['p']) && $_REQUEST['p'] ? $_REQUEST['p'] : false);
	$is_search = (isset($_REQUEST['is_search']) && $_REQUEST['is_search'] ? $_REQUEST['is_search'] : false);
	$search_terms = (isset($_REQUEST['search_terms']) && $_REQUEST['search_terms'] ? $_REQUEST['search_terms'] : false);
	if($is_search)
		$redirect_url = 'browse_video.php?s='.$s.'&v='.$v.'&p='.$p.'&is_search='.$is_search.'&search_terms='.$search_terms;
	else 
		$redirect_url = 'browse_video.php';	
}

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($user->level_info[level_playlist_allow] == 0) { header("Location: user_home.php"); exit(); }
// BE SURE PLAYLIST BELONGS TO THIS USER
$playlist = $database->database_query("SELECT * FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($playlist) != 1) { header("Location: user_video.php"); exit(); }
$playlist_info = $database->database_fetch_assoc($playlist);

// GET PRIVACY SETTINGS
$level_playlist_privacy = unserialize($user->level_info[level_playlist_privacy]);
rsort($level_playlist_privacy);
$level_playlist_comments = unserialize($user->level_info[level_playlist_comments]);
rsort($level_playlist_comments);
$level_playlist_tag = unserialize($user->level_info[level_playlist_tag]);
rsort($level_playlist_tag);
$playlist_privacy = $level_playlist_privacy[0];
$playlist_comments = $level_playlist_comments[0];
$playlist_tag = $level_playlist_tag[0];

// MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
if(!in_array($playlist_privacy, $level_playlist_privacy)) { $playlist_privacy = $level_playlist_privacy[0]; }
if(!in_array($playlist_comments, $level_playlist_comments)) { $playlist_comments = $level_playlist_comments[0]; }
if(!in_array($playlist_tag, $level_playlist_tag)) { $playlist_tag = $level_playlist_tag[0]; }

// SET VARIABLES
$result = 0;
$is_error = 0;

if($vid)
{
	$yt = new Zend_Gdata_YouTube(); 
	// video entry to be added
	$videoEntry = $yt->getVideoEntry($vid);
	// the videoEntry object contains many helper functions that access the underlying mediaGroup object
	// Video: $videoEntry->getVideoTitle()
	// Video ID: $videoEntry->getVideoId()
	// Updated: $videoEntry->getUpdated()
	// Description: $videoEntry->getVideoDescription()
	// Category: $videoEntry->getVideoCategory()
	// Tags: implode(", ", $videoEntry->getVideoTags())
	// Watch page: $videoEntry->getVideoWatchPageUrl()
	// Flash Player Url: $videoEntry->getFlashPlayerUrl()
	// Duration: $videoEntry->getVideoDuration()
	// View count: $videoEntry->getVideoViewCount()
	// Rating: $videoEntry->getVideoRatingInfo()
	// Geo Location: $videoEntry->getVideoGeoLocation()

	if($submit)
	{
		$video_title = (isset($_REQUEST['video_title']) && $_REQUEST['video_title'] ? $_REQUEST['video_title'] : false);
		$description = (isset($_REQUEST['description']) && $_REQUEST['description'] ? $_REQUEST['description'] : false);
	}
	else 
	{
		$video_title = $videoEntry->getVideoTitle();
		$description = $videoEntry->getVideoDescription();
	}
			
	$video_id = $vid;
		
	$updated = $videoEntry->getUpdated()->getText();
	$query = "SELECT UNIX_TIMESTAMP('".$updated."') as updated";
	$updated_resource = $database->database_query($query);
	$updated_timestamp = $database->database_fetch_assoc($updated_resource);
	$updated_timestamp = $updated_timestamp['updated'];
	$updated_str = date('d-m-Y G:i:s', $updated_timestamp);
					
	$duration = $videoEntry->getVideoDuration(); // in the seconds
	$sDuraton = floor($duration / 60) . ':' . $duration % 60;
		
	$category = $videoEntry->getVideoCategory();
	$tags = implode(", ", $videoEntry->getVideoTags());
	$watch_page_url = $videoEntry->getVideoWatchPageUrl();
	$flash_player_url = $videoEntry->getFlashPlayerUrl();
	
	$embed_str = get_embed_str($flash_player_url);
	
	if($submit)
	{
		// CHECK THAT TITLE IS NOT BLANK
		if(trim($video_title == "")) { $is_error = 5000073; }
	
		// IF NO ERROR, CONTINUE
		if($is_error == 0)
		{
			// Thumbnails
			$videoThumbnailUrl = '';
			$videoThumbnails = $videoEntry->getVideoThumbnails();
			foreach($videoThumbnails as $videoThumbnail)
			{
				// time: $videoThumbnail['time']
				// url: $videoThumbnail['url']
				// height: $videoThumbnail['height']
				// width: $videoThumbnail['width']
				if(isset($videoThumbnail['url']) && $videoThumbnail['url'])
				{
					$videoThumbnailUrl = $videoThumbnail['url'];
					$videoThumbnailWidth = $videoThumbnail['width'];
					$videoThumbnailHeight = $videoThumbnail['height'];
					break;
				}
			}
			
			$sExtension = strtolower( substr( $videoThumbnailUrl, ( strrpos($videoThumbnailUrl, '.') + 1 ) ) );
			
			// IMPORT VIDEO IN DATABASE
			if($is_edit)
				$database->database_query("
				UPDATE se_videos SET
					video_user_id = '".$user->user_info['user_id']."',
					video_playlist_id = '".$playlist_id."',
					video_title = '".$video_title."',
					video_video_id = '".$video_id."',
					video_updated = NOW(),
					video_description = '".$description."',
					video_category = '".$category."',
					video_tags = '".$tags."',
					video_watch_page_url = '".$watch_page_url."',
					video_flash_player_url = '".$flash_player_url."',
					video_duration = '".$duration."',
					video_embed_str = '".$embed_str."',
					video_thumbnail_url = '".$videoThumbnailUrl."',
					video_thumbnail_width = '".$videoThumbnailWidth."',
					video_thumbnail_height = '".$videoThumbnailHeight."',
					video_thumbnail_image = '".mysql_escape_string(file_get_contents($videoThumbnailUrl))."',
					video_thumbnail_extension = '".$sExtension."'
				WHERE video_video_id = '".$video_id."'");
			else	
		    	$database->database_query("
				INSERT INTO se_videos SET
					video_user_id = '".$user->user_info['user_id']."',
					video_playlist_id = '".$playlist_id."',
					video_title = '".$video_title."',
					video_video_id = '".$video_id."',
					video_updated = NOW(),
					video_description = '".$description."',
					video_category = '".$category."',
					video_tags = '".$tags."',
					video_watch_page_url = '".$watch_page_url."',
					video_flash_player_url = '".$flash_player_url."',
					video_duration = '".$duration."',
					video_embed_str = '".$embed_str."',
					video_thumbnail_url = '".$videoThumbnailUrl."',
					video_thumbnail_width = '".$videoThumbnailWidth."',
					video_thumbnail_height = '".$videoThumbnailHeight."',
					video_thumbnail_image = '".mysql_escape_string(file_get_contents($videoThumbnailUrl))."',
					video_thumbnail_extension = '".$sExtension."'");
		    $result = 1;
		    
		    // GET playlist ID
			$insert_video_id = $database->database_insert_id();
			
		    $actions->actions_add($user, "importvideo", Array($user->user_info[user_username], $user->user_displayname, $playlist_id, $insert_video_id,  $video_title), Array(), 0, FALSE, "user", $user->user_info[user_id], $playlist_privacy);
		    
		    header("Location: video.php?user=".$user->user_info[user_username]."&playlist_id=".$playlist_id);
	  		exit();
		}
	}

	$smarty->assign('redirect_url', $redirect_url);
	
	$smarty->assign('video_title', $video_title);
	$smarty->assign('video_id', $video_id);
	$smarty->assign('description', $description);
	$smarty->assign('category', $category);
	$smarty->assign('tags', $tags);
	$smarty->assign('watch_page_url', $watch_page_url);
	$smarty->assign('flash_player_url', $flash_player_url);
	$smarty->assign('duration', $sDuraton);
	$smarty->assign('embed_str', $embed_str);
}
else if($is_other)
{
	$is_manual = true;
	$video_title = (isset($_REQUEST['video_title']) && $_REQUEST['video_title'] ? $_REQUEST['video_title'] : false);
	$description = (isset($_REQUEST['description']) && $_REQUEST['description'] ? $_REQUEST['description'] : false);
	$video_id = (isset($_REQUEST['video_id']) && $_REQUEST['video_id'] ? $_REQUEST['video_id'] : false);
	$category = (isset($_REQUEST['category']) && $_REQUEST['category'] ? $_REQUEST['category'] : false);
	$tags = (isset($_REQUEST['tags']) && $_REQUEST['tags'] ? $_REQUEST['tags'] : false);
	$watch_page_url = (isset($_REQUEST['watch_page_url']) && $_REQUEST['watch_page_url'] ? $_REQUEST['watch_page_url'] : false);
	$flash_player_url = (isset($_REQUEST['flash_player_url']) && $_REQUEST['flash_player_url'] ? $_REQUEST['flash_player_url'] : false);
	$embed_str = (isset($_REQUEST['embed_str']) && $_REQUEST['embed_str'] ? $_REQUEST['embed_str'] : false);
		
	if($submit)
	{
		// SET KEY VARIABLES
		$file_maxsize = $user->level_info[level_playlist_maxsize];
		$file_exts = explode(",", str_replace(" ", "", strtolower($user->level_info[level_playlist_images_exts])));
		$file_types = explode(",", str_replace(" ", "", strtolower($user->level_info[level_playlist_images_mimes])));
		$file_maxwidth = 130;
		$file_maxheight = 97;
		$thumbnail = new se_upload();
		$input_photo_name = 'photo';
		$thumbnail->new_upload($input_photo_name, $file_maxsize, $file_exts, $file_types, $file_maxwidth, $file_maxheight);
		$is_error = $thumbnail->is_error;
		
		$sExtension = strtolower( substr( $thumbnail->file_name, ( strrpos($thumbnail->file_name, '.') + 1 ) ) );
		$img = get_resampled($thumbnail->file_tempname, $sExtension, $file_maxwidth, $file_maxheight);
		
		if(!$_FILES[$input_photo_name]['name'])
		{
			$is_error = 0;
			// CHECK THAT TITLE IS NOT BLANK
			if(trim($video_title == "")) { $is_error = 5000229; }
			/*elseif(trim($description == "")) { $is_error = 5000217; }*/
			/*elseif(trim($video_id == "")) { $is_error = 5000217; }*/
			/*elseif(trim($category == "")) { $is_error = 5000217; }*/
			/*elseif(trim($tags == "")) { $is_error = 5000217; }*/
			/*elseif(trim($watch_page_url == "")) { $is_error = 5000217; }*/
			/*elseif(trim($flash_player_url == "")) { $is_error = 5000217; }*/
			elseif(trim($embed_str == "")) { $is_error = 5000230; }
		}
		
		// IF NO ERROR, CONTINUE
		if($is_error == 0)
		{
	
		    // IMPORT VIDEO IN DATABASE
		    $database->database_query("
				INSERT INTO se_videos SET
					video_user_id = '".$user->user_info['user_id']."',
					video_playlist_id = '".$playlist_id."',
					video_title = '".$video_title."',
					video_video_id = '".$video_id."',
					video_updated = NOW(),
					video_description = '".$description."',
					video_category = '".$category."',
					video_tags = '".$tags."',
					video_watch_page_url = '".$watch_page_url."',
					video_flash_player_url = '".$flash_player_url."',
					video_duration = '".$duration."',
					video_embed_str = '".$embed_str."',
					video_thumbnail_url = '',
					video_thumbnail_width = '".$file_maxwidth."',
					video_thumbnail_height = '".$file_maxheight."',
					video_thumbnail_image = '".mysql_escape_string($img)."',
					video_thumbnail_extension = '".$sExtension."'");
		    $result = 1;
		    
		    // GET playlist ID
			$insert_video_id = $database->database_insert_id();
		    
		    $actions->actions_add($user, "importvideo", Array($user->user_info[user_username], $user->user_displayname, $playlist_id, $insert_video_id,  $video_title), Array(), 0, FALSE, "user", $user->user_info[user_id], $playlist_privacy);
		    
		    header("Location: video.php?user=".$user->user_info[user_username]."&playlist_id=".$playlist_id);
	  		exit();
		}
	}
	
	$smarty->assign('is_other', $is_other);
	$smarty->assign('is_manual', $is_manual);
	
	$smarty->assign('video_title', $video_title);
	$smarty->assign('video_id', $video_id);
	$smarty->assign('description', $description);
	$smarty->assign('category', $category);
	$smarty->assign('tags', $tags);
	$smarty->assign('watch_page_url', $watch_page_url);
	$smarty->assign('flash_player_url', $flash_player_url);
	$smarty->assign('duration', $sDuraton);
	$smarty->assign('embed_str', $embed_str);
}
else if($video_id)
{
	if($owner->user_info[user_username] == $user->user_info[user_username])
	{	
		$sql = "
			SELECT * FROM se_videos
			WHERE se_videos.video_id = '".$video_id."'";
		$video = $database->database_query($sql);
		$video_info = $database->database_fetch_assoc($video);
		
		$smarty->assign('video_title', $video_info['video_title']);
		$smarty->assign('video_id', $video_info['video_video_id']);
		$smarty->assign('description', $video_info['video_description']);
		$smarty->assign('category', $video_info['video_category']);
		$smarty->assign('tags', $video_info['video_tags']);
		$smarty->assign('watch_page_url', $video_info['video_watch_page_url']);
		$smarty->assign('flash_player_url', $video_info['video_flash_player_url']);
		$smarty->assign('duration', floor($video_info['video_duration'] / 60) . ':' . $video_info['video_duration'] % 60);
		$smarty->assign('embed_str', $video_info['video_embed_str']);
		$smarty->assign('is_edit', true);
	}
}
else 
{
	$watch_page_url = (isset($_REQUEST['watch_page_url']) && $_REQUEST['watch_page_url'] ? $_REQUEST['watch_page_url'] : false);
	// http://www.youtube.com/watch?v=hh0nVc0NYTE
	$is_error = 0;
		
	if($submit)
	{
		if(trim($watch_page_url == "")) { $is_error = 5000217; }
		
		$watch_page_url = preg_match('/^http:\/\/.*?v=(.*)&{0,1}.*$/', $watch_page_url, $matches);
		if(isset($matches[1]) && !empty($matches[1]))
		{
			$watch_page_url = $matches[0];
			$video_id = $matches[1];
		}
		else 
		{
			$watch_page_url = '';
			$is_error = 5000233;
		}
		
		// IF NO ERROR, CONTINUE
		if($is_error == 0)
		{
			$yt = new Zend_Gdata_YouTube(); 
			// video entry to be added
			$videoEntry = $yt->getVideoEntry($video_id);
		
			if(!is_object($videoEntry))
			{
				$is_error = 5000234;
				break;
			}
				
			$video_title = $videoEntry->getVideoTitle();
			$description = $videoEntry->getVideoDescription();
			
			$duration = $videoEntry->getVideoDuration(); // in the seconds
		
			$category = $videoEntry->getVideoCategory();
			$tags = implode(", ", $videoEntry->getVideoTags());
			$watch_page_url = $videoEntry->getVideoWatchPageUrl();
			$flash_player_url = $videoEntry->getFlashPlayerUrl();
	
			$embed_str = get_embed_str($flash_player_url);
			
			$videoThumbnailUrl = '';
			$videoThumbnails = $videoEntry->getVideoThumbnails();
			foreach($videoThumbnails as $videoThumbnail)
			{
				// time: $videoThumbnail['time']
				// url: $videoThumbnail['url']
				// height: $videoThumbnail['height']
				// width: $videoThumbnail['width']
				if(isset($videoThumbnail['url']) && $videoThumbnail['url'])
				{
					$videoThumbnailUrl = $videoThumbnail['url'];
					$videoThumbnailWidth = $videoThumbnail['width'];
					$videoThumbnailHeight = $videoThumbnail['height'];
					break;
				}
			}
			
			$sExtension = strtolower( substr( $videoThumbnailUrl, ( strrpos($videoThumbnailUrl, '.') + 1 ) ) );
			
			// IMPORT VIDEO IN DATABASE
		    $database->database_query("
				INSERT INTO se_videos SET
					video_user_id = '".$user->user_info['user_id']."',
					video_playlist_id = '".$playlist_id."',
					video_title = '".mysql_escape_string($video_title)."',
					video_video_id = '".$video_id."',
					video_updated = NOW(),
					video_description = '".mysql_escape_string($description)."',
					video_category = '".mysql_escape_string($category)."',
					video_tags = '".mysql_escape_string($tags)."',
					video_watch_page_url = '".$watch_page_url."',
					video_flash_player_url = '".$flash_player_url."',
					video_duration = '".$duration."',
					video_embed_str = '".$embed_str."',
					video_thumbnail_url = '".$videoThumbnailUrl."',
					video_thumbnail_width = '".$videoThumbnailWidth."',
					video_thumbnail_height = '".$videoThumbnailHeight."',
					video_thumbnail_image = '".mysql_escape_string(file_get_contents($videoThumbnailUrl))."',
					video_thumbnail_extension = '".$sExtension."'");
		    $result = 1;
		    
		    // GET playlist ID
			$insert_video_id = $database->database_insert_id();
			
		    $actions->actions_add($user, "importvideo", Array($user->user_info[user_username], $user->user_displayname, $playlist_id, $insert_video_id,  $video_title), Array(), 0, FALSE, "user", $user->user_info[user_id], $playlist_privacy);
		    
		    header("Location: video.php?user=".$user->user_info[user_username]."&playlist_id=".$playlist_id);
	  		exit();
		}
	}
	
	$smarty->assign('is_youtube', true);
	$smarty->assign('watch_page_url', $watch_page_url);
}

$smarty->assign('playlist_info', $playlist_info);
$smarty->assign('playlist_id', $playlist_id);

$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);

include "footer.php";

?>