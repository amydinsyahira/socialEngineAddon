<?php
$page = "videos";
include "header.php";

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_playlist] == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if($owner->user_exists == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($owner->level_info[level_playlist_allow] == 0) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }


// SET PRIVACY LEVEL AND WHERE CLAUSE
$privacy_max = $owner->user_privacy_max($user);
$where = "(playlist_privacy & $privacy_max)";


// CREATE PLAYLIST OBJECT
$playlist = new se_playlist($owner->user_info[user_id]);

// GET TOTAL PLAYLISTS
$total_playlists = $playlist->playlist_total($where);

// GET PLAYLIST ARRAY
$playlist_array = $playlist->playlist_list(0, $total_playlists, "playlist_order ASC", $where);

// GET CUSTOM PLAYLIST STYLE IF ALLOWED
if($owner->level_info[level_playlist_style] != 0) {
  $playliststyle_info = $database->database_fetch_assoc($database->database_query("SELECT playliststyle_css FROM se_playliststyles WHERE playliststyle_user_id='".$owner->user_info[user_id]."' LIMIT 1"));
  $global_css = $playliststyle_info[playliststyle_css];
}

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 1000160;
$global_page_title[1] = $owner->user_displayname;
$global_page_description[0] = 1000161;
$global_page_description[1] = $owner->user_displayname;

// ASSIGN SMARTY VARIABLES AND DISPLAY PLAYLISTS PAGE
$smarty->assign('playlists', $playlist_array);
$smarty->assign('total_playlists', $total_playlists);
include "footer.php";
?>