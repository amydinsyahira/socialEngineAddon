<?php
$page = "favourite_video";
include "header.php";

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_playlist] == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if($owner->user_exists == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($owner->level_info[level_playlist_allow] == 0) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

// SET VARIABLES
$result = 0;
$is_error = 0;
$del_fav = (isset($_REQUEST['del_fav']) && $_REQUEST['del_fav'] ? $_REQUEST['del_fav'] : false);
$video_id = (isset($_REQUEST['video_id']) && $_REQUEST['video_id'] ? $_REQUEST['video_id'] : false);
if($del_fav && $video_id)
{
	if($user->user_info[user_username] == $owner->user_info[user_username])
		$database->database_query("DELETE FROM se_favourite_video WHERE favourite_video_id = '".$video_id."'");
	else 
		$is_error = 5000239;
	$result = 1;
}

// SET PRIVACY LEVEL AND WHERE CLAUSE
$fav_sort = " video_id DESC ";
$fav_where = "";

// GET TOTAL FAVOURITES
$total_favourites = total_favourites();
	
// GET FAVOURITES ARRAY
$favourites = favourites_list(0, 4, $fav_sort, $fav_where);

// GET CUSTOM PLAYLIST STYLE IF ALLOWED
if($owner->level_info[level_playlist_style] != 0)
{
  $playliststyle_info = $database->database_fetch_assoc($database->database_query("SELECT playliststyle_css FROM se_playliststyles WHERE playliststyle_user_id='".$owner->user_info[user_id]."' LIMIT 1"));
  $global_css = $playliststyle_info[playliststyle_css];
}

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 5000161;
$global_page_title[1] = $owner->user_displayname;
$global_page_description[0] = 5000161;
$global_page_description[1] = $owner->user_displayname;

// ASSIGN FAVOURITES SMARY VARIABLE
$smarty->assign('favourites', $favourites);
$smarty->assign('total_favourites', $total_favourites);
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
include "footer.php";
?>