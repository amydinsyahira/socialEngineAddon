<?

$plugin_name = "Videos Plugin";
$plugin_version = "3.017";
$plugin_type = "video";
$plugin_desc = "This plugin is to allow users to find and add videos from YouTube within SocialNetwork site and mark videos as their \"favorites\" and have these displayed on their profile while sharing them with other members.";
$plugin_icon = "video.jpg";
$plugin_menu_title = "5000003";	
$plugin_pages_main = "5000004<!>video.gif<!>admin_viewplaylists.php<~!~>";
$plugin_pages_level = "5000006<!>admin_levels_playlistsettings.php<~!~>";
$plugin_url_htaccess = "";

if($install == "video")
{
	//######### INSERT ROW INTO se_plugins
	if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0)
	{
		$database->database_query("
			INSERT INTO se_plugins (
				plugin_name,
				plugin_version,
				plugin_type,
				plugin_desc,
				plugin_icon,
				plugin_menu_title,
				plugin_pages_main,
				plugin_pages_level,
				plugin_url_htaccess
				) VALUES (
				'$plugin_name',
				'$plugin_version',
				'$plugin_type',
				'$plugin_desc',
				'$plugin_icon',
				'$plugin_menu_title',
				'$plugin_pages_main',
				'$plugin_pages_level',
				'$plugin_url_htaccess')");

	//######### UPDATE PLUGIN VERSION IN se_plugins
	}
	else
	{
		$database->database_query("
			UPDATE se_plugins SET
				plugin_name = '$plugin_name',
				plugin_version = '$plugin_version',
				plugin_desc = '$plugin_desc',
				plugin_icon = '$plugin_icon',
				plugin_menu_title = '$plugin_menu_title',
				plugin_pages_main = '$plugin_pages_main',
				plugin_pages_level = '$plugin_pages_level',
				plugin_url_htaccess = '$plugin_url_htaccess'
			WHERE plugin_type = '$plugin_type'");
	}
		
	//######### CREATE se_playlists
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_playlists'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_playlists` (
				`playlist_id` int(9) NOT NULL auto_increment,
				`playlist_user_id` int(9) NOT NULL default '0',
				`playlist_datecreated` int(14) NOT NULL default '0',
				`playlist_dateupdated` int(14) NOT NULL default '0',
				`playlist_title` varchar(50) NOT NULL default '',
				`playlist_desc` text NULL,
				`playlist_search` int(1) NOT NULL default '0',
				`playlist_privacy` int(2) NOT NULL default '0',
				`playlist_comments` int(2) NOT NULL default '0',
				`playlist_cover` int(9) NOT NULL default '0',
				`playlist_views` int(9) NOT NULL default '0',
				`playlist_order` int(1) NOT NULL default '0',
				`playlist_tag` int(2) NOT NULL default '0',
			PRIMARY KEY  (`playlist_id`),
			KEY `INDEX` (`playlist_user_id`)
			) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
		
		$database->database_query("UPDATE se_playlists SET playlist_order = playlist_id, playlist_tag = 3");
	}
	
	//######### CREATE se_video
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_video'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_video` (
				`video_id` int(9) NOT NULL auto_increment,
				`video_playlist_id` int(9) NOT NULL default '0',
				`video_date` int(14) NOT NULL default '0',
				`video_title` varchar(50) NOT NULL default '',
				`video_desc` text NULL,
				`video_ext` varchar(8) NOT NULL default '',
				`video_filesize` int(9) NOT NULL default '0',
				`video_order` int(1) NOT NULL default '0',
			PRIMARY KEY  (`video_id`),
			KEY `INDEX` (`video_playlist_id`)
			) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
		
		$database->database_query("UPDATE se_video SET video_order = video_id");
	}
	
	//######### CREATE se_videocomments
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_videocomments'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_videocomments` (
				`videocomment_id` int(9) NOT NULL auto_increment,
				`videocomment_video_id` int(9) NOT NULL default '0',
				`videocomment_authoruser_id` int(9) NOT NULL default '0',
				`videocomment_date` int(14) NOT NULL default '0',
				`videocomment_body` text NULL,
			PRIMARY KEY  (`videocomment_id`),
			KEY `INDEX` (`videocomment_video_id`,`videocomment_authoruser_id`)
			) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
	}
	
	//######### CREATE se_videoscomments
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_videoscomments'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_videoscomments` (
				`videoscomment_id` int(9) NOT NULL auto_increment,
				`videoscomment_video_id` int(9) NOT NULL default '0',
				`videoscomment_authoruser_id` int(9) NOT NULL default '0',
				`videoscomment_date` int(11) NOT NULL default '0',
				`videoscomment_body` text collate utf8_unicode_ci,
			PRIMARY KEY  (`videoscomment_id`),
			KEY `profilecomment_user_id` (`videoscomment_video_id`,`videoscomment_authoruser_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
	}
	
	//######### CREATE se_videos
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_videos'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_videos` (
				`video_id` int(11) NOT NULL auto_increment,
				`video_user_id` int(11) default NULL default '0',
				`video_playlist_id` int(11) default NULL default '0',
				`video_title` varchar(100) default NULL,
				`video_video_id` varchar(30) default NULL default '0',
				`video_updated` datetime NULL default '0000-00-00 00:00:00',
				`video_description` text,
				`video_category` varchar(100) default NULL,
				`video_tags` varchar(100) default NULL,
				`video_watch_page_url` varchar(255) default NULL,
				`video_flash_player_url` varchar(255) default NULL,
				`video_duration` int(11) default NULL,
				`video_embed_str` text,
				`video_view_count` int(11) default NULL default '0',
				`video_rating` float default NULL default '0',
				`video_thumbnail_url` varchar(255) default NULL,
				`video_thumbnail_image` blob NULL,
				`video_thumbnail_width` int(11) default NULL default '0',
				`video_thumbnail_height` int(11) default NULL default '0',
				`video_thumbnail_extension` varchar(10) NULL DEFAULT NULL,
				`video_track_num` int(11) unsigned NOT NULL default '0',
			PRIMARY KEY  (`video_id`),
			KEY `video_user_id_index` (`video_user_id`),
			KEY `video_playlist_id_index` (`video_playlist_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
	}
	
	//######### CREATE se_videos
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_favourite_video'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_favourite_video` (
				`favourite_id` int(11) NOT NULL auto_increment,
				`favourite_user_id` int(11) default '0',
				`favourite_video_id` int(11) default '0',
			PRIMARY KEY  (`favourite_id`),
			KEY `favourite_user_id_index` (`favourite_user_id`),
			KEY `favourite_video_id_index` (`favourite_video_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");
	}
	
	//######### CREATE se_videotags
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_videotags'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_videotags` (
				`videotag_id` int(9) NOT NULL auto_increment,
				`videotag_video_id` int(9) NOT NULL default '0',
				`videotag_user_id` int(9) NOT NULL default '0',
				`videotag_x` int(9) NOT NULL default '0',
				`videotag_y` int(9) NOT NULL default '0',
				`videotag_height` int(9) NOT NULL default '0',
				`videotag_width` int(9) NOT NULL default '0',
				`videotag_text` varchar(255) NOT NULL default '',
			PRIMARY KEY  (`videotag_id`),
			KEY `INDEX` (`videotag_video_id`,`videotag_user_id`)
			) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
	}
	
	//######### CREATE se_playliststyles
	if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_playliststyles'")) == 0)
	{
		$database->database_query("
			CREATE TABLE `se_playliststyles` (
				`playliststyle_id` int(9) NOT NULL auto_increment,
				`playliststyle_user_id` int(9) NOT NULL default '0',
				`playliststyle_css` text NULL,
			PRIMARY KEY  (`playliststyle_id`),
			KEY `INDEX` (`playliststyle_user_id`)
			) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
	}
	
	//######### INSERT se_urls
	if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file = 'videos'")) == 0)
	{
		$database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Playlist List URL', 'videos', 'videos.php?user=\$user', '\$user/playlists/')");
	}
	//######### INSERT se_urls
	if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file = 'favourite_video'")) == 0)
	{
		$database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Favorite Video List URL', 'favourite_video', 'favourite_video.php?user=\$user', '\$user/favourites/')");
	}
	if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file = 'video'")) == 0)
	{
		$database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Playlist URL', 'video', 'video.php?user=\$user&playlist_id=\$id1', '\$user/playlists/\$id1')");
	}
	if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file='video_file'")) == 0)
	{
		$database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Video URL', 'video_file', 'video_file.php?user=\$user&playlist_id=\$id1&video_id=\$id2', '\$user/playlists/\$id1/\$id2')");
	}
	if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file='video_view'")) == 0)
	{
		$database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Video View URL', 'video_view', 'video_view.php?user=\$user&playlist_id=\$id1&video_id=\$id2', '\$user/playlists/video/\$id1/\$id2')");
	}

	//######### INSERT se_actiontypes
	if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newplaylist'")) == 0)
	{
		$actiontype_desc = SE_Language::edit(0, 'Creating a Playlist', NULL, LANGUAGE_INDEX_ACTIONS);
		$actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> created a new playlist: <a href="video.php?user=%1$s&playlist_id=%3$s">%4$s</a>', NULL, LANGUAGE_INDEX_ACTIONS);
		$database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('newplaylist', 'playlist_action_newplaylist.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname],[id],[title]', '0')");
		$actiontypes[] = $database->database_insert_id();
	}
	if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='importvideo'")) == 0)
	{
		$actiontype_desc = SE_Language::edit(0, 'Importing a Video', NULL, LANGUAGE_INDEX_ACTIONS);
		$actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> imported a new video: <a href="video_view.php?user=%1$s&playlist_id=%3$s&video_id=%4$s">%5$s</a><div class="recentaction_div_video"><a href="video_view.php?user=%1$s&playlist_id=%3$s&video_id=%4$s"><img border="0" src="get_video_thumbnail.php?video_id=%4$s"></a></div>', NULL, LANGUAGE_INDEX_ACTIONS);
		$database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('importvideo', 'playlist_action_newplaylist.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname],[id],[title]', '0')");
		$actiontypes[] = $database->database_insert_id();
	}
	if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='addtofavorites'")) == 0)
	{
		$actiontype_desc = SE_Language::edit(0, 'Adding to favorites', NULL, LANGUAGE_INDEX_ACTIONS);
		$actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> added a new video to favorites: <a href="video_view.php?user=%1$s&playlist_id=%3$s&video_id=%4$s">%5$s</a><div class="recentaction_div_video"><a href="video_view.php?user=%1$s&playlist_id=%3$s&video_id=%4$s"><img border="0" src="get_video_thumbnail.php?video_id=%4$s"></a></div>', NULL, LANGUAGE_INDEX_ACTIONS);
		$database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('addtofavorites', 'playlist_action_newplaylist.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname],[id],[title]', '0')");
		$actiontypes[] = $database->database_insert_id();
	}
	if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newvideo'")) == 0)
	{
		$actiontype_desc = SE_Language::edit(0, 'Uploading Videos to a Playlist', NULL, LANGUAGE_INDEX_ACTIONS);
		$actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> uploaded new videos to their playlist: <a href="video.php?user=%1$s&playlist_id=%3$s">%4$s</a><div class="recentaction_div_video">[video]</div>', NULL, LANGUAGE_INDEX_ACTIONS);
		$database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('newvideo', 'playlist_action_newplaylist.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname],[id],[title]', '1')");
		$actiontypes[] = $database->database_insert_id();
	}
	if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newplaylistphoto'")) == 0)
	{
		$actiontype_desc = SE_Language::edit(0, 'Uploading Photos to a Playlist', NULL, LANGUAGE_INDEX_ACTIONS);
		$actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> uploaded new photo to their playlist: <a href="video.php?user=%1$s&playlist_id=%3$s">%4$s</a><div class="recentaction_div_video"><a href="video.php?user=%1$s&playlist_id=%3$s"><img border="0" width="%6$s" src="%5$s"></a></div>', NULL, LANGUAGE_INDEX_ACTIONS);
		$database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('newplaylistphoto', 'playlist_action_newplaylist.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname],[id],[title]', '1')");
		$actiontypes[] = $database->database_insert_id();
	}
	if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='videocomment'")) == 0)
	{
		$actiontype_desc = SE_Language::edit(0, 'Posting a Video Comment', NULL, LANGUAGE_INDEX_ACTIONS);
		$actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> posted a comment on <a href="profile.php?user=%3$s">%4$s</a>\'s <a href="video_file.php?user=%3$s&video_id=%6$s">video</a>:<div class="recentaction_div">%5$s</div>', NULL, LANGUAGE_INDEX_ACTIONS);
		$database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('videocomment', 'action_postcomment.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username1],[displayname1],[username2],[displayname2],[comment],[videoid]', '0')");
		$actiontypes[] = $database->database_insert_id();
	}
	if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newtagvideo'")) == 0)
	{
		$actiontype_desc = SE_Language::edit(0, 'Getting Tagged in a Video', NULL, LANGUAGE_INDEX_ACTIONS);
		$actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> was tagged in these videos:<div class="recentaction_div_video">[video]</div>', NULL, LANGUAGE_INDEX_ACTIONS);
		$database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('newtagvideo', 'playlist_action_newtag.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname]', '1')");
		$actiontypes[] = $database->database_insert_id();
	}
	if(count($actiontypes) != 0)
	{
		$database->database_query("UPDATE se_usersettings SET usersetting_actions_display = CONCAT(usersetting_actions_display, ',', '".implode(",", $actiontypes)."')");
	}
	
	//######### INSERT se_notifytypes
	if($database->database_num_rows($database->database_query("SELECT notifytype_id FROM se_notifytypes WHERE notifytype_name='videocomment'")) == 0)
	{
		$notifytype_desc = SE_Language::edit(0, '%1$d New Video Comment(s): %2$s', NULL, LANGUAGE_INDEX_NOTIFY);
		$notifytype_title = SE_Language::edit(0, 'When I receive a new video comment.', NULL, LANGUAGE_INDEX_NOTIFY);
		$database->database_query("INSERT INTO se_notifytypes (notifytype_name, notifytype_title, notifytype_icon, notifytype_url, notifytype_desc) VALUES ('videocomment', '$notifytype_title', 'action_postcomment.gif', 'video_file.php?user=%1\$s&video_id=%2\$s', '$notifytype_desc')");
	}
	if($database->database_num_rows($database->database_query("SELECT notifytype_id FROM se_notifytypes WHERE notifytype_name='newtagvideo'")) == 0)
	{
		$notifytype_desc = SE_Language::edit(0, '%1$d New Video(s) Tagged of You: %2$s', NULL, LANGUAGE_INDEX_NOTIFY);
		$notifytype_title = SE_Language::edit(0, 'When I am tagged in a video.', NULL, LANGUAGE_INDEX_NOTIFY);
		$database->database_query("INSERT INTO se_notifytypes (notifytype_name, notifytype_title, notifytype_icon, notifytype_url, notifytype_desc) VALUES ('newtagvideo', '$notifytype_title', 'playlist_action_newtag.gif', 'video_file.php?user=%1\$s&playlist_id=0&video_id=%2\$s', '$notifytype_desc')");
	}
	if($database->database_num_rows($database->database_query("SELECT notifytype_id FROM se_notifytypes WHERE notifytype_name='videotag'")) == 0)
	{
		$notifytype_desc = SE_Language::edit(0, '%1$d New Tag(s) on Your Video: %2$s', NULL, LANGUAGE_INDEX_NOTIFY);
		$notifytype_title = SE_Language::edit(0, 'When someone tags a video I own.', NULL, LANGUAGE_INDEX_NOTIFY);
		$database->database_query("INSERT INTO se_notifytypes (notifytype_name, notifytype_title, notifytype_icon, notifytype_url, notifytype_desc) VALUES ('videotag', '$notifytype_title', 'playlist_action_newtag.gif', 'video_file.php?user=%1\$s&video_id=%2\$s', '$notifytype_desc')");
	}
	
	//######### ADD COLUMNS/VALUES TO LEVELS TABLE IF PLAYLIST HAS NEVER BEEN INSTALLED
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_playlist_allow'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_levels 
			ADD COLUMN `level_playlist_allow` int(1) NOT NULL default '1',
			ADD COLUMN `level_playlist_maxnum` int(3) NOT NULL default '10',
			ADD COLUMN `level_playlist_exts` text NOT NULL,
			ADD COLUMN `level_playlist_mimes` text NOT NULL,
			ADD COLUMN `level_playlist_storage` bigint(11) NOT NULL default '5242880',
			ADD COLUMN `level_playlist_maxsize` bigint(11) NOT NULL default '2048000',
			ADD COLUMN `level_playlist_width` varchar(4) NOT NULL default '500',
			ADD COLUMN `level_playlist_height` varchar(4) NOT NULL default '500',
			ADD COLUMN `level_playlist_style` int(1) NOT NULL default '1',
			ADD COLUMN `level_playlist_search` int(1) NOT NULL default '1',
			ADD COLUMN `level_playlist_privacy` varchar(100) NOT NULL default 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"3\";i:2;s:1:\"7\";i:3;s:2:\"15\";i:4;s:2:\"31\";i:5;s:2:\"63\";}',
			ADD COLUMN `level_playlist_comments` varchar(100) NOT NULL default 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
		
		$database->database_query("UPDATE se_levels SET level_playlist_exts='mpeg,mpg,mpa,avi,mov,swf', level_playlist_mimes='audio/mpeg,video/mpeg,video/x-msvideo,video/avi,video/quicktime'");
	}
	else
	{
		$database->database_query("UPDATE se_levels SET level_playlist_storage = '5242880'");
		$database->database_query("UPDATE se_levels SET level_playlist_maxsize = '2048000'");
		$database->database_query("UPDATE se_levels SET level_playlist_exts='mpeg,mpg,mpa,avi,mov,swf'");
		
		$columns = mysql_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_playlist_privacy'");
		while($column_info = mysql_fetch_assoc($columns))
		{
			$field_name = $column_info['Field'];
			$field_type = $column_info['Type'];
			$field_default = $column_info['Default'];
			if($field_type == "varchar(10)")
			{
				mysql_query("ALTER TABLE se_levels CHANGE level_playlist_privacy level_playlist_privacy varchar(100) NOT NULL default ''");
				mysql_query("UPDATE se_levels SET level_playlist_privacy='a:6:{i:0;s:1:\"1\";i:1;s:1:\"3\";i:2;s:1:\"7\";i:3;s:2:\"15\";i:4;s:2:\"31\";i:5;s:2:\"63\";}'");
				mysql_query("UPDATE se_playlists SET playlist_privacy = '63' WHERE playlist_privacy = '0'");
				mysql_query("UPDATE se_playlists SET playlist_privacy = '31' WHERE playlist_privacy = '1'");
				mysql_query("UPDATE se_playlists SET playlist_privacy = '15' WHERE playlist_privacy = '2'");
				mysql_query("UPDATE se_playlists SET playlist_privacy = '7' WHERE playlist_privacy = '3'");
				mysql_query("UPDATE se_playlists SET playlist_privacy = '3' WHERE playlist_privacy = '4'");
				mysql_query("UPDATE se_playlists SET playlist_privacy = '1' WHERE playlist_privacy = '5'");
			}
		}
		$columns = mysql_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_playlist_comments'");
		while($column_info = mysql_fetch_assoc($columns))
		{
			$field_name = $column_info['Field'];
			$field_type = $column_info['Type'];
			$field_default = $column_info['Default'];
			if($field_type == "varchar(10)")
			{
				mysql_query("ALTER TABLE se_levels CHANGE level_playlist_comments level_playlist_comments varchar(100) NOT NULL default ''");
				mysql_query("UPDATE se_levels SET level_playlist_comments='a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
				mysql_query("UPDATE se_playlists SET playlist_comments='63' WHERE playlist_comments='0'");
				mysql_query("UPDATE se_playlists SET playlist_comments='31' WHERE playlist_comments='1'");
				mysql_query("UPDATE se_playlists SET playlist_comments='15' WHERE playlist_comments='2'");
				mysql_query("UPDATE se_playlists SET playlist_comments='7' WHERE playlist_comments='3'");
				mysql_query("UPDATE se_playlists SET playlist_comments='3' WHERE playlist_comments='4'");
				mysql_query("UPDATE se_playlists SET playlist_comments='1' WHERE playlist_comments='5'");
			}
		}
	}
	
	//######### ADD COLUMNS/VALUES TO LEVELS TABLE IF PLAYLIST HAS NEVER BEEN INSTALLED
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_playlist_images_exts'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_levels 
			ADD COLUMN `level_playlist_images_exts` text NOT NULL,
			ADD COLUMN `level_playlist_images_mimes` text NOT NULL");
		
		$database->database_query("UPDATE se_levels SET level_playlist_images_exts = 'jpg,gif,jpeg,png,bmp', level_playlist_images_mimes = 'image/jpeg,image/pjpeg,image/jpg,image/jpe,image/pjpg,image/x-jpeg,image/x-jpg,image/gif,image/x-gif,image/png,image/x-png,image/bmp'");
	}
	else 
	{
		$database->database_query("UPDATE se_levels SET level_playlist_images_exts = 'jpg,gif,jpeg,png,bmp'");
		$database->database_query("UPDATE se_levels SET level_playlist_images_mimes = 'image/jpeg,image/pjpeg,image/jpg,image/jpe,image/pjpg,image/x-jpeg,image/x-jpg,image/gif,image/x-gif,image/png,image/x-png,image/bmp'");
	}
	
	//######### ADD COLUMNS/VALUES TO LEVELS TABLE IF PLAYLIST HAS NEVER BEEN INSTALLED
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_playlist_images_storage'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_levels 
			ADD COLUMN `level_playlist_images_storage` bigint(11) NOT NULL default '5242880',
			ADD COLUMN `level_playlist_images_maxsize` bigint(11) NOT NULL default '2048000'");
	}
	else 
	{
		$database->database_query("UPDATE se_levels SET level_playlist_images_storage = '5242880'");
		$database->database_query("UPDATE se_levels SET level_playlist_images_maxsize = '2048000'");
	}
	
	//######### ADD COLUMNS/VALUES TO LEVELS TABLE
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_playlist_profile'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_levels 
			ADD COLUMN `level_playlist_profile` SET('side', 'tab'),
			ADD COLUMN `level_playlist_tag` varchar(100) NOT NULL default 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
		$database->database_query("UPDATE se_levels SET level_playlist_profile = 'tab', level_playlist_tag = 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
	}

	//######### ADD COLUMNS/VALUES TO SETTINGS TABLE
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_permission_playlist'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_settings 
			ADD COLUMN `setting_permission_playlist` int(1) NOT NULL default '1'");
	}
	
	//######### ADD COLUMNS/VALUES TO SYSTEM EMAILS TABLE
	if($database->database_num_rows($database->database_query("SELECT systememail_id FROM se_systememails WHERE systememail_name='videocomment'")) == 0)
	{
		$systememail_subject = SE_Language::edit(0, 'New Video Comment', NULL, LANGUAGE_INDEX_EMAILS);
		$systememail_body = SE_Language::edit(0, 'Hello %1$s,\n\nA new comment has been posted on one of your videos by %2$s. Please click the following link to view it:\n\n%3$s\n\nBest Regards,\nSocial Network Administration', NULL, LANGUAGE_INDEX_EMAILS);
		$database->database_query("INSERT INTO se_systememails (systememail_name, systememail_title, systememail_desc, systememail_subject, systememail_body, systememail_vars) VALUES ('videocomment', '5000001', '5000002', '$systememail_subject', '$systememail_body', '[displayname],[commenter],[link]')");
	}
	if($database->database_num_rows($database->database_query("SELECT systememail_id FROM se_systememails WHERE systememail_name = 'newtagvideo'")) == 0)
	{
		$systememail_subject = SE_Language::edit(0, 'You have Been Tagged in a Video!', NULL, LANGUAGE_INDEX_EMAILS);
		$systememail_body = SE_Language::edit(0, 'Hello %1$s,\n\nYou have been tagged in a video. Please click the following link to view it:\n\n%2$s\n\nBest Regards,\nSocial Network Administration', NULL, LANGUAGE_INDEX_EMAILS);
		$database->database_query("INSERT INTO se_systememails (systememail_name, systememail_title, systememail_desc, systememail_subject, systememail_body, systememail_vars) VALUES ('newtagvideo', '5000151', '5000152', '$systememail_subject', '$systememail_body', '[displayname],[link]')");
	}
	if($database->database_num_rows($database->database_query("SELECT systememail_id FROM se_systememails WHERE systememail_name='videotag'")) == 0)
	{
		$systememail_subject = SE_Language::edit(0, 'New Photo Tag', NULL, LANGUAGE_INDEX_EMAILS);
		$systememail_body = SE_Language::edit(0, 'Hello %1$s,\n\nA new tag has been posted on one of your videos by %2$s. Please click the following link to view it:\n\n%3$s\n\nBest Regards,\nSocial Network Administration', NULL, LANGUAGE_INDEX_EMAILS);
		$database->database_query("INSERT INTO se_systememails (systememail_name, systememail_title, systememail_desc, systememail_subject, systememail_body, systememail_vars) VALUES ('videotag', '5000153', '5000154', '$systememail_subject', '$systememail_body', '[displayname],[tagger],[link]')");
	}
	
	//######### ADD COLUMNS/VALUES TO USER SETTINGS TABLE
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_usersettings` LIKE 'usersetting_notify_videocomment'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_usersettings 
			ADD COLUMN `usersetting_notify_videocomment` int(1) NOT NULL default '1'");
	}
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_usersettings` LIKE 'usersetting_notify_newtagvideo'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_usersettings 
			ADD COLUMN `usersetting_notify_newtagvideo` int(1) NOT NULL default '1',
			ADD COLUMN `usersetting_notify_videotag` int(1) NOT NULL default '1'");
	}

	//######### ADD COLUMNS/VALUES TO USER TABLE
	if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_users` LIKE 'user_profile_playlist'")) == 0)
	{
		$database->database_query("
			ALTER TABLE se_users 
			ADD COLUMN `user_profile_playlist` ENUM('tab', 'side') NOT NULL default 'tab'");
	}
	
	//######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS NOT BEEN INSTALLED)
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000000 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000000, 1, 'Videos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Videos', `languagevar_default` = ''
			WHERE languagevar_id = '5000000'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000001 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000001, 1, 'New Video Comment Email', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'New Video Comment Email', `languagevar_default` = ''
			WHERE languagevar_id = '5000001'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000002 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000002, 1, 'This is the email that gets sent to a user when a new comment is posted on one of their videos.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'This is the email that gets sent to a user when a new comment is posted on one of their videos.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000002'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000003 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000003, 1, 'Videos Plugin Settings', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Videos Plugin Settings', `languagevar_default` = ''
			WHERE languagevar_id = '5000003'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000004 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000004, 1, 'View Video Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'View Video Playlists', `languagevar_default` = ''
			WHERE languagevar_id = '5000004'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000005 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000005, 1, 'Global Videos Settings', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Global Videos Settings', `languagevar_default` = ''
			WHERE languagevar_id = '5000005'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000006 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000006, 1, 'Videos Settings', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Videos Settings', `languagevar_default` = ''
			WHERE languagevar_id = '5000006'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000007 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000007, 1, 'videos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'videos', `languagevar_default` = ''
			WHERE languagevar_id = '5000007'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000008 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000008, 1, 'This page contains general Videos Settings that affect your entire social network.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'This page contains general Videos Settings that affect your entire social network.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000008'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000009 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000009, 1, 'Select whether or not you want to let the public (visitors that are not logged-in) to view the following sections of your social network. In some cases (such as Profiles, Blogs, and playlists), if you have given them the option, your users will be able to make their pages private even though you have made them publically viewable here. For more permissions settings, please visit the <a href=\'admin_general.php\'>General Settings</a> page.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Select whether or not you want to let the public (visitors that are not logged-in) to view the following sections of your social network. In some cases (such as Profiles, Blogs, and playlists), if you have given them the option, your users will be able to make their pages private even though you have made them publically viewable here. For more permissions settings, please visit the <a href=\'admin_general.php\'>General Settings</a> page.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000009'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000010 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000010, 1, 'Yes, the public can view playlists unless they are made private.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Yes, the public can view playlists unless they are made private.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000010'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000011 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000011, 1, 'No, the public cannot view playlists.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'No, the public cannot view playlists.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000011'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000012 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000012, 1, 'Your maximum filesize field must contain an integer between 1 and 204800.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your maximum filesize field must contain an integer between 1 and 204800.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000012'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000013 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000013, 1, 'Your maximum width and height fields must contain integers between 1 and 9999.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your maximum width and height fields must contain integers between 1 and 9999.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000013'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000014 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000014, 1, 'Your maximum allowed playlists field must contain an integer between 1 and 999.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your maximum allowed playlists field must contain an integer between 1 and 999.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000014'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000015 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000015, 1, 'If you have allowed users to have file playlists, you can adjust their details from this page.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'If you have allowed users to have file playlists, you can adjust their details from this page.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000015'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000016 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000016, 1, 'Allow Playlists?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Allow Playlists?' , `languagevar_default` = ''
			WHERE languagevar_id = '5000016'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000017 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000017, 1, 'Do you want to let users have playlists? If set to no, all other settings on this page will not apply.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Do you want to let users have playlists? If set to no, all other settings on this page will not apply.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000017'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000018 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000018, 1, 'Yes, allow playlists.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Yes, allow playlists.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000018'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000019 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000019, 1, 'No, do not allow playlists.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'No, do not allow playlists.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000019'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000020 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000020, 1, 'Playlist Privacy Options', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Playlist Privacy Options' , `languagevar_default` = ''
			WHERE languagevar_id = '5000020'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000021 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000021, 1, 'If you enable this feature, users will be able to exclude their playlists from search results. Otherwise, all playlists will be included in search results.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'If you enable this feature, users will be able to exclude their playlists from search results. Otherwise, all playlists will be included in search results.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000021'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000022 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000022, 1, 'Yes, allow users to exclude their playlists from search results.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Yes, allow users to exclude their playlists from search results.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000022'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000023 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000023, 1, 'No, force all playlists to be included in search results.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'No, force all playlists to be included in search results.' , `languagevar_default` = ''
			WHERE languagevar_id = '5000023'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000024 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000024, 1, 'playlist Privacy Options', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'playlist Privacy Options' , `languagevar_default` = ''
			WHERE languagevar_id = '5000024'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000025 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000025, 1, 'Your users can choose from any of the options checked below when they decide who can see their playlists. If you do not check any options, everyone will be allowed to view playlists.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your users can choose from any of the options checked below when they decide who can see their playlists. If you do not check any options, everyone will be allowed to view playlists.', `languagevar_default` = ''
			WHERE languagevar_id = '5000025'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000026 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000026, 1, 'Video Comment Options', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video Comment Options', `languagevar_default` = ''
			WHERE languagevar_id = '5000026'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000027 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000027, 1, 'Your users can choose from any of the options checked below when they decide who can post comments on their video. If you do not check any options, everyone will be allowed to post comments on video.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your users can choose from any of the options checked below when they decide who can post comments on their video. If you do not check any options, everyone will be allowed to post comments on video.', `languagevar_default` = ''
			WHERE languagevar_id = '5000027'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000028 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000028, 1, 'Maximum Allowed playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Maximum Allowed playlists', `languagevar_default` = ''
			WHERE languagevar_id = '5000028'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000029 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000029, 1, 'Enter the maximum number of allowed playlists. The field must contain an integer between 1 and 999.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Enter the maximum number of allowed playlists. The field must contain an integer between 1 and 999.', `languagevar_default` = ''
			WHERE languagevar_id = '5000029'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000030 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000030, 1, 'allowed playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'allowed playlists', `languagevar_default` = ''
			WHERE languagevar_id = '5000030'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000031 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000031, 1, 'Allowed File Types', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Allowed File Types', `languagevar_default` = ''
			WHERE languagevar_id = '5000031'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000032 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000032, 1, 'List the following file extensions that users are allowed to upload. Separate file extensions with commas, for example: jpg, gif, jpeg, png, bmp', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'List the following file extensions that users are allowed to upload. Separate file extensions with commas, for example: jpg, gif, jpeg, png, bmp', `languagevar_default` = ''
			WHERE languagevar_id = '5000032'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000033 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000033, 1, 'Allowed MIME Types', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Allowed MIME Types', `languagevar_default` = ''
			WHERE languagevar_id = '5000033'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000034 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000034, 1, 'To successfully upload a file, the file must have an allowed filetype extension as well as an allowed MIME type. This prevents users from disguising malicious files with a fake extension. Separate MIME types with commas, for example: image/jpeg, image/gif, image/png, image/bmp', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'To successfully upload a file, the file must have an allowed filetype extension as well as an allowed MIME type. This prevents users from disguising malicious files with a fake extension. Separate MIME types with commas, for example: image/jpeg, image/gif, image/png, image/bmp'
			WHERE languagevar_id = '5000034'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000035 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000035, 1, 'Allowed Storage Space', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Allowed Storage Space'
			WHERE languagevar_id = '5000035'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000036 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000036, 1, 'How much storage space should each user have to store their files?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'How much storage space should each user have to store their files?'
			WHERE languagevar_id = '5000036'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000037 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000037, 1, 'unlimited', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'unlimited'
			WHERE languagevar_id = '5000037'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000038 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000038, 1, 'Maximum Filesize', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Maximum Filesize'
			WHERE languagevar_id = '5000038'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000039 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000039, 1, 'Enter the maximum filesize for uploaded files in KB. This must be a number between 1 and 204800.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Enter the maximum filesize for uploaded files in KB. This must be a number between 1 and 204800.'
			WHERE languagevar_id = '5000039'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000040 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000040, 1, 'Enter the maximum width and height (in pixels) for images uploaded to playlists. Images with dimensions outside this range will be sized down accordingly if your server has the GD Libraries installed. Note that unusual image types like TIFF, RAW, and others may not be resized.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Enter the maximum width and height (in pixels) for images uploaded to playlists. Images with dimensions outside this range will be sized down accordingly if your server has the GD Libraries installed. Note that unusual image types like TIFF, RAW, and others may not be resized.'
			WHERE languagevar_id = '5000040'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000041 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000041, 1, 'Allow Custom CSS Styles?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Allow Custom CSS Styles?'
			WHERE languagevar_id = '5000041'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000042 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000042, 1, 'If you enable this feature, your users will be able to customize the colors and fonts of their playlists by altering their CSS styles.', '')");
	}
	else 
	{
			$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'If you enable this feature, your users will be able to customize the colors and fonts of their playlists by altering their CSS styles.'
			WHERE languagevar_id = '5000042'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000043 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000043, 1, 'Yes, enable custom CSS styles.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Yes, enable custom CSS styles.'
			WHERE languagevar_id = '5000043'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000044 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000044, 1, 'No, disable custom CSS styles.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'No, disable custom CSS styles.'
			WHERE languagevar_id = '5000044'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000045 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000045, 1, 'This page lists all of the file playlists that users have created on your social network. Depending on the settings you have specified in this control panel, users can create playlists and use them to upload, organize, and share videos, music, videos, and other files. You can use this page to monitor these playlists and delete offensive material if necessary. Entering criteria into the filter fields will help you find specific playlists. Leaving the filter fields blank will show all the playlists on your social network.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'This page lists all of the file playlists that users have created on your social network. Depending on the settings you have specified in this control panel, users can create playlists and use them to upload, organize, and share videos, music, videos, and other files. You can use this page to monitor these playlists and delete offensive material if necessary. Entering criteria into the filter fields will help you find specific playlists. Leaving the filter fields blank will show all the playlists on your social network.'
			WHERE languagevar_id = '5000045'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000046 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000046, 1, 'Title', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Title'
			WHERE languagevar_id = '5000046'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000047 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000047, 1, 'Owner', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Owner'
			WHERE languagevar_id = '5000047'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000048 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000048, 1, 'No playlists were found.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'No playlists were found.'
			WHERE languagevar_id = '5000048'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000049 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000049, 1, '%1\$d playlists Found', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$d playlists Found'
			WHERE languagevar_id = '5000049'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000050 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000050, 1, 'Files', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Files'
			WHERE languagevar_id = '5000050'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000051 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000051, 1, 'Space Used', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Space Used'
			WHERE languagevar_id = '5000051'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000052 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000052, 1, 'view', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'view'
			WHERE languagevar_id = '5000052'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000053 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000053, 1, 'Are you sure you want to delete this playlist? Warning: All images and videos within this playlist will also be deleted.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Are you sure you want to delete this playlist? Warning: All images and videos within this playlist will also be deleted.'
			WHERE languagevar_id = '5000053'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000054 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000054, 1, 'Delete playlist?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Delete playlist?'
			WHERE languagevar_id = '5000054'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000055 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000055, 1, 'My Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'My Playlists'
			WHERE languagevar_id = '5000055'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000056 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000056, 1, 'Videos Settings', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Videos Settings'
			WHERE languagevar_id = '5000056'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000057 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000057, 1, 'You have %1\$d playlists and %2\$d photos.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You have %1\$d playlists and %2\$d photos.'
			WHERE languagevar_id = '5000057'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000058 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000058, 1, 'You have %1\$s MB of free space remaining.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You have %1\$s MB of free space remaining.'
			WHERE languagevar_id = '5000058'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000059 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000059, 1, 'Create New Playlist', '')");
	}
	else 
	{$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Create New Playlist'
			WHERE languagevar_id = '5000059'");
		
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000060 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000060, 1, 'My Playlists Link:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'My Playlists Link:'
			WHERE languagevar_id = '5000060'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000061 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000061, 1, 'Created:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Created:'
			WHERE languagevar_id = '5000061'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000062 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000062, 1, 'Last Update:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Last Update:'
			WHERE languagevar_id = '5000062'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000063 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000063, 1, 'Files:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Files:'
			WHERE languagevar_id = '5000063'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000064 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000064, 1, '%1\$s photos (%2\$s MB)', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s photos (%2\$s MB)'
			WHERE languagevar_id = '5000064'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000065 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000065, 1, 'Views:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Views:'
			WHERE languagevar_id = '5000065'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000066 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000066, 1, '%1\$d views', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$d views'
			WHERE languagevar_id = '5000066'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000067 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000067, 1, 'Viewable By:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Viewable By:'
			WHERE languagevar_id = '5000067'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000068 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000068, 1, 'View playlist', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'View playlist'
			WHERE languagevar_id = '5000068'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000069 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000069, 1, 'Edit playlist', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Edit playlist'
			WHERE languagevar_id = '5000069'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000070 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000070, 1, 'Delete playlist', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Delete playlist'
			WHERE languagevar_id = '5000070'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000071 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000071, 1, 'You do not have any playlists.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You do not have any playlists.'
			WHERE languagevar_id = '5000071'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000072 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000072, 1, 'Create a playlist to begin uploading files.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Create a playlist to begin uploading files.'
			WHERE languagevar_id = '5000072'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000073 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000073, 1, 'Please enter a name for this playlist.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Please enter a name for this playlist.'
			WHERE languagevar_id = '5000073'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000074 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000074, 1, 'Please give us some information about your new playlist.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Please give us some information about your new playlist.'
			WHERE languagevar_id = '5000074'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000075 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000075, 1, 'You have reached the maximum number of allowed playlists (%1\$d). You must delete some of your old playlists before you can create a new one.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You have reached the maximum number of allowed playlists (%1\$d). You must delete some of your old playlists before you can create a new one.'
			WHERE languagevar_id = '5000075'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000076 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000076, 1, 'Return to My Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Return to My Playlists'
			WHERE languagevar_id = '5000076'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000077 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000077, 1, 'Playlist Name:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Playlist Name:'
			WHERE languagevar_id = '5000077'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000078 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000078, 1, 'Playlist Description:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Playlist Description:'
			WHERE languagevar_id = '5000078'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000079 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000079, 1, 'Include this playlist in search/browse results?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Include this playlist in search/browse results?'
			WHERE languagevar_id = '5000079'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000080 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000080, 1, 'Yes, include this playlist in search/browse results.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Yes, include this playlist in search/browse results.'
			WHERE languagevar_id = '5000080'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000081 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000081, 1, 'No, exclude this playlist from search/browse results.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'No, exclude this playlist from search/browse results.'
			WHERE languagevar_id = '5000081'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000082 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000082, 1, 'Who can see this playlist?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Who can see this playlist?'
			WHERE languagevar_id = '5000082'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000083 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000083, 1, 'Who can comment in this playlist?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Who can comment in this playlist?'
			WHERE languagevar_id = '5000083'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000084 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000084, 1, 'Create playlist', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Create playlist'
			WHERE languagevar_id = '5000084'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000085 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000085, 1, 'You do not have enough free space to upload %1\$s.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You do not have enough free space to upload %1\$s.'
			WHERE languagevar_id = '5000085'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000086 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000086, 1, '%1\$s was uploaded successfully.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s was uploaded successfully.'
			WHERE languagevar_id = '5000086'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000087 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000087, 1, 'Upload videos:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Upload videos:'
			WHERE languagevar_id = '5000087'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000088 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000088, 1, 'To upload videos from your computer, click the \"Browse\" button, locate them on your computer, then click the \"Upload\" button.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'To upload videos from your computer, click the \"Browse\" button, locate them on your computer, then click the \"Upload\" button.'
			WHERE languagevar_id = '5000088'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000089 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000089, 1, 'Back to playlist', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Back to playlist'
			WHERE languagevar_id = '5000089'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000090 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000090, 1, 'You may upload files of the following types: %1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You may upload files of the following types: %1\$s'
			WHERE languagevar_id = '5000090'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000091 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000091, 1, 'You may upload files with sizes up to %1\$s KB.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You may upload files with sizes up to %1\$s KB.'
			WHERE languagevar_id = '5000091'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000092 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000092, 1, 'Your playlist has been created. You can begin uploading videos below.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your playlist has been created. You can begin uploading videos below.'
			WHERE languagevar_id = '5000092'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000093 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000093, 1, 'Edit Playlist Details', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Edit Playlist Details'
			WHERE languagevar_id = '5000093'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000094 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000094, 1, 'Use this page to change the playlist name, description, or privacy level.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Use this page to change the playlist name, description, or privacy level.'
			WHERE languagevar_id = '5000094'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000095 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000095, 1, 'Edit Thumbnails for Playlist:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Edit Thumbnails for Playlist:'
			WHERE languagevar_id = '5000095'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000096 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000096, 1, 'All photos inside this playlist are listed below.<br>This playlist contains <b>%1\$s photos</b> and has been viewed <b>%2\$s times</b>.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'All photos inside this playlist are listed below.<br>This playlist contains <b>%1\$s photos</b> and has been viewed <b>%2\$s times</b>.'
			WHERE languagevar_id = '5000096'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000097 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000097, 1, 'Back to Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Back to Playlists'
			WHERE languagevar_id = '5000097'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000098 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000098, 1, 'Add New Photos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Add New Photos'
			WHERE languagevar_id = '5000098'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000099 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000099, 1, 'Edit Playlist Info', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Edit Playlist Info'
			WHERE languagevar_id = '5000099'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000100 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000100, 1, 'There are no files in this playlist.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'There are no files in this playlist.'
			WHERE languagevar_id = '5000100'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000101 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000101, 1, 'Click here to begin adding files.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Click here to begin adding files.'
			WHERE languagevar_id = '5000101'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000102 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000102, 1, 'Caption', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Caption'
			WHERE languagevar_id = '5000102'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000103 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000103, 1, 'Delete Photo', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Delete Photo'
			WHERE languagevar_id = '5000103'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000104 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000104, 1, 'Playlist Cover', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Playlist Cover'
			WHERE languagevar_id = '5000104'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000105 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000105, 1, 'Move To:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Move To:'
			WHERE languagevar_id = '5000105'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000106 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000106, 1, 'Profile Position', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Profile Position'
			WHERE languagevar_id = '5000106'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000107 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000107, 1, 'Your users can choose from any of the options checked below when they decide where they want their playlists to appear on their profile. ', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your users can choose from any of the options checked below when they decide where they want their playlists to appear on their profile. '
			WHERE languagevar_id = '5000107'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000108 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000108, 1, 'Display playlists in Tab', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Display playlists in Tab'
			WHERE languagevar_id = '5000108'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000109 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000109, 1, 'Display playlists in Side Gutter', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Display playlists in Side Gutter'
			WHERE languagevar_id = '5000109'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000110 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000110, 1, 'Where do you want your playlists to display on your profile?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Where do you want your playlists to display on your profile?'
			WHERE languagevar_id = '5000110'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000111 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000111, 1, 'Edit Videos Settings such as your playlist\'s style.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Edit Videos Settings such as your playlist\'s style.'
			WHERE languagevar_id = '5000111'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000112 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000112, 1, 'My Playlists\' Style', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'My Playlists\' Style'
			WHERE languagevar_id = '5000112'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000113 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000113, 1, 'You can change the colors, fonts, and styles of your playlists by adding CSS code below. The contents of the text area below will be output between &lt;style&gt; tags on your playlist.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You can change the colors, fonts, and styles of your playlists by adding CSS code below. The contents of the text area below will be output between &lt;style&gt; tags on your playlist.'
			WHERE languagevar_id = '5000113'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000114 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000114, 1, 'Move Up', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Move Up'
			WHERE languagevar_id = '5000114'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000115 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000115, 1, 'Rotate Left', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Rotate Left'
			WHERE languagevar_id = '5000115'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000116 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000116, 1, 'Rotate Right', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Rotate Right'
			WHERE languagevar_id = '5000116'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000118 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000118, 1, '%1\$d playlists/videos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$d playlists/videos'
			WHERE languagevar_id = '5000118'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000119 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000119, 1, 'Video: %1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video: %1\$s'
			WHERE languagevar_id = '5000119'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000120 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000120, 1, 'playlist: %1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'playlist: %1\$s'
			WHERE languagevar_id = '5000120'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000121 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000121, 1, 'Video posted by <a href=\'%1\$s\'>%2\$s</a><br>%3\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video posted by <a href=\'%1\$s\'>%2\$s</a><br>%3\$s'
			WHERE languagevar_id = '5000121'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000122 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000122, 1, 'playlist created by <a href=\'%1\$s\'>%2\$s</a><br>%3\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'playlist created by <a href=\'%1\$s\'>%2\$s</a><br>%3\$s'
			WHERE languagevar_id = '5000122'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000123 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000123, 1, 'playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'playlists'
			WHERE languagevar_id = '5000123'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000124 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000124, 1, 'updated %1\$s by <a href=\'%2\$s\'>%3\$s</a>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'updated %1\$s by <a href=\'%2\$s\'>%3\$s</a>'
			WHERE languagevar_id = '5000124'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000125 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000125, 1, 'You do not have permission to view this file.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'You do not have permission to view this file.'
			WHERE languagevar_id = '5000125'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000126 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000126, 1, 'Uploaded', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Uploaded'
			WHERE languagevar_id = '5000126'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000127 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000127, 1, 'Browse Videos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Browse Videos'
			WHERE languagevar_id = '5000127'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000128 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000128, 1, 'View:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'View:'
			WHERE languagevar_id = '5000128'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000129 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
			VALUES (5000129, 1, 'Everyone\'s Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Everyone\'s Playlists'
			WHERE languagevar_id = '5000129'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000130 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000130, 1, 'My Friend\'s Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'My Friend\'s Playlists'
			WHERE languagevar_id = '5000130'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000131 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000131, 1, 'Show:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Show:'
			WHERE languagevar_id = '5000131'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000132 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000132, 1, 'Recently Updated Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Recently Updated Playlists'
			WHERE languagevar_id = '5000132'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000133 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000133, 1, 'Recently Created Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Recently Created Playlists'
			WHERE languagevar_id = '5000133'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000134 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000134, 1, 'Video Tagging Options', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video Tagging Options'
			WHERE languagevar_id = '5000134'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000135 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000135, 1, 'Your users can choose from any of the options checked below when they decide who can tag their videos. If you do not check any options, everyone will be allowed to tag videos.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Your users can choose from any of the options checked below when they decide who can tag their videos. If you do not check any options, everyone will be allowed to tag videos.'
			WHERE languagevar_id = '5000135'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000136 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000136, 1, 'Who can tag videos in this playlist?', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Who can tag videos in this playlist?'
			WHERE languagevar_id = '5000136'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000137 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000137, 1, 'videos of %1\$s (%2\$d)', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'videos of %1\$s (%2\$d)'
			WHERE languagevar_id = '5000137'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000138 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000138, 1, '<a href=\'%1\$s\'>%2\$s</a>\'s playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '<a href=\'%1\$s\'>%2\$s</a>\'s playlists'
			WHERE languagevar_id = '5000138'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000139 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000139, 1, '%1\$s does not have any playlists.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s does not have any playlists.'
			WHERE languagevar_id = '5000139'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000140 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000140, 1, 'Updated %1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Updated %1\$s'
			WHERE languagevar_id = '5000140'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000141 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000141, 1, '<a href=\'%1\$s\'>%2\$s</a>\'s <a href=\'%3\$s\'>playlists</a>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '<a href=\'%1\$s\'>%2\$s</a>\'s <a href=\'%3\$s\'>playlists</a>'
			WHERE languagevar_id = '5000141'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000142 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000142, 1, 'download audio', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'download audio'
			WHERE languagevar_id = '5000142'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000143 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000143, 1, 'download video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'download video'
			WHERE languagevar_id = '5000143'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000144 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000144, 1, 'download this file', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'download this file'
			WHERE languagevar_id = '5000144'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000145 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000145, 1, 'Viewing #%1\$d of %2\$d in <a href=\'%3\$s\'>%4\$s</a>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Viewing #%1\$d of %2\$d in <a href=\'%3\$s\'>%4\$s</a>'
			WHERE languagevar_id = '5000145'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000146 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000146, 1, 'Last', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Last'
			WHERE languagevar_id = '5000146'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000147 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000147, 1, 'Next', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Next'
			WHERE languagevar_id = '5000147'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000148 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000148, 1, 'Report Inappropriate Content', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Report Inappropriate Content'
			WHERE languagevar_id = '5000148'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000149 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000149, 1, 'videos of <a href=\'%1\$s\'>%2\$s</a>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'videos of <a href=\'%1\$s\'>%2\$s</a>'
			WHERE languagevar_id = '5000149'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000150 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000150, 1, 'Viewing #%1\$d of %2\$d <a href=\'%3\$s\'>videos of %4\$s</a> &nbsp;|&nbsp; <a href=\'%5\$s\'>Return to %4\$s\'s Profile</a>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Viewing #%1\$d of %2\$d <a href=\'%3\$s\'>videos of %4\$s</a> &nbsp;|&nbsp; <a href=\'%5\$s\'>Return to %4\$s\'s Profile</a>'
			WHERE languagevar_id = '5000150'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000151 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000151, 1, 'Notification of Being Tagged', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Notification of Being Tagged'
			WHERE languagevar_id = '5000151'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000152 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000152, 1, 'This is the email that gets sent to a user when someone tags them in a video.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'This is the email that gets sent to a user when someone tags them in a video.'
			WHERE languagevar_id = '5000152'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000153 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000153, 1, 'New Video Tag Email', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'New Video Tag Email'
			WHERE languagevar_id = '5000153'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000154 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000154, 1, 'This is the email that gets sent to a user when someone tags one of their videos.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'This is the email that gets sent to a user when someone tags one of their videos.'
			WHERE languagevar_id = '5000154'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000155 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000155, 1, '%1\$s\'s playlist: %2\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s\'s playlist: %2\$s'
			WHERE languagevar_id = '5000155'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000156 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000156, 1, '%1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s'
			WHERE languagevar_id = '5000156'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000157 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000157, 1, 'From %1\$s by <a href=\'%2\$s\'>%3\$s</a>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'From %1\$s by <a href=\'%2\$s\'>%3\$s</a>'
			WHERE languagevar_id = '5000157'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000158 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000158, 1, '%1\$s\'s video - %2\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s\'s video - %2\$s'
			WHERE languagevar_id = '5000158'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000159 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000159, 1, '%1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s'
			WHERE languagevar_id = '5000159'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000160 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000160, 1, '%1\$s\'s playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s\'s playlists'
			WHERE languagevar_id = '5000160'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000161 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000161, 1, '%1\$s\'s favorite video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s\'s favorite video'
			WHERE languagevar_id = '5000161'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000162 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000162, 1, 'In this video: ', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'In this video: '
			WHERE languagevar_id = '5000162'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000163 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000163, 1, 'Add Tag', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Add Tag'
			WHERE languagevar_id = '5000163'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000164 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000164, 1, 'Share This', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Share This'
			WHERE languagevar_id = '5000164'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000165 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000165, 1, 'To share this video or embed it on another web page, please copy and paste the code of your choosing:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'To share this video or embed it on another web page, please copy and paste the code of your choosing:'
			WHERE languagevar_id = '5000165'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000166 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000166, 1, 'Direct Link', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Direct Link'
			WHERE languagevar_id = '5000166'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000167 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000167, 1, 'HTML - Embedded Image', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'HTML - Embedded Image'
			WHERE languagevar_id = '5000167'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000168 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000168, 1, 'HTML - Text Link', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'HTML - Text Link'
			WHERE languagevar_id = '5000168'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000169 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000169, 1, 'UBB Code (for forums)', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'UBB Code (for forums)'
			WHERE languagevar_id = '5000169'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000170 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000170, 1, 'Close Window', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Close Window'
			WHERE languagevar_id = '5000170'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000171 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000171, 1, 'Video Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video Playlists'
			WHERE languagevar_id = '5000171'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000172 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000172, 1, '%1\$d videos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$d videos'
			WHERE languagevar_id = '5000172'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000173 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000173, 1, 'remove tag', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'remove tag'
			WHERE languagevar_id = '5000173'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000174 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000174, 1, 'Upload photo:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Upload photo:'
			WHERE languagevar_id = '5000174'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000175 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000175, 1, 'To upload photo for your playlist from your computer, click the \"Browse\" button, locate them on your computer, then click the \"Upload\" button.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'To upload photo for your playlist from your computer, click the \"Browse\" button, locate them on your computer, then click the \"Upload\" button.'
			WHERE languagevar_id = '5000175'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000176 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000176, 1, 'Search videos:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Search videos:'
			WHERE languagevar_id = '5000176'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000177 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000177, 1, 'Search', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Search'
			WHERE languagevar_id = '5000177'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000178 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000178, 1, 'YouTube', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'YouTube'
			WHERE languagevar_id = '5000178'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000179 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000179, 1, 'in Playlists', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'in Playlists'
			WHERE languagevar_id = '5000179'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000180 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000180, 1, '%1\$d video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$d video'
			WHERE languagevar_id = '5000180'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000181 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000181, 1, 'updated %1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'updated %1\$s'
			WHERE languagevar_id = '5000181'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000182 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000182, 1, 'Views: %1\$d<br>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Views: %1\$d<br>'
			WHERE languagevar_id = '5000182'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000183 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000183, 1, 'Duration: %1\$s', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Duration: %1\$s'
			WHERE languagevar_id = '5000183'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000184 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000184, 1, 'Import video to:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Import video to:'
			WHERE languagevar_id = '5000184'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000185 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000185, 1, 'Videos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Videos'
			WHERE languagevar_id = '5000185'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000186 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000186, 1, 'Import', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Import'
			WHERE languagevar_id = '5000186'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000187 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000187, 1, 'Import Video:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Import Video:'
			WHERE languagevar_id = '5000187'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000188 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000188, 1, 'Information about video.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Information about video.'
			WHERE languagevar_id = '5000188'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000189 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000189, 1, 'Video title:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video title:'
			WHERE languagevar_id = '5000189'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000190 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000190, 1, 'Video ID:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video ID:'
			WHERE languagevar_id = '5000190'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000191 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000191, 1, 'Updated:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Updated:'
			WHERE languagevar_id = '5000191'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000192 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000192, 1, 'Description:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Description:'
			WHERE languagevar_id = '5000192'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000193 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000193, 1, 'Category:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Category:'
			WHERE languagevar_id = '5000193'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000194 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000194, 1, 'Tags:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Tags:'
			WHERE languagevar_id = '5000194'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000195 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000195, 1, 'Watch page Url:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Watch page Url:'
			WHERE languagevar_id = '5000195'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000196 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000196, 1, 'Flash Player Url:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Flash Player Url:'
			WHERE languagevar_id = '5000196'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000197 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000197, 1, 'Duration:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Duration:'
			WHERE languagevar_id = '5000197'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000198 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000198, 1, 'View count:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'View count:'
			WHERE languagevar_id = '5000198'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000199 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000199, 1, 'Rating:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Rating:'
			WHERE languagevar_id = '5000199'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000200 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000200, 1, 'Embed code:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Embed code:'
			WHERE languagevar_id = '5000200'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000201 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000201, 1, 'Playlist:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Playlist:'
			WHERE languagevar_id = '5000201'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000202 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000202, 1, 'Video:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video:'
			WHERE languagevar_id = '5000202'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000203 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000203, 1, 'All videos inside this playlist are listed below.<br>This playlist contains <b>%1\$s videos</b>.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'All videos inside this playlist are listed below.<br>This playlist contains <b>%1\$s videos</b>.'
			WHERE languagevar_id = '5000203'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000204 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000204, 1, 'Click here to begin adding videos.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Click here to begin adding videos.'
			WHERE languagevar_id = '5000204'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000205 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000205, 1, 'View playlist:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'View playlist:'
			WHERE languagevar_id = '5000205'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000206 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000206, 1, 'View video from playlist:', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'View video from playlist:'
			WHERE languagevar_id = '5000206'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000207 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000207, 1, 'by <a href=\'%1\$s\'>%2\$s</a><br>', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'by <a href=\'%1\$s\'>%2\$s</a><br>'
			WHERE languagevar_id = '5000207'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000208 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000208, 1, 'Add to my favorite', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Add to my favorite'
			WHERE languagevar_id = '5000208'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000209 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000209, 1, 'Video has been added to favorites', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video has been added to favorites'
			WHERE languagevar_id = '5000209'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000210 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000210, 1, 'This video already exists in favorites', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'This video already exists in favorites'
			WHERE languagevar_id = '5000210'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000211 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000211, 1, 'Favorite Video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Favorite Video'
			WHERE languagevar_id = '5000211'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000212 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000212, 1, 'Viewing Video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Viewing Video'
			WHERE languagevar_id = '5000212'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000213 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000213, 1, '%1\$s does not have any favorite video.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '%1\$s does not have any favorite video.'
			WHERE languagevar_id = '5000213'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000214 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000214, 1, '<a href=\'%1\$s\'>%2\$s</a>\'s favorite video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = '<a href=\'%1\$s\'>%2\$s</a>\'s favorite video'
			WHERE languagevar_id = '5000214'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000215 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000215, 1, 'My Favorite Video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'My Favorite Video'
			WHERE languagevar_id = '5000215'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000216 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000216, 1, 'Add New Video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Add New Video'
			WHERE languagevar_id = '5000216'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000217 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000217, 1, 'Please fill the empty fields.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Please fill the empty fields.'
			WHERE languagevar_id = '5000217'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000218 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000218, 1, 'and %1\$s videos', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'and %1\$s videos'
			WHERE languagevar_id = '5000218'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000219 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000219, 1, 'Thumbnail image', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Thumbnail image'
			WHERE languagevar_id = '5000219'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000220 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000220, 1, 'Delete Video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Delete Video'
			WHERE languagevar_id = '5000220'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000221 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000221, 1, 'Enter one or more tags, separated by spaces.<br>Tags are keywords used to describe your video so it can be easily found by other users.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Enter one or more tags, separated by spaces.<br>Tags are keywords used to describe your video so it can be easily found by other users.'
			WHERE languagevar_id = '5000221'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000222 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000222, 1, 'The id specifies a unique ID that YouTube uses to identify a video.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The id specifies a unique ID that YouTube uses to identify a video.'
			WHERE languagevar_id = '5000222'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000223 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000223, 1, 'The category specifies the category to which the video belongs.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The category specifies the category to which the video belongs.'
			WHERE languagevar_id = '5000223'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000224 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000224, 1, 'The description contains a summary or description of a video.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The description contains a summary or description of a video.'
			WHERE languagevar_id = '5000224'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000225 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000225, 1, 'The video title identifies the title of the video.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The video title identifies the title of the video.'
			WHERE languagevar_id = '5000225'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000226 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000226, 1, 'The watch page url identifies the url of the video in YouTube.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The watch page url identifies the url of the video in YouTube.'
			WHERE languagevar_id = '5000226'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000227 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000227, 1, 'The flash player url identifies the flash player url of the video in YouTube.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The flash player url identifies the flash player url of the video in YouTube.'
			WHERE languagevar_id = '5000227'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000228 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000228, 1, 'The embed code identifies the code of the video for insert in your site.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The embed code identifies the code of the video for insert in your site.'
			WHERE languagevar_id = '5000228'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000229 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000229, 1, 'Please fill the video title field.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Please fill the video title field.'
			WHERE languagevar_id = '5000229'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000230 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000230, 1, 'Please fill the embed code field.', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Please fill the embed code field.'
			WHERE languagevar_id = '5000230'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000231 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000231, 1, 'YouTube', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'YouTube'
			WHERE languagevar_id = '5000231'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000232 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000232, 1, 'Other', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Other'
			WHERE languagevar_id = '5000232'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000233 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000233, 1, 'The watch page url has wrong format', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'The watch page url has wrong format'
			WHERE languagevar_id = '5000233'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000234 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000234, 1, 'This video wasn\'t found on YouTube', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'This video wasn\'t found on YouTube'
			WHERE languagevar_id = '5000234'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000235 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000235, 1, 'Edit Video', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Edit Video'
			WHERE languagevar_id = '5000235'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000236 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000236, 1, 'Playlist Thumbnails', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Playlist Thumbnails'
			WHERE languagevar_id = '5000236'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000237 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000237, 1, 'Delete from favourites', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Delete from favourites'
			WHERE languagevar_id = '5000237'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000238 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000238, 1, 'Video has been deleted from favourites', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video has been deleted from favourites'
			WHERE languagevar_id = '5000238'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000239 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000239, 1, 'Video has not been deleted from favourites', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Video has not been deleted from favourites'
			WHERE languagevar_id = '5000239'");
	}
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id = 5000240 LIMIT 1")) == 0)
	{
		$database->database_query("
			INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
			VALUES (5000240, 1, 'Favorites', '')");
	}
	else 
	{
		$database->database_query("
			UPDATE `se_languagevars` SET `languagevar_value` = 'Favorites'
			WHERE languagevar_id = '5000240'");
	}
}  

?>