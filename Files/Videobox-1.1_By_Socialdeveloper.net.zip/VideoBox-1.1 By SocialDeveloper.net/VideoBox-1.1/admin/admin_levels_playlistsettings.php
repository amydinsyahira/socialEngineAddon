<?php
$page = "admin_levels_playlistsettings";
include "admin_header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }
if(isset($_POST['level_id'])) { $level_id = $_POST['level_id']; } elseif(isset($_GET['level_id'])) { $level_id = $_GET['level_id']; } else { $level_id = 0; }

// VALIDATE LEVEL ID
$level = $database->database_query("SELECT * FROM se_levels WHERE level_id='$level_id'");
if($database->database_num_rows($level) != 1) { header("Location: admin_levels.php"); exit(); }
$level_info = $database->database_fetch_assoc($level);

// SET RESULT VARIABLE
$result = 0;
$is_error = 0;


// SAVE CHANGES
if($task == "dosave")
{
	$level_info[level_playlist_allow] = $_POST['level_playlist_allow'];
	$level_info[level_playlist_exts] = str_replace(", ", ",", $_POST['level_playlist_exts']);
	$level_info[level_playlist_mimes] = str_replace(", ", ",", $_POST['level_playlist_mimes']);
	$level_info[level_playlist_storage] = $_POST['level_playlist_storage'];
	$level_info[level_playlist_maxsize] = $_POST['level_playlist_maxsize'];
	$level_info[level_playlist_width] = $_POST['level_playlist_width'];
	$level_info[level_playlist_height] = $_POST['level_playlist_height'];
	$level_info[level_playlist_style] = $_POST['level_playlist_style'];
	$level_info[level_playlist_maxnum] = $_POST['level_playlist_maxnum'];
	$level_info[level_playlist_search] = $_POST['level_playlist_search'];
	$level_info[level_playlist_privacy] = is_array($_POST['level_playlist_privacy']) ? $_POST['level_playlist_privacy'] : Array(0);
	$level_info[level_playlist_comments] = is_array($_POST['level_playlist_comments']) ? $_POST['level_playlist_comments'] : Array(0);
	$level_info[level_playlist_tag] = is_array($_POST['level_playlist_tag']) ? $_POST['level_playlist_tag'] : Array(0);
	$level_info[level_playlist_profile] = is_array($_POST['level_playlist_profile']) ? $_POST['level_playlist_profile'] : Array('tab');

	// IMPLODE PROFILE OPTIONS
	$level_playlist_profile = $level_info[level_playlist_profile];
	$level_info[level_playlist_profile] = implode(",", $level_info[level_playlist_profile]);

	// GET PRIVACY AND PRIVACY DIFFERENCES
	sort($level_info[level_playlist_privacy]);
	$new_privacy_options = $level_info[level_playlist_privacy];
	$level_info[level_playlist_privacy] = serialize($level_info[level_playlist_privacy]);

	// GET COMMENT AND COMMENT DIFFERENCES
	sort($level_info[level_playlist_comments]);
	$new_comments_options = $level_info[level_playlist_comments];
	$level_info[level_playlist_comments] = serialize($level_info[level_playlist_comments]);

	// GET TAG AND TAG DIFFERENCES
	sort($level_info[level_playlist_tag]);
	$new_tag_options = $level_info[level_playlist_tag];
	$level_info[level_playlist_tag] = serialize($level_info[level_playlist_tag]);

	// CHECK THAT A NUMBER BETWEEN 1 AND 204800 (200MB) WAS ENTERED FOR MAXSIZE
	if(!is_numeric($level_info[level_playlist_maxsize]) || $level_info[level_playlist_maxsize] < 1 || $level_info[level_playlist_maxsize] > 204800)
	{
		$is_error = 5000012;
	// CHECK THAT WIDTH AND HEIGHT ARE NUMBERS
	}
	elseif(!is_numeric($level_info[level_playlist_width]) || !is_numeric($level_info[level_playlist_height]))
	{
		$is_error = 5000013;
	// CHECK THAT MAX PLAYLISTS IS A NUMBER
	}
	elseif(!is_numeric($level_info[level_playlist_maxnum]) || $level_info[level_playlist_maxnum] < 1 || $level_info[level_playlist_maxnum] > 999)
	{
		$is_error = 5000014;
	}
	else
	{
		$level_info[level_playlist_maxsize] = $level_info[level_playlist_maxsize]*1024;
		$database->database_query("
			UPDATE se_levels SET 
				level_playlist_search='$level_info[level_playlist_search]',
				level_playlist_privacy='$level_info[level_playlist_privacy]',
				level_playlist_comments='$level_info[level_playlist_comments]',
				level_playlist_tag='$level_info[level_playlist_tag]',
				level_playlist_allow='$level_info[level_playlist_allow]',
				level_playlist_maxnum='$level_info[level_playlist_maxnum]',
				level_playlist_exts='$level_info[level_playlist_exts]',
				level_playlist_mimes='$level_info[level_playlist_mimes]',
				level_playlist_storage='$level_info[level_playlist_storage]',
				level_playlist_maxsize='$level_info[level_playlist_maxsize]',
				level_playlist_width='$level_info[level_playlist_width]',
				level_playlist_height='$level_info[level_playlist_height]',
				level_playlist_style='$level_info[level_playlist_style]',
				level_playlist_profile='$level_info[level_playlist_profile]'
			WHERE level_id='$level_info[level_id]'");
		if($level_info[level_playlist_search] == 0) { $database->database_query("UPDATE se_playlists, se_users SET se_playlists.playlist_search='1' WHERE se_users.user_level_id='$level_info[level_id]' AND se_playlists.playlist_user_id=se_users.user_id"); }
		$database->database_query("UPDATE se_users SET user_profile_playlist='".$level_playlist_profile[0]."' WHERE user_level_id='$level_info[level_id]' AND user_profile_playlist NOT IN('".join("','", $level_playlist_profile)."')");
		$database->database_query("UPDATE se_playlists, se_users SET se_playlists.playlist_privacy='".$new_privacy_options[0]."' WHERE se_users.user_level_id='$level_info[level_id]' AND se_playlists.playlist_privacy NOT IN('".join("','", $new_privacy_options)."')");
		$database->database_query("UPDATE se_playlists, se_users SET se_playlists.playlist_comments='".$new_comments_options[0]."' WHERE se_users.user_level_id='$level_info[level_id]' AND se_playlists.playlist_comments NOT IN('".join("','", $new_comments_options)."')");
		$database->database_query("UPDATE se_playlists, se_users SET se_playlists.playlist_tag='".$new_tag_options[0]."' WHERE se_users.user_level_id='$level_info[level_id]' AND se_playlists.playlist_tag NOT IN('".join("','", $new_tag_options)."')");
		$result = 1;
	}
} // END DOSAVE TASK



// ADD SPACES AFTER COMMAS
$level_info[level_playlist_exts] = str_replace(",", ", ", $level_info[level_playlist_exts]);
$level_info[level_playlist_mimes] = str_replace(",", ", ", $level_info[level_playlist_mimes]);
$level_info[level_playlist_maxsize] = $level_info[level_playlist_maxsize]/1024;

// GET PREVIOUS PRIVACY SETTINGS
for($c=6;$c>0;$c--)
{
	$priv = pow(2, $c)-1;
	if(user_privacy_levels($priv) != "")
	{
		SE_Language::_preload(user_privacy_levels($priv));
		$privacy_options[$priv] = user_privacy_levels($priv);
	}
}

for($c=6;$c>=0;$c--)
{
	$priv = pow(2, $c)-1;
	if(user_privacy_levels($priv) != "")
	{
		SE_Language::_preload(user_privacy_levels($priv));
		$comment_options[$priv] = user_privacy_levels($priv);
	}
}

for($c=6;$c>=0;$c--)
{
	$priv = pow(2, $c)-1;
	if(user_privacy_levels($priv) != "")
	{
		SE_Language::_preload(user_privacy_levels($priv));
		$tag_options[$priv] = user_privacy_levels($priv);
	}
}


// ASSIGN VARIABLES AND SHOW PLAYLIST SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('level_info', $level_info);
$smarty->assign('level_playlist_privacy', unserialize($level_info[level_playlist_privacy]));
$smarty->assign('level_playlist_comments', unserialize($level_info[level_playlist_comments]));
$smarty->assign('level_playlist_tag', unserialize($level_info[level_playlist_tag]));
$smarty->assign('level_playlist_profile', explode(",", $level_info[level_playlist_profile]));
$smarty->assign('playlist_privacy', $privacy_options);
$smarty->assign('playlist_comments', $comment_options);
$smarty->assign('playlist_tag', $tag_options);
include "admin_footer.php";
?>