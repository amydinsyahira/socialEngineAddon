<?php

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE VIDEO FUNCTIONS FILE
include "../include/class_playlist.php";

// INCLUDE EXAMPLE LANGUAGE FILE
include "../lang/lang_english_video.php";

// INCLUDE VIDEO FUNCTION FILE
include "../include/functions_video.php";
//require_once($_SERVER['DOCUMENT_ROOT'] . '/InstallationChecker.php');

$clientLibraryPath = dirname($_SERVER['SCRIPT_FILENAME']) . '/../ZendGdata/library';
$oldPath = set_include_path(get_include_path() . PATH_SEPARATOR . $clientLibraryPath);
//$installationChecker = new InstallationChecker(); exit;

require_once $clientLibraryPath . '/Zend/Loader.php'; // the Zend dir must be in your include_path
Zend_Loader::loadClass('Zend_Gdata_YouTube');


// SET USER DELETION HOOK
SE_Hook::register("se_user_delete", deleteuser_playlist);

?>