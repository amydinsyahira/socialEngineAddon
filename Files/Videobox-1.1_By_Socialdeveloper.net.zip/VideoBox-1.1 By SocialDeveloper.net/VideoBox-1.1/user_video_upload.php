<?php
$page = "user_video_upload";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }
if(isset($_POST['playlist_id'])) { $playlist_id = $_POST['playlist_id']; } elseif(isset($_GET['playlist_id'])) { $playlist_id = $_GET['playlist_id']; } else { $playlist_id = 0; }

// ENSURE PLAYLISTS ARE ENABLED FOR THIS USER
if($user->level_info[level_playlist_allow] == 0) { header("Location: user_home.php"); exit(); }

// BE SURE PLAYLIST BELONGS TO THIS USER
$playlist = $database->database_query("SELECT * FROM se_playlists WHERE playlist_id='$playlist_id' AND playlist_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($playlist) != 1) { header("Location: user_video.php"); exit(); }
$playlist_info = $database->database_fetch_assoc($playlist);

// SET PLAYLIST
$playlist = new se_playlist($user->user_info[user_id]);

// SET RESULT AND ERROR VARS
$result = "";
$is_error = 0;
$show_uploader = 1;
$file_result = Array();

// GET TOTAL SPACE USED
$space_used = $playlist->playlist_space();
if($user->level_info[level_playlist_storage])
	$space_left = $user->level_info[level_playlist_storage] - $space_used;
else
	$space_left = ( $dfs=disk_free_space("/") ? $dfs : pow(2, 32) );

// UPLOAD FILES
if($task == "doupload")
{
	$isAjax = $_POST['isAjax'];
	$file_result = Array();
	
	// WORKAROUND FOR FLASH UPLOADER
	if($_FILES['file1']['type'] == "application/octet-stream" && $isAjax)
	{ 
		$file_types = explode(",", str_replace(" ", "", strtolower($user->level_info[level_playlist_mimes])));
		$file_types_images = explode(",", str_replace(" ", "", strtolower($user->level_info[level_playlist_images_mimes])));
		//$_FILES['file1']['type'] = $file_types[0];
		$_FILES['file1']['type'] = $file_types_images[0];
	}
	
	// RUN FILE UPLOAD FUNCTION FOR EACH SUBMITTED FILE
	$update_playlist = 0;
	$new_playlist_cover = "";
	$action_video = Array();
	for($f = 1;$f < 6;$f ++)
	{
		$fileid = "file".$f;
		if($_FILES[$fileid]['name'] != "")
		{
			$file_result[$fileid] = $playlist->playlist_image_upload($fileid, $playlist_id, $space_left);
			if($file_result[$fileid]['is_error'] == 0)
			{
				$file_result[$fileid]['message'] = 5000086;
				$new_playlist_cover = $file_result[$fileid]['video_id'];
				$video_path = $url->url_base.substr($url->url_userdir($user->user_info[user_id]), 2).$file_result[$fileid]['video_id']."_thumb.jpg";
				
				if(file_exists(substr($url->url_userdir($user->user_info[user_id]), 2).$file_result[$fileid]['video_id']."_thumb.jpg"))
				{ 
					$video_width = $misc->photo_size($video_path, "100", "100", "w");
					$video_height = $misc->photo_size($video_path, "100", "100", "h");
					$action_video[] = Array(
						'video_link' => 'video.php?user='.$user->user_info[user_username].'&playlist_id='.$playlist_id,
						'video_path' => $video_path,
						'video_width' => $video_width,
						'video_height' => $video_height);
				} 
				$update_playlist = $file_result[$fileid]['video_id'];
			}
			else
			{
				$file_result[$fileid]['message'] = $file_result[$fileid]['is_error'];
			}
			
			SE_Language::_preload($file_result[$fileid]['message']);
		}
	}
	
	// UPDATE PLAYLIST UPDATED DATE AND PLAYLIST COVER IF FILE UPLOADED
	if($update_playlist)
	{
		$newdate = time();
		if($playlist_info[playlist_cover] != 0) { $new_playlist_cover = $playlist_info[playlist_cover]; }
		$database->database_query("UPDATE se_playlists SET playlist_cover='$new_playlist_cover', playlist_dateupdated='$newdate' WHERE playlist_id='$playlist_id'");

		// UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
		$user->user_lastupdate();

		// INSERT ACTION
		$playlist_title = $playlist_info[playlist_title];
		if(strlen($playlist_title) > 100) { $playlist_title = substr($playlist_title, 0, 97)."..."; }
		$video_path = $url->url_base.substr($url->url_userdir($user->user_info[user_id]), 2).$update_playlist."_thumb.jpg";
		$actions->actions_add($user, "newplaylistphoto", Array($user->user_info[user_username], $user->user_displayname, $playlist_id, $playlist_title, $video_path, 100), $action_video, 60, FALSE, "user", $user->user_info[user_id], $playlist_info[playlist_privacy]);
	}

	// OUTPUT JSON RESULT
	if($isAjax)
	{
		SE_Language::load();
		if($update_playlist)
		{
			$result = "success"; 
			$size = sprintf(SE_Language::_get($file_result['file1']['message']), $file_result['file1']['file_name']);
			$error = null; 
		}
		else
		{
			$result = "failure";
			$error = sprintf(SE_Language::_get($file_result['file1']['message']), $file_result['file1']['file_name']);
			$size = null;
		}
		$json = '{"result":"'.$result.'","error":"'.$error.'","size":"'.$size.'"}';
		if(!headers_sent()) { header('Content-type: application/json'); }
		echo $json;
		exit();

		// SHOW PAGE WITH RESULTS
	}
	else
	{
		$show_uploader = 0;
	}
} // END TASK



// FIND OUT IF PLAYLIST WAS JUST CREATED
if(isset($_GET['new_playlist']) AND $_GET['new_playlist'] == 1) { $new_playlist = 1; } else { $new_playlist = 0; }

// GET MAX FILESIZE ALLOWED
$max_filesize_kb = ($user->level_info[level_playlist_maxsize]) / 1024;
$max_filesize_kb = round($max_filesize_kb, 0);
$max_filesize_images_kb = ($user->level_info[level_playlist_images_maxsize]) / 1024;
$max_filesize_images_kb = round($max_filesize_images_kb, 0);

// CONVERT UPDATED SPACE LEFT TO MB
$space_left_mb = ($space_left / 1024) / 1024;
$space_left_mb = round($space_left_mb, 2);


// START NEW SESSION AND SET SESSION VARS FOR UPLOADER
session_start();
$_SESSION = array();
session_regenerate_id();
$_SESSION['upload_token'] = md5(uniqid(rand(), true));
$_SESSION['action'] = "user_video_upload.php";
$_SESSION['user_id'] = $_COOKIE['user_id'];
$_SESSION['user_email'] = $_COOKIE['user_email'];
$_SESSION['user_password'] = $_COOKIE['user_password'];

// SET INPUTS
$inputs = Array('playlist_id' => $playlist_info[playlist_id]);

// ASSIGN VARIABLES AND SHOW UPLOAD FILES PAGE
$smarty->assign('new_playlist', $new_playlist);
$smarty->assign('show_uploader', $show_uploader);
$smarty->assign('session_id', session_id());
$smarty->assign('upload_token', $_SESSION['upload_token']);
$smarty->assign('file_result', $file_result);
$smarty->assign('playlist_info', $playlist_info);
$smarty->assign('inputs', $inputs);
$smarty->assign('space_left', $space_left_mb);
$smarty->assign('allowed_exts', str_replace(",", ", ", $user->level_info[level_playlist_exts]));
$smarty->assign('allowed_images_exts', str_replace(",", ", ", $user->level_info[level_playlist_images_exts]));
$smarty->assign('max_filesize', $max_filesize_kb);
$smarty->assign('max_filesize_images', $max_filesize_images_kb);
include "footer.php";

?>