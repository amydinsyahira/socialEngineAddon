<?php

//  THIS CLASS CONTAINS PLAYLIST ENTRY-RELATED METHODS 
//  METHODS IN THIS CLASS:
//    se_playlist()
//    playlist_total()
//    playlist_list()
//    playlist_space()
//    playlist_delete()
//    playlist_delete_selected()
//    playlist_files()
//    playlist_video_upload()
//    playlist_video_list()
//    playlist_video_update()
//    playlist_video_delete()
//    playlist_video_rotate()
class se_playlist
{
	// INITIALIZE VARIABLES
	var $is_error;			// DETERMINES WHETHER THERE IS AN ERROR OR NOT
	var $user_id;			// CONTAINS THE USER ID OF THE USER WHOSE PLAYLIST WE ARE EDITING

	// THIS METHOD SETS INITIAL VARS
	// INPUT: $user_id (OPTIONAL) REPRESENTING THE USER ID OF THE USER WHOSE PLAYLISTS WE ARE CONCERNED WITH
	// OUTPUT: 
	function se_playlist($user_id = 0)
	{
	  $this->user_id = $user_id;
	} // END se_playlist() METHOD

	// THIS METHOD RETURNS THE TOTAL NUMBER OF PLAYLISTS
	// INPUT: $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF PLAYLISTS
	function playlist_total($where = "")
	{
		global $database;

		// BEGIN PLAYLIST QUERY
		$playlist_query = "SELECT playlist_id FROM se_playlists";

		// IF NO USER ID SPECIFIED, JOIN TO USER TABLE
		if($this->user_id == 0) { $playlist_query .= " LEFT JOIN se_users ON se_playlists.playlist_user_id=se_users.user_id"; }

		// ADD WHERE IF NECESSARY
		if($where != "" || $this->user_id != 0) { $playlist_query .= " WHERE"; }

		// ENSURE USER ID IS NOT EMPTY
		if($this->user_id != 0) { $playlist_query .= " playlist_user_id='".$this->user_id."'"; }

		// INSERT AND IF NECESSARY
		if($this->user_id != 0 && $where != "") { $playlist_query .= " AND"; }

		// ADD WHERE CLAUSE, IF NECESSARY
		if($where != "") { $playlist_query .= " $where"; }
		
		// GET AND RETURN TOTAL VIDEO PLAYLISTS
		$playlist_total = $database->database_num_rows($database->database_query($playlist_query));
		return $playlist_total;
	} // END playlist_total() METHOD

	// THIS METHOD RETURNS AN ARRAY OF PLAYLISTS
	// INPUT: $start REPRESENTING THE PLAYLIST TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF PLAYLISTS TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY OF PLAYLISTS
	function playlist_list($start, $limit, $sort_by = "playlist_id DESC", $where = "")
	{
		global $database, $user, $owner;

		// BEGIN QUERY
		$playlist_query = "SELECT se_playlists.*, count(se_video.video_id) AS total_files, sum(se_video.video_filesize) AS total_space";
	
		// IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
		if($this->user_id == 0) { $playlist_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo, se_users.user_fname, se_users.user_lname"; }

		// CONTINUE QUERY
		$playlist_query .= " FROM se_playlists LEFT JOIN se_video ON se_playlists.playlist_id=se_video.video_playlist_id";

		// IF NO USER ID SPECIFIED, JOIN TO USER TABLE
		if($this->user_id == 0) { $playlist_query .= " LEFT JOIN se_users ON se_playlists.playlist_user_id=se_users.user_id"; }

		// ADD WHERE IF NECESSARY
		if($where != "" || $this->user_id != 0) { $playlist_query .= " WHERE"; }

		// ENSURE USER ID IS NOT EMPTY
		if($this->user_id != 0) { $playlist_query .= " playlist_user_id=".$this->user_id; }

		// INSERT AND IF NECESSARY
		if($this->user_id != 0 && $where != "") { $playlist_query .= " AND"; }

		// ADD WHERE CLAUSE, IF NECESSARY
		if($where != "") { $playlist_query .= " $where"; }

		// ADD GROUP BY, ORDER, AND LIMIT CLAUSE
		$playlist_query .= " GROUP BY playlist_id ORDER BY $sort_by LIMIT $start, $limit";
		
		// RUN QUERY
		$playlists = $database->database_query($playlist_query);
		
		// GET PLAYLISTS INTO AN ARRAY
		$playlist_array = Array();
		while($playlist_info = $database->database_fetch_assoc($playlists))
		{
			// IF NO USER ID SPECIFIED, CREATE OBJECT FOR AUTHOR
			if($this->user_id == 0)
			{
				$author = new se_user();
				$author->user_exists = 1;
				$author->user_info[user_id] = $playlist_info[user_id];
				$author->user_info[user_username] = $playlist_info[user_username];
				$author->user_info[user_fname] = $playlist_info[user_fname];
				$author->user_info[user_lname] = $playlist_info[user_lname];
				$author->user_info[user_photo] = $playlist_info[user_photo];
				$author->user_displayname();

				// OTHERWISE, SET AUTHOR TO OWNER/LOGGED-IN USER
			}
			elseif($owner->user_exists != 0 && $owner->user_info[user_id] == $playlist_info[playlist_user_id])
			{
				$author = $owner;
			}
			elseif($user->user_exists != 0 && $user->user_info[user_id] == $playlist_info[playlist_user_id])
			{
				$author = $user;
			}

			// CONVERT SPACE TO MB
			$playlist_space_mb = ($playlist_info[total_space] / 1024) / 1024;
			$playlist_space_mb = round($playlist_space_mb, 2);

			// GET PATH OF PLAYLIST  
			$playlist_cover_id = 0;
			$playlist_cover_ext = "";
			if($playlist_info[playlist_cover] != 0)
			{
				$playlist_cover_query = $database->database_query("SELECT video_id, video_ext FROM se_video WHERE video_id='$playlist_info[playlist_cover]' AND video_playlist_id='$playlist_info[playlist_id]'");
				if($database->database_num_rows($playlist_cover_query) == 1)
				{
					$playlist_cover_array = $database->database_fetch_assoc($playlist_cover_query);
					$playlist_cover_id = $playlist_cover_array[video_id];
					$playlist_cover_ext = $playlist_cover_array[video_ext];
				}
			}
			
			// CREATE ARRAY OF PLAYLIST DATA
			SE_Language::_preload(user_privacy_levels($playlist_info[playlist_privacy]));
			
			$sql = "
				SELECT count(se_videos.video_id) as cnt, MAX(se_videos.video_updated) as updated
				FROM se_videos
				WHERE video_playlist_id = '".$playlist_info[playlist_id]."'";
			$resource = $database->database_query($sql);
			$video_info = $database->database_fetch_assoc($resource);
			$playlist_dateupdated = (isset($video_info['cnt']) && $video_info['cnt'] ? strtotime($video_info['updated']) : $playlist_info[playlist_dateupdated]);
			
			$playlist_array[] = Array(
				'playlist_id' => $playlist_info[playlist_id],
				'playlist_user_id' => $playlist_info[playlist_user_id],
				'playlist_author' => $author,
				'playlist_datecreated' => $playlist_info[playlist_datecreated],
				'playlist_dateupdated' => $playlist_dateupdated,
				'playlist_dateupdated_raw' => $playlist_info[playlist_dateupdated],
				'playlist_title' => $playlist_info[playlist_title],
				'playlist_desc' => $playlist_info[playlist_desc],
				'playlist_files' => $playlist_info[total_files],
				'playlist_video_files' => $video_info['cnt'],
				'playlist_space' => $playlist_space_mb,
				'playlist_privacy' => user_privacy_levels($playlist_info[playlist_privacy]),
				'playlist_cover_id' => $playlist_cover_id,
				'playlist_cover_ext' => $playlist_cover_ext,
				'playlist_views' => $playlist_info[playlist_views]);
		}
		
		// RETURN ARRAY
		return $playlist_array;
	} // END playlist_list() METHOD

	// THIS METHOD RETURNS THE SPACE USED
	// INPUT: $playlist_id (OPTIONAL) REPRESENTING THE ID OF THE PLAYLIST TO CALCULATE
	// OUTPUT: AN INTEGER REPRESENTING THE SPACE USED
	function playlist_space($playlist_id = 0)
	{
		global $database;

		// BEGIN QUERY
		$playlist_query = "SELECT sum(se_video.video_filesize) AS total_space";
	
		// CONTINUE QUERY
		$playlist_query .= " FROM se_playlists LEFT JOIN se_video ON se_playlists.playlist_id=se_video.video_playlist_id";

		// ADD WHERE IF NECESSARY
		if($this->user_id != 0 || $playlist_id != 0) { $playlist_query .= " WHERE"; }

		// ENSURE USER ID IS NOT EMPTY
		if($this->user_id != 0) { $playlist_query .= " playlist_user_id='".$this->user_id."'"; }

		// INSERT AND IF NECESSARY
		if($this->user_id != 0 && $playlist_id != 0) { $playlist_query .= " AND"; }

		// SPECIFY PLAYLIST IF NECESSARY
		if($playlist_id != 0) { $playlist_query .= " playlist_id='$playlist_id'"; }

		// GET AND RETURN TOTAL SPACE USED
		$space_info = $database->database_fetch_assoc($database->database_query($playlist_query));
		return $space_info[total_space];
	} // END playlist_space() METHOD

	// THIS METHOD DELETES A SPECIFIED PLAYLIST
	// INPUT: $playlist_id REPRESENTING THE ID OF THE PLAYLIST TO DELETE
	// OUTPUT: 
	function playlist_delete($playlist_id)
	{
		global $database, $url;

		$video = $database->database_query("SELECT video_id, video_ext FROM se_video WHERE video_playlist_id='$playlist_id'");

		// LOOP OVER VIDEO
		while($video_info = $database->database_fetch_assoc($video))
		{
			$video_path = $url->url_userdir($this->user_id).$video_info[video_id].".".$video_info[video_ext];
			
			if(file_exists($video_path)) { unlink($video_path); }
			
			$thumb_path = $url->url_userdir($this->user_id).$video_info[video_id]."_thumb.".$video_info[video_ext];
			
			if(file_exists($thumb_path)) { unlink($thumb_path); }
		}

		$database->database_query("DELETE FROM se_playlists, se_video, se_videos, se_favourite_video, se_videocomments, se_videotags USING se_playlists LEFT JOIN se_video ON se_playlists.playlist_id=se_video.video_playlist_id LEFT JOIN se_videos ON se_playlists.playlist_id=se_videos.video_playlist_id LEFT JOIN se_videocomments ON se_video.video_id=se_videocomments.videocomment_video_id LEFT JOIN se_videotags ON se_video.video_id=se_videotags.videotag_video_id LEFT JOIN se_favourite_video ON se_videos.video_id = se_favourite_video.favourite_video_id WHERE se_playlists.playlist_id='$playlist_id'");

		// CALL PLAYLIST CREATION HOOK
		($hook = SE_Hook::exists('se_playlist_delete')) ? SE_Hook::call($hook, array()) : NULL;

	} // END playlist_delete() METHOD

	// THIS METHOD DELETES SELECTED PLAYLISTS
	// INPUT: $start REPRESENTING THE PLAYLIST TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF PLAYLISTS TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: 
	function playlist_delete_selected($start, $limit, $sort_by = "playlist_id DESC", $where = "")
	{
		global $database;

		// BEGIN QUERY
		$playlist_query = "SELECT se_playlists.*, count(se_video.video_id) AS total_files, sum(se_video.video_filesize) AS total_space";
	
		// IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
		if($this->user_id == 0) { $playlist_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo"; }

		// CONTINUE QUERY
		$playlist_query .= " FROM se_playlists LEFT JOIN se_video ON se_playlists.playlist_id=se_video.video_playlist_id";

		// IF NO USER ID SPECIFIED, JOIN TO USER TABLE
		if($this->user_id == 0) { $playlist_query .= " LEFT JOIN se_users ON se_playlists.playlist_user_id=se_users.user_id"; }

		// ADD WHERE IF NECESSARY
		if($where != "" || $this->user_id != 0) { $playlist_query .= " WHERE"; }

		// ENSURE USER ID IS NOT EMPTY
		if($this->user_id != 0) { $playlist_query .= " playlist_user_id='".$this->user_id."'"; }

		// INSERT AND IF NECESSARY
		if($this->user_id != 0 && $where != "") { $playlist_query .= " AND"; }

		// ADD WHERE CLAUSE, IF NECESSARY
		if($where != "") { $playlist_query .= " $where"; }

		// ADD GROUP BY, ORDER, AND LIMIT CLAUSE
		$playlist_query .= " GROUP BY playlist_id ORDER BY $sort_by LIMIT $start, $limit";

		// RUN QUERY
		$playlists = $database->database_query($playlist_query);

		// GET PLAYLISTS INTO AN ARRAY
		$playlist_array = Array();
		while($playlist_info = $database->database_fetch_assoc($playlists))
		{
			$var = "delete_playlist_".$playlist_info[playlist_id];
			if($_POST[$var] == 1) { $this->playlist_delete($playlist_info[playlist_id]); }
		}
	} // END playlist_delete_selected() METHOD

	// THIS METHOD RETURNS THE NUMBER OF FILES
	// INPUT: $playlist_id (OPTIONAL) REPRESENTING THE ID OF THE PLAYLIST TO CALCULATE
	//	  $where (OPTIONAL) REPRESENTING A WHERE CLAUSE
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF FILES
	function playlist_files($playlist_id = 0, $where = "")
	{
		global $database;

		// BEGIN QUERY
		$playlist_query = "SELECT count(se_video.video_id) AS total_files";
	
		// CONTINUE QUERY
		$playlist_query .= " FROM se_playlists LEFT JOIN se_video ON se_playlists.playlist_id=se_video.video_playlist_id";

		// ADD WHERE IF NECESSARY
		if($this->user_id != 0 || $playlist_id != 0 || $where != "") { $playlist_query .= " WHERE"; }

		// ENSURE USER ID IS NOT EMPTY
		if($this->user_id != 0) { $playlist_query .= " playlist_user_id='".$this->user_id."'"; }

		// INSERT AND IF NECESSARY
		if($this->user_id != 0 && ($playlist_id != 0 || $where != "")) { $playlist_query .= " AND"; }

		// SPECIFY PLAYLIST IF NECESSARY
		if($playlist_id != 0) { $playlist_query .= " playlist_id='$playlist_id'"; }

		// INSERT AND IF NECESSARY
		if($playlist_id != 0 && $where != "") { $playlist_query .= " AND"; }

		// ADD WHERE CLAUSE
		if($where != "") { $playlist_query .= " $where"; }

		// GET AND RETURN TOTAL FILES
		$file_info = $database->database_fetch_assoc($database->database_query($playlist_query));
		return $file_info[total_files];
	} // END playlist_files() METHOD

	// THIS METHOD UPLOADS VIDEO TO AN PLAYLIST
	// INPUT: $file_name REPRESENTING THE NAME OF THE FILE INPUT
	//	  $playlist_id REPRESENTING THE ID OF THE PLAYLIST TO UPLOAD THE VIDEO TO
	//	  $space_left REPRESENTING THE AMOUNT OF SPACE LEFT
	// OUTPUT:
	function playlist_image_upload($file_name, $playlist_id, &$space_left)
	{
		global $database, $url, $user;

		// SET KEY VARIABLES
		$file_maxsize = $user->level_info[level_playlist_maxsize];
		$file_exts = explode(",", str_replace(" ", "", strtolower($user->level_info[level_playlist_images_exts])));
		$file_types = explode(",", str_replace(" ", "", strtolower($user->level_info[level_playlist_images_mimes])));
		$file_maxwidth = $user->level_info[level_playlist_width];
		$file_maxheight = $user->level_info[level_playlist_height];
		$new_video = new se_upload();
		$new_video->new_upload($file_name, $file_maxsize, $file_exts, $file_types, $file_maxwidth, $file_maxheight);
		
		// UPLOAD AND RESIZE VIDEO IF NO ERROR
		if($new_video->is_error == 0)
		{

			// GET MAX ORDER
			$max = $database->database_fetch_assoc($database->database_query("SELECT max(video_order) AS max FROM se_video LEFT JOIN se_playlists ON se_video.video_playlist_id=se_playlists.playlist_id WHERE se_playlists.playlist_user_id='".$user->user_info[user_id]."'"));
			$video_order = $max[max]+1;
			
			// INSERT ROW INTO VIDEO TABLE
			$database->database_query("
				INSERT INTO se_video (
					video_playlist_id,
					video_date,
					video_order
				) VALUES (
					'$playlist_id',
					'".time()."',
					'$video_order')");
			$video_id = $database->database_insert_id();
			
			// CHECK IF IMAGE RESIZING IS AVAILABLE, OTHERWISE MOVE UPLOADED IMAGE
			if($new_video->is_image == 1)
			{
				$file_dest = $url->url_userdir($user->user_info[user_id]).$video_id.".jpg";
				$thumb_dest = $url->url_userdir($user->user_info[user_id]).$video_id."_thumb.jpg";
				
				// UPLOAD THUMB
				$new_video->upload_thumb($thumb_dest, 200);

				// UPLOAD FILE
				$new_video->upload_photo($file_dest);

				$file_ext = "jpg";
				$file_filesize = filesize($file_dest);
			}
			else
			{
				$file_dest = $url->url_userdir($user->user_info[user_id]).$video_id.".".$new_video->file_ext;

				// UPLOAD THUMB IF NECESSARY
				if($new_video->file_ext == 'gif')
				{
					$thumb_dest = $url->url_userdir($user->user_info[user_id]).$video_id."_thumb.jpg";
					$new_video->upload_thumb($thumb_dest, 200);
				}

				// MOVE FILE
				$new_video->upload_file($file_dest);
				$file_ext = $new_video->file_ext;
				$file_filesize = filesize($file_dest);
			}

			// CHECK SPACE LEFT
			if($file_filesize > $space_left)
			{
				$new_video->is_error = 1000085;
			}
			else
			{
				$space_left = $space_left-$file_filesize;
			}

			// DELETE FROM DATABASE IF ERROR
			if($new_video->is_error != 0)
			{
				$database->database_query("DELETE FROM se_video WHERE video_id='$video_id' AND video_playlist_id='$playlist_id'");
				@unlink($file_dest);

			// UPDATE ROW IF NO ERROR
			}
			else
			{
				$database->database_query("UPDATE se_video SET video_ext='$file_ext', video_filesize='$file_filesize' WHERE video_id='$video_id' AND video_playlist_id='$playlist_id'");
			}
		}
	
		// RETURN FILE STATS
		$file_result = Array(
			'is_error' => $new_video->is_error,
			'file_name' => $_FILES[$file_name]['name'],
			'video_id' => $video_id,
			'video_ext' => $file_ext,
			'video_filesize' => $file_filesize);

		return $file_result;
	} // END playlist_video_upload() METHOD

	// THIS METHOD RETURNS AN ARRAY OF VIDEO
	// INPUT: $start REPRESENTING THE VIDEO TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF VIDEO TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	//	  $select (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO SELECT
	// OUTPUT: AN ARRAY OF VIDEO
	function playlist_video_list($start, $limit, $sort_by = "video_id DESC", $where = "", $select = "")
	{
		global $database, $user, $owner;

		// BEGIN QUERY
		$video_query = "SELECT se_video.*, se_playlists.playlist_id, se_playlists.playlist_user_id, se_playlists.playlist_title, count(se_videocomments.videocomment_id) AS total_comments";
	
		// IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
		if($this->user_id == 0) { $video_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo"; }
	
		// ADD ADDITIONAL SELECTS
		if($select != "") { $video_query .= $select; }

		// CONTINUE QUERY
		$video_query .= " FROM se_video LEFT JOIN se_videocomments ON se_videocomments.videocomment_video_id=se_video.video_id LEFT JOIN se_playlists ON se_playlists.playlist_id=se_video.video_playlist_id";

		// IF NO USER ID SPECIFIED, JOIN TO USER TABLE
		if($this->user_id == 0) { $video_query .= " LEFT JOIN se_users ON se_playlists.playlist_user_id=se_users.user_id"; }

		// ADD WHERE IF NECESSARY
		if($where != "" || $this->user_id != 0) { $video_query .= " WHERE"; }

		// ENSURE USER ID IS NOT EMPTY
		if($this->user_id != 0) { $video_query .= " playlist_user_id='".$this->user_id."'"; }

		// INSERT AND IF NECESSARY
		if($this->user_id != 0 && $where != "") { $video_query .= " AND"; }

		// ADD WHERE CLAUSE, IF NECESSARY
		if($where != "") { $video_query .= " $where"; }

		// ADD GROUP BY, ORDER, AND LIMIT CLAUSE
		$video_query .= " GROUP BY video_id ORDER BY $sort_by LIMIT $start, $limit";

		// RUN QUERY
		$video = $database->database_query($video_query);

		// GET VIDEO INTO AN ARRAY
		$video_array = Array();
		while($video_info = $database->database_fetch_assoc($video))
		{

			// IF NO USER ID SPECIFIED, CREATE OBJECT FOR AUTHOR
			if($this->user_id == 0)
			{
				$author = new se_user();
				$author->user_exists = 1;
				$author->user_info[user_id] = $video_info[user_id];
				$author->user_info[user_username] = $video_info[user_username];
				$author->user_info[user_photo] = $video_info[user_photo];

				// OTHERWISE, SET AUTHOR TO OWNER/LOGGED-IN USER
			}
			elseif($owner->user_exists != 0 && $owner->user_info[user_id] == $video_info[playlist_user_id])
			{
				$author = $owner;
			}
			elseif($user->user_exists != 0 && $user->user_info[user_id] == $video_info[playlist_user_id])
			{
				$author = $user;
			}

			// CREATE ARRAY OF VIDEO DATA
			$video_array[] = Array(
				'video_id' => $video_info[video_id],
				'video_playlist_id' => $video_info[video_playlist_id],
				'video_author' => $author,
				'video_date' => $video_info[video_date],
				'video_title' => $video_info[video_title],
				'video_desc' => str_replace("<br>", "\r\n", $video_info[video_desc]),
				'video_ext' => $video_info[video_ext],
				'video_filesize' => $video_info[video_filesize],
				'video_comments_total' => $video_info[total_comments]);
		}

		// RETURN ARRAY
		return $video_array;
	} // END playlist_video_list() METHOD

	// THIS METHOD UPDATES VIDEO INFORMATION
	// INPUT: $start REPRESENTING THE VIDEO TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF VIDEO TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY CONTAINING ALL THE VIDEO ID
	function playlist_video_update($start, $limit, $sort_by = "video_id DESC", $where = "")
	{
		global $database;

		// BEGIN QUERY
		$video_query = "SELECT se_video.*, se_playlists.playlist_id, se_playlists.playlist_user_id, se_playlists.playlist_title, count(se_videocomments.videocomment_id) AS total_comments";
	
		// IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
		if($this->user_id == 0) { $video_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo"; }

		// CONTINUE QUERY
		$video_query .= " FROM se_video LEFT JOIN se_videocomments ON se_videocomments.videocomment_video_id=se_video.video_id LEFT JOIN se_playlists ON se_playlists.playlist_id=se_video.video_playlist_id";

		// IF NO USER ID SPECIFIED, JOIN TO USER TABLE
		if($this->user_id == 0) { $video_query .= " LEFT JOIN se_users ON se_playlists.playlist_user_id=se_users.user_id"; }

		// ADD WHERE IF NECESSARY
		if($where != "" || $this->user_id != 0) { $video_query .= " WHERE"; }

		// ENSURE USER ID IS NOT EMPTY
		if($this->user_id != 0) { $video_query .= " playlist_user_id='".$this->user_id."'"; }

		// INSERT AND IF NECESSARY
		if($this->user_id != 0 && $where != "") { $video_query .= " AND"; }

		// ADD WHERE CLAUSE, IF NECESSARY
		if($where != "") { $video_query .= " $where"; }

		// ADD GROUP BY, ORDER, AND LIMIT CLAUSE
		$video_query .= " GROUP BY video_id ORDER BY $sort_by LIMIT $start, $limit";

		// RUN QUERY
		$video = $database->database_query($video_query);

		// GET VIDEO INTO AN ARRAY
		$video_array = Array();
		while($video_info = $database->database_fetch_assoc($video))
		{
			$var1 = "video_title_".$video_info[video_id];
			$var2 = "video_desc_".$video_info[video_id];
			$var3 = "video_playlist_id_".$video_info[video_id];
			$video_title = censor($_POST[$var1]);
			$video_desc = censor(str_replace("\r\n", "<br>", $_POST[$var2]));
			$video_playlist_id = $_POST[$var3];
			if($video_title != $video_info[video_title] || $video_desc != $video_info[video_desc] || $video_playlist_id != $video_info[video_playlist_id])
			{
				if($video_playlist_id != $video_info[video_playlist_id])
				{
					if($database->database_num_rows($database->database_query("SELECT playlist_id FROM se_playlists WHERE playlist_id='$video_playlist_id' AND playlist_user_id='".$this->user_id."' LIMIT 1")) != 1)
					{
						$video_playlist_id = $video_info[video_playlist_id];
					}
				}
				$database->database_query("UPDATE se_video SET video_title='$video_title', video_desc='$video_desc', video_playlist_id='$video_playlist_id' WHERE video_id='$video_info[video_id]'");
			}
	    
			if($video_playlist_id == $video_info[video_playlist_id])
			{
				$video_array[] = $video_info[video_id];
			}
		}

		return $video_array;
	} // END playlist_video_update() METHOD

	// THIS METHOD DELETES SELECTED VIDEO
	// INPUT: $start REPRESENTING THE VIDEO TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF VIDEO TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT:
	function playlist_video_delete($start, $limit, $sort_by = "video_id DESC", $where = "")
	{
		global $database, $url;

		$delete = $_POST['delete'];
		if(count($delete) == 0) { return; }

		// BEGIN QUERY
		$video_query = "SELECT se_video.video_id, se_video.video_ext FROM se_video LEFT JOIN se_videocomments ON se_videocomments.videocomment_video_id=se_video.video_id LEFT JOIN se_playlists ON se_playlists.playlist_id=se_video.video_playlist_id";

		// ADD WHERE IF NECESSARY
		$video_query .= " WHERE se_video.video_id IN(".implode(", ", $delete).") AND playlist_user_id='".$this->user_id."'";

		// ADD WHERE CLAUSE IF NECESSARY
		if($where != "") { $video_query .= " AND $where"; }

		// ADD GROUP BY, ORDER, AND LIMIT CLAUSE
		$video_query .= " GROUP BY video_id ORDER BY $sort_by LIMIT $start, $limit";

		// RUN QUERY
		$video = $database->database_query($video_query);

		// LOOP OVER VIDEO
		$thumbs = Array();
		while($video_info = $database->database_fetch_assoc($video))
		{
			$video_path = $url->url_userdir($this->user_id).$video_info[video_id].".".$video_info[video_ext];
			if(file_exists($video_path)) { unlink($video_path); }
			$thumb_path = $url->url_userdir($this->user_id).$video_info[video_id]."_thumb.jpg";
			if(file_exists($thumb_path)) { unlink($thumb_path); }
			$thumbs[] = $url->url_base.substr($url->url_userdir($this->user_id), 2).$video_info[video_id]."_thumb.jpg";
		}

		// DELETE ACTION VIDEO IF NECESSARY
		$database->database_query("DELETE FROM se_actionvideo WHERE actionvideo_path IN ('".implode("', '", $thumbs)."')");

		// DELETE VIDEO FROM DATABASE
		$database->database_query("DELETE FROM se_video, se_videocomments, se_videotags USING se_video LEFT JOIN se_videocomments ON se_video.video_id=se_videocomments.videocomment_video_id LEFT JOIN se_videotags ON se_video.video_id=se_videotags.videotag_video_id WHERE se_video.video_id IN(".implode(", ", $delete).")");

		return true;
	} // END playlist_video_delete() METHOD

	// THIS METHOD ROTATES SELECTED VIDEO
	// INPUT: $video_id REPRESENTING THE ID OF THE VIDEO TO ROTATE
	//	  $angle REPRESENTING THE NUMBER OF DEGREES TO ROTATE THE IMAGE
	// OUTPUT:
	function playlist_video_rotate($video_id, $dir)
	{
		global $database, $url;

		// ENSURE VIDEO BELONGS TO USER
		$video = $database->database_query("SELECT se_video.* FROM se_video LEFT JOIN se_playlists ON se_video.video_playlist_id=se_playlists.playlist_id WHERE video_id='$video_id' AND playlist_user_id='".$this->user_id."'");
		if($database->database_num_rows($video) != 1) { return; }
		$video_info = $database->database_fetch_assoc($video);

		// GET IMAGE INFORMATION
		$video_path = $url->url_userdir($this->user_id).$video_info[video_id].".".$video_info[video_ext];
		$video_dimensions = @getimagesize($video_path);
		$video_width = $video_dimensions[0];
		$video_height = $video_dimensions[1];

		// ROTATE IMAGE
		switch($video_info[video_ext])
		{
			case "gif":
				$old = imagecreatefromgif($video_path);
				$rotate = imagerotate($old, $dir, 0);
				imagejpeg($rotate, $video_path, 100);
				ImageDestroy($old);
				ImageDestroy($rotate);
				break;
			case "bmp":
				$old = imagecreatefrombmp($video_path);
				$rotate = imagerotate($old, $dir, 0);
				imagejpeg($rotate, $video_path, 100);
				ImageDestroy($old);
				ImageDestroy($rotate);
				break;
			case "jpeg":
			case "jpg":
				$old = imagecreatefromjpeg($video_path);
				$rotate = imagerotate($old, $dir, 0);
				imagejpeg($rotate, $video_path, 100);
				ImageDestroy($old);
				ImageDestroy($rotate);
				break;
			case "png":
				$old = imagecreatefrompng($video_path);
				$rotate = imagerotate($old, $dir, 0);
				imagejpeg($rotate, $video_path, 100);
				ImageDestroy($old);
				ImageDestroy($rotate);
				break;
		} 

		// GET THUMB INFO
		$thumb_path = $url->url_userdir($this->user_id).$video_info[video_id]."_thumb.jpg";
		$thumb_dimensions = @getimagesize($thumb_path);
		$thumb_width = $thumb_dimensions[0];
		$thumb_height = $thumb_dimensions[1];

		// ROTATE THUMB
		$old = imagecreatefromjpeg($thumb_path);
		$rotate = imagerotate($old, $dir, 0);
		imagejpeg($rotate, $thumb_path, 100);
		ImageDestroy($old);
		ImageDestroy($rotate);
	} // END playlist_video_rotate() METHOD
	
	//  moves the specified track up one level in the playlist
	// INPUT: music id number
	function video_moveup($video_id)
	{
		global $database;
		
		$old_track_id = $database->database_fetch_assoc($database->database_query("SELECT video_track_num FROM se_videos WHERE video_id = '$video_id' AND video_user_id='$this->user_id'"));
		$new_track_id = $old_track_id[video_track_num] - 1;
		$previous_track_id = $database->database_fetch_assoc($database->database_query("SELECT video_track_num, video_id FROM se_videos WHERE video_track_num = '$new_track_id' AND video_user_id='$this->user_id'"));
		
		$database->database_query("UPDATE se_videos SET video_track_num ='$new_track_id' WHERE video_track_num = '$old_track_id[video_track_num]' AND video_user_id='$this->user_id' AND video_id = '$video_id' LIMIT 1");
		$database->database_query("UPDATE se_videos SET video_track_num ='$old_track_id[video_track_num]' WHERE video_track_num = '$new_track_id' AND video_user_id='$this->user_id' AND video_id = '$previous_track_id[video_id]' LIMIT 1");
    
		return TRUE;
	}
    
	// Reorders the entire playlist
	// INPUT: video id number
	function video_reorder($video_ids)
	{
		global $database;
    
		if( is_string($video_ids) )
			$video_ids = explode(',', $video_ids);
    
		if( !is_array($video_ids) || empty($video_ids) )
			return FALSE;
    
		// MAKE ORDER
		$video_index = 1;
		foreach( $video_ids as $video_id )
		{
			$sql = "UPDATE se_videos SET video_track_num='{$video_index}' WHERE video_user_id='{$this->user_id}' && video_id='{$video_id}' LIMIT 1";
			$database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
			$video_index++;
		}
    
		return TRUE;
	}
	
}

?>