<?php

function searchInYouTube($searchTerms = '', $startIndex = 1, $maxResults = 50)
{
	$yt = new Zend_Gdata_YouTube(); 
	
	$query = $yt->newVideoQuery();
	// Here are some of the most common VideoQuery methods for setting search parameters:
	// setAuthor() Sets the author of the entry. Author is synonymous with YouTube username.
	// setFormat() Specifies a video format. Accepts numeric parameters to specify one of two kinds of RTSP streaming URLs for mobile video playback or a HTTP URL to the embeddable Flash player.
	// setRacy() Indicates whether restricted content should be included in the results. Accepts only two parameters: 'include' or 'exclude'.
	// setMaxResults() Sets the maximum number of entries to return at one time.
	// setStartIndex() Sets the 1-based index of the first result to be retrieved (for paging).
	// setOrderBy() Sets the order in which to list entries, such as by RELEVANCE, VIEW_COUNT, UPDATED, or RATING.
	// setTime() Sets a time period to limit standard feed results to: TODAY, THIS_WEEK, THIS_MONTH, or ALL_TIME.
	// setVideoQuery() Sets a search query term. Searches for the specified string in all video metadata, such as titles, tags, and descriptions. 
	$query->setOrderBy('viewCount');
	$query->setMaxResults($maxResults);
	$query->setStartIndex($startIndex);
	$query->setVideoQuery($searchTerms);
	$query->setFormat(5);
	
	$videoFeed = $yt->getVideoFeed($query);
	return $videoFeed;
}

function total_favourites()
{
	global $database, $user, $owner;
	
	if($owner->user_exists != 0 && $owner->user_info[user_id])
		$user_id = $owner->user_info[user_id];
	else if($user->user_exists != 0 && $user->user_info[user_id])
		$user_id = $user->user_info[user_id];

	$favourites_query = "SELECT favourite_id FROM se_favourite_video WHERE favourite_user_id = '".$user_id."'";
	
	// GET AND RETURN TOTAL FAVOURITES
	$favourites_total = $database->database_num_rows($database->database_query($favourites_query));
	return $favourites_total;
}

function favourites_list($start, $limit, $sort_by = "video_id DESC", $where = "")
{
	global $database, $user, $owner;
	
	if($owner->user_exists != 0 && $owner->user_info[user_id])
		$user_id = $owner->user_info[user_id];
	else if($user->user_exists != 0 && $user->user_info[user_id])
		$user_id = $user->user_info[user_id];

	$favourites_query = "
		SELECT se_favourite_video.*, se_videos.*
		FROM se_favourite_video
		LEFT JOIN se_videos ON se_favourite_video.favourite_video_id = se_videos.video_id
		WHERE ".($where ? $where . ' AND' : '')." se_favourite_video.favourite_user_id = '".$user_id."'";	
	
	// ADD GROUP BY, ORDER, AND LIMIT CLAUSE
	$favourites_query .= " ORDER BY $sort_by LIMIT $start, $limit";

	// RUN QUERY
	$favourites = $database->database_query($favourites_query);
		
	// GET FAVOURITES INTO AN ARRAY
	$favourite_array = Array();
	//$yt = new Zend_Gdata_YouTube(); 
	while($favourite_info = $database->database_fetch_assoc($favourites))
	{
		//$videoEntry = $yt->getVideoEntry($favourite_info['video_video_id']);
		
		// IF NO USER ID SPECIFIED, CREATE OBJECT FOR AUTHOR
		if($user_id == 0)
		{
			$author = new se_user();
			$author->user_exists = 1;
			$author->user_info[user_id] = $favourite_info[user_id];
			$author->user_info[user_username] = $favourite_info[user_username];
			$author->user_info[user_fname] = $favourite_info[user_fname];
			$author->user_info[user_lname] = $favourite_info[user_lname];
			$author->user_info[user_photo] = $favourite_info[user_photo];
			$author->user_displayname();

			// OTHERWISE, SET AUTHOR TO OWNER/LOGGED-IN USER
		}
		elseif($owner->user_exists != 0 && $owner->user_info[user_id] == $favourite_info[favourite_user_id])
		{
			$author = $owner;
		}
		elseif($user->user_exists != 0 && $user->user_info[user_id] == $favourite_info[favourite_user_id])
		{
			$author = $user;
		}

		/*
		// Thumbnails
		$videoThumbnailUrl = '';
		$videoThumbnails = $videoEntry->getVideoThumbnails();
		foreach($videoThumbnails as $videoThumbnail)
		{
			if(isset($videoThumbnail['url']) && $videoThumbnail['url'])
			{
				$videoThumbnailUrl = $videoThumbnail['url'];
				$videoThumbnailWidth = $videoThumbnail['width'];
				$videoThumbnailHeight = $videoThumbnail['height'];
				break;
			}
		}
		*/
		$videoThumbnailUrl = 'get_video_thumbnail.php?video_id='.$favourite_info['video_id'];
		$videoThumbnailWidth = $favourite_info['video_thumbnail_width'];
		$videoThumbnailHeight = $favourite_info['video_thumbnail_height'];
		
		/*
		$videoTitle = $videoEntry->getVideoTitle();
		
		// GET PATH OF PLAYLIST  
		$favourite_cover_id = 0;
		$favourite_cover_ext = "";
		$sExtension = substr( $videoThumbnailUrl, ( strrpos($videoThumbnailUrl, '.') + 1 ) ) ;
		$sExtension = strtolower( $sExtension ) ;
				
		if($videoThumbnailUrl)
		{
			$favourite_cover_id = $favourite_info[favourite_id];
			$favourite_cover_ext = $sExtension;
		}
		*/
		
		$videoTitle = $favourite_info['video_title'];
		$favourite_cover_id = 0;
		$favourite_cover_ext = "";
		
		$sExtension = $favourite_info['video_thumbnail_extension'];
				
		if($videoThumbnailUrl)
		{
			$favourite_cover_id = $favourite_info['favourite_id'];
			$favourite_cover_ext = $sExtension;
		}
		
		$favourite_info[video_updated] = strtotime($favourite_info[video_updated]);
		
		$favourite_array[] = Array(
			'favourite_id' => $favourite_info[favourite_id],
			'favourite_video_id' => $favourite_info[favourite_video_id],
			'favourite_user_id' => $favourite_info[favourite_user_id],
			'favourite_playlist_id' => $favourite_info[video_playlist_id],
			'favourite_author' => $author,
			'favourite_datecreated' => $favourite_info[video_updated],
			'favourite_dateupdated' => $favourite_info[video_updated],
			'favourite_dateupdated_raw' => $favourite_info[video_updated],
			'favourite_title' => $favourite_info[video_title],
			'favourite_desc' => $favourite_info[video_description],
			'favourite_cover_id' => $favourite_cover_id,
			'favourite_cover_ext' => $favourite_cover_ext,
			/*'favourite_views' => $favourite_info[video_view_count],*/
			'favourite_thumbnail_url' => $videoThumbnailUrl,
			'favourite_thumbnail_width' => $videoThumbnailWidth,
			'favourite_thumbnail_height' => $videoThumbnailHeight,);
	}
	// RETURN ARRAY
	
	return $favourite_array;
}

function get_resized($image_path = '', $extension = '', $width = false, $height = false)
{
	$orig_img = image_from_source($image_path);
	$or_x = $_x = imagesx($orig_img);
	$or_y = $_y = imagesy($orig_img);
	$dst_x = $dst_y = 0;
	if (!($width))
		$width = $or_x;
	if (!($height))
		$height = $or_y;
	if ($_x > $width || $_y > $height)
	{
		if ($or_x * $height > $or_y * $width)
		{
			$_x = $width;
			$_y = $_x * $or_y / $or_x;
		}
		else
		{
			$_y = $height;
			$_x = $_y * $or_x / $or_y;
		};
	};
	$img = imagecreatetruecolor($_x, $_y);
	imagecopyresized($img, $orig_img, $dst_x, $dst_y, 0, 0, $_x, $_y, $or_x, $or_y);
	if(is_resource($img) === false)	
		return false;	
	return create_image_by_resource($img, $extension);
}
	
function get_resampled($image_path = '', $extension = '', $width = false, $height = false)
{
	$orig_img = image_from_source($image_path);
	$h_y = $h_x = 0;
	$or_x = $_x = imagesx($orig_img);
	$or_y = $_y = imagesy($orig_img);
	if (!($width))
		$width = $or_x;
	if (!($height))
		$height = $or_y;
	$img = imagecreatetruecolor($width, $height);
	if ($or_x * $height > $width * $or_y)
	{
		$_x = round($or_y / $height * $width);
		$h_x = round(($or_x - $_x) / 2);
	}
	else
	{
		$_y = round($or_x / $width * $height);
		$h_y = round(($or_y - $_y) / 2);
	};
	imagecopyresampled($img, $orig_img, 0, 0, $h_x, $h_y, $width, $height, $_x, $_y);
	if(is_resource($img) === false)	
		return false;
	return create_image_by_resource($img, $extension);
}

function image_from_source($source)
{
	$img = file_exists($source)
		? imagecreatefromstring(file_get_contents($source))
		: imagecreatefromstring($source);
	
	if(is_resource($img) === false)	
		return false;	
	return $img;
}

function create_image_by_resource($resource, $extension = 'jpg')
{
	$postfix = (strtolower($extension) == 'jpg')? 'jpeg': strtolower($extension);
	$function = 'image'.$postfix;	
	
	ob_start();
	
	if(function_exists($function) && $function($resource) === false)
	{
		ob_end_clean();
		return false;	
	}
	if(!function_exists($function))	
	{
		ob_end_clean();
		return false;
	}
		
	$sImg = ob_get_contents();
	ob_end_clean();
	
	return $sImg;		
}

// THIS FUNCTION IS RUN WHEN A USER IS DELETED
// INPUT: $user_id REPRESENTING THE USER ID OF THE USER BEING DELETED
// OUTPUT: 
function deleteuser_playlist($user_id)
{
	global $database;

	// DELETE PLAYLISTS, MEDIA, AND COMMENTS
	$database->database_query("DELETE FROM se_playlists, se_video, se_videos, se_favourite_video, se_videocomments, se_videotags USING se_playlists LEFT JOIN se_video ON se_playlists.playlist_id=se_video.video_playlist_id LEFT JOIN se_videos ON se_playlists.playlist_id=se_videos.video_playlist_id LEFT JOIN se_videocomments ON se_video.video_id=se_videocomments.videocomment_video_id LEFT JOIN se_videotags ON se_video.video_id=se_videotags.videotag_video_id LEFT JOIN se_favourite_video ON se_videos.video_id = se_favourite_video.favourite_video_id WHERE se_playlists.playlist_user_id = '$user_id'");

	// DELETE TAGS OF USER
	$database->database_query("UPDATE se_videotags SET videotag_user_id='0' WHERE videotag_user_id = $user_id");

	// DELETE STYLE
	$database->database_query("DELETE FROM se_playliststyles WHERE playliststyle_user_id= ' $user_id'");

} // END deleteuser_playlist() FUNCTION

function search_video()
{
	global $database, $url, $results_per_page, $p, $search_text, $t, $search_objects, $results, $total_results;

	// CONSTRUCT QUERY
	$video_query = "
	(
	SELECT
          '1' AS sub_type,
	  se_videos.video_playlist_id AS playlist_id,
	  se_videos.video_title AS title,
	  se_videos.video_description AS description,
	  se_videos.video_id AS video_id,
	  se_videos.video_thumbnail_extension AS video_ext,
	  se_users.user_id,
	  se_users.user_username,
	  se_users.user_photo,
	  se_users.user_fname,
	  se_users.user_lname
	FROM
	  se_videos,
	  se_playlists,
	  se_users,
	  se_levels
	WHERE
	  se_videos.video_playlist_id = se_playlists.playlist_id AND
	  se_playlists.playlist_user_id = se_users.user_id AND
	  se_users.user_level_id = se_levels.level_id AND
	  (
	    se_playlists.playlist_search = '1' OR
	    se_levels.level_playlist_search = '0'
	  )
	  AND
	  (
	    se_videos.video_title LIKE '%$search_text%' OR
	    se_videos.video_description LIKE '%$search_text%'
	  )
	ORDER BY video_id DESC
	)
	UNION ALL
	(
	SELECT
	  '2' AS sub_type,
	  se_playlists.playlist_id AS playlist_id,
	  se_playlists.playlist_title AS title,
	  se_playlists.playlist_desc AS description,
	  se_playlists.playlist_cover AS video_id,
	  se_video.video_ext AS video_ext,
	  se_users.user_id,
	  se_users.user_username,
	  se_users.user_photo,
	  se_users.user_fname,
	  se_users.user_lname
	FROM
	  se_playlists,
	  se_users,
	  se_levels
	LEFT JOIN se_video ON se_video.video_id = se_playlists.playlist_cover  
	WHERE
	  se_playlists.playlist_user_id = se_users.user_id AND
	  se_users.user_level_id = se_levels.level_id AND
	  (
	    se_playlists.playlist_search = '1' OR
	    se_levels.level_playlist_search = '0'
	  )
	  AND
	  (
	    se_playlists.playlist_title LIKE '%$search_text%' OR
	    se_playlists.playlist_desc LIKE '%$search_text%'
	  )
	GROUP BY playlist_id ORDER BY playlist_id DESC
	)"; 
	
	// GET TOTAL RESULTS
	$total_videos = $database->database_num_rows($database->database_query($video_query));
	
	// IF NOT TOTAL ONLY
	if($t == "video")
	{
		// MAKE PLAYLIST PAGES
		$start = ($p - 1) * $results_per_page;
		$limit = $results_per_page+1;

		// SEARCH PLAYLISTS
		$videos = $database->database_query($video_query." ORDER BY video_id DESC LIMIT $start, $limit");
		while($video_info = $database->database_fetch_assoc($videos))
		{
			// CREATE AN OBJECT FOR USER
			$profile = new se_user();
			$profile->user_info[user_id] = $video_info[user_id];
			$profile->user_info[user_username] = $video_info[user_username];
			$profile->user_info[user_fname] = $video_info[user_fname];
			$profile->user_info[user_lname] = $video_info[user_lname];
			$profile->user_info[user_photo] = $video_info[user_photo];
			$profile->user_displayname();

			// RESULT IS A VIDEO
			if($video_info[sub_type] == 1)
			{
				$result_url = $url->url_create('video_view', $video_info[user_username], $video_info[playlist_id], $video_info[video_id]);
				$result_name = 5000119;
				$result_desc = 5000121;

				// RESULT IS AN PLAYLIST
			}
			else
			{
				$result_url = $url->url_create('video', $video_info[user_username], $video_info[playlist_id]);
				$result_name = 5000120;
				$result_desc = 5000122;
			}
			
			// SET THUMBNAIL, IF AVAILABLE
			switch($video_info[video_ext])
			{
				case "jpeg":
				case "jpg":
				case "gif":
				case "png":
				case "bmp":
					if($video_info[sub_type] == 1)
						$thumb_path = 'get_video_thumbnail.php?video_id='.$video_info['video_id'];
					else 
						$thumb_path = $url->url_userdir($video_info[user_id]).$video_info[video_id]."_thumb.jpg";	
					break;
				default:
					$thumb_path = "./images/icons/file_big.gif";
			}

			// IF NO TITLE
			if($video_info[title] == "") { SE_Language::_preload(589); SE_Language::load(); $video_info[title] = SE_Language::_get(589); }

			// IF DESCRIPTION IS LONG
			if(strlen($video_info[description]) > 150) { $video_info[description] = substr($video_info[description], 0, 147)."..."; }

			$results[] = Array(
				'result_url' => $result_url,
				'result_icon' => $thumb_path,
				'result_name' => $result_name,
				'result_name_1' => $video_info[title],
				'result_desc' => $result_desc,
				'result_desc_1' => $url->url_create('profile', $video_info[user_username]),
				'result_desc_2' => $profile->user_displayname,
				'result_desc_3' => $video_info[description]);
		}

		// SET TOTAL RESULTS
		$total_results = $total_videos;

	}

	// SET ARRAY VALUES
	SE_Language::_preload_multi(5000118, 5000119, 5000120, 5000121, 5000122);
	
	$search_objects[] = Array('search_type' => 'video',
				'search_lang' => 5000118,
				'search_total' => $total_videos);
}

function get_embed_str($flash_player_url)
{
	$embed_str = '
		<object width="425" height="350">
			<param name="movie" value="MEDIA_CONTENT_URL"></param>
				<embed src="MEDIA_CONTENT_URL" type="MEDIA_CONTENT_TYPE" width="425" height="350">
			</embed>
		</object>';
	$search_arr = array('MEDIA_CONTENT_URL', 'MEDIA_CONTENT_TYPE');
	$media_content_url = $flash_player_url;
	$media_content_type = 'application/x-shockwave-flash';
	$replace_arr = array($media_content_url, $media_content_type);
	$embed_str = str_replace($search_arr, $replace_arr, $embed_str);

	return $embed_str;
}

?>
