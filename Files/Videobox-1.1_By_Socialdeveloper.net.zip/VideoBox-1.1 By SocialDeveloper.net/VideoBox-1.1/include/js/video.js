function import_form_submit(playlist_id)
{
	form_name = "import_form_" + playlist_id;
	document.forms[form_name].submit();
}

var SocialEngineVideo = new Class({
  
  options: {
    'ajaxURL' : 'video_ajax.php'
  },
  
  
  sortablesEffect: null,
  
  
  currentConfirmDeleteID: 0,
  
  
  
  initialize: function()
  {
    var bind = this;
    window.addEvent('domready', function()
    {
      if( !$$('.seVideoRow').length ) return;
      
      bind.sortablesEffect = new Sortables($$('.userVideoList'),
      {
        constrain: true,
        clone: false,
        revert: true,
        handle: '.seVideoMoveHandle',
        opacity: 0.6
      });
      
      bind.sortablesEffect.addEvent('complete', function()
      {
        bind.sendFullVideoOrder();
      });
      
    });
  },
  
  
  // Move Up
  moveUpVideo: function(videoID)
  {
    // Ajax
    var request = new Request.JSON({
      'method' : 'post',
      'url' : this.options.ajaxURL,
      'data' : {
        'task' : 'moveupvideo',
        'video_id' : videoID
      },
      'onComplete':function(responseObject)
      {
        if( $type(responseObject)!="object" || !responseObject.result || responseObject.result=="failure" )
        {
          //alert('There was an error processing your move request.');
        }
      }
    });
    
    request.send();
    
    // Switch the element's order.
    var videoContainer = $('seVideo_' + videoID);
    var previousContainer = videoContainer.getPrevious();
    videoContainer.inject(previousContainer, 'before');
    
    // Make it so the first one can't move up
    this.refreshMoveUpButtons();
  },
  
  
  sendFullVideoOrder: function()
  {
    var isFirst = true;
    var order = '';
    $$('.seVideoRow').each(function(videoRowElement)
    {
      var videoID = videoRowElement.getElement('.seVideoID').getProperty('html');
      if( !isFirst ) order += ',';
      order += videoID;
      isFirst = false;
    });
    
    // Ajax
    var request = new Request.JSON({
      'method' : 'post',
      'url' : this.options.ajaxURL,
      'data' : {
        'task' : 'reordervideo',
        'video_order' : order
      },
      'onComplete':function(responseObject)
      {
        if( $type(responseObject)!="object" || !responseObject.result || responseObject.result=="failure" )
        {
          //alert('There was an error processing your move request.');
        }
      }
    });
    
    request.send();
    
    // Make it so the first one can't move up
    this.refreshMoveUpButtons();
  },
  
  
  refreshMoveUpButtons: function()
  {
    /*
    var isFirst = true;
    $$('.seVideoRow').each(function(rowElement)
    {
      if( isFirst )
      {
        rowElement.getElement('.seVideoMoveUp').style.display = 'none';
        rowElement.getElement('.seVideoMoveDisabled').style.display = '';
      }
      else
      {
        rowElement.getElement('.seVideoMoveUp').style.display = '';
        rowElement.getElement('.seVideoMoveDisabled').style.display = 'none';
      }
      isFirst = false;
    });
    */
  },
  
  
  
  // Delete
  deleteVideo: function(videoID)
  {
    // Display
    this.currentConfirmDeleteID = videoID;
    TB_show(SELanguage.Translate(4000038), '#TB_inline?height=100&width=300&inlineId=confirmvideodelete', '', '../images/trans.gif');
  },
  
  deleteVideoConfirm: function(videoID)
  {
    // Ajax
    var request = new Request.JSON({
      'method' : 'post',
      'url' : this.options.ajaxURL,
      'data' : {
        'task' : 'deletevideo',
        'video_id' : videoID
      },
      'onComplete':function(responseObject)
      {
        if( $type(responseObject)!="object" || !responseObject.result || responseObject.result=="failure" )
        {
          //alert('There was an error processing your delete request.');
        }
      }
    });
    
    request.send();
    
    // Destroy
    if( this.sortablesEffect )
      this.sortablesEffect.removeItems($('seVideo_' + videoID));
    
    $('seVideo_' + videoID).destroy();
    
    this.refreshMoveUpButtons();
  },
  
  
  
  // Editing
  editVideoTitle: function(videoID)
  {
    // Get title
    var videoTitleContainer = $('seVideo_' + videoID);
    var videoTitle = videoTitleContainer.getElement('.seVideoTitle').getProperty('html');
    
    // Set title
    var videoTitleInput = videoTitleContainer.getElement('.seVideoTitleEditor').getElement('input');
    videoTitleInput.setProperty('value', videoTitle);
    
    // Display
    this.showVideoTitleEditor(videoID);
    
    // Focus
    videoTitleInput.focus();
    videoTitleInput.select();
  },
  
  saveVideoTitle: function(videoID)
  {
    // Get title
    var videoTitleContainer = $('seVideo_' + videoID);
    var videoTitle = videoTitleContainer.getElement('.seVideoTitleEditor').getElement('input').getProperty('value');
    
    // Ajax
    var request = new Request.JSON({
      'method' : 'post',
      'url' : this.options.ajaxURL,
      'data' : {
        'task' : 'editvideotitle',
        'video_id' : videoID,
        'video_title' : videoTitle
      },
      'onComplete':function(responseObject)
      {
        if( $type(responseObject)!="object" || !responseObject.result || responseObject.result=="failure" )
        {
          //alert('There was an error processing your edit request.');
        }
      }
    });
    
    request.send();
    
    // Set title
    videoTitleContainer.getElement('.seVideoTitle').setProperty('html', videoTitle);
    
    // Display
    this.hideVideoTitleEditor(videoID);
  },
  
  cancelVideoTitle: function(videoID)
  {
    // Display
    this.hideVideoTitleEditor(videoID);
  },
  
  showVideoTitleEditor: function(videoID)
  {
    var videoTitleContainer = $('seVideo_' + videoID);
    
    videoTitleContainer.getElement('.seVideoTitle').style.display = 'none';
    videoTitleContainer.getElement('.seVideoTitleEdit').style.display = 'none';
    
    videoTitleContainer.getElement('.seVideoTitleEditor').style.display = '';
    videoTitleContainer.getElement('.seVideoTitleSave').style.display = '';
    videoTitleContainer.getElement('.seVideoTitleCancel').style.display = '';
  },
  
  hideVideoTitleEditor: function(videoID)
  {
    var videoTitleContainer = $('seVideo_' + videoID);
    
    videoTitleContainer.getElement('.seVideoTitle').style.display = '';
    videoTitleContainer.getElement('.seVideoTitleEdit').style.display = '';
    
    videoTitleContainer.getElement('.seVideoTitleEditor').style.display = 'none';
    videoTitleContainer.getElement('.seVideoTitleSave').style.display = 'none';
    videoTitleContainer.getElement('.seVideoTitleCancel').style.display = 'none';
  }

});