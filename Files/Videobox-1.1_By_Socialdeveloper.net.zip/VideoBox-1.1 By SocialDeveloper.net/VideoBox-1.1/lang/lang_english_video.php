<?

// SET GENERAL VARIABLES, AVAILABLE ON EVERY PAGE
$video_plugin[1] = "Video";

// ASSIGN ALL SMARTY GENERAL VIDEO VARIABLES
reset($video_plugin);
while(list($key, $val) = each($video_plugin))
	$smarty->assign("video_plugin_".$key, $val);

// SET LANGUAGE PAGE VARIABLES
switch ($page)
{
	case "user_video":
		$user_video[1] = "";
		$user_video[2] = "";
		$user_video[3] = "";
		break;
}

// ASSIGN ALL SMARTY VARIABLES
if(is_array(${"$page"}))
{
	reset(${"$page"});
	while(list($key, $val) = each(${"$page"}))
	{
		$smarty->assign($page.'_'.$key, $val);
	}
}
?>