<?php

ob_start();
include "header.php";

$task = ( !empty($_POST['task']) ? $_POST['task'] : ( !empty($_GET['task']) ? $_GET['task'] : NULL ) );
$user_id = ( !empty($_POST['user_id']) ? $_POST['user_id'] : ( !empty($_GET['user_id']) ? $_GET['user_id'] : NULL ) );
$video_id = ( !empty($_POST['video_id']) ? $_POST['video_id'] : ( !empty($_GET['video_id']) ? $_GET['video_id'] : NULL ) );
$video_order = ( !empty($_POST['video_order']) ? $_POST['video_order'] : ( !empty($_GET['video_order']) ? $_GET['video_order'] : NULL ) );
$video_title = ( !empty($_POST['video_title']) ? $_POST['video_title'] : ( !empty($_GET['video_title']) ? $_GET['video_title'] : NULL ) );

if( $task == "reordervideo" )
{
	if( empty($user) || !$user->user_exists || !$user->level_info['level_playlist_allow'] )
		$is_error = 1;

	$video = new se_playlist($user->user_info['user_id']);

	// OUTPUT
	ob_end_clean();
  
	if( !$is_error && $video->video_reorder($video_order) )
		echo '{"result":"success"}';
	else
		echo '{"result":"failure"}';
		
	exit();
}


?>