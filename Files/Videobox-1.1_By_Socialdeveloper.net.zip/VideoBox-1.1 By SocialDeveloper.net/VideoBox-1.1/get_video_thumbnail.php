<?php
// INCLUDE DATABASE INFORMATION
include "include/database_config.php";

include "include/class_database.php";
include "include/functions_general.php";

$database = new se_database($database_host, $database_username, $database_password, $database_name);

$video_id = isset($_GET['video_id']) ? intVal($_GET['video_id']) : 0;

$sql = "
	SELECT *
	FROM se_videos
	WHERE video_id = '".$video_id."'";
$video = $database->database_query($sql);
$video_info = $database->database_fetch_assoc($video);

$img = (isset($video_info['video_thumbnail_image']) && $video_info['video_thumbnail_image'] ? $video_info['video_thumbnail_image'] : false);
if(!$img)
	return false;

$img = imagecreatefromstring($img);

header("Pragma: public");
header("Content-Type: image/jpeg");
header("Content-Transfer-Encoding: binary");
header("Cache-Control: must-revalidate");
$ExpStr = "Expires: " . gmdate("D, d M Y H:i:s", time() - 30) . " GMT";
header($ExpStr);
imagejpeg($img);
imagedestroy($img);

?>