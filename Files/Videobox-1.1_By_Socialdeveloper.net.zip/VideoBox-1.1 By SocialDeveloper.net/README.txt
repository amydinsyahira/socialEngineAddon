Video Box v1.1 By SocialDeveloper.net

Notes:
Copyright and legal stuff belongs to everyone at SocialDeveloper.net 
If you have any problems, please email us at support@socialdeveloper.net 


Requirements:
PHP5 
Most Recent Version of SE

Important:
Make sure you have PHP5 Enabled, if your unsure, contact your host and ask them. The script will fail and explode if its not enabled so make sure!

Important:
Also make sure your not using the SE Video plugin. The files will overwrite each other so who knows what will happen if you forget that. 





Install Instructions:
Upload all the files to your SE directory as you would any other plugin. 

CHMOD all the files in the /templates folder to 777

Login to the admin panel and navigate on over to the Plugins directory and Click install plugin. 

Once that completes, make sure to delete the file install_video.php file out of the admin folder.






Directory URLS:
The first sample is the code most users will use for people that have SE at the root of their site. 

If you have SE installed in a sub directory, look at the 2nd code to see how you would format your URLS. 

We can configure it for you for a small fee if you can't get it to work so just email us if you have any problems.

Just paste the code into your .htaccess that holds the rest of your directory url stuff. The sample url is for reference to see how you would format the code

//Sample SE URL- http://mydomain.com/home.php

RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/?$ /videos.php?user=$1 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/favourites/?$ /favourite_video.php?user=$1 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/([0-9]+)/?$ /video.php?user=$1&playlist_id=$2 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/([0-9]+)/([0-9]+)/?$ /video_file.php?user=$1&playlist_id=$2&video_id=$3 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/video/([0-9]+)/([0-9]+)/?$ /video_view.php?user=$1&playlist_id=$2&video_id=$3 [L]


//Sample SE URL2- http://mydomain.com/sefolder/home.php

RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/?$ /sefolder/videos.php?user=$1 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/favourites/?$ /sefolder/favourite_video.php?user=$1 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/([0-9]+)/?$ /sefolder/video.php?user=$1&playlist_id=$2 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/([0-9]+)/([0-9]+)/?$ /sefolder/video_file.php?user=$1&playlist_id=$2&video_id=$3 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/playlists/video/([0-9]+)/([0-9]+)/?$ /sefolder/video_view.php?user=$1&playlist_id=$2&video_id=$3 [L]








