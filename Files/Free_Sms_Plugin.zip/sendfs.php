 <?php

//Set API variables
$API['KEY'] = "Gcvu7kdFnqAIb7lIIQGIP07vxUTeOWLNKtje6ardUkni2gyZOcEZxuIEv6rU382";
$API['VERSION'] = "1.03";

if(isset($_REQUEST['startTrial']))
{
  $arrArgs['user_name'] = $_REQUEST['user_name'];
  $arrArgs['user_mobile'] = $_REQUEST['user_mobile'];

  foreach($_REQUEST['friend_name'] as $key => $value)
    {
      $arrArgs['friend_name['.$key.']'] = $value;
    }
  foreach($_REQUEST['friend_mobile'] as $key => $value)
    {
      $arrArgs['friend_mobile['.$key.']'] = $value;
    }
  $arrArgs['message'] = $_REQUEST['message'];
  $arrArgs['method'] = "3jam.trial.startNew";
  
  $result = send_to_server($arrArgs);

  if(preg_match("/<rsp stat=\"ok\">/",$result))
    {
      //Start 3jam trial request successful. Now display captcha

      preg_match("/<conversation id=\"(.*)\"/",$result,$matches);
      $conversation_id = $matches[1];

      display_captcha($conversation_id);
    }
  else
    {
      //Error found so re-display form and error
      preg_match("/msg=\"(.*)\"/",$result,$matches);
      $sErrorMsg = $matches[1];

      display_form($sErrorMsg);      
    }
}
else if(isset($_REQUEST['submitCaptcha']))
{
  $arrArgs['conversation_id'] = $_REQUEST['conversation_id'];
  $arrArgs['verification_captcha'] = $_REQUEST['verification_captcha'];
  $arrArgs['method'] = "3jam.trial.confirmCaptcha";

  $result = send_to_server($arrArgs);

  if(preg_match("/<rsp stat=\"ok\">/",$result))
    {
      //Captcha verification successful. Mobile verification code sent, now ask user to input it.
      display_mobile_verification($_REQUEST['conversation_id']);
    }
  else
    {
      //Error found so re-display form and error
      preg_match("/msg=\"(.*)\"/",$result,$matches);
      $sErrorMsg = $matches[1];

      display_captcha($_REQUEST['conversation_id'],$sErrorMsg);
    }
}
else if(isset($_REQUEST['submitMobileVerification']))
{
  $arrArgs['conversation_id'] = $_REQUEST['conversation_id'];
  $arrArgs['verification_code'] = $_REQUEST['verification_code'];
  $arrArgs['method'] = "3jam.trial.confirmTrial";

  $result = send_to_server($arrArgs);

  if(preg_match("/<rsp stat=\"ok\">/",$result))
    {
      //Submit mobile verification code successful
      display_3jam_started();
    }
  else
    {
      //Error found so re-display form and error
      preg_match("/msg=\"(.*)\"/",$result,$matches);
      $sErrorMsg = $matches[1];

      display_mobile_verification($_REQUEST['conversation_id'],$sErrorMsg);
    }
}
else
{
  display_form();
}


function send_to_server($arrArgs)
{
  global $API;

  //Set API Version number
  $arrArgs['api_version'] = $API['VERSION'];

  //Set API URL
  $url = "https://api.3jam.com/webapi.php";

  //Set authentication keys

  $arrArgs['api_key'] = $API['KEY'];

  $creq = curl_init();
  curl_setopt($creq, CURLOPT_URL, $url);
  curl_setopt($creq, CURLOPT_TIMEOUT, 20); //set timeout in case other side hangs, which won't return for a while
  curl_setopt($creq, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($creq, CURLOPT_POST,1);
  curl_setopt($creq, CURLOPT_POSTFIELDS, $arrArgs);
  curl_setopt($creq, CURLOPT_SSL_VERIFYPEER, FALSE); //Turn off certificate verification so Curl works
  $curl_result = curl_exec($creq);

  if(curl_errno($creq))
    {
      //If there's a problem with Curl on your machine
      print "Curl error on local machine: ".curl_error($creq);
    }
  
  return $curl_result;
}

function display_form($sErrorMsg='')
{
  $html = '

<center>
'.($sErrorMsg == '' ? '' : '<font color="red">'.$sErrorMsg.'</font>').'
<table border="0">
<tr><td><div style="font-size=10pt; color: #333333;">Your Name, Lastname</div></td><td><div style="font-size=10pt; color: #333333;">Your Nr:<BR>(+40763678022)</div></td></tr>
<tr><form action="'.$_SERVER['SCRIPT_NAME'].'" method="post">

<td><input type="text" name="user_name" style="border: 1px solid #AAAAAA; font-family: arial, verdana, serif; font-size: 9pt; color: #333333; vertical-align: middle; padding-left: 2px;" value="'.(!empty($_REQUEST['user_name']) ? $_REQUEST['user_name'] : "").'"></td>
<td><input type="text" name="user_mobile" style="border: 1px solid #AAAAAA; font-family: arial, verdana, serif; font-size: 9pt; color: #333333; vertical-align: middle; padding-left: 2px;" value="'.(!empty($_REQUEST['user_mobile']) ? $_REQUEST['user_mobile'] : "").'"></td></tr>

<tr><td><div style="font-size=10pt; color: #333333;">Your Friend Name:</div></td><td><div style="font-size=10pt; color: #333333;">Your Friend Nr: (+407........)</div></td></tr> <tr><td>
<input type="text" name="friend_name[1]" style="border: 1px solid #AAAAAA; font-family: arial, verdana, serif; font-size: 9pt; color: #333333; vertical-align: middle; padding-left: 2px;" value="'.(!empty($_REQUEST['friend_name'][1]) ? $_REQUEST['friend_name'][1] : "").'"></td>
<td><input type="text" name="friend_mobile[1]" style="border: 1px solid #AAAAAA; font-family: arial, verdana, serif; font-size: 9pt; color: #333333; vertical-align: middle; padding-left: 2px;" value="'.(!empty($_REQUEST['friend_mobile'][1]) ? $_REQUEST['friend_mobile'][1] : "").'"></td></tr>


<tr><td><div style="font-size: 9pt; color: #333333;">Your Msg:</div></td><td>&nbsp;</td></tr>
<tr><td colspan="2"><textarea name="message" cols="30" rows="3">'.(isset($_REQUEST['message']) ? $_REQUEST['message'] : "Type your message here. remember that you have only 100 characters. ").'</textarea></td></tr>
<tr><td colspan="2"><input type="submit" name="startTrial" value="Next" style="font-family: arial, verdana, serif; font-size: 8pt;	padding: 3px; color: #333333; font-weight: bold; background: #EEEEEE; vertical-align: middle; border-top: 1px solid #CCCCCC; border-left: 1px solid #CCCCCC; border-bottom: 1px solid #777777; border-right: 1px solid #777777;
">





</td></tr>
</form>';

print $html;
}

function display_captcha($conversation_id,$sErrorMsg='')
{
  $html = '<center>


<h3 style="font-size=10pt; color: #333333;">Type the code:</h3></center><center>
'.($sErrorMsg == '' ? '' : '<font color="red">'.$sErrorMsg.'</font>').'
<p><img src="http://api.3jam.com/captcha?id='.$conversation_id.'" width="200" height="60" /></p>
<form action="'.$_SERVER['SCRIPT_NAME'].'" method="post">
<input type="text" name="verification_captcha" style="border: 1px solid #AAAAAA; font-family: arial, verdana, serif; font-size: 9pt; color: #333333; vertical-align: middle; padding-left: 2px;">
<input type="hidden" name="conversation_id" value="'.$conversation_id.'">
<BR>
<input type="submit" name="submitCaptcha" value="Next" style="font-family: arial, verdana, serif; font-size: 8pt;	padding: 3px; color: #333333; font-weight: bold; background: #EEEEEE; vertical-align: middle; border-top: 1px solid #CCCCCC; border-left: 1px solid #CCCCCC; border-bottom: 1px solid #777777; border-right: 1px solid #777777;">
</form>




<BR>';

  print $html;
}

function display_mobile_verification($conversation_id,$sErrorMsg='')
{
  $html = '


<center><h3 style="font-size=10pt; color: #333333;">Enter Verification code</h3>
'.($sErrorMsg == '' ? '' : '<font color="red">'.$sErrorMsg.'</font>').'
<form action="'.$_SERVER['SCRIPT_NAME'].'" method="post">
<input type="text" name="verification_code" style="border: 1px solid #AAAAAA; font-family: arial, verdana, serif; font-size: 9pt; color: #333333; vertical-align: middle; padding-left: 2px;">
<input type="hidden" name="conversation_id" value="'.$conversation_id.'">
<BR>
<input type="submit" name="submitMobileVerification" value="Send SMS" style="font-family: arial, verdana, serif; font-size: 8pt;	padding: 3px; color: #333333; font-weight: bold; background: #EEEEEE; vertical-align: middle; border-top: 1px solid #CCCCCC; border-left: 1px solid #CCCCCC; border-bottom: 1px solid #777777; border-right: 1px solid #777777;">
</form>
<div style="font-size=10pt; color: #333333;">This code will arrive on your phone in 10 min max.</div> </center>





<BR>';

  print $html;
}

function display_3jam_started()
{
  $html = '<center>
<h3 style="font-size=10pt; color: #333333;">Your SMS has been send</h3>
</center>

<div style="font-size=10pt; color: #333333;">Click  <a href="'.$_SERVER['PHP_SELF'].'">Here</a> and send more.</div>';
  print $html;
}

?>