<?
// FIVE4U.NET  FREESMS FILE
$page = "freesms";
include "header.php";

// INCLUDE EXAMPLE LANGUAGE FILE
include "./lang/lang_".$global_lang."_freesms.php";

// IF PREVIOUSLY LOGGED IN EMAIL COOKIE AVAILABLE, SET IT
if(isset($_COOKIE['prev_email'])) { $prev_email = $_COOKIE['prev_email']; } else { $prev_email = ""; }
include "footer.php";
?>