<?php
$page = "smart_friend_search";
include "header.php";


// THIS FILE CONTAINS RANDOM JAVASCRIPT-Y FEATURES SUCH AS POSTING COMMENTS AND DELETING ACTIONS
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = ""; }


// AUTOSUGGEST FRIEND
if($task == "suggest_friend") {

  // GET USER INPUT AND LIMIT
  $input = strtolower( $_GET['input'] );
  $len = strlen($input);
  $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 20;
	
  // RETRIEVE FITTING FRIENDS
  $aResults = array();
  $friends = $database->database_query("SELECT user_id, user_username, user_photo FROM se_friends LEFT JOIN se_users ON se_friends.friend_user_id1='".$user->user_info[user_id]."' AND se_users.user_id=se_friends.friend_user_id2 WHERE SUBSTRING(user_username, 1, $len)='$input' LIMIT $limit");
  while($friend_info = $database->database_fetch_assoc($friends)) {
	$friend = new se_user();
	$friend->user_info[user_id] = $friend_info[user_id];
    	$friend->user_info[user_username] = $friend_info[user_username];
    	$friend->user_info[user_fname] = $friend_info[user_fname];
    	$friend->user_info[user_lname] = $friend_info[user_lname];
    	$friend->user_info[user_photo] = $friend_info[user_photo];
	//$friend->user_displayname();

	//if(!$setting[setting_username]) { $friend_info[user_username] = $friend->user_displayname; }

	$aResults[] = array( "id"=>$friend_info[user_id] ,"value"=>$friend_info[user_username], "info"=>$friend_info[user_username], "photo"=>$friend->user_photo("./images/nophoto.gif"), "photo_width"=>$misc->photo_size($friend->user_photo("./images/nophoto.gif"),'50','50','w'));
  }
	
  // OUTPUT JSON
  header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
  header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // always modified
  header ("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
  header ("Pragma: no-cache"); // HTTP/1.0
  header("Content-Type: application/json");
  echo "{\"results\": [";
  $arr = array();
  for ($i=0;$i<count($aResults);$i++) {
	$arr[] = "{\"id\": \"".$aResults[$i]['id']."\", \"value\": \"".$aResults[$i]['value']."\", \"info\": \"".$aResults[$i]['info']."\", \"photo\": \"".$aResults[$i]['photo']."\", \"photo_width\": \"".$aResults[$i]['photo_width']."\"}";
  }
  echo implode(", ", $arr);
  echo "]}";
  exit();

}

?>