<?

//LANG VARS
$smart_friend_lang1 = "Smart Friend Search";
$smart_friend_lang2 = "Go";


// ASSIGN SMARTY VARS
$smarty->assign('smart_friend_lang1', $smart_friend_lang1);
$smarty->assign('smart_friend_lang2', $smart_friend_lang2);
?>