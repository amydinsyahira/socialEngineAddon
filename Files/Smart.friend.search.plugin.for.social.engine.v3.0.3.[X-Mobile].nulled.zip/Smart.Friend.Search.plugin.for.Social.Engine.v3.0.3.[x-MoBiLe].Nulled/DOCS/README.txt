Hello,
Got it working - and a little suggestion for optimization

replace in smart_friend_search.php on line 20:


$friends = $database->database_query("SELECT user_id, user_username, user_photo FROM se_friends LEFT JOIN se_users ON se_friends.friend_user_id1='".$user->user_info[user_id]."' AND se_users.user_id=se_friends.friend_user_id2 WHERE SUBSTRING(user_username, 1, $len)='$input' LIMIT $limit");

with

$friends = $database->database_query("SELECT user_id, user_username, user_photo FROM se_friends LEFT JOIN se_users ON se_friends.friend_user_id1='".$user->user_info[user_id]."' AND se_users.user_id=se_friends.friend_user_id2 WHERE user_username LIKE '%$input%' LIMIT $limit");


With this change you get a more like wildcard search (means, finding the input string anywhere in the username, not from the beginning on).
