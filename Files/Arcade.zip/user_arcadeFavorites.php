<?php
$page = "user_arcadeFavorites";
include "header.php";

////////GET LANG IDS
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'arcadeFavorites.', '') AS `key`
				FROM `arcade_settings` WHERE `defVarName` LIKE '%arcadeFavorites.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aArcdSttng = array();
$sSql = "	SELECT 
					* 
				FROM `arcade_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aArcdSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
$smarty->assign('aArcadeSetting', $aArcdSttng);
//////////////////////////////////////////////////////////////////////////
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);

if( is_numeric($iUserId) && $aArcdSttng['favorite'] == 2)
{
	$smarty->assign('bDeleted', FALSE);
	$iDelFav = isset($_GET['delFav']) ? mysql_real_escape_string($_GET['delFav']) : FALSE;
	if( isset($iDelFav) )
	{
		$sSql = "DELETE FROM `arcade_favorite` WHERE `gameid` = '{$iDelFav}' && `userid` = '{$iUserId}' ";
		$rResult = mysql_query($sSql);
		$smarty->assign('bDeleted', TRUE);
	}
	
	$iFav = isset($_GET['addFav']) ? mysql_real_escape_string($_GET['addFav']) : FALSE;
    if( isset($iFav) )
	{
		$sql="	SELECT 
						`g`.`gameid`,
						`f`.`userid`
					FROM `arcade_games`AS `g` 
					LEFT JOIN `arcade_favorite` AS `f` ON `f`.`gameid` = `g`.`gameid` && `f`.`userid` = '".$iUserId."'
					WHERE `g`.`gameid` = '".$iFav."' LIMIT 1";
		$result=mysql_query($sql);
		if( ($aGame = mysql_fetch_assoc($result)) )
		{
			$bExists = isset($aGame['userid']) ? TRUE : FALSE;
			$smarty->assign('bAdded', FASE);
			if( $bExists == FALSE)
			{
				$sSql = "INSERT INTO `arcade_favorite` (`gameid`, `userid`) VALUES ('{$iFav}', '{$iUserId}') ";
				$rResult = mysql_query($sSql);
				$smarty->assign('bAdded', TRUE);
			}
			$smarty->assign('bExists', $bExists);
			$smarty->assign('aGame', $aGame);
		}else
			$smarty->assign('aGame', FALSE);
	}
	
	$aFavorites = array();
	$sSql="	SELECT 
					`g`.`gameid`,
					`g`.`title`,
					`g`.`stdimage`
				FROM `arcade_favorite` AS `f` 
				INNER JOIN `arcade_games`AS `g` ON `g`.`gameid` = `f`.`gameid`
				WHERE `f`.`userid` = '".$iUserId."' ";
	$rResult=mysql_query($sSql);
	while( ($aRow = mysql_fetch_assoc($rResult)) )
	{
		$aRow['title'] = stripslashes($aRow['title']);
		if( !file_exists('file/arcade/images/'.$aRow['stdimage']) )
			$aRow['stdimage'] = FALSE;
		$aFavorites[] = $aRow;
	}
	$smarty->assign('aFavorites', $aFavorites);
}
else
{
	$sMainFolder = "http://".$_SERVER['SERVER_NAME'].str_replace('user_arcadeFavorites.php', '', $_SERVER['SCRIPT_NAME']);
	header("Location: ".$sMainFolder."gamelist.php");
	exit;
}
// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>