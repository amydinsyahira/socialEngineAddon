<?

$page = "admin_arcadeMergeCategory";
include "admin_header.php";

// defaults
$sName = NULL;
$sOrder = NULL;
$bError = false;
$bCatDNE = false;
$bNameDNE = false;
$bMerged = false;

if (isset($_POST['submit'])) {
	$sCat1 = mysql_real_escape_string($_POST['sCat1']);
	$sCat2 = mysql_real_escape_string($_POST['sCat2']);
	
	$sName = mysql_real_escape_string( trim($_POST['sName']) );
	$sOrder = mysql_real_escape_string( trim($_POST['sOrder']) );
	$sOrder = !is_numeric($sOrder) ? 0 : $sOrder;
	
	$sSql1 = 'SELECT * FROM `arcade_categories` WHERE `catid` = '.$sCat1.' LIMIT 1';
	$rResult1 = mysql_query($sSql1);

	$sSql2 = 'SELECT * FROM `arcade_categories` WHERE `catid` = '.$sCat2.' LIMIT 1';
	$rResult2 = mysql_query($sSql2);

	if( (mysql_fetch_assoc($rResult1)) && (mysql_fetch_assoc($rResult2)))
	{
		if( $sName != "" )
		{
			$sql = 'INSERT INTO `arcade_categories` (catname, displayorder) VALUES ("'.$sName.'", "'.$sOrder.'")';
			$result = mysql_query($sql) or die(mysql_error());
			$iInsertId = mysql_insert_id();
			
			$sSql = 'UPDATE `arcade_games` SET `categoryid` = "'.$iInsertId.'" WHERE `categoryid` = "'.$sCat1.'" || `categoryid` = "'.$sCat2.'" ';
			$rResult = mysql_query($sSql);
			$bMerged = true;
		}
		else
		{
			$bNameDNE = true;
			$bError = true;
		}
	}
	else
	{
		$bCatDNE = true;
		$bError = true;
	}
}
$smarty->assign('sName', $sName);
$smarty->assign('sOrder', $sOrder);
$smarty->assign('bError', $bError);
$smarty->assign('bNameDNE', $bNameDNE);
$smarty->assign('bCatDNE', $bCatDNE);
$smarty->assign('bMerged', $bMerged);


$aCategories = array();
$sql = 'SELECT `catid`,`catname` FROM `arcade_categories` ORDER BY `catname`';
$result = mysql_query($sql) or die(mysql_error());
while( $aRow = mysql_fetch_assoc($result) )
	$aCategories[ $aRow['catid'] ] = htmlentities( stripslashes($aRow['catname']) );
$smarty->assign('aCategories', $aCategories);
include "admin_footer.php";
?>