<?php
$aLangList = array();
$sSql = 'SELECT `language_id`, `language_default` FROM `se_languages` ';
$rResult = mysql_query($sSql);
while( ($aRow = mysql_fetch_assoc($rResult)) )
{
	$aLangList[] = $aRow['language_id'];
	if( $aRow['language_default'] == 1 )
	{
		$iDefaultKey = count($aLangList);
		$iDefaultId = $aRow['language_id'];
	}
}
$iDefaultKey = count($aLangList) - $iDefaultKey;

$sSql = 'SELECT `languagevar_id` FROM `se_languagevars` ORDER BY `languagevar_id` DESC LIMIT 1';
$rResult = mysql_query($sSql);
$aRow = mysql_fetch_assoc($rResult);
$iLast = $aRow['languagevar_id'];

$sSql = 'SELECT `languagevar_id` FROM `se_languagevars` WHERE `languagevar_value` = "SEG Arcade" && `languagevar_default` = "admin_home" ';
$rResult = mysql_query($sSql);
if( ($aRow = mysql_fetch_assoc($rResult) ) )
	$iPlugin = $aRow['languagevar_id'];
else
{
	$iPlugin = $iLast + 1;
	$sSql = '	INSERT INTO 
					`se_languagevars` 
				(`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
				VALUES 
				('.$iPlugin.', "1", "SEG Arcade", "admin_home")
			';
	$rResult = mysql_query($sSql);
}

$aLangData = array();
//Header Page
$aLangData[1]['value'] = 'Arcade'; $aLangData[1]['default'] = 'user_messages_view, user_messages_outbox, user_messages, user_home, user_friends_requests_outgoing, user_friends_requests, user_friends, user_editprofile_style, user_editprofile_photo, user_editprofile, user_album, user_account_privacy, user_account_pass, user_account_delete, user_account, signup_verify, signup, search_advanced, search, profile, network, lostpass_reset, lostpass, login, invite, home, help_tos, help_contact, help,'; $aLangData[1]['defaultKey'] = 'arcadeMenu';
//Top Arcade Page
$aLangData[2]['value'] = 'Top Arcade Statistics'; $aLangData[2]['default'] = ' toparcade, '; $aLangData[2]['defaultKey'] = 'toparcade.top_arcade_statistics';
$aLangData[3]['value'] = mysql_real_escape_string('Top Games by # of Times Played'); $aLangData[3]['default'] = ' toparcade, '; $aLangData[3]['defaultKey'] = 'toparcade.top_games_by_num_of_times_played';
$aLangData[4]['value'] = 'Game Title'; $aLangData[4]['default'] = ' toparcade, '; $aLangData[4]['defaultKey'] = 'toparcade.game_title';
$aLangData[5]['value'] = 'Plays'; $aLangData[5]['default'] = ' toparcade, '; $aLangData[5]['defaultKey'] = 'toparcade.plays';
$aLangData[6]['value'] = mysql_real_escape_string('Top Players by # of Records Held'); $aLangData[6]['default'] = ' toparcade, '; $aLangData[6]['defaultKey'] = 'toparcade.top_players_by_num_of_records_held';
$aLangData[7]['value'] = 'Champion'; $aLangData[7]['default'] = ' toparcade, '; $aLangData[7]['defaultKey'] = 'toparcade.champion';
$aLangData[8]['value'] = 'Records'; $aLangData[8]['default'] = ' toparcade, '; $aLangData[8]['defaultKey'] = 'toparcade.records';
//Highscores Page
$aLangData[9]['value'] = mysql_real_escape_string("%1\$s's Highscores"); $aLangData[9]['default'] = ' highscores, '; $aLangData[9]['defaultKey'] = 'highscore.games_highscores';
$aLangData[10]['value'] = 'Game Info'; $aLangData[10]['default'] = ' highscores, '; $aLangData[10]['defaultKey'] = 'highscore.game_info';
$aLangData[11]['value'] = mysql_real_escape_string("%1\$s Thumbnail"); $aLangData[11]['default'] = ' highscores, '; $aLangData[11]['defaultKey'] = 'highscore.title_thumbnail';
$aLangData[12]['value'] = 'Times played:'; $aLangData[12]['default'] = ' highscores, '; $aLangData[12]['defaultKey'] = 'highscore.times_played';
$aLangData[13]['value'] = 'Overall High Scores'; $aLangData[13]['default'] = ' highscores, '; $aLangData[13]['defaultKey'] = 'highscore.overall_high_scores';
$aLangData[14]['value'] = 'Member'; $aLangData[14]['default'] = ' highscores, '; $aLangData[14]['defaultKey'] = 'highscore.member';
$aLangData[15]['value'] = 'Score'; $aLangData[15]['default'] = ' highscores, '; $aLangData[15]['defaultKey'] = 'highscore.score';
$aLangData[16]['value'] = 'Records'; $aLangData[16]['default'] = ' highscores, '; $aLangData[16]['defaultKey'] = 'toparcade.records';
$aLangData[17]['value'] = 'Your High Scores'; $aLangData[17]['default'] = ' highscores, '; $aLangData[17]['defaultKey'] = 'highscore.your_high_scores';
$aLangData[18]['value'] = 'Date'; $aLangData[18]['default'] = ' highscores, '; $aLangData[18]['defaultKey'] = 'highscore.date';
$aLangData[19]['value'] = 'Play this game!'; $aLangData[19]['default'] = ' highscores, '; $aLangData[19]['defaultKey'] = 'highscore.play_this_game';
$aLangData[59]['value'] = 'There are no recorded high scores at this time.'; $aLangData[59]['default'] = ' highscores, '; $aLangData[59]['defaultKey'] = 'highscore.there_are_no_highscores_at_this_time';
//Game Page
$aLangData[20]['value'] = 'Game Info'; $aLangData[20]['default'] = ' game, '; $aLangData[20]['defaultKey'] = 'game.game_info';
$aLangData[21]['value'] = 'Title:'; $aLangData[21]['default'] = ' game, '; $aLangData[21]['defaultKey'] = 'game.title';
$aLangData[22]['value'] = 'Game ID:'; $aLangData[22]['default'] = ' game, '; $aLangData[22]['defaultKey'] = 'game.game_id';
$aLangData[23]['value'] = 'Arcade Champion:'; $aLangData[23]['default'] = ' game, '; $aLangData[23]['defaultKey'] = 'game.arcade_champion';
$aLangData[24]['value'] = 'Game ID:'; $aLangData[24]['default'] = ' game, '; $aLangData[24]['defaultKey'] = 'game.game_id';
$aLangData[25]['value'] = 'Score to Beat:'; $aLangData[25]['default'] = ' game, '; $aLangData[25]['defaultKey'] = 'game.score_to_beat';
$aLangData[26]['value'] = 'View High Scores'; $aLangData[26]['default'] = ' game, '; $aLangData[26]['defaultKey'] = 'game.view_high_scores';
$aLangData[27]['value'] = '(Notice)'; $aLangData[27]['default'] = ' game, '; $aLangData[27]['defaultKey'] = 'game.notice';
$aLangData[28]['value'] = 'You must be logged in and have the correct permissions to play arcade games.'; $aLangData[28]['default'] = ' game, '; $aLangData[28]['defaultKey'] = 'game.you_must_be_logged_in_to_play';
$aLangData[60]['value'] = 'Report Game'; $aLangData[60]['default'] = ' game, '; $aLangData[60]['defaultKey'] = 'game.report_game';
//Gamelist Page
$aLangData[29]['value'] = 'Browse Games'; $aLangData[29]['default'] = ' gamelist, '; $aLangData[29]['defaultKey'] = 'gamelist.browse_games';
$aLangData[30]['value'] = 'Arcade News'; $aLangData[30]['default'] = ' gamelist, '; $aLangData[30]['defaultKey'] = 'gamelist.arcade_news';
$aLangData[31]['value'] = 'Arcade Champion'; $aLangData[31]['default'] = ' gamelist, '; $aLangData[31]['defaultKey'] = 'gamelist.arcade_champion';
$aLangData[32]['value'] = 'View All'; $aLangData[32]['default'] = ' gamelist, '; $aLangData[32]['defaultKey'] = 'gamelist.view_all';
$aLangData[33]['value'] = mysql_real_escape_string("%1\$s records"); $aLangData[33]['default'] = ' gamelist, '; $aLangData[33]['defaultKey'] = 'gamelist.arcade_champ_records';
$aLangData[34]['value'] = 'Most Played Game';  $aLangData[34]['default'] = ' gamelist, '; $aLangData[34]['defaultKey'] = 'gamelist.most_played_game';
$aLangData[35]['value'] = mysql_real_escape_string("%1\$s total plays"); $aLangData[35]['default'] = ' gamelist, '; $aLangData[35]['defaultKey'] = 'gamelist.total_plays';
$aLangData[36]['value'] = 'You do not have any game plays yet.'; $aLangData[36]['default'] = ' gamelist, '; $aLangData[36]['defaultKey'] = 'gamelist.you_do_not_have_any_game_plays';
$aLangData[37]['value'] = 'Search Games:';  $aLangData[37]['default'] = ' gamelist, '; $aLangData[37]['defaultKey'] = 'gamelist.search_games';
$aLangData[38]['value'] = 'Description'; $aLangData[38]['default'] = ' gamelist, '; $aLangData[38]['defaultKey'] = 'gamelist.description';
$aLangData[39]['value'] = 'Submit'; $aLangData[39]['default'] = ' gamelist, '; $aLangData[39]['defaultKey'] = 'gamelist.submit';
$aLangData[40]['value'] = 'Random'; $aLangData[40]['default'] = ' gamelist, '; $aLangData[40]['defaultKey'] = 'gamelist.random';
$aLangData[41]['value'] = 'Game'; $aLangData[41]['default'] = ' gamelist, '; $aLangData[41]['defaultKey'] = 'gamelist.game';
$aLangData[42]['value'] = 'Category'; $aLangData[42]['default'] = ' gamelist, '; $aLangData[42]['defaultKey'] = 'gamelist.category';
$aLangData[43]['value'] = 'Champion'; $aLangData[43]['default'] = ' gamelist, '; $aLangData[43]['defaultKey'] = 'gamelist.champion';
$aLangData[44]['value'] = 'Options'; $aLangData[44]['default'] = ' gamelist, '; $aLangData[44]['defaultKey'] = 'gamelist.options';
$aLangData[45]['value'] = 'More'; $aLangData[45]['default'] = ' gamelist, '; $aLangData[45]['defaultKey'] = 'gamelist.more';
$aLangData[46]['value'] = 'Champion:'; $aLangData[46]['default'] = ' gamelist, '; $aLangData[46]['defaultKey'] = 'gamelist.champion2';
$aLangData[47]['value'] = 'Your best:'; $aLangData[47]['default'] = ' gamelist, '; $aLangData[47]['defaultKey'] = 'gamelist.your_best';
$aLangData[48]['value'] = 'High Scores'; $aLangData[48]['default'] = ' gamelist, '; $aLangData[48]['defaultKey'] = 'gamelist.high_scores';
$aLangData[49]['value'] = 'Challenge'; $aLangData[49]['default'] = ' gamelist, '; $aLangData[49]['defaultKey'] = 'gamelist.challenge';
$aLangData[50]['value'] = 'There are no games in this category.'; $aLangData[50]['default'] = ' gamelist, '; $aLangData[50]['defaultKey'] = 'gamelist.there_are_no_games_in_this_category';
$aLangData[51]['value'] = 'Jump To Page:'; $aLangData[51]['default'] = ' gamelist, '; $aLangData[51]['defaultKey'] = 'gamelist.jump_to_page';
$aLangData[52]['value'] = mysql_real_escape_string("This category has <strong>%1\$s</strong> Games."); $aLangData[52]['default'] = ' gamelist, '; $aLangData[52]['defaultKey'] = 'gamelist.this_category_has_inum_games';
$aLangData[53]['value'] = mysql_real_escape_string("<a href='profile.php?user_id=%1\$s'>%2\$s</a> has just defeated <a href='profile.php?user_id=%3\$s'>%4\$s</a> in a duel at <a href='game.php?play=%5\$s'>%6\$s</a> with a score of %7\$s!"); $aLangData[53]['default'] = ' gamelist, '; $aLangData[53]['defaultKey'] = 'gamelist.news_msg1';
$aLangData[54]['value'] = mysql_real_escape_string("<a href='profile.php?user_id=%1\$s'>%2\$s</a> has just set a new record for <a href='game.php?play=%3\$s'>%4\$s</a> with a score of %5\$s!"); $aLangData[54]['default'] = ' gamelist, '; $aLangData[54]['defaultKey'] = 'gamelist.news_msg2';
$aLangData[55]['value'] = mysql_real_escape_string("<a href='profile.php?user_id=%1\$s'>%2\$s</a> has just defeated <a href='profile.php?user_id=%3\$s'>%4\$s</a>'s record at <a href='game.php?play=%5\$s'>%6\$s</a> with a score of %7\$s!"); $aLangData[55]['default'] = ' gamelist, '; $aLangData[55]['defaultKey'] = 'gamelist.news_msg3';
$aLangData[56]['value'] = mysql_real_escape_string("<a href='profile.php?user_id=%1\$s'>%2\$s</a> has just set the record for <a href='game.php?play=%3\$s'>%4\$s</a> with a score of %5\$s!");$aLangData[56]['default'] = ' gamelist, '; $aLangData[56]['defaultKey'] = 'gamelist.news_msg4';
$aLangData[57]['value'] = '(Notice)'; $aLangData[57]['default'] = ' gamelist, '; $aLangData[57]['defaultKey'] = 'gamelist.notice';
$aLangData[58]['value'] = 'You do not have any news yet. The news will be automatically updated as soon as someone gets a highscore or wins a challenge.'; $aLangData[58]['default'] = ' gamelist, '; $aLangData[58]['defaultKey'] = 'gamelist.no_news';
$aLangData[61]['value'] = 'Title'; $aLangData[61]['default'] = ' gamelist, '; $aLangData[61]['defaultKey'] = 'gamelist.title';
$aLangData[62]['value'] = 'No games could be found.'; $aLangData[62]['default'] = ' gamelist, '; $aLangData[62]['defaultKey'] = 'gamelist.no_games_found';
$aLangData[63]['value'] = 'Remove From Favorites'; $aLangData[63]['default'] = ' gamelist, '; $aLangData[63]['defaultKey'] = 'gamelist.remove_from_favorites';
$aLangData[64]['value'] = 'Add To Favorites'; $aLangData[64]['default'] = ' gamelist, '; $aLangData[64]['defaultKey'] = 'gamelist.add_to_favorites';
///Arcade Favorites
$aLangData[65]['value'] = 'Favorite Games'; $aLangData[65]['default'] = ' arcadeFavorites, '; $aLangData[65]['defaultKey'] = 'arcadeFavorites.favorite_games';
$aLangData[66]['value'] = '(Notice)'; $aLangData[66]['default'] = ' arcadeFavorites, '; $aLangData[66]['defaultKey'] = 'arcadeFavorites.notice';
$aLangData[67]['value'] = 'Game is already a favorite'; $aLangData[67]['default'] = ' arcadeFavorites, '; $aLangData[67]['defaultKey'] = 'arcadeFavorites.game_is_already_a_favorite';
$aLangData[68]['value'] = 'Game has been added to favorites'; $aLangData[68]['default'] = ' arcadeFavorites, '; $aLangData[68]['defaultKey'] = 'arcadeFavorites.game_has_been_added';
$aLangData[69]['value'] = 'Game has been removed from your favorites'; $aLangData[69]['default'] = ' arcadeFavorites, '; $aLangData[69]['defaultKey'] = 'arcadeFavorites.game_has_been_removed';
///Arcade Challenge
$aLangData[70]['value'] = 'Arcade Challenges'; $aLangData[70]['default'] = ' arcadechallenge, '; $aLangData[70]['defaultKey'] = 'arcadechallenge.arcade_challenges';
$aLangData[71]['value'] = '(Notice)'; $aLangData[71]['default'] = ' arcadechallenge, '; $aLangData[71]['defaultKey'] = 'arcadechallenge.notice';
$aLangData[72]['value'] = 'Your challenge could not be sent.'; $aLangData[72]['default'] = ' arcadechallenge, '; $aLangData[72]['defaultKey'] = 'arcadechallenge.your_challenge_could_not_be_sent';
$aLangData[73]['value'] = 'Your challenge has been sent.'; $aLangData[73]['default'] = ' arcadechallenge, '; $aLangData[73]['defaultKey'] = 'arcadechallenge.your_challenge_has_been_sent';
$aLangData[74]['value'] = 'Create New Challenge'; $aLangData[74]['default'] = ' arcadechallenge, '; $aLangData[74]['defaultKey'] = 'arcadechallenge.create_new_challenge';
$aLangData[75]['value'] = 'Game ID'; $aLangData[75]['default'] = ' arcadechallenge, '; $aLangData[75]['defaultKey'] = 'arcadechallenge.game_id';
$aLangData[76]['value'] = 'Friend Name'; $aLangData[76]['default'] = ' arcadechallenge, '; $aLangData[76]['defaultKey'] = 'arcadechallenge.friend';
$aLangData[77]['value'] = 'Message to User'; $aLangData[77]['default'] = ' arcadechallenge, '; $aLangData[77]['defaultKey'] = 'arcadechallenge.msg_to_user';
$aLangData[78]['value'] = 'Challenge'; $aLangData[78]['default'] = ' arcadechallenge, '; $aLangData[78]['defaultKey'] = 'arcadechallenge.challenge';
$aLangData[79]['value'] = 'Current Challenges'; $aLangData[79]['default'] = ' arcadechallenge, '; $aLangData[79]['defaultKey'] = 'arcadechallenge.current_challenges';
$aLangData[80]['value'] = 'Date'; $aLangData[80]['default'] = ' arcadechallenge, '; $aLangData[80]['defaultKey'] = 'arcadechallenge.date';
$aLangData[81]['value'] = 'Challenger'; $aLangData[81]['default'] = ' arcadechallenge, '; $aLangData[81]['defaultKey'] = 'arcadechallenge.challenger';
$aLangData[82]['value'] = 'Game'; $aLangData[82]['default'] = ' arcadechallenge, '; $aLangData[82]['defaultKey'] = 'arcadechallenge.game';
$aLangData[83]['value'] = 'Your Score'; $aLangData[83]['default'] = ' arcadechallenge, '; $aLangData[83]['defaultKey'] = 'arcadechallenge.your_score';
$aLangData[84]['value'] = 'Opponent Score'; $aLangData[84]['default'] = ' arcadechallenge, '; $aLangData[84]['defaultKey'] = 'arcadechallenge.opponent_score';
$aLangData[85]['value'] = 'Winner'; $aLangData[85]['default'] = ' arcadechallenge, '; $aLangData[85]['defaultKey'] = 'arcadechallenge.winner';
$aLangData[86]['value'] = 'Play Now'; $aLangData[86]['default'] = ' arcadechallenge, '; $aLangData[86]['defaultKey'] = 'arcadechallenge.play_now';
$aLangData[87]['value'] = 'All'; $aLangData[87]['default'] = ' arcadechallenge, '; $aLangData[87]['defaultKey'] = 'arcadechallenge.all';
$aLangData[88]['value'] = 'Won'; $aLangData[88]['default'] = ' arcadechallenge, '; $aLangData[88]['defaultKey'] = 'arcadechallenge.won';
$aLangData[89]['value'] = 'Lost'; $aLangData[89]['default'] = ' arcadechallenge, '; $aLangData[89]['defaultKey'] = 'arcadechallenge.lost';
$aLangData[90]['value'] = 'Undecided'; $aLangData[90]['default'] = ' arcadechallenge, '; $aLangData[90]['defaultKey'] = 'arcadechallenge.undecided';
$aLangData[91]['value'] = 'You do not have any challenges'; $aLangData[91]['default'] = ' arcadechallenge, '; $aLangData[91]['defaultKey'] = 'arcadechallenge.you_do_not_have_any_challenges';
//$aLangData[92]['value'] = 'Game'; $aLangData[92]['default'] = ' arcadechallenge, '; $aLangData[92]['defaultKey'] = 'arcadechallenge.game';

//$aLangData[62]['value'] = 'Play this game!';
//$aLangData[62]['default'] = ' highscores, ';
//$aLangData[62]['defaultKey'] = 'highscore.play_this_game';


foreach($aLangData as $k=>$v)
{
	$sSql = 'SELECT `languagevar_id` FROM `se_languagevars` WHERE `languagevar_value` = "'.$v['value'].'" && `languagevar_default` = "'.$v['default'].'" && `languagevar_language_id` = "'.$iDefaultId.'" ';
	$rResult = mysql_query($sSql);
	if( ($aRow = mysql_fetch_assoc($rResult) ) )
		$aLangData[$k]['id'] = $aRow['languagevar_id'];
	else
	{
		$aTemp = array();
		foreach($aLangList as $v2)
		{
			$iLast++;
			$aTemp[] = '("'.$iLast.'", "'.$v2.'", "'.$v['value'].'", "'.$v['default'].'")';
		}
		$sSql = '	INSERT INTO 
							`se_languagevars` 
						(`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
						VALUES '.implode(', ', $aTemp);
		$rResult = mysql_query($sSql);
		$aLangData[$k]['id'] = $iLast - $iDefaultKey;
	}
}

$sql = 'CREATE TABLE `arcade_settings` ('
        . ' `id` INT(12) NOT NULL AUTO_INCREMENT PRIMARY KEY, '
        . ' `defVarName` VARCHAR(250) NOT NULL, '
        . ' `languagevar_id` INT(12) NOT NULL '
        . ' )'
        . ' ENGINE = myisam;';
$result=mysql_query($sql);

$aArcdSttngs = array();
$sSql = 'SELECT * FROM `arcade_settings` ';
$rResult = mysql_query($sSql);
while( ($aRow = mysql_fetch_assoc($rResult)) )
	$aArcdSttngs[$aRow['defVarName']] = $aRow;

if( !array_key_exists('AdminTitle', $aArcdSttngs) )
{
	$sSql = 'INSERT INTO `arcade_settings` (`defVarName`, `languagevar_id`) VALUES ("AdminTitle", "'.$iPlugin.'") ';
	$rResut = mysql_query($sSql);
}

foreach($aLangData as $k=>$v)
	if( !array_key_exists($v['defaultKey'], $aArcdSttngs) )
	{
		$sSql = "INSERT INTO `arcade_settings` (`defVarName`, `languagevar_id`) VALUES ('{$v['defaultKey']}', '{$v['id']}') ";
		$rResut = mysql_query($sSql);
	}

$plugin_name = "Плагин Аркады"; // Plugin's Title
$plugin_version = 1.04; // Plugin's Version
$plugin_type = "Arcade"; // Plugin's Unique Identifying Name
$plugin_desc = "Духовный Наставник Аркад в Social Engine. Проще говоря, много игр для Social Engine. <a href = \"http://www.socengine.ru/add/plug/51-polnyj-perevod-na-russkij-yazyk-plagina-arcade.html\">Скачать перевод на Русский Язык с SocEngine.Ru</a>"; // Plugin's Description
$plugin_icon = "joystick.png"; // Plugin's Icon
$plugin_pages_main = "$iPlugin<!>joystick.png<!>admin_arcade.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";

if($install == "Arcade") 
{
	//######### INSERT ROW INTO se_plugins
	if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
	$database->database_query("INSERT INTO se_plugins (plugin_name, plugin_version, plugin_type, plugin_desc, plugin_icon, plugin_pages_main, plugin_pages_level, plugin_url_htaccess) VALUES ('$plugin_name', '$plugin_version', '$plugin_type', '$plugin_desc', '$plugin_icon', '$plugin_pages_main', '$plugin_pages_level', '$plugin_url_htaccess')");
	//######### UPDATE PLUGIN VERSION IN se_plugins
	} else {
	$database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name', plugin_version='$plugin_version', plugin_desc='$plugin_desc', plugin_icon='$plugin_icon', plugin_pages_main='$plugin_pages_main', plugin_pages_level='$plugin_pages_level', plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
	}
}

$sql = "CREATE TABLE IF NOT EXISTS `arcade_games` (
`gameid` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`shortname` VARCHAR( 100 ) NOT NULL ,
`title` VARCHAR( 100 ) NOT NULL ,
`description` TEXT NOT NULL ,
`file` VARCHAR( 100 ) NOT NULL ,
`width` INT( 4 ) DEFAULT '550' NOT NULL ,
`height` INT( 4 ) DEFAULT '400' NOT NULL ,
`miniimage` VARCHAR( 100 ) NOT NULL ,
`stdimage` VARCHAR( 100 ) NOT NULL ,
`categoryid` INT( 11 ) UNSIGNED DEFAULT '1' NOT NULL ,
`timesplayed` INT( 11 ) UNSIGNED DEFAULT '0' NOT NULL ,
`isreverse` TINYINT( 1 ) UNSIGNED DEFAULT '0' NOT NULL ,
PRIMARY KEY ( `gameid` ) ,
UNIQUE (
`shortname` ,
`file`
)
) TYPE = MYISAM ;";
$result=mysql_query($sql);

$sql = "CREATE TABLE IF NOT EXISTS `arcade_categories` (
`catid` INT( 10 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`catname` VARCHAR( 250 ) NOT NULL ,
`displayorder` INT( 10 ) UNSIGNED DEFAULT '0' NOT NULL ,
PRIMARY KEY ( `catid` ) 
) TYPE = MYISAM ;";
$result=mysql_query($sql);

$sql="CREATE TABLE IF NOT EXISTS `arcade_scores` (
`scoreid` INT( 11 ) NOT NULL AUTO_INCREMENT ,
`gameid` VARCHAR( 100 ) NOT NULL ,
`userid` INT( 12 ) NOT NULL ,
`score` INT( 100 ) NOT NULL ,
`time` INT(12) NOT NULL DEFAULT '0',
PRIMARY KEY ( `scoreid` )
) TYPE = MYISAM ;";
$result=mysql_query($sql);

$sql="CREATE TABLE IF NOT EXISTS `arcade_userhighscores` (
`scoreid` INT( 11 ) NOT NULL AUTO_INCREMENT ,
`gameid` INT( 11 ) NOT NULL ,
`userid` INT( 12 ) NOT NULL ,
`score` INT( 100 ) NOT NULL ,
`time` INT(12) NOT NULL DEFAULT '0',
PRIMARY KEY ( `scoreid` )
) TYPE = MYISAM ;";
$result=mysql_query($sql);

$sql="CREATE TABLE `arcade_highscores` (
`scoreid` INT( 11 ) NOT NULL AUTO_INCREMENT ,
`gameid` INT( 12 ) NOT NULL ,
`userid` INT( 12 ) NOT NULL ,
`score` INT( 100 ) NOT NULL ,
`time` INT(12) NOT NULL,
PRIMARY KEY ( `scoreid` )
) TYPE = MYISAM ;";
$result=mysql_query($sql);

$sql = "CREATE TABLE IF NOT EXISTS `arcade_info` (
`userid` INT( 12 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`champs` INT(12) NOT NULL ,
`points` INT(12) NOT NULL ,
`arcade_fav` INT(12) NOT NULL,
PRIMARY KEY ( `userid` ) 
) TYPE = MYISAM ;";
$result=mysql_query($sql);

$sql = "CREATE TABLE IF NOT EXISTS `arcade_favorite` (
`id` INT( 12 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`gameid` INT( 11 ) NOT NULL ,
`userid` INT( 250 ) NOT NULL ,
PRIMARY KEY ( `id` )
)
TYPE = MYISAM ;";
$result=mysql_query($sql);

$sql = 'CREATE TABLE `arcade_news` ('
        . ' `id` INT(12) NOT NULL AUTO_INCREMENT PRIMARY KEY, '
        . ' `type` INT(12) NOT NULL, '
        . ' `time` INT(12) NOT NULL, '
        . ' `winnerid` INT(12) NOT NULL, '
        . ' `loserid` INT(12) NOT NULL, '
        . ' `score` VARCHAR(250) NOT NULL, '
        . ' `gameid` INT(12) NOT NULL '
        . ' )'
        . ' ENGINE = myisam;';
$result=mysql_query($sql);

$sql = 'CREATE TABLE `arcade_challenges` ('
        . ' `id` INT(12) NOT NULL AUTO_INCREMENT PRIMARY KEY, '
        . ' `user1` INT(12) NOT NULL, '
        . ' `user2` INT(12) NOT NULL, '
        . ' `time` INT(12) NOT NULL, '
        . ' `score1` INT(12) default NULL, '
        . ' `score2` INT(12) default NULL, '
        . ' `gameid` INT(12) NOT NULL, '
        . ' `winner` INT(12) default NULL'
        . ' )'
        . ' ENGINE = myisam;';
$result=mysql_query($sql);

$sql = 'CREATE TABLE IF NOT EXISTS `arcade_options` (`id` INT(12) NOT NULL AUTO_INCREMENT, `var` VARCHAR(250) NOT NULL, `value` VARCHAR(250) NOT NULL, PRIMARY KEY (`id`)) ENGINE = MyISAM';
$result = mysql_query($sql);

//options
$var = array();
$value = array();

$var[] = "activitypoints";
$value[] = "1";

$var[] = "activitylimit";
$value[] = "10";

//value 1 = disable, 2 = enable
$var[] = "favorite";
$value[] = "1";

$var[] = "userlevels";
$value[] = "0,1,2,3,4,5";

//value 1 = disable, 2 = enable
$var[] = "guestplay";
$value[] = "2";

//value 2 = disable, 1 = enable
$var[] = "footerlink";
$value[] = "1";

$var[] = "seohome";
$value[] = "Arcade - Play Games - <%game_category%>";

$var[] = "seoplay";
$value[] = "Play <%game_title%> - <%game_category%>";

$var[] = "seoscore";
$value[] = "Highscores for <%game_title%> - <%game_category%>";

$var[] = "seochallenge";
$value[] = "Arcade Challenges";

$var[] = "champsonprofile";
$value[] = "1";

$var[] = "linksonprofile";
$value[] = "1";

$var[] = "linklimit";
$value[] = "10";

$var[] = "memberindex";
$value[] = "1";

$var[] = "visitornews";
$value[] = "1";

$var[] = "visitortopgames";
$value[] = "1";

$var[] = "membernews";
$value[] = "1";

$var[] = "membertopgames";
$value[] = "1";

$var[] = "tieGoesTo";
$value[] = "2";

/*
$var[] = "";
$value[] = "";
*/

$count = count($var);

for($i=0;$i<$count;$i++)
{
	$sql = "SELECT * FROM `arcade_options` WHERE `var` = '" . $var[$i] . "'";
	$result = mysql_query($sql);
	$num = mysql_num_rows($result);
	if($num == 0){
		$sql = "INSERT INTO `arcade_options` (`var`, `value`) VALUES ('" . $var[$i] . "', '" . $value[$i] . "')";
		$result = mysql_query($sql);
	}
}

?>