<?
$page = "admin_arcade";
include "admin_header.php";

if(isset($_POST['submit']))
{
	$bSubmit = true;
	$sql = "SELECT * FROM `arcade_options`";
	$result = mysql_query($sql);
	if( is_array($_POST['userlevels']) )
		$_POST['userlevels'] = implode(",", $_POST['userlevels']);
	else
		$_POST['userlevels'] = "";
	while($row = mysql_fetch_array($result)){
		$var = $row['var'];
		if( $var == 'tieGoesTo' )
			$iTieOption = $row['value'];
		if(isset($_POST[$var]))
		{
			$sql2 = "UPDATE `arcade_options` SET `value` = '" . $_POST[$var] . "' WHERE `var` = '$var' LIMIT 1";
			$result2 = mysql_query($sql2);
		}
	}
	
	if( $_POST['tieGoesTo'] == 2 && $iTieOption == 1 )
	{
		$sSql = '	DELETE FROM `arcade_highscores`  ';
		$rResult = mysql_query($sSql);
		$sSql = '	INSERT INTO 
							`arcade_highscores` 
						(`gameid`, `userid`, `score`, `time`) 
						SELECT `as4`.`gameid`, `as4`.`userid`, `as4`.`score`, `as4`.`time`
						FROM `arcade_scores` AS `as4`
						JOIN	(
							SELECT `asj2`.`gameid`, MAX(`asj2`.`time`) AS `time`
							FROM
								(
								SELECT `as1`.`gameid`, `as1`.`userid`, `as1`.`score`, `as1`.`time`
								FROM `arcade_scores` AS `as1`
								JOIN 	(
												SELECT `asj`.`gameid`, MAX(`asj`.`score`) AS `score`
												FROM `arcade_scores` AS `asj`
												GROUP BY `asj`.`gameid`
											) AS `as2`
								ON 
									`as1`.`gameid` = `as2`.`gameid` && 
									`as1`.`score` = `as2`.`score`
								)	AS `asj2` 
							GROUP BY `asj2`.`gameid` 
									)	AS `as3` 
						ON 
							`as3`.`gameid` = `as4`.`gameid`&& 
							`as3`.`time` = `as4`.`time`';
		$rResult = mysql_query($sSql);
	}
	elseif( $_POST['tieGoesTo'] == 1 && $iTieOption == 2 )
	{
		$sSql = '	DELETE FROM `arcade_highscores`  ';
		$rResult = mysql_query($sSql);
		$sSql = '	INSERT INTO 
							`arcade_highscores` 
						(`gameid`, `userid`, `score`, `time`) 
						SELECT `as4`.`gameid`, `as4`.`userid`, `as4`.`score`, `as4`.`time`
						FROM `arcade_scores` AS `as4`
						JOIN	(
							SELECT `asj2`.`gameid`, MIN(`asj2`.`time`) AS `time`
							FROM
								(
								SELECT `as1`.`gameid`, `as1`.`userid`, `as1`.`score`, `as1`.`time`
								FROM `arcade_scores` AS `as1`
								JOIN 	(
												SELECT `asj`.`gameid`, MAX(`asj`.`score`) AS `score`
												FROM `arcade_scores` AS `asj`
												GROUP BY `asj`.`gameid`
											) AS `as2`
								ON 
									`as1`.`gameid` = `as2`.`gameid` && 
									`as1`.`score` = `as2`.`score`
								)	AS `asj2` 
							GROUP BY `asj2`.`gameid` 
									)	AS `as3` 
						ON 
							`as3`.`gameid` = `as4`.`gameid`&& 
							`as3`.`time` = `as4`.`time`';
		$rResult = mysql_query($sSql);
	}
}

$sql = "SELECT * FROM `arcade_options`";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result)){
	$var = $row['var'];
	$value = $row['value'];
	$options[$var] = $value;
}
$options['userlevels'] = explode(",", $options['userlevels']);
foreach($options['userlevels'] as $k=>$v)
	$options['userlevels'][$k] = trim($v);
$smarty->assign('aOptions', $options);

$aUserLevels = array();
$sql = 'SELECT 
				`level_id`, `level_name` 
			FROM `se_levels` ';
$result = mysql_query($sql);
while( $aRow=mysql_fetch_assoc($result) )
{
	$aUserLevels[ $aRow['level_id'] ]['name'] = $aRow['level_name'];
	if( is_numeric(array_search($aRow['level_id'], $options['userlevels'])) )
		$aUserLevels[ $aRow['level_id'] ]['sel'] = 1;
}
$smarty->assign('aUserLevels', $aUserLevels);
include "admin_footer.php";
?>