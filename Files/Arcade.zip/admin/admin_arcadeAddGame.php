<?

$page = "admin_arcadeAddGame";
include "admin_header.php";

$time = time();
$shortname = NULL;
$title = NULL;
$file = NULL;
$width = NULL;
$height = NULL;
$miniimage = NULL;
$stdimage = NULL;
$isreverse = NULL;
$description = NULL;
$categoryid = NULL;

if (isset($_POST['submit'])){
	$shortname =  mysql_real_escape_string($_POST['shortname']);
	$title =  mysql_real_escape_string($_POST['title']);
	$file =  mysql_real_escape_string($_POST['file']);
	$width =  mysql_real_escape_string($_POST['width']);
	$height =  mysql_real_escape_string($_POST['height']);
	$miniimage =  mysql_real_escape_string($_POST['miniimage']);
	$stdimage =  mysql_real_escape_string($_POST['stdimage']);
	$isreverse =  mysql_real_escape_string($_POST['isreverse']);
	$description =  mysql_real_escape_string($_POST['description']);
	$categoryid =  mysql_real_escape_string($_POST['categoryid']);
	
	$error = false;
	if ($shortname == "")
	{
		$smarty->assign('bShortName', true);
		$error = true;
	}
	else
		$smarty->assign('bShortName', false);
	if ($title == "")
	{
		$smarty->assign('bTitle', true);
		$error = true;
	}
	else
		$smarty->assign('bTitle', false);
	if ($description == "")
	{
		$smarty->assign('bDescription', true);
		$error = true;
	}
	else
		$smarty->assign('bDescription', false);
	if ($file == "")
	{
		$smarty->assign('bFile', true);
		$error = true;
	}
	else
		$smarty->assign('bFile', false);
	if ($miniimage == "")
	{
		$smarty->assign('bMiniImage', true);
		$error = true;
	}
	else
		$smarty->assign('bMiniImage', false);
	if ($stdimage == "")
	{
		$smarty->assign('bStdImage', true);
		$error = true;
	}
	else
		$smarty->assign('bStdImage', false);
	if ($isreverse == "")
	{
		$smarty->assign('bIsReverse', true);
		$error = true;
	}
	else
		$smarty->assign('bIsReverse', false);
	if($error == false)
	{
		$sql = "INSERT INTO `arcade_games` (`shortname`, `title`, `description`, `file`, `width`, `height`, `miniimage`, `stdimage`, `categoryid`, `isreverse`) VALUES ('$shortname', '$title', '$description', '$file', '$width', '$height',  '$miniimage', '$stdimage', '$categoryid', '$isreverse')";
		$result=mysql_query($sql) or die(mysql_error());
		
		$shortname = "";
		$title = "";
		$file = "";
		$width = "";
		$height = "";
		$miniimage = "";
		$stdimage = "";
		$isreverse = "";
		$description = "";
		$categoryid = "";
		$smarty->assign('bSubmit', true);
	}
	$smarty->assign('bSubmit', true);
}
$smarty->assign('bSubmit', false);

$smarty->assign('shortname', $shortname);
$smarty->assign('title', $title);
$smarty->assign('file', $file);
$smarty->assign('width', $width);
$smarty->assign('height', $height);
$smarty->assign('miniimage', $miniimage);
$smarty->assign('stdimage', $stdimage);
$smarty->assign('isreverse', $isreverse);
$smarty->assign('description', $description);
$smarty->assign('categoryid', $categoryid);

$sql="SELECT * FROM `arcade_categories` ORDER BY `displayorder`";
$result=mysql_query($sql);
$catarray = array(); $aCategory = array();
while($row = mysql_fetch_array($result))
	$aCategory[$row['catid']] = stripslashes($row['catname']);
$smarty->assign('aCategory', $aCategory);


include "admin_footer.php";
?>