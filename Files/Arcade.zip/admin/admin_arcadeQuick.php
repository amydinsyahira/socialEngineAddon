<?
$page = "admin_arcadeQuick";
include "admin_header.php";

// defaults
$perm_error = false;
$completed = false;

// new game class
include '../include/newGame.class.php';

// check destination folder permissions
$message = array();
$perm = substr(decoct(fileperms('../file/arcade/swf')),2);
if($perm != 777){
	$message['1'] = true;
	$perm_error = true;
}
$perm = substr(decoct(fileperms('../file/arcade/images')),2);
if($perm != 777){
	$message['2'] = true;
	$perm_error = true;
}
$perm = substr(decoct(fileperms('../file/arcade/gamedata')),2);
if($perm != 777){
	$message['3'] = true;
	$perm_error = true;
}
$perm = substr(decoct(fileperms('../file/arcade/extras')),2);
if($perm != 777){
	$message['4'] = true;
	$perm_error = true;
}

if(isset($_POST['submitStart'])){
	// time
	$time = time();

	// vars to fill
	$games_installed = 0;
	$install_file_not_found = 0;
	$duplicate_game = 0;
	$bad_permissions = 0;

	// read initial list
	$folder=dir("../file/arcade/upload");
	while($fEntry=$folder->read()){
		if (preg_match("/\./", "$fEntry")) {
		}
		else{
			// ok, this could be a game or a folder of games
			if(is_dir($folder->path . '/' . $fEntry)){
				$newGame = new newGame($folder->path,$fEntry);
				$newGame->read_files();
				// is it actually a game?
				if($newGame->is_game()){
					$output = $newGame->add_game(intval($_POST['uploadFolder']),$time);
					if($output == 1){
						$games_installed++;
					}
					elseif($output == 2){
						$install_file_not_found++;
					}
					elseif($output == 3){
						$duplicate_game++;
					}
					elseif($output == 4){
						$bad_permissions++;
					}
				}
				// nope, lets see if its a folder that has games
				else{
					foreach($newGame->folders as $value){
						$newGame2 = new newGame($folder->path . '/' . $fEntry,$value);
						$newGame2->read_files();
						// is it actually a game?
						if($newGame2->is_game()){
							$postval = md5($fEntry);
							$output = $newGame2->add_game(intval($_POST[$postval]),$time);
							if($output == 1){
								$games_installed++;
							}
							elseif($output == 2){
								$install_file_not_found++;
							}
							elseif($output == 3){
								$duplicate_game++;
							}
							elseif($output == 4){
								$bad_permissions++;
							}
						}
						// nope, lets see if its a folder that has games
						else{
							// nothing here, we're only going one deep
						}
					}
				}
			}
			else{
				// is not a game or a folder
			}			
		}
	}
	$folder->close();
	
	$completed = true;
	$smarty->assign("games_installed", $games_installed);
	$smarty->assign("install_file_not_found", $install_file_not_found);
	$smarty->assign("duplicate_game", $duplicate_game);
	$smarty->assign("bad_permissions", $bad_permissions);
}
else{
	// get list of categories
	$sql="SELECT * FROM `arcade_categories` ORDER BY `displayorder`";
	$result=mysql_query($sql);
	$catnum = mysql_num_rows($result);
	$catarray = array();
	while($row = mysql_fetch_array($result)){
		$catid = $row['catid'];
		$catname = $row['catname'];
		$catarray[$catid] = $catname;
	}
	$smarty->assign("catarray",$catarray);

	// vars to fill
	$main_games = 0;
	$game_folders = array();

	// read initial list
	$folder=dir("../file/arcade/upload");
	while($fEntry=$folder->read()){
		if (preg_match("/\./", "$fEntry")) {
		}
		else{
			// ok, this could be a game or a folder of games
			if(is_dir($folder->path . '/' . $fEntry)){
				$newGame = new newGame($folder->path,$fEntry);
				$newGame->read_files();
				// is it actually a game?
				if($newGame->is_game()){
					$main_games++;
				}
				// nope, lets see if its a folder that has games
				else{
					foreach($newGame->folders as $value){
						$newGame2 = new newGame($folder->path . '/' . $fEntry,$value);
						$newGame2->read_files();
						// is it actually a game?
						if($newGame2->is_game()){
							if(isset($game_folders[$fEntry])){
								$game_folders[$fEntry]['games']++;
							}
							else{
								$game_folders[$fEntry]['games'] = 1;
							}
						}
						// nope, lets see if its a folder that has games
						else{
							// nothing here, we're only going one deep
						}
					}
				}
			}
			else{
				// is not a game or a folder
			}			
		}
	}
	$folder->close();
	$smarty->assign("main_games", $main_games);
	$smarty->assign("game_folders", $game_folders);
}

if(isset($message)){
	$smarty->assign("message", $message);
}
$smarty->assign("completed", $completed);

include "admin_footer.php";
?>