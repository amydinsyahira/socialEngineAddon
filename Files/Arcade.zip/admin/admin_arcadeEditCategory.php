<?

$page = "admin_arcadeEditCategory";
include "admin_header.php";

$bError = false;
$smarty->assign('bSubmit', false);
if(isset($_POST['submit']))
{
		$displayorder = $_POST['displayorder'];
		$sCatName = mysql_real_escape_string($_POST['sCatName']);
		$edid = $_POST['pcat'];
		$displayorder = strip_tags($displayorder);
		$displayorder = trim($displayorder);
		if ($displayorder == "") 
		{
			$_GET['edit'] = $edid;
			$bError = true;
		}
		else {
			$smarty->assign('bSubmit', true);
			$sql="UPDATE `arcade_categories` SET `displayorder` = '".$displayorder."', `catname` = '".$sCatName."' WHERE `catid` = '".$edid."' LIMIT 1";
			$result=mysql_query($sql);
		}
}

if(isset($_GET['edit']))
	$getedit = mysql_real_escape_string($_GET['edit']);
elseif(isset($_GET['delete']))
	$getdelete = mysql_real_escape_string($_GET['delete']);
elseif(isset($_GET['deletecheck']))
	$getdeletecheck = mysql_real_escape_string($_GET['deletecheck']);
	
if(isset($getdelete))
{
	$smarty->assign('iType', 1);
	$smarty->assign('sGetDelete', $getdelete);
}
elseif(isset($getdeletecheck))
{
	$sql = "DELETE FROM `arcade_categories` WHERE `catid` = '".$getdeletecheck."' LIMIT 1";
	$result = mysql_query($sql);
	$smarty->assign('iType', 2);
}
elseif (isset($getedit)) 
{
	$smarty->assign('iType', 3);
	$edid = $getedit;
	$sql="SELECT * FROM `arcade_categories` WHERE catid = '$edid' LIMIT 1";
	$result=mysql_query($sql);
	$row = mysql_fetch_array($result);
	$row['catname'] = stripslashes($row['catname']);
	$smarty->assign('aRow', $row);
	$smarty->assign('bError', false);
	if($bError == true)
		$smarty->assign('bError', true);
}
else 
{
	$smarty->assign('iType', 4);
	$sql="SELECT * FROM `arcade_categories` ORDER BY `displayorder`";
	$result=mysql_query($sql);
	$catnum = mysql_num_rows($result);
	$smarty->assign('iCatNum', $catnum); $aCat = array();
	for($i = 0; $i < $catnum; $i++) { 
		$row = mysql_fetch_array($result);
		$row['catname'] = stripslashes($row['catname']);
		$aCat[] = $row;
	}
	$smarty->assign('aCat', $aCat);
}


include "admin_footer.php";
?>