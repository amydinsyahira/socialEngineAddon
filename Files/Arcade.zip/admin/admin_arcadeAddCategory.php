<?

$page = "admin_arcadeAddCategory";
include "admin_header.php";

$rawName = "";
$rawOrder = "";
$smarty->assign('iType', 1);
if (isset($_POST['submit'])) {
	$catname = $_POST['catname'];
	$displayorder = $_POST['displayorder'];
	$rawName = $catname;
	$rawOrder = $displayorder;
	$catname = strip_tags($catname);
	$catname = mysql_real_escape_string(trim($catname));
	$displayorder = strip_tags($displayorder);
	$displayorder = mysql_real_escape_string(trim($displayorder));
	if ($catname == "") 
		$smarty->assign('iType', 2);
	else if ($displayorder == "") 
		$smarty->assign('iType', 3);
	else 
	{
		//create category
		$sql = "INSERT INTO `arcade_categories` (catname, displayorder) VALUES ('$catname', '$displayorder')";
		$result = mysql_query($sql) or die(mysql_error());
		$smarty->assign('iType', 4);
	}
}
$smarty->assign('sRawName', $rawName);
$smarty->assign('sRawOrder', $rawOrder);


include "admin_footer.php";
?>