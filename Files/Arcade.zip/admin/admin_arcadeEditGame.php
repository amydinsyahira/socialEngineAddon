<?

$page = "admin_arcadeEditGame";
include "admin_header.php";

if(isset($_GET['delete']))
	$getdelete = mysql_real_escape_string($_GET['delete']);
elseif(isset($_GET['erase']))
	$geterase = mysql_real_escape_string($_GET['erase']);
elseif(isset($_GET['delsure']))
	$getdelsure = mysql_real_escape_string($_GET['delsure']);
elseif(isset($_GET['hssure']))
	$gethssure = mysql_real_escape_string($_GET['hssure']);

if(isset($_GET['edit']))
	$getedit = mysql_real_escape_string($_GET['edit']);
if(isset($_GET['editc']))
{
	$geteditc = mysql_real_escape_string($_GET['editc']);
	$smarty->assign('sGetEditC', $geteditc);
}
if(isset($_GET['catc']))
	$getcatc = mysql_real_escape_string($_GET['catc']);	
if(isset($_GET['gamec']))
	$getgamec = mysql_real_escape_string($_GET['gamec']);
if(isset($_GET['begin']))
	$getbegin = mysql_real_escape_string($_GET['begin']);

if (isset($getdelete)){
	$iType = 1;
	$delid = $getdelete;
	$sql="DELETE FROM `arcade_games` WHERE `gameid` = '".$delid."' LIMIT 1";
	$result=mysql_query($sql);
}
elseif (isset($geterase)){
	$iType = 2;
	$sql="DELETE FROM `arcade_scores` WHERE `gameid` = '".$geterase."'";
	$result=mysql_query($sql);
	$sql="DELETE FROM `arcade_highscores` WHERE `gameid` = '".$geterase."'";
	$result=mysql_query($sql);
}
elseif(isset($getcatc, $getgamec)){
	$iType = 3;
	$catc = $getcatc;
	$gamec = $getgamec;
	$sql = "UPDATE `arcade_games` SET `categoryid` = '".$catc."' WHERE `gameid` = '".$gamec."' LIMIT 1";
	$result=mysql_query($sql);
}
elseif(isset($_POST['submit'])){
	$iType = 4;
	$gameid = mysql_real_escape_string($_POST['pgameid']);
	$categoryid = mysql_real_escape_string($_POST['categoryid']);
	$width = mysql_real_escape_string($_POST['width']);
	$height = mysql_real_escape_string($_POST['height']);
	$miniimage = mysql_real_escape_string($_POST['miniimage']);
	$stdimage = mysql_real_escape_string($_POST['stdimage']);
	$isreverse = mysql_real_escape_string($_POST['isreverse']);
	$shortname = mysql_real_escape_string($_POST['shortname']);
	$title = mysql_real_escape_string($_POST['title']);
	$description = mysql_real_escape_string($_POST['description']);
	if ($file == "") {
		$iType2 = 1;
		$getedit = $gameid;
	}
	else if ($miniimage == "") {
		$iType2 = 2;
		$getedit = $gameid;
	}
	else if ($stdimage == "") {
		$iType2 = 3;
		$getedit = $gameid;
	}
	else if ($isreverse == "") {
		$iType2 = 4;
		$getedit = $gameid;
	}
	else{
		$iType2 = 4;
		$sql = "UPDATE `arcade_games` SET 
		`width` = '$width',
		`shortname` = '$shortname',
		`title` = '$title',
		`description` = '$description',
		`height` = '$height',
		`categoryid` = '$categoryid',
		`miniimage` = '$miniimage',
		`stdimage` = '$stdimage',
		`isreverse` = '$isreverse' WHERE `gameid` = '$gameid' LIMIT 1";
		$result=mysql_query($sql);
	}
	$smarty->assign('iType2', $iType2);
}
else{
	$iType = NULL;
}
$smarty->assign('iType', $iType);

if(isset($getdelsure)){
	$smarty->assign('iSection', 1);
	$smarty->assign('sGetDelSure', $getdelsure);
}
elseif(isset($gethssure)){
	$smarty->assign('iSection', 2);
	$smarty->assign('sGetHsSure', $gethssure);
}
elseif (isset($getedit)){
	$smarty->assign('iSection', 3);
	$editgame = $getedit;
	$sql="SELECT * FROM `arcade_games` WHERE `gameid` = '$editgame' LIMIT 1";
	$result=mysql_query($sql);
	$aGame = mysql_fetch_array($result);
	$aGame['title'] = stripslashes($aGame['title']);
	$aGame['description'] = stripslashes($aGame['description']);
	$categoryid = $aGame['categoryid'];
	$smarty->assign('aGame', $aGame);
	$smarty->assign('iCategoryId', $categoryid);
	
	$sql="SELECT * FROM `arcade_categories` WHERE `catid` = '$categoryid' LIMIT 1";
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	$excatname = $row['catname'];
	$smarty->assign('sExcatName', $excatname);

	$sql5="SELECT * FROM `arcade_categories` ORDER BY `displayorder`";
	$result5=mysql_query($sql5);
	$catarray = array(); $aOptions = array();
	while($row5 = mysql_fetch_array($result5))
		$aOptions[$row5['catid']] = stripslashes($row5['catname']);
	$smarty->assign('aOptions', $aOptions);
}
else{
	$smarty->assign('iSection', 4);
	$sql8="SELECT * FROM `arcade_categories` ORDER BY `displayorder`";
	$result8=mysql_query($sql8);
	$catnum8 = mysql_num_rows($result8);
	$sCat = "";
	$catnum8M1 = $catnum8-1; $aTopCat = array();
	for($i = 0; $i < $catnum8; $i++) { 
		$row8 = mysql_fetch_array($result8);
		$aTopCat[$row8['catid']] = stripslashes($row8['catname']);
		$sCat .= "<a href='admin_arcadeEditGame.php?catc=".$row8['catid']."&gamec=%gId%'>".stripslashes($row8['catname'])."</a>";
		if($i < $catnum8M1)$sCat .=" :: ";	
	}

	$smarty->assign('aTopCat', $aTopCat);
	//$editgame = $getedit;
	if(isset($_POST['searchSubmit'])){
		$words = mysql_real_escape_string($_POST['keyWords']);
		$sql8="SELECT * FROM `arcade_games` WHERE `title` LIKE '%".$words."%' OR `description` LIKE '%".$words."%' ORDER BY `title`";
	}
	elseif(isset($geteditc)){
		$editc = $geteditc;
		if($editc == "allgs")
			$sql8="SELECT * FROM `arcade_games` ORDER BY `title`";
		else
			$sql8="SELECT * FROM `arcade_games` WHERE `categoryid` = '$editc' ORDER BY `title`";
	}
	else{
		$sql8="SELECT * FROM `arcade_games` ORDER BY `title`";
		$geteditc = "allgs";
	}
	$result8=mysql_query($sql8);
	$num8 = mysql_num_rows($result8);

	$gamestemp = array();
	$beginarray = array();
	$begincount = 0;
	$total = 0;
	$beginarray[] = $total;
	while($row8 = mysql_fetch_array($result8)){
		$gamestemp[] = $row8;
		$begincount++;
		$total++;
		if($begincount == 20){
			$beginarray[] = $total;
			$begincount = 0;
		}
	}
	
	if(isset($getbegin) && $getbegin > 0){
	}
	else{
		$getbegin = 0;
	}
	
	if($num8 < 20){
		$end = $num8;
	}
	else{
		$end = $getbegin + 20;
	}
	$aGames = array();
	for($i=$getbegin;$i<$end;$i++){
		if(isset($gamestemp[$i])){
			$gamestemp[$i]['title'] = stripslashes($gamestemp[$i]['title']);
			$gamestemp[$i]['links'] = str_replace('%gId%', $gamestemp[$i]['gameid'], $sCat);
			$aGames[] = $gamestemp[$i];
		}
	}
	$smarty->assign('aGames', $aGames);
	
	$aBegin = array();
	foreach ($beginarray as $k=>$v)
		$aBegin[$k+1] = $v;
	$smarty->assign('aBegin', $aBegin);	
}

include "admin_footer.php";
?>