<?

$page = "admin_arcadeBuildStats";
include "admin_header.php";

$smarty->assign('bRun', false);
if(isset($_POST['submit']))
{
	$smarty->assign('bRun', true);
	$sql = "SELECT `gameid`,`isreverse` FROM `arcade_games`";
	$result = mysql_query($sql);
	$num = mysql_num_rows($result);
	
	$arcade_champs = array();
	
	if(isset($_POST['groupNum']))
		$groupNum = $_POST['groupNum'];
	else
		$groupNum = 300;
	if(isset($_POST['current']))
		$current = $_POST['current'] - 1;
	else
	{
		$current = 0;
		$sql1 = "UPDATE `arcade_info` SET `champs` = 0";
		$result1 = mysql_query($sql1);
	}
	if($current >= $num){
		$smarty->assign('bDone', true);
	}
	else
	{
		mysql_data_seek($result,$current);
		$tempcur = 0;
		$bDone = false;
		while($row = mysql_fetch_assoc($result))
		{
			$gameid = $row['gameid'];
			if($row['isreverse'] == 1)
				$sql2 = "SELECT `userid` FROM `arcade_highscores` WHERE `gameid` =  '$gameid' ";
			else
				$sql2 = "SELECT `userid` FROM `arcade_highscores` WHERE `gameid` =  '$gameid' ";
			$result2 = mysql_query($sql2);
			$num2 = mysql_num_rows($result2);
			if($num2 == 1)
			{
				$row2 = mysql_fetch_assoc($result2);
				if(isset( $arcade_champs[ $row2['userid'] ]) )
					$arcade_champs[ $row2['userid'] ] += 1;
				else
					$arcade_champs[ $row2['userid'] ] = 1;
			}
			$current++;
			$tempcur++;
			if($tempcur >= $groupNum){
				break;
			}
			if($current >= $num){
				$bDone = true;
				break;
			}
		}
		foreach($arcade_champs as $key => $value)
		{
			$sql3 = "SELECT `champs` FROM `arcade_info` WHERE `userid` = '". $key ."' LIMIT 1";
			$result3 = mysql_query($sql3);
			if( ($row3 = mysql_fetch_array($result3)) )
			{
				$temp_champs = $row3['champs'];
				$temp_champs += $value;
				$sql3 = "UPDATE `arcade_info` SET `champs` = '". $temp_champs ."' WHERE `userid` = '". $key ."' LIMIT 1";
				mysql_query($sql3);
			}
			else
			{
				$sql3 = "INSERT INTO `arcade_info` (`champs`, `userid`) VALUES ('".$value."',  '".$key."' ) ";
				mysql_query($sql3);
			}
		}
		if($bDone == true)
			$smarty->assign('bDone', true);
		else
		{
			$smarty->assign('bDone', false);
			$smarty->assign('iCurrent', $current++);
			$smarty->assign('iNum', $num);
			$smarty->assign('sGroupNum', $groupNum);
		}
	}
	
}

include "admin_footer.php";
?>