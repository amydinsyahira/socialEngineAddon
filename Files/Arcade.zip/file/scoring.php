<?php
include "header.php";
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
// record highscore
if(isset($_GET['do']))
	$getdo = $_GET['do'];
if( !empty($getdo) && is_numeric($iUserId) )
{
	if($getdo == "newscore")
	{	
		$sMainFolder = "http://".$_SERVER['SERVER_NAME'].str_replace('index.php', '', $_SERVER['SCRIPT_NAME']);
		$gname = mysql_real_escape_string($_POST['gname']);
		$score = floor(mysql_real_escape_string($_POST['gscore']));
	
		$sql="SELECT `gameid`,`isreverse`,`title` FROM `arcade_games` WHERE `shortname` = '{$gname}' LIMIT 1";
		$result=mysql_query($sql);
		$row = mysql_fetch_assoc($result);
		$gameid = $row['gameid'];
		$isreverse = $row['isreverse'];
		$gameTitle = stripslashes($row['title']);
		$time = time();
		
		$checktime = $time - 60;
		$sql = "SELECT `gameid` FROM `arcade_scores` 
					WHERE 
						`gameid` = '{$gameid}' && 
						`userid` = '{$iUserId}' && 
						`score` = '{$score}' && 
						`time` > '{$checktime}' LIMIT 1";
		$result = mysql_query($sql);
		if( mysql_num_rows($result) === 0 )
		{
			$aArcadeSttng = array();
			$sSql = "	SELECT 
								* 
							FROM `arcade_options` ";
			$rResult = mysql_query($sSql);
			while( ($aRow=mysql_fetch_assoc($rResult)) )
				$aArcadeSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
			if( $aArcadeSttng['activitypoints'] > 0 )
			{
				$sql = "	SELECT COUNT(*) AS `cnt` 
								FROM `arcade_scores` 
								WHERE 
									`userid` = '{$iUserId}' && 
									`time` BETWEEN '".($time-86400)."' AND '".$time."'";
				$result = mysql_query($sql);
				$row = mysql_query($result);
				$row['cnt'] = $row['cnt'] ? $row['cnt'] : 0 ;
				if( $row['cnt'] < $aArcadeSttng['activitypoints'] )
				{
					$sql = "SELECT `userid` FROM `arcade_info` WHERE `userid` = '{$iUserId}' ";
					$result = mysql_query($sql);
					if( ($row=mysql_fetch_assoc($result)) )
						$sql = "UPDATE `arcade_info` SET `points` = `points` + '{$aRow['value']}' WHERE `userid` = '{$iUserId}' LIMIT 1";
					else
						$sql = "INSERT INTO `arcade_info` (`userid`, `points`) VALUES ('{$iUserId}', '{$aRow['value']}')";
					$result = mysql_query($sql);
				}
			}
		//check to see if we have a new high score
			if( $aArcadeSttng['tieGoesTo'] == 2 )
				$sql = "SELECT `gameid` FROM `arcade_highscores` WHERE `gameid` = '{$gameid}' AND `score` ".($isreverse == 1 ? "<=" : ">=")." '{$score}' LIMIT 1";
			else
				$sql = "SELECT `gameid` FROM `arcade_highscores` WHERE `gameid` = '{$gameid}' AND `score` ".($isreverse == 1 ? "<" : ">")." '{$score}' LIMIT 1";
			$result=mysql_query($sql);
			if( mysql_num_rows($result) === 0 )
			{
		 //remove credit from old highscorer
				$sql = "SELECT `userid` FROM `arcade_highscores` WHERE `gameid` = '{$gameid}' LIMIT 1";
				$result=mysql_query($sql);
				if( ($row = mysql_fetch_assoc($result)) )
				{
					$sql = "UPDATE `arcade_info` SET `champs` = `champs`-1 WHERE `userid` = '{$row['userid']}' LIMIT 1";
					$result=mysql_query($sql);
				}
		// add credit to new highscorer
				$sql = "UPDATE `arcade_info` SET `champs` = `champs`+1 WHERE `userid` = '{$iUserId}' LIMIT 1";
				$result=mysql_query($sql);
				$sql = "SELECT `userid` FROM `arcade_highscores` WHERE `gameid` = '{$gameid}' ";
				$result = mysql_query($sql);
				if( ($row=mysql_fetch_assoc($result)) )
					$sql = "UPDATE `arcade_highscores` SET `userid` = '{$iUserId}', `score` = '{$score}', `time` = '{$time}' WHERE `gameid` = '{$gameid}' ";
				else
					$sql = "INSERT INTO `arcade_highscores` (`userid`, `score`, `gameid`, `time`) VALUES ('{$iUserId}', '{$score}', '{$gameid}', '{$time}')";
				$result=mysql_query($sql);
		// submit to news
				$row['userid'] = isset($row['userid']) ? $row['userid'] : ""; 
				$sql = "INSERT INTO `arcade_news` (`type`, `time`, `winnerid`, `loserid`, `score`, `gameid`) VALUES ('1', '{$time}', '{$iUserId}', '{$row['userid']}', '{$score}', '{$gameid}')";
				$result=mysql_query($sql);
			}
		//Check to see if score is a new user high score
			if( $aArcadeSttng['tieGoesTo'] == 2)
				$sql = "SELECT `scoreid` FROM `arcade_userhighscores` WHERE `gameid` = '{$gameid}' && `score` ".($isreverse == 1 ? ">=" : "<=")." '{$score}' && `userid` = '{$iUserId}' LIMIT 1";
			else
				$sql = "SELECT `scoreid` FROM `arcade_userhighscores` WHERE `gameid` = '{$gameid}' && `score` ".($isreverse == 1 ? ">" : "<")." '{$score}' && `userid` = '{$iUserId}' LIMIT 1";
			$result=mysql_query($sql);
			if( mysql_num_rows($result) === 1)
			{
				$aRow = mysql_fetch_assoc($result);
				$sSql = 'DELETE FROM `arcade_userhighscores` WHERE `scoreid`= "'.$aRow['scoreid'].'" LIMIT 1';
				$rResult =mysql_query($sSql);
				$sql = 'INSERT INTO `arcade_userhighscores` (`score`,  `gameid`, `userid`, `time`) VALUES ( "'.$score.'",  "'.$gameid.'", "'.$iUserId.'", "'.$time.'" )';
				$result =mysql_query($sql);
			}
			else
			{
				$sql = "SELECT `scoreid` FROM `arcade_userhighscores` WHERE `gameid` = '{$gameid}' && `userid` = '{$iUserId}' LIMIT 1";
				$result=mysql_query($sql);
				if( !($row=mysql_fetch_assoc($result)) )
				{
					$sql = "INSERT INTO `arcade_userhighscores` (`gameid`, `score`, `userid`, `time`) VALUES ('{$gameid}', '{$score}', '{$iUserId}', '{$time}')";
					$result=mysql_query($sql);
				}
			}
		//Record game score		
			$sql = "INSERT INTO `arcade_scores` (`gameid`, `userid`, `score`,`time`) VALUES ('{$gameid}', '{$iUserId}', '{$score}','{$time}')";
			$result=mysql_query($sql);				
		// update challenge
			if( isset($_SESSION['arcadeCid']) )
			{
				$ncid = mysql_real_escape_string($_SESSION['arcadeCid']);
				$sql = "SELECT 
							`score1`, 
							`score2`, 
							`user1` as `userId1`,
							`user2` as `userId2`
						FROM `arcade_challenges` 
						WHERE `id` = '{$ncid}' && (`user1` = '{$iUserId}' || `user2` = '$iUserId') && `gameid` = '{$gameid}' LIMIT 1";
				$result = mysql_query($sql);
				if( ($row = mysql_fetch_assoc($result)) )
				{
					if($row['userId1'] == $iUserId)
						$col = "score1";
					else
						$col = "score2";
					if( !isset($row[ $col ]) )
					{
						$sql = "UPDATE `arcade_challenges` SET `{$col}` = '{$score}'  WHERE `id` = '{$ncid}' LIMIT 1";
						$result = mysql_query($sql);
					}
					// check winner
					$sql = "SELECT 
									`ac`.`score1`,
									`ac`.`score2`,
									`ac`.`user1`,
									`ac`.`user2`,
									`au1`.`user_displayname` as `userName1`,
									`au1`.`user_username` AS `userMsg1`,
									`au2`.`user_displayname` as `userName2`,
									`au2`.`user_username` AS `userMsg2`
								FROM `arcade_challenges` AS `ac`
								INNER JOIN `se_users` AS `au1` ON `au1`.`user_id` = `ac`.`user1`
								INNER JOIN `se_users` AS `au2` ON `au2`.`user_id` = `ac`.`user2`
								WHERE `ac`.`id` = '{$ncid}' LIMIT 1";
					$result = mysql_query($sql);
					$row = mysql_fetch_assoc($result);
					$aResult = array();
					if( isset($row['score1'], $row['score2']) )
					{
						if( $row['score1'] > $row['score2'] && $isreverse == 1 || $row['score2'] >= $row['score1'] && $isreverse != 1 )
							$aResult = array(	'winnerId' => $row['user2'], 
															'loserId' => $row['user1'], 
															'winnerName' => $row['userName2'], 
															'loserName' => $row['userName1'], 
															'winnerName2' => $row['userMsg2'], 
															'loserName2' => $row['userMsg1'],
															'winnerScore' => $row['score2'], 
															'loserScore' => $row['score1']);
						elseif( $row['score1'] > $row['score2'] && $isreverse != 1 || $row['score2'] >= $row['score1'] && $isreverse == 1 )
							$aResult = array(	'winnerId' => $row['user1'], 
															'loserId' => $row['user2'], 
															'winnerName' => $row['userName1'], 
															'loserName' => $row['userName2'], 
															'winnerName2' => $row['userMsg1'], 
															'loserName2' => $row['userMsg2'],
															'winnerScore' => $row['score1'], 
															'loserScore' => $row['score2']);
						$sql = "UPDATE `arcade_challenges` SET `winner` = '{$aResult['winnerId']}'  WHERE `id` = '{$ncid}' LIMIT 1";
						$result = mysql_query($sql);
						$sql = "INSERT INTO `arcade_news` (`type`, `time`, `winnerid`, `loserid`, `score`, `gameid`) VALUES ('2', '{$time}', '{$aResult['winnerId']}', '{$aResult['loserId']}', '{$aResult['winnerScore']}', '$gameid')";
						$result=mysql_query($sql);
					// send loser a message
							$subject = "{$aResult['winnerName']} has defeated you at {$gameTitle}";
							$mess = 	"{$aResult['winnerName']} has defeated your score of {$aResult['loserScore']} at {$gameTitle} with a score of {$aResult['winnerScore']}.".
											"<p>You can view more details by clicking <a href='arcadechallenge.php'>here.</a>";
							$user->user_message_send($aResult['loserName2'], $subject, $mess);
					// send winner a message
							$subject = "You have just defeated {$aResult['loserName']} at {$gameTitle}";
							$mess = 	"Your score of {$aResult['winnerScore']} defeated {$aResult['loserName']}'s score of {$aResult['loserScore']} at {$gameTitle}!".
											"<p>You can view more details by clicking <a href='arcadechallenge.php'>here.</a>";
							$user->user_message_send($aResult['winnerName2'], $subject, $mess);
					}
					else
					{
					// send opponent a message
						$to = ($row['user1'] == $iUserId) ? $row['userMsg2'] : $row['userMsg1'];
						$subject = $user->user_info['user_displayname']." has submitted a score!";
						$mess = 	$user->user_info['user_displayname']." has submitted a score of {$score} for your arcade duel at {$gameTitle}!".
										"<p> You can play to submit your opposing score by clicking <a href='game.php?play={$gameid}&cid={$ncid}'>here.</a>";
						$user->user_message_send($to, $subject, $mess);
					}				
				}
				unset($_SESSION['arcadeCid']);
			}
			$turl = $sMainFolder."highscores.php?highscore=".$gameid;
			header("Location: $turl");
			exit;
		}
		else
		{
			$turl = $sMainFolder."highscores.php?highscore=".$gameid;
			header("Location: $turl");
			exit;
		}
	}
}
?>