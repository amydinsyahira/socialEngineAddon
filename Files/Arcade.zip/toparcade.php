<?php
$page = "toparcade";
include "header.php";

////////GET LANG IDS
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'toparcade.', '') AS `key`
				FROM `arcade_settings` WHERE `defVarName` LIKE '%toparcade.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aArcdSttng = array();
$sSql = "	SELECT 
					* 
				FROM `arcade_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aArcdSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
$smarty->assign('aArcadeSetting', $aArcdSttng);
//////////////////////////////////////////////////////////////////////////
$aGames = array();
$sql = "	SELECT 
					`title`,`gameid`,`timesplayed` 
				FROM `arcade_games` 
				ORDER BY `timesplayed` DESC LIMIT 50
			";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
	$aGames[] = array(	'title' => stripslashes($row['title']),
										'gameid' => $row['gameid'],
										'timesplayed' => $row['timesplayed']);
$smarty->assign('aGames', $aGames);

$sql ="SELECT `setting_username` FROM `se_settings` LIMIT 1";
$result = mysql_query($sql);
$aRow = mysql_fetch_assoc($result);
$bUserNames = $aRow['setting_username'] == 1 ? TRUE : FALSE;

// only show users with records.
$aChamps = array();
$sql = "	SELECT 
					`a`.`champs`,
					`u`.`user_id`,
					".($bUserNames ? "
					`u`.`user_username` AS `user`":"
					`u`.`user_displayname` AS `user`")." 
				FROM `arcade_info` AS `a`
				INNER JOIN `se_users` AS `u` ON `u`.`user_id` = `a`.`userid`
				ORDER BY `champs` DESC LIMIT 50";
$result = mysql_query($sql);
while( ($row = mysql_fetch_assoc($result)) )
	$aChamps[] = array(	'user' => $row['user'],
											'userId' => $row['user_id'],
											'champs' => $row['champs']);
$smarty->assign('aChamps', $aChamps);

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>