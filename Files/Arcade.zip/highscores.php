<?php
$page = "highscores";
include "header.php";
/////////////////////////////////////////////
//////////CHECKS ID
if(isset($_GET['highscore']))
	$iGameId = mysql_real_escape_string($_GET['highscore']);
else
{
	$sMainFolder = "http://".$_SERVER['SERVER_NAME'].str_replace('highscores.php', '', $_SERVER['SCRIPT_NAME']);
	header("Location: ".$sMainFolder."gamelist.php");
	exit;
}
////////GET LANG IDS 
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'highscore.', '') AS `key`
				FROM `arcade_settings` WHERE `defVarName` LIKE '%highscore.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aArcdSttng = array();
$sSql = "	SELECT 
					* 
				FROM `arcade_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aArcdSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
$smarty->assign('aArcadeSetting', $aArcdSttng);
//////////////////////////////////////////////////////////////////////////
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);

$sql ="SELECT `setting_username` FROM `se_settings` LIMIT 1";
$result = mysql_query($sql);
$aRow = mysql_fetch_assoc($result);
$bUserNames = $aRow['setting_username'] == 1 ? TRUE : FALSE;

$sSql="SELECT * FROM `arcade_games` WHERE `gameid` = '".$iGameId."' LIMIT 1";
$rResult=mysql_query($sSql);
$aRow = mysql_fetch_assoc($rResult);
$aRow['title'] = stripslashes($aRow['title']);
$aRow['description'] = stripslashes($aRow['description']);
$isreverse = $aRow['isreverse'];
$smarty->assign('aGame', $aRow);

$aScores = array();
if ( $aArcdSttng['oneHighScore'] == 2 )
	$sql="	SELECT 
					`s`.`score`,
					".($bUserNames ? "
					`u`.`user_username` AS `username`,":"
					`u`.`user_displayname` AS `username`,")." 
					`u`.`user_id` AS `userId`
				FROM `arcade_scores` AS `s`
				INNER JOIN `se_users` AS `u` ON `u`.`user_id` = `s`.`userid`
				WHERE `gameid` = '{$iGameId}' 
				ORDER BY `s`.`score` ".($isreverse == 1 ? "" : "DESC")." LIMIT 100";
else
	$sql="	SELECT
					".($bUserNames ? "
					`u`.`user_username` AS `username`,":"
					`u`.`user_displayname` AS `username`,")."
					`u`.`user_id` AS `userId`,
					MAX( `s`.`score` ) AS `score` 
				FROM 
					`arcade_scores` AS `s`
				INNER JOIN `se_users` AS `u` ON `u`.`user_id` = `s`.`userid`
				WHERE 
					`s`.`gameid` = '{$iGameId}' 
				GROUP BY `s`.`userid` 
				ORDER BY `score` ".($isreverse == 1 ? "" : "DESC")." LIMIT 100";	
$result=mysql_query($sql);
while($row = mysql_fetch_array($result))
	$aScores[] = array(	'sUserName' => $row['username'],
										'userId' => $row['userId'],
										'sScore' => $row['score']);
$smarty->assign('aScores', $aScores);

$smarty->assign('bScores2', FALSE);
if ( $aArcdSttng['oneHighScore'] == 2 )
{
	$aScores2 = array();
	if($isreverse == 1)
		$sql="	SELECT 
						`score`,`time` 
					FROM 
						`arcade_scores` 
					WHERE 
						`gameid` = '{$iGameId}' && 
						`userid` = '".mysql_real_escape_string($iUserId)."' 
					ORDER BY `score` LIMIT 100";
	else
		$sql="	SELECT 
						`score`, `time` 
					FROM 
						`arcade_scores` 
					WHERE 
						`gameid` = '{$iGameId}' && 
						`userid` = '".mysql_real_escape_string($iUserId)."' 
					ORDER BY `score` DESC LIMIT 100";
	$result=mysql_query($sql);
	while( ($row = mysql_fetch_assoc($result)) )
		$aScores2[] = $row;
	$smarty->assign('aScores2', $aScores2);
	$smarty->assign('bScores2', TRUE);
}

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>