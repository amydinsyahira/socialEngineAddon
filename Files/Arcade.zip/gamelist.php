<?php
$page = "gamelist";
include "header.php";

////////GET LANG IDS
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'gamelist.', '') AS `key`
				FROM `arcade_settings` WHERE `defVarName` LIKE '%gamelist.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
$aArcdSttng = array();
$sSql = "	SELECT 
					* 
				FROM `arcade_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aArcdSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
$smarty->assign('aArcadeSetting', $aArcdSttng);
//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////GET CATEGORY
$sCat = isset($_GET['cat']) ? $_GET['cat'] : "";
$smarty->assign('sCat', $sCat);

$sql="SELECT `catname`, `catid` FROM `arcade_categories` ORDER BY `displayorder`";
$result=mysql_query($sql);
$aCate = array(); 
while($row = mysql_fetch_assoc($result))
		$aCate[$row['catid']] = stripslashes($row['catname']);

$smarty->assign('aCate', $aCate);

//////////////////////////////////////////////////////////////////////////
/////////GET NEWS
$sql ="SELECT `setting_username` FROM `se_settings` LIMIT 1";
$result = mysql_query($sql);
$aRow = mysql_fetch_assoc($result);
$bUserNames = $aRow['setting_username'] == 1 ? TRUE : FALSE;

$sql = "	SELECT
					`n`.`winnerid`, 
					`n`.`loserid`,
					`n`.`time`,
					`n`.`gameid`,
					`n`.`score`,
					`n`.`type`,
					`g`.`title`,
					".($bUserNames ? "
					`u1`.`user_username` AS `winnerName`,
					`u2`.`user_username` AS `loserName`":
					"`u1`.`user_displayname` AS `winnerName`,
					`u2`.`user_displayname` AS `loserName`")."
				FROM 
					`arcade_news`  AS `n`
				INNER JOIN `arcade_games` AS `g` ON `g`.`gameid` = `n`.`gameid`
				LEFT JOIN `se_users` AS `u1` ON `u1`.`user_id` = `n`.`winnerid`
				LEFT JOIN `se_users` AS `u2` ON `u2`.`user_id` = `n`.`loserid`
				ORDER BY `n`.`time` DESC LIMIT 1";
$result = mysql_query($sql);
if( ($row = mysql_fetch_assoc($result)) )
{
    $row['time'] = date('F j, Y', $row['time']);
    $row['title'] = stripslashes($row['title']);

    if($row['winnerid'] != $row['loserid'] && $row['loserid'] != 0 && $row['type'] == 2)
        $smarty->assign('iNewsType', 1);
    elseif($row['winnerid'] == $row['loserid'] && $row['type'] == 1)
    	$smarty->assign('iNewsType', 2);
    elseif($row['winnerid'] != $row['loserid'] && $row['loserid'] != 0 && $row['type'] == 1)
    	$smarty->assign('iNewsType', 3);
    elseif($row['loserid'] == 0 && $row['type'] == 1)
        $smarty->assign('iNewsType', 4);

	$smarty->assign('aNewsData', $row);
}else
	$smarty->assign('iNewsType', 5);
///////////////////////////////////////////////////////////////////////////////////////	    
$sql = "	SELECT 
					`u`.`user_displayname`,
					`i`.`userid`,
					`i`.`arcade_champs` 
				FROM `arcade_info` AS `i`
				INNER JOIN `se_users` AS `u` ON `u`.`user_id` = `i`.`userid`
				ORDER BY `arcade_champs` DESC LIMIT 1";
$result = mysql_query($sql);
$row = mysql_fetch_assoc($result);
$smarty->assign('aGameChamp', $row);

$sql = "	SELECT 
					`gameid`,
					`timesplayed`,
					`stdimage`,
					`title` 
				FROM `arcade_games` 
				ORDER BY `timesplayed` DESC LIMIT 1";
$result = mysql_query($sql);
$row = mysql_fetch_assoc($result);
$smarty->assign('sMostPlayedTitle', stripslashes($row['title']));
$smarty->assign('aMostPlayed', $row);
/////////////////////////////////////////////////////////////////////////////////////////////
////////////////////GAME LIST
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);

if(isset($_REQUEST['searchType']))
	$smarty->assign('sSearchType', $_REQUEST['searchType']);
else
	$smarty->assign('sSearchType', false);
	
$smarty->assign('sSearchWords', '');
if( isset($_REQUEST['searchWords']) )
	$smarty->assign('sSearchWords', htmlentities($_REQUEST['searchWords']));

//Build Query
if( 	
		isset($_REQUEST['searchWords'], $_REQUEST['searchType']) && 
		!empty($_REQUEST['searchType']) && !empty($_REQUEST['searchWords'])
	)
	$bSearch = true;
else
	$bSearch = false;
$sOrder = "";
$sWhere = "";
$aWhere = array();
if($sCat != "")	
	$aWhere[] = " `ag`.`categoryid` = '".mysql_real_escape_string($sCat)."' ";
elseif(!$bSearch)
	$sOrder = " ORDER BY RAND()";
if($bSearch)
{
	if($_REQUEST['searchType'] == 'title')
		$aWhere[] = " `ag`.`title` LIKE '%".mysql_real_escape_string($_REQUEST['searchWords'])."%' ";
	else
		$aWhere[] = " `ag`.`description` LIKE '%".mysql_real_escape_string($_REQUEST['searchWords'])."%' ";
}
if(count($aWhere) > 0)
	$sWhere = " WHERE ".implode(" && ", $aWhere);


$iPage = isset($_REQUEST['page']) ? $_REQUEST['page']*1 : 0;
$iLimit = ($iPage == "" ? 0 : ($iPage-1)*20);
$iLimit2 = 20;
$sLimit = " LIMIT ".$iLimit.', '.$iLimit2;

$sql1 = "	SELECT 
					`ag`.`gameid`,
					`ag`.`categoryid`,
					`ag`.`isreverse`,
					".($bUserNames ? "
					`u1`.`user_username` AS `highScoreName`,":"
					`u1`.`user_displayname` AS `highScoreName`,")."
					`u1`.`user_username` AS `highScoreLink`,
					`ah`.`score` AS `highScore`,
					".( is_numeric($iUserId) ? "
					`auh`.`score` AS `userScore`, 
					`af`.`id` AS `favorites`,
					": "")."
					`ag`.`stdimage`,
					`ag`.`description`,
					`ag`.`title`
				FROM `arcade_games` AS `ag`
				LEFT JOIN `arcade_highscores` AS `ah` 
												ON `ah`.`gameid` = `ag`.`gameid`
				LEFT JOIN `se_users` AS `u1` ON `u1`.`user_id` = `ah`.`userid` 
				".( is_numeric($iUserId) ? "	
				LEFT JOIN (
									SELECT 
										MAX(`score`) AS `score`,
										`gameid` 
									FROM `arcade_userhighscores` 
									WHERE `userid` = '".$iUserId."' GROUP BY `gameid`
									) AS `auh` 
				ON `auh`.`gameid` = `ag`.`gameid` 
				LEFT JOIN `arcade_favorite` AS `af` 
				ON (`af`.`gameid` = `ag`.`gameid` && `af`.`userid` = '".$iUserId."' )
											" : "")."
				".$sWhere." GROUP BY `ag`.`gameid` ".$sOrder.$sLimit;
// Get Query
$game_array = array();
$result1 = mysql_query($sql1);
if (mysql_num_rows($result1) > 0)
{
	$bAdmin = false;
	if( isset($admin->admin_exists) )
		$bAdmin = true;
	$smarty->assign('bAdmin', $bAdmin);
	
	$aGames = array();
	while( $row = mysql_fetch_assoc($result1) ) 
	{
		// get catname
		$sTempCat = array_key_exists($row['categoryid'], $aCate) ? $aCate[$row['categoryid']] : "Uncategorized";		
		if( isset($row['highScore']) && $row['highScore'] > 0 )
		{
			$sTempName = $row['highScoreName'];
			$sTempScore = $row['highScore'];
			$sHighScoreLink = $row['highScoreLink'];
			$bChamp = true;
		}
		else
		{
			$sTempName = "None";
			$sHighScoreLink = '';
			$sTempScore = 0;
			$bChamp = false;
		}
		// get users highscore
		if(isset($User))
		{
			$bTempScore2 = true;
			if( isset($row['userScore']) && $row['userScore'] > 0)
				$sTempScore2 = $row['userScore'];
			else 
				$sTempScore2 = "None";
		 }
		 else
		 {
		 	$bTempScore2 = false;
		 	$sTempScore2 = 'None';
		}
		 $aGames[] = array(	'gameid'=> $row['gameid'],
											'stdimage'=> $row['stdimage'],
											'description'=> stripslashes($row['description']),
											'title'=> stripslashes($row['title']),
											'categoryid'=> $row['categoryid'],
											'favorites'=> $row['favorites'],
											'sTempCat'=> $sTempCat,
											'sTempName'=> $sTempName,
											'sHighScoreLink'=> $sHighScoreLink,
											'sTempScore'=> $sTempScore,
											'sTempScore2'=> $sTempScore2,
											'bTempScore2' => $bTempScore2);
	}
}
$smarty->assign('aGames', $aGames);	
/////////////////////////////////////////////////////////////////////
// generate links for the bottom
$smarty->assign('sCat', '');
if($sCat != "")
	$sCat = "&cat=".$sCat;
if($bSearch)
	$sCat = "&searchType=".$_REQUEST['searchType']."&searchWords=".$_REQUEST['searchWords'];
$smarty->assign('sCat', $sCat);


$sql1 = "	SELECT 
					COUNT(*) AS `cnt`
				FROM `arcade_games` AS `ag`
				".$sWhere;
$result1 = mysql_query($sql1);
$aRow = mysql_fetch_assoc($result1);
$iNum = $aRow['cnt'];
$iPgMax = ceil($iNum/$iLimit2);	 
$smarty->assign('iNum', $iNum);
$smarty->assign('iPgMax', $iPgMax);
$smarty->assign('iPage', $iPage==0 ? 1 : $iPage );

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>