<?php
$page = "game";
include "header.php";

////////GET LANG IDS
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'game.', '') AS `key`
				FROM `arcade_settings` WHERE `defVarName` LIKE '%game.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aArcdSttng = array();
$sSql = "	SELECT 
					* 
				FROM `arcade_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aArcdSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
$aArcdSttng['userlevels'] = explode(",", $aArcdSttng['userlevels']);
$smarty->assign('aArcadeSetting', $aArcdSttng);
//////////////////////////////////////////////////////////////////////////
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);
//sessionize arcade challenge id if one is set
if(isset($_GET['cid']))
    $_SESSION['arcadeCid'] = $_GET['cid'];
if( is_numeric($iUserId) && in_array($user->user_info['user_level_id'], $aArcdSttng['userlevels']) || $aArcdSttng['guestplay'] == 2 && $iUserId == FALSE)
{
    $sql ="SELECT `setting_username` FROM `se_settings` LIMIT 1";
	$result = mysql_query($sql);
	$aRow = mysql_fetch_assoc($result);
	$bUserNames = $aRow['setting_username'] == 1 ? TRUE : FALSE;

	$_SESSION['sgameid'] = $iGameId = isset($_GET['play']) ? mysql_real_escape_string($_GET['play']) : "";
    $sql="SELECT * FROM `arcade_games` WHERE `gameid` = '".$iGameId."' LIMIT 1";
    $result=mysql_query($sql);
    $aGame = mysql_fetch_assoc($result);

	$aGame['timesplayed']++;
    $sql = "UPDATE `arcade_games` SET `timesplayed` = '".$aGame['timesplayed']."' WHERE `gameid` = '".$iGameId."' LIMIT 1";
    $result = mysql_query($sql);
	
    $aGame['title'] = stripslashes($aGame['title']);
	$aGame['description'] = stripslashes($aGame['description']);
    
    $sql="	SELECT 
					`h`.`score`, 
					".($bUserNames ? "
					`u`.`user_username` AS `username`":"
					`u`.`user_displayname` AS `username`")."
				FROM 
					`arcade_highscores` AS `h` 
				INNER JOIN `se_users` AS `u` ON `u`.`user_id` = `h`.`userid`
				WHERE 
					`h`.`gameid` = '{$aGame['gameid']}' 
				LIMIT 1";
    $result=mysql_query($sql);
    if( ($row = mysql_fetch_assoc($result)) )
	{
        $champname = $row['username'];
        $champscore = $row['score'];
	}
    else 
    {
        $champname = "None";
        $champscore = 0;
    }
    $smarty->assign('sChampScore', $champscore);
    $smarty->assign('sChampName', $champname);
    $smarty->assign('aGame', $aGame);
}

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>