<?php
class newGame {
	public $folder;
	public $path;
	public $files = array();
	public $folders = array();
	public $images = array();
	public $swf;
	public $php;
	public $gamedata = false;
	function newGame($path,$folder){
		$this->path = $path;
		$this->folder = $folder;
	}
	function read_files(){
		$full_path = $this->path . "/" . $this->folder;
		$folder=dir($full_path);
		while($fEntry=$folder->read()){
			if ($fEntry == '.' || $fEntry == '..') {
			}
			else{
				if(is_dir($folder->path. '/' .$fEntry)){
					if($fEntry == 'gamedata'){
						$this->gamedata = true;
					}
					else{
						$this->folders[] = $fEntry;
					}
				}
				elseif (preg_match('/1\.gif/', $fEntry)) {
					$this->pic1 = '1.gif';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/1\.jpg/', $fEntry)) {
					$this->pic1 = '1.jpg';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/1\.jpeg/', $fEntry)) {
					$this->pic1 = '1.jpeg';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/1\.png/', $fEntry)) {
					$this->pic1 = '1.png';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/2\.gif/', $fEntry)) {
					$this->pic2 = '2.gif';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/2\.jpg/', $fEntry)) {
					$this->pic2 = '2.jpg';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/2\.jpeg/', $fEntry)) {
					$this->pic2 = '2.jpeg';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/2\.png/', $fEntry)) {
					$this->pic2 = '2.png';
					$this->images[] = $fEntry;
				}
				elseif (preg_match('/\.swf/', $fEntry)) {
					$this->swf = $fEntry;
				}
				elseif (preg_match('/\.php/', $fEntry)) {
					$this->php = $fEntry;
				}
				else{
					$this->files[] = $fEntry;
				}
			}
		}
		$folder->close();
	}
	function is_game(){
		if(!empty($this->swf) && !empty($this->php) && count($this->images) > 1){
			return true;
		}
		else{
			return false;
		}
	}
	function add_game($catID,$time){
		// check file permisisons
		$this->fullpath = $this->path . '/' . $this->folder;
		$perm = substr(decoct(fileperms($this->path . '/' . $this->folder)),2);
		if($perm != 777){
			return 4;
		}
		else{
			// read php file
			$content = file_get_contents($this->path . '/' . $this->folder . '/' . $this->php);
			preg_match_all("#shortname, gameid, title, descr, file, width, height, miniimage, stdimage, gamesettings, highscorerid, highscore\) VALUES \('(.*?)', (.*?), '(.*?)', '(.*?)', '(.*?)', (.*?), (.*?), '(.*?)', '(.*?)', (.*?), (.*?), (.*?)\)\"\)\;#s", $content, $matches);
			if(isset($matches['1']['0'])){
				$this->name = mysql_real_escape_string(stripslashes($matches['1']['0']));
				$this->title = mysql_real_escape_string(stripslashes($matches['3']['0']));
				$this->width = mysql_real_escape_string(stripslashes($matches['6']['0']));
				$this->height = mysql_real_escape_string(stripslashes($matches['7']['0']));
				$this->desc = mysql_real_escape_string(stripslashes($matches['4']['0']));
			}
			// or include the file
			if(empty($this->name)){
				@include $this->path . "/" . $this->folder . '/' . $this->php;
				$this->name = mysql_real_escape_string(stripslashes($config['gname']));
				$this->title = mysql_real_escape_string(stripslashes($config['gtitle']));
				$this->width = mysql_real_escape_string(stripslashes($config['gwidth']));
				$this->height = mysql_real_escape_string(stripslashes($config['gheight']));
				$this->desc = mysql_real_escape_string(stripslashes($config['gwords']));
			}
			if(!empty($this->name) && !empty($this->title) && !empty($this->width) && !empty($this->height) && !empty($this->desc)){
				$sql = "SELECT `shortname` FROM `arcade_games` WHERE `shortname` = '".$this->name."' LIMIT 1";
				$result = mysql_query($sql) or die(mysql_error());
				$num = mysql_num_rows($result);
				if($num > 0)
					return 3;
				else{
					// add game
					$pic1 = $this->name.$this->pic1;
					$pic2 = $this->name.$this->pic2;
										
					$sql = "INSERT INTO `arcade_games` (`shortname`,`title`,`description`,`file`,`width`,`height`,`miniimage`,`stdimage`,`isreverse`,`categoryid`) ".
					"VALUES ('" . $this->name . "', '". $this->title . "', '". $this->desc ."', '".$this->swf."', '" . $this->width . "', '". $this->height ."', '". $pic2 ."', '". $pic1."', '0','". $catID ."')";
					$result=mysql_query($sql) or die(mysql_error());
					// move gamedata folder
					if($this->gamedata === true){
						@$this->dir_copy($this->fullpath. '/gamedata','../file/arcade/gamedata');
						$this->unlinkRecursive($this->fullpath. '/gamedata', true);
					}
					// move swf
					copy($this->fullpath. '/' . $this->swf,'../file/arcade/swf/'.$this->swf);
					unlink($this->fullpath. '/' . $this->swf);
					// move images
					foreach($this->images as $value){
						copy($this->fullpath. '/' . $value,'../file/arcade/images/'.$value);
						unlink($this->fullpath. '/' . $value);
					}
					// delete php file
					unlink($this->fullpath. '/' . $this->php);
					// move weird files
					foreach($this->files as $value){
						copy($this->fullpath. '/' . $value,'../file/arcade/extras/'.$value);
						unlink($this->fullpath. '/' . $value);
					}
					// delete remaining file
					$this->unlinkRecursive($this->fullpath, true);
					return 1;
				}
			}
			else{
				return 2;
			}
		}
	}
	function dir_copy($srcdir, $dstdir, $offset = '', $verbose = false){
		if(!isset($offset)) $offset=0;
		$num = 0;
		$fail = 0;
		$sizetotal = 0;
		$fifail = '';
		if(!is_dir($dstdir)) mkdir($dstdir);
		if($curdir = opendir($srcdir)) {
			while($file = readdir($curdir)) {
				if($file != '.' && $file != '..') {
					$srcfile = $srcdir . '/' . $file;
					$dstfile = $dstdir . '/' . $file;
					if(is_file($srcfile)) {
						if(is_file($dstfile)) $ow = filemtime($srcfile) - filemtime($dstfile); else $ow = 1;
						if($ow > 0) {
							if($verbose) echo "Copying '$srcfile' to '$dstfile'...<br />";
							if(copy($srcfile, $dstfile)) {
								touch($dstfile, filemtime($srcfile)); $num++;
								chmod($dstfile, 0777);
								$sizetotal = ($sizetotal + filesize($dstfile));
								if($verbose) echo "OK\n";
							}
							else {
								echo "Error: File '$srcfile' could not be copied!<br />\n";
								$fail++;
								$fifail = $fifail.$srcfile.'|';
							}
						}
					}
					else if(is_dir($srcfile)) {
						$res = explode(',',$ret);
						$ret = $this->dir_copy($srcfile, $dstfile, $verbose);
						$mod = explode(',',$ret);
						$imp = array($res[0] + $mod[0],$mod[1] + $res[1],$mod[2] + $res[2],$mod[3].$res[3]);
						$ret = implode(',',$imp);
					}
				}
			}
			closedir($curdir);
		}
		$red = explode(',',$ret);
		$ret = ($num + $red[0]).','.(($fail-$offset) + $red[1]).','.($sizetotal + $red[2]).','.$fifail.$red[3];
		return $ret;
	}
	function unlinkRecursive($dir, $deleteRootToo){
		if(!$dh = @opendir($dir))
		{
			return;
		}
		while (false !== ($obj = readdir($dh)))
		{
			if($obj == '.' || $obj == '..')
			{
				continue;
			}
			if (!@unlink($dir . '/' . $obj))
			{
				$this->unlinkRecursive($dir.'/'.$obj, true);
			}
		}
		closedir($dh);
		if ($deleteRootToo)
		{
			@rmdir($dir);
		}
		return;
	} 
}
?>