<?


// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

$sSql = "	SELECT 
					`languagevar_id`
				FROM `arcade_settings` WHERE `defVarName` = 'arcadeMenu' ";
$rResult = mysql_query($sSql);
$aRow=mysql_fetch_assoc($rResult);

// PRELOAD LANGUAGE
SE_Language::_preload($aRow['languagevar_id']);

// SET MAIN MENU VARS
$plugin_vars[menu_main] = Array('file' => 'gamelist.php', 'title' => $aRow['languagevar_id']);

?>