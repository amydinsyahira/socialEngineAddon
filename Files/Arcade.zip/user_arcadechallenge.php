<?php
$page = "user_arcadechallenge";
include "header.php";

////////GET LANG IDS
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'arcadechallenge.', '') AS `key`
				FROM `arcade_settings` WHERE `defVarName` LIKE '%arcadechallenge.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aArcdSttng = array();
$sSql = "	SELECT 
					* 
				FROM `arcade_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aArcdSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
$smarty->assign('aArcadeSetting', $aArcdSttng);
//////////////////////////////////////////////////////////////////////////
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);

$getgid = isset($_GET['gid']) ? mysql_real_escape_string($_GET['gid']) : "";
$getlim = isset($_GET['lim']) ? mysql_real_escape_string($_GET['lim']) : "";
$iPage = isset($_GET['page']) ? mysql_real_escape_string($_GET['page']) : "";
$sFriend = isset($_GET['sFriend']) ? mysql_real_escape_string($_GET['sFriend']) : "";

$smarty->assign('sFriend', $sFriend);
$smarty->assign('iGetgid', $getgid);
$smarty->assign('sCat', $getlim=="" ? "" : "&".$getlim );

$bChallenge = false;	
if( isset($_POST['submit']) )
{
    $aError = array();
	$bChallenge = true;
	$gameid = mysql_real_escape_string($_POST['gameid']);
    $friend = mysql_real_escape_string($_POST['friend']);
    
    $sql = "SELECT `user_id` FROM `se_users` WHERE `user_username` = '{$friend}' && `user_id` != '{$iUserId}' LIMIT 1";
    $result = mysql_query($sql);
	if( ($row=mysql_fetch_assoc($result)) )
		$iFriendId = $row['user_id'];
	else
		$aError[] = 'Please enter a valid user.';
    
	$sql = "SELECT `title` FROM `arcade_games` WHERE `gameid` = '{$gameid}' LIMIT 1";
    $result = mysql_query($sql);
	if( ($row=mysql_fetch_assoc($result)) )
		$sGameTitle = $row['title'];
	else
		$aError[] = 'Please enter a valid Game ID.';
	
    if( isset($aError) && count($aError) == 0 )
    {
        $time = time();
        $sql = "INSERT INTO `arcade_challenges` (`user1`, `user2`, `time`, `gameid`) VALUES ('{$iUserId}', '{$iFriendId}', '{$time}', '{$gameid}')";
        $result = mysql_query($sql);
        $challengeId = mysql_insert_id();
        $subject = "Arcade Challenge From {$user->user_info['user_displayname']}";
        $mess = 	"<p>{$user->user_info['user_displayname']} has challenged you to an arcade duel at {$sGameTitle}! <p> You can accept by clicking".
						" <a href='game.php?play={$gameid}&cid={$challengeId}'>here. </a></p><br/>";
		if($_POST['msg'] != "")
			$mess .= "<p>Here is the message from {$user->user_info['user_displayname']}: <br/>{$_POST['msg']}</p>";
        $user->user_message_send($friend, $subject, $mess);
		$bChallengeSent = true;
    }
    else
	{
    	$bChallengeSent = false;
		$smarty->assign('aError', $aError);
		$smarty->assign('iGetgid', $_POST['gameid']);
		$smarty->assign('sFriend', $_POST['friend']);
		$smarty->assign('sMsg', $_POST['msg']);
	}
    $smarty->assign('bChallengeSent', $bChallengeSent);
}
$smarty->assign('bChallenge', $bChallenge);

$iLimit = ($iPage == "" ? 0 : ($iPage-1)*15);
$iLimit2 = 15;
if(isset($getlim))
{
	if($getlim == "Won")
		$sql = "	SELECT
							* 
						FROM `arcade_challenges`
						WHERE 
							(	`user1` = '{$iUserId}' || 
								`user2` = '{$iUserId}'
							) && 
							`winner` = '{$iUserId}' 
						ORDER BY `time` DESC";
	elseif($getlim == "Lost")
		$sql = "	SELECT 
							* 
						FROM `arcade_challenges` 
						WHERE 
							(	`user1` = '{$iUserId}' || 
								`user2` = '{$iUserId}'
							) && 
						`winner` != '$aUser' && 
						`winner` != '' 
						ORDER BY `time` DESC";
	elseif($getlim == "Undecided")
		$sql = "	SELECT 
							* 
						FROM `arcade_challenges` 
						WHERE 
							(	`user1` = '{$iUserId}' || 
								`user2` = '{$iUserId}'
							) && 
							`winner` = '' 
						ORDER BY `time` DESC";
	else
		$sql = "SELECT 
						* 
					FROM 
						`arcade_challenges` 
					WHERE 
						`user1` = '{$iUserId}' || 
						`user2` = '{$iUserId}' 
					ORDER BY `time` DESC";
}
else
	$sql = "	SELECT 
						* 
					FROM `arcade_challenges` 
					WHERE 
						`user1` = '{$iUserId}' || 
						`user2` = '{$iUserId}' 
					ORDER BY `time` DESC";
$result = mysql_query($sql);
$iNum = mysql_num_rows($result);
$iPgMax = ceil($iNum/$iLimit2);	 
$smarty->assign('iNum', $iNum);
$smarty->assign('iPgMax', $iPgMax);
$smarty->assign('iPage', $iPage==0 ? 1 : $iPage );

$sql .= ' LIMIT '.$iLimit.', '.$iLimit2;
$result = mysql_query($sql);
$num = mysql_num_rows($result);
$list = array(); $aChallenges = array();
for($i=0;$i<$num;$i++){
	$row = mysql_fetch_array($result);
	$id = $row['id'];
	$time = $row['time'];
	$score1 = $row['score1'];
	$score2 = $row['score2'];
	$gameid = $row['gameid'];
	$user1 = $row['user1'];
	$user2 = $row['user2'];
	$winner = $row['winner'];
	$time = date("m/d/y", $time);
	
	$list[0]['cid'] = $id;
	$list[0]['gameid'] = $gameid;
	
	$sql2 = "SELECT * FROM `arcade_games` WHERE `gameid` = '$gameid' LIMIT 1";
	$result2 = mysql_query($sql2);
	$row2 = mysql_fetch_array($result2);
	$title = stripslashes($row2['title']);
	if($user1 == $User->info['user']){
		$cu = $user2;
		$score = $score1;
		$oscore = $score2;
	}
	else{
		$cu = $user1;
		$score = $score2;
		$oscore = $score1;
	}
	if(!$winner){
		$winner = "Undecided";
	}
	$list[0]['cu'] = $cu;
	$list[0]['winner'] = $winner;
	$list[0]['time'] = $time;
	$list[0]['title'] = $title;
	
	if(!empty($score)){
		$list[0]['score'] = $score;
		$list[0]['noscore'] = 0;
	}
	else{
		$list[0]['noscore'] = 1;
	}
	if(!empty($oscore)){
		$list[0]['oscore'] = $oscore;
	}
	else{
		$list[0]['oscore'] = "None";
	}
	$list[0]['winner'] = $winner;
	$aChallenges[] = array(	'time' => $list[0]['time'],
							'cu' => $list[0]['cu'],
							'gameid' => $list[0]['gameid'],
							'noscore' => $list[0]['noscore'],
							'score' => $list[0]['score'],	
							'cid' => $list[0]['cid'],
							'oscore' => $list[0]['oscore'],
							'winner' => $list[0]['winner'],
							'title' => $list[0]['title']);
}
$smarty->assign('aChallenges', $aChallenges);

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>