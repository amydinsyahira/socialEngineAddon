<?php

$page = "game";
include "header.php";


// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if( !$user->user_exists && !$setting['setting_permission_game'] )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if( !$owner->user_exists )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}


// ENSURE GAMES ARE ENABLED FOR THIS USER
if($owner->level_info[level_game_allow] == 0) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

$task = rc_toolkit::get_request('task','main');
$game_id = rc_toolkit::get_request('game_id',0);


// INSTANTIATE GAME AND SET GAME VARS
$game = new se_game($owner->user_info[user_id], $game_id);
if (!$game->game_exists || !$game->game_info['game_uploaded']) {
  rc_toolkit::redirect($url->url_create('profile', $owner->user_info[user_username]));
}
$game->game_info = $game->game_info;

// CHECK PRIVACY
$privacy_max = $owner->user_privacy_max($user);
if(!($game->game_info[game_privacy] & $privacy_max)) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 11230148);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}


$game->game_info[game_dir] = $game->game_dir();
$game->calculate_game_rating($game->game_info);
$game->game_info[game_rating_total] = $game->get_game_rating_total($game_id);

// GET GAME COMMENT PRIVACY
$allowed_to_comment = 1;
if(!($privacy_max & $game->game_info[game_comments])) { $allowed_to_comment = 0; }


// CHECK IF USER IS ALLOWED TO RATE
$allowed_to_rate = 1;
if($database->database_num_rows($database->database_query("SELECT NULL FROM se_gameratings WHERE gamerating_game_id='{$game->game_info[game_id]}' AND gamerating_user_id='{$user->user_info[user_id]}'")) != 0 || !$user->user_exists) { $allowed_to_rate = 0; }


// RATE GAME
if($task == "rate_do") {
  $rating = (int) $_POST['rating'];

  if($allowed_to_rate) {
    if($rating <= 5 && $rating >= 1) {
      $database->database_query("INSERT INTO se_gameratings (gamerating_game_id, gamerating_user_id, gamerating_rating) VALUES ('{$game->game_info[game_id]}', '{$user->user_info[user_id]}', '$rating')");

      // GET AVERAGE RATING / NUM VOTES FOR BAYESIAN WEIGHTED RATING
      $avg = $database->database_fetch_assoc($database->database_query("SELECT avg(game_cache_rating) AS average_rating, avg(game_cache_rating_total) AS average_total FROM se_games WHERE game_cache_rating_total<>'0'"));

      // GET TOTAL RATING
      $new_rating = ($game->game_info[game_cache_rating]*$game->game_info[game_rating_total]+$rating)/($game->game_info[game_rating_total]+1);
      $new_total = $game->game_info[game_rating_total]+1;
      $new_rating_weighted = ( ($avg[average_total] * $avg[average_rating]) + ($new_total * $new_rating) ) / ($avg[average_total] + $new_total);

      // SET NEW CACHED RATINGS
      $database->database_query("UPDATE se_games SET game_cache_rating='$new_rating', game_cache_rating_weighted='$new_rating_weighted', game_cache_rating_total='$new_total' WHERE game_id='{$game->game_info[game_id]}'");
      $allowed_to_rate = 0;
      $game->game_info[game_rating_full] = floor($new_rating);
      $game->game_info[game_rating_part] = (($new_rating-$game->game_info[game_rating_full]) == 0) ? 0 : 1;
      $game->game_info[game_rating_none] = 5-$game->game_info[game_rating_full]-$game->game_info[game_rating_part];
      $game->game_info[game_rating_total] = $new_total;
    }
  }

  $response_array = array(
			'allowed_to_rate' => (bool) $allowed_to_rate,
			'rating_full' => (int) $game->game_info[game_rating_full],
			'rating_part' => (int) $game->game_info[game_rating_part],
			'rating_none' => (int) $game->game_info[game_rating_none],
			'rating_total' => (int) $game->game_info[game_rating_total]
			);

  // OUTPUT JSON
  echo json_encode($response_array);
  exit();

}



// GET USER'S GAMES
$total_games = $game->game_total("(game_uploaded='1')");

$max_more_game_entries = 6;
$more_game = new se_game();
$more_game_array = $more_game->game_list(0, $max_more_game_entries, "RAND()", "(game_uploaded='1' AND game_gamecat_id='{$game->game_info[game_gamecat_id]}')", 1);


// GET GAME COMMENTS
$comment = new se_comment('game', 'game_id', $game->game_info[game_id]);
$total_comments = $comment->comment_total();


// UPDATE GAME VIEWS
if($user->user_info[user_id] != $owner->user_info[user_id]) {
  $game_views_new = $game->game_info[game_views] + 1;
  $database->database_query("UPDATE se_games SET game_views='$game_views_new' WHERE game_id='{$game->game_info[game_id]}' LIMIT 1");
}

// UPDATE NOTIFICATIONS
if($user->user_info[user_id] == $owner->user_info[user_id]) {
  $database->database_query("DELETE FROM se_notifys USING se_notifys LEFT JOIN se_notifytypes ON se_notifys.notify_notifytype_id=se_notifytypes.notifytype_id WHERE se_notifys.notify_user_id='".$owner->user_info[user_id]."' AND se_notifytypes.notifytype_name='gamecomment' AND notify_object_id='".$game->game_info[game_id]."'");
}

//rc_toolkit::debug($game);

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 11230151;
$global_page_title[1] = $owner->user_displayname;
$global_page_title[2] = $game->game_info[game_title];
$global_page_description[0] = 11230102;
$global_page_description[1] = $game->game_info[game_desc];

//rc_toolkit::debug($game);

// ASSIGN VARIABLES AND DISPLAY GAME PAGE
$smarty->assign('game', $game);
$smarty->assign('game_info', $game->game_info);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('allowed_to_comment', $allowed_to_comment);
$smarty->assign('allowed_to_rate', $allowed_to_rate);
$smarty->assign('games', $more_game_array);
$smarty->assign('total_games', $total_games);
include "footer.php";
?>