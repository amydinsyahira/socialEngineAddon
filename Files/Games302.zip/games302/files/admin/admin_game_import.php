<?php

set_time_limit(0);

$page = "admin_game_import";

include "admin_header.php";


$game_packs = array();
$game_pack_dir = './import_games/';
if($handle = opendir($game_pack_dir))
{
  while(($file = readdir($handle)) !== false)
  {
    if($file != '.' && $file != '..')
    {
      if (strstr($file, 'game_pack_') and strstr($file, '.php')) {
        include($game_pack_dir.$file);
        $game_packs[$file] = $import_config;
      }
    }
  }
  closedir($handle);
}

$task = rc_toolkit::get_request('task', 'main');
$mapping_categories = rc_toolkit::get_request('mapping_categories', array());
$import_game_privacy = rc_toolkit::get_request('import_game_privacy', 63);
$import_game_comment = rc_toolkit::get_request('import_game_comment', 63);
$import_username = rc_toolkit::get_request('import_username');

$game_pack_script = rc_toolkit::get_request('game_pack_script');

if ($game_pack_script) {
  include ($game_pack_dir.$game_pack_script);
}


$game = new se_game();

$existing_categories = $game->game_category_list();

$import_categories = $import_config['categories'];


for($c=6;$c>0;$c--) {
  $priv = pow(2, $c)-1;
  if(user_privacy_levels($priv) != "") {
    SE_Language::_preload(user_privacy_levels($priv));
    $privacy_options[$priv] = user_privacy_levels($priv);
  }
}

for($c=6;$c>=0;$c--) {
  $priv = pow(2, $c)-1;
  if(user_privacy_levels($priv) != "") {
    SE_Language::_preload(user_privacy_levels($priv));
    $comment_options[$priv] = user_privacy_levels($priv);
  }
}


if ($task == 'doimport' && $game_pack_script) {
  
  $import_user = new se_user(array('0',$import_username));
  if (! $import_user->user_exists) {
    $error = 11231043;
  }
  
  if (!$error) {
    
    $import_game_user_id = $import_user->user_info['user_id'];
    $import_game_search = 1;
    
    
    $filter_condition = "game_id >= '{$import_config['start_id']}' AND game_id <= '{$import_config['end_id']}'";
    
    
    
    $queries = array();
    $queries['Delete Duplicate'] = "DELETE FROM se_games WHERE $filter_condition";
    $queries['Insert Records'] = file_get_contents('./import_games/'.$import_config['sql_file']);
    
    foreach($mapping_categories as $mck => $mcv) {
      $queries["Update Category $mck => $mcv"] = "UPDATE se_games SET game_gamecat_id = '$mcv' WHERE game_gamecat_id = '$mck' AND $filter_condition";
    }

    $current_timestamp = time();

    $queries["Update Columns"] = "UPDATE se_games SET 
        game_uploaded = '1',
        game_user_id='$import_game_user_id', 
        game_search='$import_game_search', 
        game_privacy='$import_game_privacy', 
        game_comments='$import_game_comment',
        game_datecreated='$current_timestamp',
        game_dateupdated='$current_timestamp'
      WHERE $filter_condition";
    

    foreach ($queries as $qdesc => $query) {
      $database->database_query($query) OR die("Error Query: $query");
      //echo "<p>EXEC QUERY :: $qdesc";
    }
    $result = 11231044;
  }
  

}


$smarty->assign('import_config', $import_config);
$smarty->assign('game_packs', $game_packs);
$smarty->assign('game_pack_script', $game_pack_script);
$smarty->assign('game_privacy', $privacy_options);
$smarty->assign('game_comments', $comment_options);
$smarty->assign('import_game_privacy', $import_game_privacy);
$smarty->assign('import_game_comment', $import_game_comment);
$smarty->assign('import_username', $import_username);
$smarty->assign('mapping_categories', $mapping_categories);
$smarty->assign('import_categories', $import_categories);
$smarty->assign('existing_categories', $existing_categories);

$smarty->assign('task', $task);
$smarty->assign('error', $error);
$smarty->assign('result', $result);
include "admin_footer.php";
?>