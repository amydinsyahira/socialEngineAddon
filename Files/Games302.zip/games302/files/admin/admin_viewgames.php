<?php

$page = "admin_viewgames";
include "admin_header.php";

$s = rc_toolkit::get_request('s', 'id');
$p = rc_toolkit::get_request('p', 1);
$f_title = rc_toolkit::get_request('f_title', '');
$f_owner = rc_toolkit::get_request('f_owner', '');
$f_featured = rc_toolkit::get_request('f_featured','');
$f_file = rc_toolkit::get_request('f_file','');
$f_photo = rc_toolkit::get_request('f_photo','');
$f_catid = rc_toolkit::get_request('f_catid','');
$task = rc_toolkit::get_request('task', 'main');
$game_id = rc_toolkit::get_request('game_id', 0);

// CREATE GAME OBJECT
$games_per_page = 100;
$game = new se_game();


// DELETE GAME
if($task == "deletegame") {
  if($database->database_num_rows($database->database_query("SELECT game_id FROM se_games WHERE game_id='$game_id'")) == 1) { 
    $game->game_delete($game_id);
  }
}

$featured = rc_toolkit::get_request('featured');
if ($featured && $game_id > 0) {
  $featured_value = ($featured == 'yes') ? 1 : 0;
  $database->database_query("UPDATE se_games SET game_featured = '$featured_value' WHERE game_id='$game_id'");
}


// SET GAME SORT-BY VARIABLES FOR HEADING LINKS
$i = "id";   // GAME_ID
$t = "t";    // GAME_TITLE
$u = "u";    // OWNER OF GAME

// SET SORT VARIABLE FOR DATABASE QUERY
if($s == "i") {
  $sort = "se_games.game_id";
  $i = "id";
} elseif($s == "id") {
  $sort = "se_games.game_id DESC";
  $i = "i";
} elseif($s == "t") {
  $sort = "se_games.game_title";
  $t = "td";
} elseif($s == "td") {
  $sort = "se_games.game_title DESC";
  $t = "t";
} elseif($s == "u") {
  $sort = "user_username";
  $u = "ud";
} elseif($s == "ud") {
  $sort = "user_username DESC";
  $u = "u";
} else {
  $sort = "se_games.game_id DESC";
  $i = "i";
}




// ADD CRITERIA FOR FILTER
$where_clause = Array();
if($f_owner != "") { $where_clause[] = "(se_users.user_username LIKE '%$f_owner%' OR CONCAT(se_users.user_fname, ' ', se_users.user_lname) LIKE '%$f_owner%')"; }
if($f_title != "") { $where_clause[] = " se_games.game_title LIKE '%$f_title%'"; }

if($f_featured == 'y') { $where_clause[] = " se_games.game_featured='1' "; }
elseif ($f_featured == 'n') { $where_clause[] = " se_games.game_featured='0' "; }

if($f_file == 'y') { $where_clause[] = " se_games.game_uploaded='1' "; }
elseif ($f_file == 'n') { $where_clause[] = " se_games.game_uploaded='0' "; }

if($f_photo == 'y') { $where_clause[] = " se_games.game_photo<>'' "; }
elseif ($f_photo == 'n') { $where_clause[] = " se_games.game_photo='' "; }

$gamecats_array = $game->game_category_list();
$gamecat_ids = array();
foreach ($gamecats_array as $k=>$v) {
  $gamecat_ids[$v['gamecat_id']] = $v['gamecat_languagevar_id'];
}
$gamecats_array[] = array(
  'gamecat_id' => -1,
  'gamecat_user_id' => 0,
  'gamecat_title' => 'Uncategorized',
  'gamecat_languagevar_id' => 11231032,
  'gamecat_parentcat_id' => 0,
);
if ($f_catid == -1) {
  $where_clause[] = " game_gamecat_id NOT IN ('".join("','", array_keys($gamecat_ids))."')";
}
elseif (array_key_exists($f_catid, $gamecat_ids)) {
  $where_clause[] = " game_gamecat_id='$f_catid'";
}


if(count($where_clause) != 0) { $where = "(".implode(" AND ", $where_clause).")"; }


// DELETE NECESSARY GAMES
$start = ($p - 1) * $games_per_page;
if($task == "delete") { $game->game_delete_selected($start, $games_per_page, $sort, $where); }

// GET TOTAL GAMES
$total_games = $game->game_total($where);

// MAKE GAME PAGES
$page_vars = make_page($total_games, $games_per_page, $p);
$page_array = Array();
for($x=0;$x<=$page_vars[2]-1;$x++) {
  if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
  $page_array[$x] = Array('page' => $x+1,
			  'link' => $link);
}

// GET GAME ARRAY
$games = $game->game_list($page_vars[0], $games_per_page, $sort, $where);







// ASSIGN VARIABLES AND SHOW VIEW GAMES PAGE
$smarty->assign('gamecats', $gamecats_array);
$smarty->assign('total_games', $total_games);
$smarty->assign('pages', $page_array);
$smarty->assign('games', $games);
$smarty->assign('f_title', $f_title);
$smarty->assign('f_owner', $f_owner);
$smarty->assign('f_featured', $f_featured);
$smarty->assign('f_file', $f_file);
$smarty->assign('f_photo', $f_photo);
$smarty->assign('f_catid', $f_catid);
$smarty->assign('i', $i);
$smarty->assign('t', $t);
$smarty->assign('u', $u);
$smarty->assign('f', $f);
$smarty->assign('su', $su);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('s', $s);
include "admin_footer.php";
?>