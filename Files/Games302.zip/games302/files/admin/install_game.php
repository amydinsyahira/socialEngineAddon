<?php
$plugin_name = "Game Plugin";
$plugin_version = "3.02";
$plugin_type = "game";
$plugin_desc = "This plugin lets your users upload and share flash-based games. This is a great way to encourage content creation and increase interactive level on your social network.";
$plugin_icon = "game_game16.gif";
$plugin_menu_title = "11230115";
$plugin_pages_main = "11230133<!>game_game16.gif<!>admin_game_import.php<~!~>11230085<!>game_game16.gif<!>admin_viewgames.php<~!~>11230116<!>game_settings16.gif<!>admin_game.php<~!~>";
$plugin_pages_level = "11230045<!>admin_levels_gamesettings.php<~!~>";
$plugin_url_htaccess = "RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/game/([0-9]+)/?$ \$server_info/game.php?user=\$1&game_id=\$2 [L]";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';
$plugin_reindex_totals = TRUE;

if ($install == "game")
{
  
  //######### INSERT ROW INTO se_plugins
  $sql = "SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'";
  $resource = $database->database_query($sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      INSERT INTO se_plugins (plugin_name,
        plugin_version,
        plugin_type,
        plugin_desc,
        plugin_icon,
        plugin_menu_title,
        plugin_pages_main,
        plugin_pages_level,
        plugin_url_htaccess
      ) VALUES (
        '{$plugin_name}',
        '{$plugin_version}',
        '{$plugin_type}',
        '" . str_replace("'", "\'", $plugin_desc) . "',
        '{$plugin_icon}',
        '{$plugin_menu_title}',
        '{$plugin_pages_main}',
        '{$plugin_pages_level}',
        '{$plugin_url_htaccess}'
      )
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### UPDATE PLUGIN VERSION IN se_plugins
  else
  {
    $sql = "
      UPDATE
        se_plugins
      SET
        plugin_name='{$plugin_name}',
        plugin_version='{$plugin_version}',
        plugin_desc='" . str_replace("'", "\'", $plugin_desc) . "',
        plugin_icon='{$plugin_icon}',
        plugin_menu_title='{$plugin_menu_title}',
        plugin_pages_main='{$plugin_pages_main}',
        plugin_pages_level='{$plugin_pages_level}',
        plugin_url_htaccess='{$plugin_url_htaccess}'
      WHERE
        plugin_type='{$plugin_type}'
      LIMIT
        1
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### CREATE se_gamecats
  $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_gamecats'";
  $resource = $database->database_query($sql) or die($database->database_error() . " <b>SQL was: </b>$sql");
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      CREATE TABLE `se_gamecats`
      (
        `gamecat_id`               INT           UNSIGNED  NOT NULL auto_increment,
        `gamecat_user_id`          INT           UNSIGNED  NOT NULL default 0,
        `gamecat_title`            VARCHAR(128)            NOT NULL default '',
        `gamecat_languagevar_id`   INT           UNSIGNED  NOT NULL default 0,
        `gamecat_parentcat_id`     INT           UNSIGNED  NOT NULL default 0,
        PRIMARY KEY  (`gamecat_id`)
      )
      CHARACTER SET {$plugin_db_charset} COLLATE {$plugin_db_collation}
    ";
    $resource = $database->database_query($sql) or die($database->database_error() . " <b>SQL was: </b>$sql");
  }
  //######### CREATE se_games
  $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_games'";
  $resource = $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      CREATE TABLE `se_games`
      (
        `game_id` int(9) unsigned NOT NULL auto_increment,
        `game_user_id` int(9) unsigned NOT NULL default '0',
        `game_gamecat_id` int(9) unsigned NOT NULL default '0',
        `game_uploaded` tinyint(1) NOT NULL default '0',
        `game_datecreated` int(14) NOT NULL default '0',
        `game_dateupdated` int(14) NOT NULL default '0',
        `game_title` varchar(255) default NULL,
        `game_desc` text NULL,
        `game_instruction` text NULL,
        `game_credit` text NULL,
        `game_code` text NULL,
        `game_height` int(5) unsigned NOT NULL default '0',
        `game_width` int(5) unsigned NOT NULL default '0',
        `game_file` varchar(255) default NULL,
        `game_photo` varchar(255) default NULL,
        `game_views` int(9) unsigned NOT NULL default '0',
        `game_cache_rating` float NOT NULL default '0',
        `game_cache_rating_weighted` float NOT NULL default '0',
        `game_cache_rating_total` int(5) unsigned NOT NULL default '0',
        `game_is_featured` tinyint(1) NOT NULL default '0',
        `game_privacy` int(3) default NULL,
        `game_comments` int(3) default NULL,
        `game_search` tinyint(1) unsigned default '1',
        `game_featured` tinyint(1) unsigned default '0',
        `game_totalcomments` int(9) unsigned NOT NULL default '0',
        PRIMARY KEY  (`game_id`),
        KEY `game_cache_rating` (`game_cache_rating`),
        KEY `game_views` (`game_views`),
        FULLTEXT KEY `title_and_text` (`game_title`,`game_desc`)
      )
      ENGINE=MyISAM CHARACTER SET {$plugin_db_charset} COLLATE {$plugin_db_collation}
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
    
    $sql = "ALTER TABLE se_games AUTO_INCREMENT = 100000";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### CREATE se_gamecomments
  $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_gamecomments'";
  $resource = $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      CREATE TABLE `se_gamecomments`
      (
        `gamecomment_id` int(10) unsigned NOT NULL auto_increment,
        `gamecomment_game_id` int(10) unsigned NOT NULL,
        `gamecomment_authoruser_id` int(9) unsigned default NULL,
        `gamecomment_date` int(14) NOT NULL default '0',
        `gamecomment_body` text NULL,
        PRIMARY KEY  (`gamecomment_id`),
        KEY `INDEX` (`gamecomment_game_id`, `gamecomment_authoruser_id`)
      )
      ENGINE=MyISAM CHARACTER SET {$plugin_db_charset} COLLATE {$plugin_db_collation}
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### CREATE se_gameratings
  $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_gameratings'";
  $resource = $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      CREATE TABLE `se_gameratings` (
        `gamerating_game_id` int(10) unsigned NOT NULL,
        `gamerating_user_id` int(9) unsigned NOT NULL,
        `gamerating_rating` tinyint(1) unsigned default NULL,
        PRIMARY KEY  (`gamerating_game_id`,`gamerating_user_id`),
        KEY `INDEX` (`gamerating_game_id`)
      )
      ENGINE=MyISAM CHARACTER SET {$plugin_db_charset} COLLATE {$plugin_db_collation}
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### INSERT se_urls
  $sql = "SELECT url_id FROM se_urls WHERE url_file='game'";
  $resource = $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      INSERT INTO se_urls
        (url_title, url_file, url_regular, url_subdirectory)
      VALUES
        ('Game URL', 'game', 'game.php?user=\$user&game_id=\$id1', '\$user/game/\$id1')
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### INSERT se_actiontypes
  $actiontypes = array();
  if (! $database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newgame'")))
  {
    $database->database_query("
      INSERT INTO se_actiontypes
        (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media)
      VALUES
        ('newgame', 'game_action_addgame.gif', '1', '1', '11230178', '11230179', '[username],[displayname],[gameid],[gametitle]', '1')
    ");
    $actiontypes[] = $database->database_insert_id();
  }
  if (! $database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='gamecomment'")))
  {
    $database->database_query("
      INSERT INTO se_actiontypes
        (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media)
      VALUES
        ('gamecomment', 'action_postcomment.gif', '1', '1', '11230180', '11230181', '[username1],[displayname1],[username2],,[comment],[id],[title]', '0')
    ");
    $actiontypes[] = $database->database_insert_id();
  }
  $actiontypes = array_filter($actiontypes);
  if (! empty($actiontypes))
  {
    $database->database_query("UPDATE se_usersettings SET usersetting_actions_display = CONCAT(usersetting_actions_display, ',', '" . implode(",", $actiontypes) . "')");
  }

  //######### INSERT se_notifytypes
  if (! $database->database_num_rows($database->database_query("SELECT notifytype_id FROM se_notifytypes WHERE notifytype_name='gamecomment'")))
  {
    $database->database_query("
      INSERT INTO se_notifytypes
        (notifytype_name, notifytype_desc, notifytype_icon, notifytype_url, notifytype_title)
      VALUES
        ('gamecomment', '11230182', 'action_postcomment.gif', 'game.php?user=%1\$s&game_id=%2\$s', '11230183')
    ");
  }
  //######### ADD COLUMNS/VALUES TO SYSTEM EMAILS TABLE
  if (! $database->database_num_rows($database->database_query("SELECT systememail_id FROM se_systememails WHERE systememail_name='gamecomment'")))
  {
    $database->database_query("
      INSERT INTO se_systememails
        (systememail_name, systememail_title, systememail_desc, systememail_subject, systememail_body, systememail_vars)
      VALUES
        ('gamecomment', '11230152', '11230153', '11230184', '11230185', '[displayname],[commenter],[link]')
    ");
  }
  //######### ADD COLUMNS/VALUES TO LEVELS TABLE IF GAME HAS NEVER BEEN INSTALLED
  if ($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_game_allow'")) == 0)
  {
    $sql = "
      ALTER TABLE se_levels
      ADD COLUMN `level_game_allow` tinyint(3) unsigned NOT NULL default '1',
      ADD COLUMN `level_game_photo`          TINYINT     UNSIGNED  NOT NULL default 1,
      ADD COLUMN `level_game_photo_width`    VARCHAR(3)            NOT NULL default '120',
      ADD COLUMN `level_game_photo_height`   VARCHAR(3)            NOT NULL default '120',
      ADD COLUMN `level_game_photo_exts`     VARCHAR(50)           NOT NULL default 'jpeg,jpg,gif,png',
      ADD COLUMN `level_game_privacy` varchar(100) NOT NULL default 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"3\";i:2;s:1:\"7\";i:3;s:2:\"15\";i:4;s:2:\"31\";i:5;s:2:\"63\";}',
      ADD COLUMN `level_game_comments` varchar(100) NOT NULL default 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}',
      ADD COLUMN `level_game_search` tinyint(1) unsigned NOT NULL default '1',
      ADD COLUMN `level_game_maxnum` int(10) unsigned NOT NULL default '10000',
      ADD COLUMN `level_game_maxsize` int(10) unsigned NOT NULL default '20971520'
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
    
    $sql = "UPDATE se_levels SET level_game_allow='3'";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE IF GAME HAS NEVER BEEN INSTALLED
  if ($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_permission_game'")) == 0)
  {
    $sql = "
      ALTER TABLE se_settings
      ADD COLUMN `setting_permission_game` tinyint(1) unsigned NOT NULL default '1',
      ADD COLUMN `setting_game_width` int(5) unsigned NOT NULL default '640',
      ADD COLUMN `setting_game_height` int(5) unsigned NOT NULL default '640',
      ADD COLUMN `setting_game_mimes` text collate utf8_unicode_ci,
      ADD COLUMN `setting_game_exts` text collate utf8_unicode_ci
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
    $sql = "UPDATE se_settings SET setting_game_mimes='application/x-shockwave-flash', setting_game_exts='swf'";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### ADD COLUMNS/VALUES TO USER SETTINGS TABLE
  if ($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_usersettings` LIKE 'usersetting_notify_gamecomment'")) == 0)
  {
    $sql = "ALTER TABLE se_usersettings ADD COLUMN `usersetting_notify_gamecomment` int(1) NOT NULL default '1'";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS NOT BEEN INSTALLED)
  $sql = "SELECT NULL FROM se_languagevars WHERE languagevar_language_id=1 && languagevar_id=11230001 LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      INSERT INTO `se_languagevars`
        (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
      VALUES
        (11230001, 1, 'Please register to view comments.', ''),
        (11230002, 1, 'This game does not exist', ''),
        (11230003, 1, 'Game', ''),
        (11230004, 1, 'To add a new game, please provide a title and description for your game, as well as specify privacy settings below.<br>Make sure you select the correct category that match your game type, and provide correct demension of your game file which you will be able to upload it in next step.', ''),
        (11230005, 1, 'Edit game settings', ''),
        (11230006, 1, 'Please provide a title for your game.', ''),
        (11230007, 1, 'Game File', ''),
        (11230008, 1, 'You may upload files of the following types: %1\$s', ''),
        (11230009, 1, 'You may upload files with sizes up to %1\$s KB.', ''),
        (11230010, 1, 'Title', ''),
        (11230011, 1, 'Please type in a title', ''),
        (11230012, 1, 'Description', ''),
        (11230013, 1, 'Describe your game or just provide some keywords.', ''),
        (11230014, 1, 'Include this game in search/browse results?', ''),
        (11230015, 1, 'Yes, include this game in search/browse results.', ''),
        (11230016, 1, 'No, exclude this game from search/browse results.', ''),
        (11230017, 1, 'Who can view this game?', ''),
        (11230018, 1, 'Who can comment on this game?', ''),
        (11230019, 1, 'Upload game', ''),
        (11230020, 1, 'Save changes', ''),
        (11230021, 1, 'Search Games', ''),
        (11230022, 1, '%1\$s\'s games', ''),
        (11230023, 1, '%1\$s comment(s)', ''),
        (11230024, 1, 'Uploaded %1\$s.', ''),
        (11230025, 1, 'My Games', ''),
        (11230026, 1, 'Browse your games', ''),
        (11230027, 1, 'minimize', ''),
        (11230028, 1, 'Game', ''),
        (11230029, 1, 'Browse Games', ''),
        (11230030, 1, 'Browse popular games', ''),
        (11230031, 1, 'Browse', ''),
        (11230032, 1, 'My Games', ''),
        (11230033, 1, 'Upload new game', ''),
        (11230034, 1, 'Search', ''),
        (11230035, 1, 'Search', ''),
        (11230036, 1, 'Thanks for rating!', ''),
        (11230037, 1, 'Ratings: <b><span id=\'rating_total\'>%1\$s</span></b>', ''),
        (11230038, 1, 'Views: <b>%1\$s</b>', ''),
        (11230039, 1, 'Report game', ''),
        (11230040, 1, 'Games from', ''),
        (11230041, 1, 'Game URL', ''),
        (11230042, 1, 'Permanent game URL:', ''),
        (11230043, 1, '%1\$s view(s), %2\$s comment(s)', ''),
        (11230044, 1, 'Game', ''),
        (11230045, 1, 'Game Settings', ''),
        (11230046, 1, 'Game Settings', ''),
        (11230047, 1, 'Allow Games?', ''),
        (11230048, 1, 'You may choose what access users in this level have to games.', ''),
        (11230049, 1, 'Users may only view games.', ''),
        (11230050, 1, 'Users may not use games.', ''),
        (11230051, 1, 'Game Privacy Options', ''),
        (11230052, 1, 'Search Privacy Options', ''),
        (11230053, 1, 'If you enable this feature, users will be able to exclude their games from search results. Otherwise, all games will be included in search results.', ''),
        (11230054, 1, 'Yes, allow users to exclude their games from search results. ', ''),
        (11230055, 1, 'No, force all games to be included in search results. ', ''),
        (11230056, 1, 'Game Privacy Options', ''),
        (11230057, 1, 'Your users can choose from any of the options checked below when they decide who can see their game. If you do not check any options, everyone will be allowed to view games.', ''),
        (11230058, 1, 'Game Comment Options', ''),
        (11230059, 1, 'Your users can choose from any of the options checked below when they decide who can post comments on their game. If you do not check any options, everyone will be allowed to post comments on media.', ''),
        (11230060, 1, 'Maximum Allowed Games', ''),
        (11230061, 1, 'Enter the maximum number of allowed games. The field must contain an integer between 1 and 999. ', ''),
        (11230062, 1, 'allowed games', ''),
        (11230063, 1, 'Maximum Upload Filesize', ''),
        (11230064, 1, 'Enter the maximum filesize for uploaded files in KB.', ''),
        (11230065, 1, 'Save Changes', ''),
        (11230066, 1, 'If you have enabled games, your users will have the option of uploading their games to their profile. Use this page to configure your game settings.', ''),
        (11230067, 1, 'You are not logged in!', ''),
        (11230068, 1, 'The Game \"%1\$s\" is being processed and will be available soon.', ''),
        (11230069, 1, 'The game \"%1\$s\" could not be processed. Please try your upload again or upload another game file.', ''),
        (11230070, 1, '%1\$s view(s)', ''),
        (11230071, 1, 'View:', ''),
        (11230072, 1, 'Everyone\'s Games', ''),
        (11230073, 1, 'My Friends\' Games', ''),
        (11230074, 1, 'Show:', ''),
        (11230075, 1, 'Recently Added', ''),
        (11230076, 1, 'Other <a href=\'%1\$s\'>%2\$s</a>\'s games', ''),
        (11230077, 1, 'Cancel', ''),
        (11230078, 1, 'Game Title', ''),
        (11230079, 1, 'Game Description', ''),
        (11230080, 1, 'Game File', ''),
        (11230081, 1, 'You have reached the maximum number of allowed games (%1\$d). You must delete some of your old games before you can upload a new one.', ''),
        (11230082, 1, 'To edit your game\'s title, description, and privacy settings, complete the form below and click \"Save Changes\".', ''),
        (11230083, 1, 'Edit Game', ''),
        (11230084, 1, 'Other Games', ''),
        (11230085, 1, 'View Games', ''),
        (11230086, 1, 'This page lists all of the games that users have uploaded on your social network. You can use this page to monitor these games and delete offensive material if necessary. Entering criteria into the filter fields will help you find specific games. Leaving the filter fields blank will show all the games on your social network.', ''),
        (11230087, 1, 'Title', ''),
        (11230088, 1, 'Owner', ''),
        (11230089, 1, 'No games were found.', ''),
        (11230090, 1, '%1\$d Games Found', ''),
        (11230091, 1, 'view', ''),
        (11230092, 1, 'days', ''),
        (11230093, 1, 'about 1 month', ''),
        (11230094, 1, 'months', ''),
        (11230095, 1, 'about 1 year', ''),
        (11230096, 1, 'over', ''),
        (11230097, 1, 'years', ''),
        (11230098, 1, 'Games', ''),
        (11230099, 1, 'Games', ''),
        (11230100, 1, 'Comments', ''),
        (11230101, 1, 'read more', ''),
        (11230102, 1, '%1\$s', ''),
        (11230103, 1, 'You currently have %1\$s game(s).', ''),
        (11230104, 1, 'Add New Game', ''),
        (11230105, 1, 'You can upload up to', ''),
        (11230106, 1, 'Add New Game', ''),
        (11230107, 1, 'Edit Game', ''),
        (11230108, 1, 'Delete Game', ''),
        (11230109, 1, 'You do not have any games.', ''),
        (11230110, 1, 'Upload a game here.', ''),
        (11230111, 1, 'Back To My Games', ''),
        (11230112, 1, 'Uploading...', ''),
        (11230113, 1, 'Do not close this window until your upload is complete.', ''),
        (11230114, 1, 'View more games...', ''),
        (11230115, 1, 'Game Plugin Settings', ''),
        (11230116, 1, 'Global Game Settings', ''),
        (11230117, 1, 'Global Game Settings', ''),
        (11230118, 1, 'This page contains general game settings that affect your entire social network. ', ''),
        (11230119, 1, 'Select whether or not you want to let the public (visitors that are not logged-in) to view the following sections of your social network. In some cases (such as Profiles, Blogs, and Albums), if you have given them the option, your users will be able to make their pages private even though you have made them publically viewable here. For more permissions settings, please visit the <a href=\'admin_general.php\'>General Settings</a> page.', ''),
        (11230120, 1, 'Yes, the public can view games unless they are made private.', ''),
        (11230121, 1, 'No, the public cannot view games.', ''),
        (11230122, 1, 'Users may view and upload games.', ''),
        (11230123, 1, 'Please enter the full path to your FFMPEG installation. (Environment variables are not present)', ''),
        (11230124, 1, 'Game File Settings', ''),
        (11230125, 1, 'To successfully upload a file, the file must have an allowed filetype extension as well as an allowed MIME type. For example: application/x-shockwave-flash', ''),
        (11230126, 1, '(comma separated list)', ''),
        (11230127, 1, 'Enter the file extensions that are connected to your specified mime types.', ''),
        (11230128, 1, 'Game And Thumbnail Size', ''),
        (11230129, 1, 'Enter the maximum size for game file that user is allowed to input.', ''),
        (11230130, 1, 'Enter the size of the thumbnail. ', ''),
        (11230131, 1, 'Height', ''),
        (11230132, 1, 'Width', ''),
        (11230133, 1, 'Import Games', ''),
        (11230134, 1, 'This page allow you to import game package that you purchased from Radcodes store.', ''),
        (11230135, 1, 'No games has been found.', ''),
        (11230136, 1, 'Game Categories', ''),
        (11230137, 1, 'Categorized game make it easier for users to find game that interest them. User will be required to select category that best match their game type.', ''),
        (11230138, 1, 'Language Variable', ''),
        (11230139, 1, 'Add Category', ''),
        (11230140, 1, 'Game Upload Results', ''),
        (11230141, 1, 'Game: %1\$s', ''),
        (11230142, 1, 'Game posted by <a href=\'%1\$s\'>%2\$s</a><br>%3\$s', ''),
        (11230143, 1, '%1\$d games', ''),
        (11230144, 1, 'Most Popular', ''),
        (11230145, 1, 'Delete Game?', ''),
        (11230146, 1, 'Are you sure you want to delete this game?', ''),
        (11230147, 1, 'Report Abuse', ''),
        (11230148, 1, 'You do not have permission to view this game.', ''),
        (11230149, 1, 'Recently Uploaded Games', ''),
        (11230150, 1, 'Top Rated Games', ''),
        (11230151, 1, '%1\$s\'s game - %2\$s', ''),
        (11230152, 1, 'New Game Comment Email', ''),
        (11230153, 1, 'This is the email that gets sent to a user when a comment is posted on one of their games.', ''),
        (11230154, 1, 'Your maximum filesize field must contain an integer greater than 1.', ''),
        (11230155, 1, 'Your maximum allowed games field must contain an integer between 1 and 999.', ''),
        (11230156, 1, 'Highest Rated', ''),
        
        (11230157, 1, 'The game \"%1\$s\" has been created, however there is no game file associated with it yet. Click <a href=\"%2\$s\">here</a> to the upload the game now.', ''),
        (11230158, 1, 'Category: <b><a href=\"%1\$s\">%2\$s</a></b>', ''),
        (11230159, 1, 'All Games', ''),
        (11230160, 1, 'Browse Games &gt; %1\$s', ''),
        (11230161, 1, 'Search:', ''),
        (11230162, 1, 'Go', ''),
        (11230163, 1, 'No games were found matching your criteria.', ''),
        (11230164, 1, 'Featured Games', ''),
        (11230165, 1, 'Latest Games', ''),
        (11230166, 1, 'Submit', ''),
        (11230167, 1, 'Next', ''),
        (11230168, 1, 'Featured', ''),
        (11230169, 1, 'File', ''),
        (11230170, 1, 'Photo', ''),
        (11230171, 1, 'Yes', ''),
        (11230172, 1, 'No', ''),
        (11230173, 1, 'Category', ''),
        (11230174, 1, 'Uncategorized', ''),
        
        (11230175, 1, 'Games: %1\$d games', ''),
        (11230176, 1, 'Game Comments: %1\$d comments', ''),
        (11230177, 1, 'Game Ratings: %1\$d ratings', ''),
        
        (11230178, 1, 'Uploading a Game', 'actiontypes'),
        (11230179, 1, '<a href=\"profile.php?user=%1\$s\">%2\$s</a> added a new game \"<a href=\"game.php?user=%1\$s&game_id=%3\$s\">%4\$s</a>\"', 'actiontypes'),
        (11230180, 1, 'Posting a Game Comment', 'actiontypes'),
        (11230181, 1, '<a href=\"profile.php?user=%1\$s\">%2\$s</a> posted a comment on the game <a href=\"game.php?user=%3\$s&game_id=%6\$s\">%7\$s</a>:<div class=\"recentaction_div\">%5\$s</div><div class=\"recentaction_div_media\">[media]</div>', 'actiontypes'),
        (11230182, 1, '%1\$d New Game Comment(s): %2\$s', 'notifytypes'),
        (11230183, 1, 'When a new comment is posted one of my games.', 'notifytypes'),
        (11230184, 1, 'New Game Comment', 'systememails'),
        (11230185, 1, 'Hello %1\$s,\n\nA new comment has been posted by %2\$s on one of your games. Please click the following link to view it:\n\n%3\$s\n\nBest Regards,\nSocial Network Administration', 'systememails'),
        

        (11231000, 1, 'Allow Game Photos?', ''),
        (11231001, 1, 'If you enable this feature, users will be able to upload a small photo icon when creating or editing an game. This can be displayed next to the game name on users\' profiles, in search/browse results, etc.', ''),
        (11231002, 1, 'Yes, users can upload a photo icon when they create/edit an game.', ''),
        (11231003, 1, 'No, users can not upload a photo icon when they create/edit an game.', ''),
        (11231004, 1, 'If you have selected yes above, please input the maximum dimensions for the game photos. If your users upload a photo that is larger than these dimensions, the server will attempt to scale them down automatically. This feature requires that your PHP server is compiled with support for the GD Libraries.', ''),
        (11231005, 1, 'Maximum Width:', ''),
        (11231006, 1, '(in pixels, between 1 and 999)', ''),
        (11231007, 1, 'Maximum Height:', ''),
        (11231008, 1, '(in pixels, between 1 and 999)', ''),
        (11231009, 1, 'What file types do you want to allow for game photos? Separate file types with commas, i.e. jpg, jpeg, gif, png', ''),
        (11231010, 1, 'Allowed File Types:', ''),
            
        (11231011, 1, 'Game Instruction', ''),
        (11231012, 1, 'Game Credit', ''),
        (11231013, 1, 'Enter dimension of your game file', ''),
        (11231014, 1, 'The maximum allowed width is %1\$spx and height is %2\$spx.', ''),
        (11231015, 1, 'Please enter game title', ''),
        (11231016, 1, 'Please enter valid width for game file', ''),
        (11231017, 1, 'Please enter valid height for game file', ''),
                
        
        (11231018, 1, 'Game Category', ''),
        (11231019, 1, 'Please select a category', ''),
        
        (11231020, 1, 'Edit File', ''),
        (11231021, 1, 'Edit Photo', ''),
        (11231022, 1, 'Upload Game Photo', ''),
        (11231023, 1, 'To upload a game photo from your computer, click the \"Browse\" button, locate it on your computer, then click the \"Upload\" button.', ''),
        (11231024, 1, 'Upload Game File', ''),
        (11231025, 1, 'To upload a game file from your computer, click the \"Browse\" button, locate it on your computer, then click the \"Upload\" button.', ''),
        
        (11231026, 1, 'More <b><a href=\"%1\$s\">%2\$s</a></b> Games', ''),
        (11231027, 1, 'Instructions:', ''),
        (11231028, 1, 'View Instructions', ''),
        (11231029, 1, 'Game Credit:', ''),
        (11231030, 1, 'Search My Games', ''),
        (11231031, 1, 'Search entries for', ''),
        (11231032, 1, 'Uncategorized', ''),
        
        (11231033, 1, 'Game Pack', ''),
        (11231034, 1, 'Please select the game pack you would like to import', ''),
        (11231035, 1, 'Load Script', ''),
        (11231036, 1, 'Import Options', ''),
        (11231037, 1, 'This pack contain games with ID from <b>%1\$s</b> to <b>%2\$s</b>. All existing games within that ID range will be deleted.<br/>ID from 1 to 100000 are reserved for importing so usually you dont have to worry about this.', ''),
        (11231038, 1, 'Please enter the username who would be the owner of imported games. It\'s best to create a special user designated managing these games, ex: arcade, funpack, gameadmin etc.', ''),
        (11231039, 1, 'Please define how import game categories should be map to your existing game categories:', ''),
        (11231040, 1, 'Import Category', ''),
        (11231041, 1, 'Existing Category', ''),
        (11231042, 1, 'Import Now', ''),
        (11231043, 1, 'The username you entered does not exist.', ''),
        (11231044, 1, 'Game pack imported successfully.', '')
        
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE  
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_game_license'")) == 0) {
    $database->database_query("ALTER TABLE se_settings 
          ADD COLUMN `setting_game_license` varchar(255) NOT NULL default ''
          ");
    $database->database_query("UPDATE se_settings SET setting_game_license='XXXX-XXXX-XXXX-XXXX'");
  }    
  
  
  $sql = "SELECT NULL FROM se_languagevars WHERE languagevar_language_id=1 && languagevar_id=11231045 LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      INSERT INTO `se_languagevars`
        (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
      VALUES
        (11231045, 1, 'License Key', ''),
        (11231046, 1, 'Enter the your license key that is provided to you when you purchased this plugin. If you do not know your license key, please contact support team.', ''),
        (11231047, 1, 'Format: XXXX-XXXX-XXXX-XXXX', ''),
        (11231048, 1, 'Please fill in all the fields.', ''),
        (11231049, 1, 'No game has been featured yet.', ''),
        (11231050, 1, 'No game has been uploaded yet.', '')
        
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
  
  $sql = "SELECT NULL FROM se_languagevars WHERE languagevar_language_id=1 && languagevar_id=11231051 LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  if (! $database->database_num_rows($resource))
  {
    $sql = "
      INSERT INTO `se_languagevars`
        (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
      VALUES
        (11231051, 1, 'Please use the form below to update the game details.', '')        
    ";
    $database->database_query($sql) or die($database->database_error() . " SQL: " . $sql);
  }
}
?>