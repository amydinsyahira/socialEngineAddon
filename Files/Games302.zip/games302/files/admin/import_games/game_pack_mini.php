<?php 

$import_config = array();
$import_config['name'] = 'Mini 300 Games Pack';
$import_config['start_id'] = 1001;
$import_config['end_id'] = 1315;
$import_config['categories'] = array(
100001 => 'Action',
100002 => 'Arcade',
100003 => 'Beat Up',
100004 => 'Casino',
100005 => 'Other',
100006 => 'Puzzle',
100007 => 'Racing',
100008 => 'Retro',
100009 => 'Shooting',
100010 => 'Sports',
);
$import_config['sql_file'] = 'game_pack_mini.sql';
