<?php


$page = "admin_game";
include "admin_header.php";

$task = rc_toolkit::get_request('task','main');

$rc_validator = new rc_validator();


$gamecat_id              = ( !empty($_POST['gamecat_id'])     ? $_POST['gamecat_id']     : NULL );
$gamecat_title           = ( !empty($_POST['gamecat_title'])  ? $_POST['gamecat_title']  : NULL );
$gamecat_showusercreated = !empty($_POST['gamecat_showusercreated']);

$result = 0;

// DELETE CATEGORY
if( $task=="deletegamecat" )
{
  $sql = "DELETE FROM se_gamecats WHERE gamecat_id='{$gamecat_id}' LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( $database->database_affected_rows($resource) )
    echo '{"result" : "success"}';
  else
    echo '{"result" : "failure"}';
  
  exit();
}


// CREATE CATEGORY
else if( $task=="creategamecat" )
{
  $lvar_id = SE_Language::edit(0, $gamecat_title, NULL, LANGUAGE_INDEX_SUBNETS);
  $sql = "INSERT INTO se_gamecats (gamecat_languagevar_id,gamecat_title) VALUES ('{$lvar_id}','{$gamecat_title}')";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( $database->database_affected_rows($resource) )
    echo '{"result" : "success", "gamecat_id" : '.$database->database_insert_id().', "gamecat_languagevar_id" : '.$lvar_id.'}';
  else
    echo '{"result" : "failure"}';
  
  exit();
}


// EDIT CATEGORY
else if( $task=="editgamecat" )
{
  // Get langvar id
  $sql = "SELECT * FROM se_gamecats WHERE gamecat_id='{$gamecat_id}' LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( !$database->database_num_rows($resource) )
  {
    echo '{"result" : "failure"}';
    exit();
  }
  
  $result = $database->database_fetch_assoc($resource);
  $lvar_id = $result['gamecat_languagevar_id'];
  
  
  SE_Language::edit($lvar_id, $gamecat_title);
  $sql = "UPDATE se_gamecats SET gamecat_title='{$gamecat_title}' WHERE gamecat_id='{$gamecat_id}' LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( $database->database_affected_rows($resource) || $resource )
    echo '{"result" : "success"}';
  else
    echo '{"result" : "failure"}';
  
  exit();
}



// SAVE CHANGES
else if($task == "dosave") {
  $setting[setting_game_license] = $_POST['setting_game_license'];
  $setting[setting_permission_game] = $_POST['setting_permission_game'];
  $setting[setting_game_width] = $_POST['setting_game_width'];
  $setting[setting_game_height] = $_POST['setting_game_height'];
  $setting[setting_game_mimes] = $_POST['setting_game_mimes'];
  $setting[setting_game_exts] = $_POST['setting_game_exts'];

  // ENSURE THAT WIDTHS/HEIGHTS ARE EVEN
  if($setting[setting_game_width]%2 != 0) { $setting[setting_game_width] = $setting[setting_game_width]+1; }
  if($setting[setting_game_height]%2 != 0) { $setting[setting_game_height] = $setting[setting_game_height]+1; }

  if (!$rc_validator->has_errors()) {
      $database->database_query("UPDATE se_settings SET 
          setting_game_license='$setting[setting_game_license]',
          setting_permission_game='$setting[setting_permission_game]',
          setting_game_width='$setting[setting_game_width]',
          setting_game_height='$setting[setting_game_height]',
          setting_game_mimes='$setting[setting_game_mimes]',
          setting_game_exts='$setting[setting_game_exts]'
          ");
    
      $result = 1;
  }

}

// GET GAME ENTRY CATEGORIES
$categories_array = se_game::game_category_list($gamecat_showusercreated);

// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('gamecats', $categories_array);
include "admin_footer.php";
?>