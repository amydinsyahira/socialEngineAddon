<?php


$page = "user_game_edit";
include "header.php";

$task = rc_toolkit::get_request('task','update');
$game_id = rc_toolkit::get_request('game_id');


// ENSURE GAME IS ENABLED FOR THIS USER
if( ~(int)$user->level_info['level_game_allow'] & 3 ) {
  rc_toolkit::redirect("user_home.php");
}


// CREATE GAME OBJECT
$game = new se_game($user->user_info['user_id'], $game_id);
if (!$game->game_exists || $user->user_info['user_id'] != $game->game_info['game_user_id']) {
  rc_toolkit::redirect("user_home.php");
}


// GET PRIVACY SETTINGS
$level_game_privacy = unserialize($user->level_info['level_game_privacy']);
rsort($level_game_privacy);
$level_game_comments = unserialize($user->level_info['level_game_comments']);
rsort($level_game_comments);

// GET PREVIOUS PRIVACY SETTINGS
for($c=0;$c<count($level_game_privacy);$c++) {
  if(user_privacy_levels($level_game_privacy[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_privacy[$c]));
    $privacy_options[$level_game_privacy[$c]] = user_privacy_levels($level_game_privacy[$c]);
  }
}

for($c=0;$c<count($level_game_comments);$c++) {
  if(user_privacy_levels($level_game_comments[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_comments[$c]));
    $comment_options[$level_game_comments[$c]] = user_privacy_levels($level_game_comments[$c]);
  }
}
  
// SET RESULT AND ERROR VARS
$result = FALSE;
$is_error = 0;
$show_uploader = 1;
$file_result = array();
$max_uploads = 1;

//rc_toolkit::debug($game->game_info);
//rc_toolkit::debug($game->game_dir($game->game_info['game_id']),$game->game_info['game_id']);

// UPLOAD FILES
if( $task=="doupdate" )
{
  $game->game_info['game_gamecat_id'] = $_POST['game_gamecat_id'];
  $game->game_info['game_title']     = censor($_POST['game_title']);
  $game->game_info['game_desc']      = censor(str_replace("\r\n", "<br>", $_POST['game_desc']));
  $game->game_info['game_instruction'] = censor(str_replace("\r\n", "<br>", $_POST['game_instruction']));
  $game->game_info['game_credit'] = censor(str_replace("\r\n", "<br>", $_POST['game_credit']));
  $game->game_info['game_width']    = $_POST['game_width'];
  $game->game_info['game_height']   = $_POST['game_height'];
  $game->game_info['game_search']    = $_POST['game_search'];
  $game->game_info['game_privacy']   = $_POST['game_privacy'];
  $game->game_info['game_comments']  = $_POST['game_comments'];
  
  if( !$user->level_info['level_game_search'] ) $game->game_info['game_search'] = TRUE;
  
  // MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
  if(!in_array($game_privacy, $level_game_privacy)) { $game_privacy = $level_game_privacy[0]; }
  if(!in_array($game_comments, $level_game_comments)) { $game_comments = $level_game_comments[0]; }
  
  if( !$user->level_info['level_game_search'] ) {
    $game->game_info['game_search'] = 1;
  }
  
  $result = $game->game_edit($game->game_info);
  if ((is_array($result) && isset($result['is_error'])) || $result === false) {
    $is_error = $result['is_error'];
    $result = false;
  }
  else {
    $result = true;
  }
}

$game->game_info['game_desc'] = str_replace("<br>", "\r\n", $game->game_info['game_desc']);
$game->game_info['game_instruction'] = str_replace("<br>", "\r\n", $game->game_info['game_instruction']);
$game->game_info['game_credit'] = str_replace("<br>", "\r\n", $game->game_info['game_credit']);
  

$gamecats_array = $game->game_category_list($user->user_info['user_id']);
$smarty->assign('gamecats', $gamecats_array);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
$smarty->assign('result', $result);

//rc_toolkit::debug($gamecats_array);

// ASSIGN VARIABLES AND SHOW UPLOAD FILES PAGE
$smarty->assign('is_error', $is_error);
$smarty->assign('task', $task);
$smarty->assign('type', $type);
$smarty->assign_by_ref('game', $game);
include "footer.php";
?>