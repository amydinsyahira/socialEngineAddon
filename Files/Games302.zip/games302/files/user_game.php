<?php

$page = "user_game";
include "header.php";

$task = rc_toolkit::get_request('task','main');
$p = rc_toolkit::get_request('p',1);
$search = rc_toolkit::get_request('search');

// ENSURE GAME IS ENABLED FOR THIS USER
if( ~(int)$user->level_info['level_game_allow'] & 3 ) {
  rc_toolkit::redirect("user_home.php");
}

// CREATE GAME OBJECT
$game = new se_game($user->user_info[user_id]);

// GET PRIVACY SETTINGS
$level_game_privacy = unserialize($user->level_info[level_game_privacy]);
rsort($level_game_privacy);
$level_game_comments = unserialize($user->level_info[level_game_comments]);
rsort($level_game_comments);


// DELETE GAME
if($task == "delete") {
  $game_id = $_GET['game_id'];

  $game->game_delete($game_id);


// EDIT GAME
} elseif($task == "edit") {
  $game_id = rc_toolkit::get_request('game_id');
  $game_obj = new se_game($user->user_info[user_id], $game_id);
  
  $game_obj->game_info['game_gamecat_id'] = $_POST['game_gamecat_id'];
  $game_obj->game_info['game_title']     = censor($_POST['game_title']);
  $game_obj->game_info['game_desc']      = censor(str_replace("\r\n", "<br>", $_POST['game_desc']));
  $game_obj->game_info['game_instruction'] = censor(str_replace("\r\n", "<br>", $_POST['game_instruction']));
  $game_obj->game_info['game_credit'] = censor(str_replace("\r\n", "<br>", $_POST['game_credit']));
  $game_obj->game_info['game_width']    = $_POST['game_width'];
  $game_obj->game_info['game_height']   = $_POST['game_height'];
  $game_obj->game_info['game_search']    = $_POST['game_search'];
  $game_obj->game_info['game_privacy']   = $_POST['game_privacy'];
  $game_obj->game_info['game_comments']  = $_POST['game_comments'];
  
  if( !$user->level_info['level_game_search'] ) $game_obj->game_info['game_search'] = TRUE;
  
  // MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
  if(!in_array($game_privacy, $level_game_privacy)) { $game_privacy = $level_game_privacy[0]; }
  if(!in_array($game_comments, $level_game_comments)) { $game_comments = $level_game_comments[0]; }
  
  $result = $game_obj->game_edit($game_obj->game_info);
  
  if( $result['is_error'] )
  {
    $is_error = $result['is_error'];
  }
}

$where = "";
if (trim($search)) {
  $where = "(game_title LIKE '%$search%' OR game_desc LIKE '%$search%' OR game_instruction LIKE '%$search%' OR game_credit LIKE '%$search%')";
}

// GET GAMES
$total_games = $game->game_total($where);
$rc_pager = new rc_pager($p, 10, $total_games);
$game_array = $game->game_list($rc_pager->offset, $rc_pager->page_size, "game_uploaded, game_title ASC", $where, 1);
$rc_pager->assign_smarty_vars(count($game_array));


// GET PREVIOUS PRIVACY SETTINGS
for($c=0;$c<count($level_game_privacy);$c++) {
  if(user_privacy_levels($level_game_privacy[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_privacy[$c]));
    $privacy_options[$level_game_privacy[$c]] = user_privacy_levels($level_game_privacy[$c]);
  }
}

for($c=0;$c<count($level_game_comments);$c++) {
  if(user_privacy_levels($level_game_comments[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_comments[$c]));
    $comment_options[$level_game_comments[$c]] = user_privacy_levels($level_game_comments[$c]);
  }
}

$gamecats_array = $game->game_category_list($user->user_info['user_id']);
$smarty->assign('gamecats', $gamecats_array);
$smarty->assign('is_error', $is_error);

// ASSIGN VARIABLES AND SHOW VIEW GAMES PAGE
$smarty->assign('search', $search);
$smarty->assign('games_total', $total_games);
$smarty->assign('games', $game_array);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
include "footer.php";
?>