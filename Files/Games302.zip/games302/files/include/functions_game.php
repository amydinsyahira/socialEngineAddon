<?php


defined('SE_PAGE') or exit();


function get_games($limit, $sort, $where)
{
  $game = new se_game();
  $games = $game->game_list(0, $limit, $sort, $where, 1);
  return $games;
}


function featured_games($limit=5)
{
	return get_games($limit, "RAND()", "game_search='1' AND game_uploaded='1' AND game_featured='1'");
}


function latest_games($limit=5)
{
  return get_games($limit, "game_datecreated DESC", "game_search='1' AND game_uploaded='1'");
}


function lastest_featured_games($limit=5)
{
  return get_games($limit, "game_datecreated DESC", "game_search='1' AND game_uploaded='1' AND game_featured='1'");
}


function search_game()
{
	global $database, $url, $results_per_page, $p, $search_text, $t, $search_objects, $results, $total_results;

	// CONSTRUCT QUERY
	$game_query = "SELECT 
			  se_games.*, 
			  se_users.user_id, 
			  se_users.user_username,
			  se_users.user_photo,
			  se_users.user_fname,
			  se_users.user_lname
			FROM
			  se_games,
			  se_users,
			  se_levels
			WHERE
			  se_games.game_user_id=se_users.user_id AND
			  se_users.user_level_id=se_levels.level_id AND
			  (
			    se_games.game_search='1' OR
			    se_levels.level_game_search='0'
			  )
			  AND
			  (
			    se_games.game_title LIKE '%$search_text%' OR
			    se_games.game_desc LIKE '%$search_text%'
			  )"; 

	// GET TOTAL RESULTS
	$total_games = $database->database_num_rows($database->database_query($game_query." LIMIT 201"));

	// IF NOT TOTAL ONLY
	if($t == "game") {

	  // MAKE GAME PAGES
	  $start = ($p - 1) * $results_per_page;
	  $limit = $results_per_page+1;

	  // SEARCH GAMES
	  $game = new se_game();
	  $games = $database->database_query($game_query." ORDER BY game_id DESC LIMIT $start, $limit");
	  while($game_info = $database->database_fetch_assoc($games)) {

	    // CREATE AN OBJECT FOR USER
	    $profile = new se_user();
	    $profile->user_info[user_id] = $game_info[user_id];
	    $profile->user_info[user_username] = $game_info[user_username];
	    $profile->user_info[user_fname] = $game_info[user_fname];
	    $profile->user_info[user_lname] = $game_info[user_lname];
	    $profile->user_info[user_photo] = $game_info[user_photo];
	    $profile->user_displayname();

	    // SET RESULT VARS
	    $result_url = $url->url_create("game", $game_info[user_username], $game_info[game_id]);
	    $result_name = 11230141;
	    $result_desc = 11230142;

	    // SET DIRECTORY
	    $game_info[game_dir] = $game->game_dir($game_info[game_id]);
	
	    // CHECK FOR THUMBNAIL
	    $thumb_path = $game_info[game_dir].$game_info[game_id]."_thumb.jpg";
	    if(!file_exists($thumb_path)) { $game_info[game_thumb] = "./images/game_placeholder.gif"; }

	    // IF NO TITLE
	    if($game_info[game_title] == "") { $game_info[game_title] = SE_Language::get(589); }

	    // IF DESCRIPTION IS LONG
	    if(strlen($game_info[game_desc]) > 150) { $game_info[game_desc] = substr($game_info[game_desc], 0, 147)."..."; }

	    $results[] = Array('result_url' => $result_url,
				'result_icon' => $thumb_path,
				'result_name' => $result_name,
				'result_name_1' => $game_info[game_title],
				'result_desc' => $result_desc,
				'result_desc_1' => $url->url_create('profile', $game_info[user_username]),
				'result_desc_2' => $profile->user_displayname,
				'result_desc_3' => $game_info[game_desc]);
	  }

	  // SET TOTAL RESULTS
	  $total_results = $total_games;

	}

	// SET ARRAY VALUES
	SE_Language::_preload_multi(11230141, 11230142, 11230143);
	if($total_games > 200) { $total_games = "200+"; }
	$search_objects[] = Array('search_type' => 'game',
				'search_lang' => 11230143,
				'search_total' => $total_games);


} // END search_game() FUNCTION









// THIS FUNCTION IS RUN WHEN A USER IS DELETED
// INPUT: $user_id REPRESENTING THE USER ID OF THE USER BEING DELETED
// OUTPUT: 

function deleteuser_game($user_id)
{
	global $database;

	// GET GAME OBJECT
	$game = new se_game($user_id);

	// DELETE GAMES, COMMENTS, AND RATINGS
	$database->database_query("DELETE FROM se_games, se_gamecomments, se_gameratings USING se_games LEFT JOIN se_gamecomments ON se_games.game_id=se_gamecomments.gamecomments_game_id LEFT JOIN se_gameratings ON se_games.game_id=se_gameratings.gamerating_game_id WHERE se_games.game_user_id='$user_id'");

	// DELETE USER'S FILES
	if(is_dir($game->game_dir())) {
	  $dir = $game->game_dir();
	} else {
	  $dir = ".".$game->game_dir();
	}
  
	if($dh = @opendir($dir))
  {
	  while( ($file = @readdir($dh)) !== false )
    {
	    if( $file != "." && $file != ".." )
      {
	      @unlink($dir.$file);
	    }
	  }
	  @closedir($dh);
	}
	@rmdir($dir);
}
// deleteuser_game


function site_statistics_game(&$args)
{
  global $database;
  
  $statistics =& $args['statistics'];

  $total = $database->database_fetch_assoc($database->database_query("SELECT COUNT(game_id) AS total FROM se_games WHERE game_uploaded=1"));
  $statistics['games'] = array(
    'title' => 11230175,
    'stat'  => (int) ( isset($total['total']) ? $total['total'] : 0 )
  );
}
// site_statistics_game
