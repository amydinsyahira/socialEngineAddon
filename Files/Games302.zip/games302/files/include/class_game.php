<?php

include_once "class_radcodes.php";

class se_game
{
  var $game_info = array();
  var $is_error = NULL;
  var $user_id = NULL;
  var $game_exists = false;

  function se_game ($user_id = NULL, $game_id = NULL)
  {
    global $database, $user;
    
    $this->user_id = $user_id;
    
    if ($game_id)
    {
      $sql = "SELECT * FROM se_games LEFT JOIN se_gamecats ON gamecat_id = game_gamecat_id WHERE game_id='{$game_id}' LIMIT 1";
      $resource = $database->database_query($sql);
      if ($resource && $database->database_num_rows($resource))
      {
        $this->game_exists = TRUE;
        $this->game_info = $database->database_fetch_assoc($resource);
        if (! $this->game_info['gamecat_id'])
        {
          $this->game_info['gamecat_languagevar_id'] = 11231032;
          $this->game_info['gamecat_id'] = -1;
        }
        SELanguage::_preload($this->game_info['gamecat_languagevar_id']);

        // GET LEVEL INFO FROM USER/OWNER IF MATCH
        if ($this->game_info['game_user_id'] == $user->user_info['user_id'])
        {
          $this->gameowner_level_info = & $user->level_info;
        }
        elseif ($this->game_info['game_user_id'] == $owner->user_info['user_id'])
        {
          $this->gameowner_level_info = & $owner->level_info;
        }
        else
        {
          $sql = "SELECT se_levels.* FROM se_users LEFT JOIN se_levels ON se_users.user_level_id=se_levels.level_id WHERE se_users.user_id='{$this->game_info['game_user_id']}'";
          $resource = $database->database_query($sql) or die($database->database_error()." SQL: ".$sql);
          $this->gameowner_level_info = $database->database_fetch_assoc($resource);
        }
      }
    }
  }
  // se_game

  
  function game_category_list ($user_id = FALSE)
  {
    global $database;
    $sql = "SELECT * FROM se_gamecats ";

    if ($user_id !== TRUE && $user_id > 0)
    {
      $sql .= "WHERE gamecat_user_id=0 || gamecat_user_id='{$user_id}' ";
    }
    elseif ($user_id === FALSE)
    {
      $sql .= "WHERE gamecat_user_id=0 ";
    }
      
    $sql .= "ORDER BY gamecat_id ASC";
    $res = $database->database_query($sql);
    $gamecats_array = array();
    while ($result = $database->database_fetch_assoc($res))
    {
      // PRELOAD
      if (! empty($result['gamecat_languagevar_id']))
      {
        SE_Language::_preload($result['gamecat_languagevar_id']);
      }
        
      $gamecats_array[] = $result;
    }
    return $gamecats_array;
  }
  // game_category_list  
  
  
  function game_total ($where = "")
  {
    global $database;
    
    $game_query = "SELECT game_id FROM se_games";

    if ($this->user_id == 0)
    {
      $game_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id";
    }
    
    $cs = array($where);
    if ($this->user_id != 0)
    {
      $cs['user'] = "game_user_id='" . $this->user_id . "'";
    }

    $game_query .= " ".rc_toolkit::criteria_builder($cs,'AND',true);
    
    $game_total = $database->database_num_rows($database->database_query($game_query));
    return $game_total;
  }
  // game_total
  
  
  function game_list ($start, $limit, $sort_by = "game_id DESC", $where = "", $details = 0)
  {
    global $database, $user, $owner;

    $game_query = "SELECT se_games.*";

    if ($details)
    {
      $game_query .= ", count(se_gamecomments.gamecomment_id) AS total_comments";
    }

    if ($this->user_id == 0)
    {
      $game_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo, se_users.user_fname, se_users.user_lname";
    }

    $game_query .= " FROM se_games";

    if ($details)
    {
      $game_query .= " LEFT JOIN se_gamecomments ON se_games.game_id=se_gamecomments.gamecomment_game_id";
    }

    if ($this->user_id == 0)
    {
      $game_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id";
    }
    
    $cs = array($where);
    if ($this->user_id != 0)
    {
      $cs['user'] = "game_user_id='" . $this->user_id . "'";
    }
    $game_query .= " ".rc_toolkit::criteria_builder($cs,'AND',true);
    
    $game_query .= " GROUP BY game_id ORDER BY $sort_by LIMIT $start, $limit";
    
    $res = $database->database_query($game_query);
    
    $game_array = array();
    while ($game_info = $database->database_fetch_assoc($res))
    {
      if ($this->user_id == 0)
      {
        $author = new se_user();
        $author->user_exists = 1;
        $author->user_info[user_id] = $game_info[user_id];
        $author->user_info[user_username] = $game_info[user_username];
        $author->user_info[user_fname] = $game_info[user_fname];
        $author->user_info[user_lname] = $game_info[user_lname];
        $author->user_info[user_photo] = $game_info[user_photo];
        $author->user_displayname();
      }
      elseif ($owner->user_exists != 0 && $owner->user_info[user_id] == $game_info[game_user_id])
      {
        $author = $owner;
      }
      elseif ($user->user_exists != 0 && $user->user_info[user_id] == $game_info[game_user_id])
      {
        $author = $user;
      }
      
      $this->calculate_game_rating($game_info);
      
      $game_object = new se_game($author->user_info[user_id]);
      $game_object->game_exists = true;
      $game_object->game_info = $game_info;
      
      $game_info[game] = $game_object;
      $game_info[game_author] = $author;
      $game_info[game_dir] = $game_object->game_dir($game_info[game_id]);
      
      
      //rc_toolkit::debug($game_info);
      
      $game_array[] = $game_info;
    }

    return $game_array;
  }
  // game_list
  

  function calculate_game_rating(&$game_info)
  {
    $game_info[game_rating_full] = floor($game_info[game_cache_rating]);
    $game_info[game_rating_part] = (($game_info[game_cache_rating] - $game_info[game_rating_full]) == 0) ? 0 : 1;
    $game_info[game_rating_none] = 5 - $game_info[game_rating_full] - $game_info[game_rating_part];
  }
  
  
  function get_game_rating_total($game_id)
  {
    global $database;
  	return $database->database_num_rows($database->database_query("SELECT NULL FROM se_gameratings WHERE gamerating_game_id='$game_id'"));
  }
  
  
  function game_dir ($game_id = 0)
  {
    if ($game_id == 0 & $this->game_exists)
    {
      $game_id = $this->game_info[game_id];
    }
    $subdir = $game_id + 999 - (($game_id - 1) % 1000);
    $gamedir = "./uploads_game/$subdir/$game_id/";
    
    return $gamedir;
  }
  // game_dir
  
  

  function game_edit ($game_data)
  {
    global $database, $url, $setting, $user;
    // INSERT ROW INTO GAME TABLE
    $time = time();
    
    // filter clean data
    $keys = array('game_gamecat_id' , 'game_title' , 'game_desc' , 'game_instruction' , 'game_credit' , 'game_width' , 'game_height' , 'game_search' , 'game_privacy' , 'game_comments');
    
    foreach ($game_data as $k=>$v)
    {
      if (!in_array($k, $keys))
      {
        unset($game_data[$k]);
      }
    }

    if (empty($game_data[game_gamecat_id]))
    {
      $is_error = 11231019;
    }
    elseif (! trim($game_data[game_title]))
    {
      $is_error = 11231015;
    }
    elseif (! is_numeric($game_data[game_width]) || $game_data[game_width] > $setting['setting_game_width'] || $game_data[game_width] < 1)
    {
      $is_error = 11231016;
    }
    elseif (! is_numeric($game_data[game_height]) || $game_data[game_height] > $setting['setting_game_height'] || $game_data[game_height] < 1)
    {
      $is_error = 11231017;
    }
    
    if ($is_error)
    {
      return array('is_error' => $is_error);
    }
    
    if (! $this->game_exists)
    {        
      $game_data['game_user_id'] = $user->user_info['user_id'];
      $game_data['game_datecreated'] = $time;
      $game_data['game_dateupdated'] = $time;
      
      $query_data = rc_toolkit::db_data_packer($game_data);
      $sql = "INSERT INTO se_games SET $query_data";
        
      $resource = $database->database_query($sql);
      $this->game_info['game_id'] = $database->database_insert_id();
      if (! $database->database_affected_rows() || ! $this->game_info['game_id']){
        return FALSE;
      }
        
      $this->game_exists = TRUE;
    }
    else
    {
      // Check owner
      if ($this->game_info['game_user_id'] != $this->user_id)
      {
        return FALSE;
      }
      $game_data['game_dateupdated'] = $time;
      $sql = "UPDATE se_games SET ".rc_toolkit::db_data_packer($game_data). " WHERE game_id='{$this->game_info['game_id']}' LIMIT 1";
      $resource = $database->database_query($sql);
      if (! $resource)
        return FALSE;
    }
    // GET UPDATED GAME INFO
    $sql = "SELECT * FROM se_games WHERE game_id='{$this->game_info['game_id']}' LIMIT 1";
    $resource = $database->database_query($sql);
    if (! $resource || ! $database->database_num_rows($resource))
      return FALSE;
      
    $this->game_info = $database->database_fetch_assoc($resource);
    return $this->game_info['game_id'];
  }
  // game_edit
  
  
 

  function game_file ()
  {
    $game_dir = $this->game_dir($this->game_info['game_id']);
    $game_file = $game_dir . $this->game_info['game_file'];
    return $game_file;
  }
  // game_file
  

  function game_upload ($file_name)
  {
    global $database, $url, $setting, $user, $actions;
    
    // Check exists and owner
    if (! $this->game_exists || $this->game_info['game_user_id'] != $this->user_id)
    {
      return FALSE;
    }
    
    // SET KEY VARIABLES
    $file_maxsize = $user->level_info[level_game_maxsize];
    $file_exts = explode(",", str_replace(" ", "", strtolower($setting[setting_game_exts])));
    $file_types = explode(",", str_replace(" ", "", strtolower($setting[setting_game_mime])));
    // IF FILE EXTS AND MIMES ARE EMPTY, FILL IN WITH GAME'S EXT/TYPE
    if (trim($setting[setting_game_exts]) == "")
    {
      $file_exts[] = strtolower(str_replace(".", "", strrchr($_FILES[$file_name]['name'], ".")));
    }
    if (trim($setting[setting_game_mime]) == "")
    {
      $file_types[] = strtolower($_FILES[$file_name]['type']);
    }
    $game_ext = strtolower(str_replace(".", "", strrchr($_FILES[$file_name]['name'], ".")));
    // CHECK THAT UPLOAD DIRECTORY EXISTS, IF NOT THEN CREATE
    $game_directory = $this->game_dir($this->game_info['game_id']);
    $game_path_array = explode("/", $game_directory);
    array_pop($game_path_array);
    array_pop($game_path_array);
    $subdir = implode("/", $game_path_array) . "/";
    if (! is_dir($subdir))
    {
      mkdir($subdir, 0777);
      chmod($subdir, 0777);
      $handle = fopen($subdir . "index.php", 'x+');
      fclose($handle);
    }
    if (! is_dir($game_directory))
    {
      mkdir($game_directory, 0777);
      chmod($game_directory, 0777);
      $handle = fopen($game_directory . "/index.php", 'x+');
      fclose($handle);
    }

    $new_game = new se_upload();
    $new_game->new_upload($file_name, $file_maxsize, $file_exts, $file_types);

    if (! $new_game->is_error)
    {
      $game_id = $this->game_info['game_id'];
      $new_filename = $game_id;
      $new_gamefile = $new_filename . '.' . $game_ext;
      $file_dest = $this->game_dir($this->game_info['game_id']) . $new_gamefile;
      
      $new_game->upload_file($file_dest);
      if (!$new_game->is_error)
      {
        $sql = "UPDATE se_games SET game_uploaded=1, game_file='$new_gamefile' WHERE game_id='{$game_id}' LIMIT 1";
        $database->database_query($sql);
        
        // it still has the old value :-)
        if (!$this->game_info['game_uploaded']) {
            $actions->actions_add($user, "newgame", 
              array($user->user_info['user_username'], $user->user_displayname, $this->game_info['game_id'], $this->game_info['game_title']),
              $action_media, 
              0, 
              false, 
              "user", 
              $user->user_info['user_id'], $user->user_info['user_privacy']
            );
        }
        
        $this->game_info['game_uploaded'] = 1;
        $this->game_info['game_file'] = $new_gamefile;
        
        
      }

    }

    $file_result = Array('is_error' => $new_game->is_error);
    return $file_result;
  }
  // game_upload
  

  function game_delete ($game_id)
  {
    global $database, $url;
    $game_query = $database->database_query("SELECT * FROM se_games WHERE game_id='$game_id'");
    if ($database->database_num_rows($game_query) != 1)
    {
      return;
    }
    $game_info = $database->database_fetch_assoc($game_query);
    if ($this->user_id != 0 && $game_info[game_user_id] != $this->user_id)
    {
      return;
    }
    // DELETE GAME AND PHOTO
    $game_path = $this->game_dir($game_id) . $game_info[game_file];
    if (file_exists($game_path))
    {
      unlink($game_path);
    }
    $photo_path = $this->game_dir($game_id) . $game_info[game_photo];
    if (file_exists($photo_path))
    {
      unlink($photo_path);
    }
    $thumb_path = $this->game_dir($game_id) . substr($game_info[game_photo], 0, strrpos($game_info[game_photo], ".")) . "_thumb" . substr($game_info[game_photo], strrpos($game_info[game_photo], "."));

    if (file_exists($thumb_path))
    {
      unlink($thumb_path);
    }
    $database->database_query("DELETE FROM se_games, se_gamecomments, se_gameratings USING se_games LEFT JOIN se_gamecomments ON se_games.game_id=se_gamecomments.gamecomment_game_id LEFT JOIN se_gameratings ON se_games.game_id=se_gameratings.gamerating_game_id WHERE se_games.game_id='$game_id'");
  }
  // game_delete
  

  function game_delete_selected ($start, $limit, $sort_by = "game_id DESC", $where = "")
  {
    global $database;

    $game_query = "SELECT se_games.game_id FROM se_games";

    if ($this->user_id == 0)
    {
      $game_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id";
    }
    
    $cs = array($where);
    if ($this->user_id != 0)
    {
      $cs['user'] = "game_user_id=" . $this->user_id;
    }

    $game_query .= " ".rc_toolkit::criteria_builder($cs,'AND',true);
    $game_query .= " GROUP BY game_id ORDER BY $sort_by LIMIT $start, $limit";

    $res = $database->database_query($game_query);
    while ($game_info = $database->database_fetch_assoc($res))
    {
      if ($_POST["delete_game_" . $game_info[game_id]] == 1)
      {
        $this->game_delete($game_info[game_id]);
      }
    }
  }
  // game_delete_selected
  

  function game_photo ($nophoto_image = NULL, $thumb = FALSE)
  {
    if (empty($this->game_info['game_photo']))
    {
      return $nophoto_image;
    }
      
    $game_dir = $this->game_dir($this->game_info['game_id']);
    $game_photo = $game_dir . $this->game_info['game_photo'];
    if ($thumb)
    {
      $game_thumb = substr($game_photo, 0, strrpos($game_photo, ".")) . "_thumb" . substr($game_photo, strrpos($game_photo, "."));
      if (file_exists($game_thumb))
      {
        return $game_thumb;
      }
        
    }
    if (file_exists($game_photo))
    {
      return $game_photo;
    }
      
    return $nophoto_image;
  }
  // game_photo
  
  
  function game_photo_upload ($photo_name)
  {
    global $database, $url;
    // Check exists and owner
    if (! $this->game_exists || $this->game_info['game_user_id'] != $this->user_id)
    {
      return FALSE;
    }
    // SET KEY VARIABLES
    $file_maxsize = $this->gameowner_level_info[level_game_maxsize];
    $file_exts = explode(",", str_replace(" ", "", strtolower($this->gameowner_level_info['level_game_photo_exts'])));
    $file_types = explode(",", str_replace(" ", "", strtolower("image/jpeg, image/jpg, image/jpe, image/pjpeg, image/pjpg, image/x-jpeg, x-jpg, image/gif, image/x-gif, image/png, image/x-png")));
    $file_maxwidth = $this->gameowner_level_info[level_game_photo_width];
    $file_maxheight = $this->gameowner_level_info[level_game_photo_height];
    // CHECK THAT UPLOAD DIRECTORY EXISTS, IF NOT THEN CREATE
    $game_directory = $this->game_dir($this->game_info['game_id']);
    $game_path_array = explode("/", $game_directory);
    array_pop($game_path_array);
    array_pop($game_path_array);
    $subdir = implode("/", $game_path_array) . "/";
    if (! is_dir($subdir))
    {
      mkdir($subdir, 0777);
      chmod($subdir, 0777);
      $handle = fopen($subdir . "index.php", 'x+');
      fclose($handle);
    }
    if (! is_dir($game_directory))
    {
      mkdir($game_directory, 0777);
      chmod($game_directory, 0777);
      $handle = fopen($game_directory . "/index.php", 'x+');
      fclose($handle);
    }
    $photo_newname = "0_" . rand(1000, 9999) . ".jpg";
    $file_dest = $this->game_dir($this->game_info[game_id]) . $photo_newname;
    $thumb_dest = substr($file_dest, 0, strrpos($file_dest, ".")) . "_thumb" . substr($file_dest, strrpos($file_dest, "."));
    $new_photo = new se_upload();
    $new_photo->new_upload($photo_name, $file_maxsize, $file_exts, $file_types, $file_maxwidth, $file_maxheight);
    // UPLOAD AND RESIZE PHOTO IF NO ERROR
    if (! $new_photo->is_error)
    {
      $this->game_photo_delete();
      $new_photo->upload_thumb($thumb_dest);
      if ($new_photo->is_image)
        $new_photo->upload_photo($file_dest);
      else
        $new_photo->upload_file($file_dest);
      if (! $new_photo->is_error)
      {
        $sql = "UPDATE se_games SET game_photo='{$photo_newname}' WHERE game_id='{$this->game_info['game_id']}'";
        $resource = $database->database_query($sql) or die($database->database_error()." SQL: ".$sql);;
        $this->game_info['game_photo'] = $photo_newname;
      }
    }

    $file_result = Array('is_error' => $new_photo->is_error);
    return $file_result;

  }
  // game_photo_upload  
  
  
  function game_photo_delete ()
  {
    global $database;
    
    if ($game_photo = $this->game_photo())
    {
      $sql = "UPDATE se_games SET game_photo='' WHERE game_id='{$this->game_info[game_id]}'";
      $resource = $database->database_query($sql) or die($database->database_error()." SQL: ".$sql);
      unlink($game_photo);
      $game_thumb = $this->game_photo(null, true);
      unlink($game_thumb);
      $this->game_info['game_photo'] = NULL;
    }
  }
  // game_photo_delete  
  
}
