<?php


// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
defined('SE_PAGE') or exit();

include_once "./include/class_radcodes.php";
include_once "./include/class_game.php";
include_once "./include/functions_game.php";



// PRELOAD LANGUAGE
SE_Language::_preload(11230098,11231032);

// SET MAIN MENU VARS
if( ($user->user_exists && (int)$user->level_info['level_game_allow'] & 1) || (!$user->user_exists && $setting['setting_permission_game']) )
{
  $plugin_vars['menu_main'] = Array('file' => 'browse_games.php', 'title' => 11230098);
}

// SET USER MENU VARS
if( $user->user_exists && (int)$user->level_info['level_game_allow'] & 2 )
{
  $plugin_vars['menu_user'] = Array('file' => 'user_game.php', 'icon' => 'game_game16.gif', 'title' => 11230098);
}


if((int)$owner->level_info['level_game_allow'] & 2 && $page == "profile") {

  // START GAME
  $game = new se_game($owner->user_info['user_id']);
  $sort = "game_id DESC";

  // GET PRIVACY LEVEL AND SET WHERE
  $game_privacy_max = $owner->user_privacy_max($user);
  $where = "game_uploaded=1 AND (game_privacy & $game_privacy_max)";

  // GET TOTAL GAMES
  $total_games = $game->game_total($where);
  if ($total_games > 20) {
    $games = $game->game_list(0, 20, $sort, $where);
  }
  else {
    $games = $game->game_list(0, $total_games, $sort, $where);
  }

  // ASSIGN GAMES SMARY VARIABLE
  $smarty->assign('games', $games);
  $smarty->assign('total_games', $total_games);

  // SET PROFILE MENU VARS
  if($total_games != 0) {
    $plugin_vars['menu_profile_tab'] = Array('file'=> 'profile_game_tab.tpl', 'title' => 11230098);
  }

}


// SET HOOKS
SE_Hook::register("se_search_do", 'search_game');
  
SE_Hook::register("se_user_delete", 'deleteuser_game');
  
SE_Hook::register("se_site_statistics", 'site_statistics_game');

?>