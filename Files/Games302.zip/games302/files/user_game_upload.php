<?php


$page = "user_game_upload";
include "header.php";

$task = rc_toolkit::get_request('task','create');
$game_id = rc_toolkit::get_request('game_id');


// ENSURE GAME IS ENABLED FOR THIS USER
if( ~(int)$user->level_info['level_game_allow'] & 3 ) {
  rc_toolkit::redirect("user_home.php");
}

if ($task == 'photo' && !$user->level_info['level_game_photo']){
  rc_toolkit::redirect("user_home.php");
}

// CREATE GAME OBJECT
$game = new se_game($user->user_info['user_id'], $game_id);
$total_games = $game->game_total();
if($total_games >= $user->level_info['level_game_maxnum']) { $task = "main"; }

// GET PRIVACY SETTINGS
$level_game_privacy = unserialize($user->level_info['level_game_privacy']);
rsort($level_game_privacy);
$level_game_comments = unserialize($user->level_info['level_game_comments']);
rsort($level_game_comments);


// SET RESULT AND ERROR VARS
$result = FALSE;
$is_error = 0;
$show_uploader = 1;
$file_result = array();
$max_uploads = 1;

// Init default values
if( $task=="create" )
{
  $game->game_info = array(
    'game_title' => "",
    'game_desc' => "",
    'game_instruction' => "",
    'game_credit' => "",
    'game_search' => TRUE,
    'game_privacy' => $level_game_privacy[0],
    'game_comments' => $level_game_comments[0]
  );
}
//rc_toolkit::debug($game->game_info);
//rc_toolkit::debug($game->game_dir($game->game_info['game_id']),$game->game_info['game_id']);

// UPLOAD FILES
if( $task=="docreate" )
{
  $game->game_info['game_gamecat_id'] = $_POST['game_gamecat_id'];
  $game->game_info['game_title']     = censor($_POST['game_title']);
  $game->game_info['game_desc']      = censor(str_replace("\r\n", "<br>", $_POST['game_desc']));
  $game->game_info['game_instruction'] = censor(str_replace("\r\n", "<br>", $_POST['game_instruction']));
  $game->game_info['game_credit'] = censor(str_replace("\r\n", "<br>", $_POST['game_credit']));
  $game->game_info['game_width']    = $_POST['game_width'];
  $game->game_info['game_height']   = $_POST['game_height'];
  $game->game_info['game_search']    = $_POST['game_search'];
  $game->game_info['game_privacy']   = $_POST['game_privacy'];
  $game->game_info['game_comments']  = $_POST['game_comments'];
  
  if( !$user->level_info['level_game_search'] ) $game->game_info['game_search'] = TRUE;
  
  // MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
  if(!in_array($game_privacy, $level_game_privacy)) { $game_privacy = $level_game_privacy[0]; }
  if(!in_array($game_comments, $level_game_comments)) { $game_comments = $level_game_comments[0]; }
  
  if( !$user->level_info['level_game_search'] ) {
    $game->game_info['game_search'] = 1;
  }
  
  $result = $game->game_edit($game->game_info);

  if ((is_array($result) && isset($result['is_error'])) || $result === false) {
    $task = "create";
    $is_error = $result['is_error'];
  }
  else {
    $url = "user_game_upload.php?task=upload&game_id=".$game->game_info['game_id'];
    rc_toolkit::redirect($url);
  }
}

elseif( $task=="doupload" )
{
  $type = rc_toolkit::get_request('type','file');
  if ($type == 'photo') {
    $method = 'game_photo_upload';
  }
  else {
    $method = 'game_upload';  
  }
  
  $isAjax = $_POST['isAjax'];
  $file_result = Array();

  // WORKAROUND FOR FLASH UPLOADER
  if($_FILES['file1']['type'] == "application/octet-stream" && $isAjax)
  { 
    $file_types = explode(",", str_replace(" ", "", strtolower("image/jpeg, image/jpg, image/jpe, image/pjpeg, image/pjpg, image/x-jpeg, x-jpg, image/gif, image/x-gif, image/png, image/x-png")));
    $_FILES['file1']['type'] = $file_types[0];
  }
  
  for( $f=1; $f<=$max_uploads; $f++ )
  {
    $fileid = "file".$f;
    if( empty($_FILES[$fileid]['name']))
      continue;
    
    $file_result[$fileid] = $game->$method("file1");
    $file_result[$fileid]['file_name'] = $file_result[$fileid]['name'] = $_FILES[$fileid]['name'];
    
    if( !$file_result[$fileid]['is_error'] )
    {
      $file_result[$fileid]['message'] = 1000086;
      $result = TRUE;
    }
    else
    {
      $file_result[$fileid]['message'] = $file_result[$fileid]['is_error'];
    }
    SE_Language::_preload($file_result[$fileid]['message']);
  }

  // OUTPUT JSON RESULT
  if( $isAjax )
  {
    SE_Language::load();
    
    if( $result )
    {
      $result = "success"; 
      $size = sprintf(SE_Language::_get($file_result['file1']['message']), $file_result['file1']['name']);
      $error = null; 
    }
    else
    {
      $result = "failure";
      $error = sprintf(SE_Language::_get($file_result['file1']['message']), $file_result['file1']['name']);
      $size = null;
    }
    if(!headers_sent()) { header('Content-type: application/json'); }
    echo json_encode(array('result' => $result, 'error' => $error, 'size' => $size));
    exit();
  }
  
  // SHOW PAGE WITH RESULTS
  else
  {
    $show_uploader = FALSE;
  }
  
  
  if( !$file_result['file1']['is_error'] )
  {
    $url = "user_game_upload.php?task=complete&game_id=".$game->game_info['game_id'];
    rc_toolkit::redirect($url);
  }
  
  else
  {
    if ($type == 'photo') {
      $task = "photo";
    }
    else {
      $task = "upload";
    }    
    
    $is_error = $file_result['file1']['is_error'];
  }
}



// DO CREATE PAGE STUFF
if( $task=="create" )
{
  // GET PREVIOUS PRIVACY SETTINGS
  for($c=0;$c<count($level_game_privacy);$c++) {
    if(user_privacy_levels($level_game_privacy[$c]) != "") {
      SE_Language::_preload(user_privacy_levels($level_game_privacy[$c]));
      $privacy_options[$level_game_privacy[$c]] = user_privacy_levels($level_game_privacy[$c]);
    }
  }

  for($c=0;$c<count($level_game_comments);$c++) {
    if(user_privacy_levels($level_game_comments[$c]) != "") {
      SE_Language::_preload(user_privacy_levels($level_game_comments[$c]));
      $comment_options[$level_game_comments[$c]] = user_privacy_levels($level_game_comments[$c]);
    }
  }
  
  $smarty->assign('total_games', $total_games);
  
  $game->game_info['game_desc'] = str_replace("<br>", "\r\n", $game->game_info['game_desc']);
  $game->game_info['game_instruction'] = str_replace("<br>", "\r\n", $game->game_info['game_instruction']);
  $game->game_info['game_credit'] = str_replace("<br>", "\r\n", $game->game_info['game_credit']);
  
  $smarty->assign('privacy_options', $privacy_options);
  $smarty->assign('comment_options', $comment_options);
}





// DO UPLOAD PAGE STUFF
if( $task=="upload" || $task=="photo")
{  
	
  if ($type == 'photo' || $task=="photo") {
    $file_exts = $user->level_info['level_game_photo_exts'];
    $type = 'photo';
  }
  else {
    $file_exts = $setting[setting_game_exts];
  }
  $file_exts = str_replace(" ","",$file_exts);
  
  // GET MAX FILESIZE ALLOWED
  $max_filesize_kb = ($user->level_info['level_game_maxsize']) / 1024;
  $max_filesize_kb = round($max_filesize_kb, 0);
  
  
  // START NEW SESSION AND SET SESSION VARS FOR UPLOADER
  
  // Backwards compatibility with <SE3.10
  if( !session_id() )
  {
    session_start();
    $_SESSION['ul_user_id'] = $_COOKIE['user_id'];
    $_SESSION['ul_user_email'] = $_COOKIE['user_email'];
    $_SESSION['ul_user_password'] = $_COOKIE['se_user_pass'];
  }

  // Keep with 3.10+
  $_SESSION['upload_token'] = md5(uniqid(rand(), true));
  $_SESSION['action'] = "user_game_upload.php";
  
  // SET INPUTS
  $inputs = Array('game_id' => $game->game_info['game_id'], 'task' => 'doupload', 'type' => $type);

  $smarty->assign('show_uploader', $show_uploader);
  $smarty->assign('session_id', session_id());
  $smarty->assign('upload_token', $_SESSION['upload_token']);
  $smarty->assign('file_result', $file_result);
  $smarty->assign('inputs', $inputs);
  $smarty->assign('allowed_exts', str_replace(",", ", ", $file_exts));
  $smarty->assign('max_filesize', $max_filesize_kb);
  
  // SET UPLOADER PARAMS
  $smarty->assign('user_upload_max_files', 1);
  $smarty->assign('user_upload_max_size', $user->level_info['level_game_maxsize']);
  $smarty->assign('user_upload_allowed_extensions', $file_exts);
}

$gamecats_array = $game->game_category_list($user->user_info['user_id']);
$smarty->assign('gamecats', $gamecats_array);

//rc_toolkit::debug($gamecats_array);

// ASSIGN VARIABLES AND SHOW UPLOAD FILES PAGE
$smarty->assign('is_error', $is_error);
$smarty->assign('task', $task);
$smarty->assign('type', $type);
$smarty->assign_by_ref('game', $game);
include "footer.php";
?>