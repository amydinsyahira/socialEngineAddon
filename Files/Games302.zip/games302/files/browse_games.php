<?php


$page = "browse_games";
include "header.php";

//rc_toolkit::debug($user);

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if( (!$user->user_exists && !$setting['setting_permission_game']) || ($user->user_exists && (1 & ~(int)$user->level_info['level_game_allow'])) )
{
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

$p = rc_toolkit::get_request('p', 1);
$s = rc_toolkit::get_request('s', 'game_datecreated DESC');
$v = rc_toolkit::get_request('v', 0);
$gamecat_id = rc_toolkit::get_request('gamecat_id');
$keyword = rc_toolkit::get_request('keyword');

if (!in_array($s, array("game_datecreated DESC","game_views DESC","game_cache_rating_weighted DESC")))
{
  $s = "game_dateupdated DESC";
}

if($v != "0" && $v != "1") { $v = 0; }



// CREATE GAME OBJECT
$game = new se_game();

// SET WHERE CLAUSE
$where = "game_search='1' AND game_uploaded='1' AND
	(CASE
	    WHEN se_games.game_user_id='{$user->user_info['user_id']}'
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_REGISTERED) AND '{$user->user_exists}'<>0)
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_ANONYMOUS) AND '{$user->user_exists}'=0)
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_games.game_user_id AND friend_user_id2='{$user->user_info['user_id']}' AND friend_status='1' LIMIT 1))
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_SUBNET) AND '{$user->user_exists}'<>0 AND (SELECT TRUE FROM se_users WHERE user_id=se_games.game_user_id AND user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM se_friends AS friends_primary LEFT JOIN se_users ON friends_primary.friend_user_id1=se_users.user_id LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE friends_primary.friend_user_id1=se_games.game_user_id AND friends_secondary.friend_user_id2='{$user->user_info['user_id']}' AND se_users.user_subnet_id='{$user->user_info['user_subnet_id']}' LIMIT 1))
	      THEN TRUE
	    ELSE FALSE
	END)";


// ONLY MY FRIENDS' GAMES
if($v == "1" && $user->user_exists) {

  // SET WHERE CLAUSE
  $where .= " AND (SELECT TRUE FROM se_friends WHERE friend_user_id1='{$user->user_info['user_id']}' AND friend_user_id2=se_games.game_user_id AND friend_status=1)";

}

$gamecat_languagevar_id = null;
$gamecats_array = $game->game_category_list();

$gamecat_ids = array();
foreach ($gamecats_array as $k=>$vc) {
  $gamecat_ids[$vc['gamecat_id']] = $vc['gamecat_languagevar_id'];
}

$gamecats_array[] = array(
  'gamecat_id' => -1,
  'gamecat_user_id' => 0,
  'gamecat_title' => 'Uncategorized',
  'gamecat_languagevar_id' => 11231032,
  'gamecat_parentcat_id' => 0,
);

if ($gamecat_id == -1) {
  $gamecat_languagevar_id = 11231032;
  $where .= " AND game_gamecat_id NOT IN ('".join("','", array_keys($gamecat_ids))."')";
}
elseif (array_key_exists($gamecat_id, $gamecat_ids)) {
  $gamecat_languagevar_id = $gamecat_ids[$gamecat_id];
  $where .= " AND game_gamecat_id='$gamecat_id'";
}
else {
  $gamecat_id = '';
}

if (strlen($keyword)) {
  $where .= " AND (game_title LIKE '%$keyword%' OR game_desc LIKE '%$keyword%')";
}

// GET TOTAL GAMES
$total_games = $game->game_total($where);

// MAKE ENTRY PAGES
$games_per_page = 30;
$page_vars = make_page($total_games, $games_per_page, $p);

// GET GAME ARRAY
$game_array = $game->game_list($page_vars[0], $games_per_page, $s, $where, 1);


//rc_toolkit::debug($gamecats_array);

$featured_games = featured_games(4);
$smarty->assign_by_ref('featured_games', $featured_games);


//rc_toolkit::debug($gamecats_array);

// ASSIGN SMARTY VARIABLES AND DISPLAY GAMES PAGE
$smarty->assign('gamecats', $gamecats_array);

$smarty->assign('keyword', $keyword);
$smarty->assign('gamecat_languagevar_id', $gamecat_languagevar_id);
$smarty->assign('gamecat_id', $gamecat_id);
$smarty->assign('games', $game_array);
$smarty->assign('total_games', $total_games);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($game_array));
$smarty->assign('s', $s);
$smarty->assign('v', $v);
include "footer.php";
?>