<?php
require_once("pagerank_lib.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Pagerank lib test page</title>
</head>

<body>
<form id="form1" name="form1" method="get" action="pagerank_lib.example.php">
  URL : 
  <input name="url" type="text" id="url" value="<?php echo $_REQUEST['url']; ?>" />
  <input type="submit" name="Submit" value="Submit" />
</form>
<?php
if ((isset($_REQUEST['Submit'])) && ($_REQUEST['url']!='')) {
?>
<fieldset>
<legend>Query result</legend>
<?php
$url=$_REQUEST['url'];

echo "Technorati rank = ".get_technorati_rank($url, "ee470f3fa8571bc7bc83eddaa35ae153")."<br />";
echo "Technorati inblogs(authority) = ".$techno_inblogs."<br />";
echo "Technorati inlinks = ".$techno_inlinks."<br />";
echo "Technorati last update = ".$techno_update."<br />";
echo "Google pagerank = ".getpagerank($url)."<br />";
echo "Alexa popularity = ".get_alexa_popularity($url)."<br />";
echo "Alexa backlink = ".alexa_backlink($url)."<br />";
echo "Google backlink = ".google_backlink($url)."<br />";
echo "Yahoo inlink = ".yahoo_inlink($url)."<br />";
echo "Google indexed = ".google_indexed($url)."<br />";
echo "Yahoo indexed = ".yahoo_indexed($url)."<br />";
echo "MSN indexed = ".msn_indexed($url)."<br />";
echo "AllTheWeb result = ".alltheweb_link($url)."<br />";
echo "Altavista result = ".altavista_link($url)."<br />";
echo "Exactrank = ".get_exactrank($url)."<br />";
echo "Googlebot last access = ".googlebot_lastaccess($url)."<br />";
echo "Blogworth = ".blogworth($url)."<br />";
echo "Listed in DMOZ ? ".dmoz_listed($url)."<br />";
?>
</fieldset>
<?php
};
?>
</body>
</html>
