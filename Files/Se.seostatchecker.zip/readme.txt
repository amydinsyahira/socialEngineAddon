Seo StatChecker By: Ilan Patao (ilan@dangerstudio.com)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

An easy plugin to your SocialEngine Administration page to easily search your server ranking stats on major search engines such as Google, Yahoo, MSN, Alexa, etc. Very useful tool for people demanding viewing results of their SEO campeign for SocialEngine on the fly.



Seo StatChecker Installation:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Installation Time: 2 minutes.

Unzip the files containing the 'Admin' and 'Templates' directories; using any FTP client simply upload the two directories into your SE root folder; you will be prompted to replace one file which will update the admin menu with the icon and menu link to the SEO StatCheker; confirm the upload and you're done!