<frameset rows="*,145" framespacing="0" frameborder="no" border="0">
<frame src="./wc.php" name="Webchat_Frame" scrolling="NO" noresize>
<frame src="http://clk.tradedoubler.com/click?p=1699&a=1586087&g=16888090" name="Ad_Frame" scrolling="NO" noresize>
</frameset>
