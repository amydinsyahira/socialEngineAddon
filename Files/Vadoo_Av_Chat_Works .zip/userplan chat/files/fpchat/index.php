<!-- //this plugin was devoloped by Alex Misiyuk - founder of Vadoo! 
 -->

<html>
<head>
	<title>Example Webchat Page</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	<script language="javascript">
	<!--
		function up_launchChat()
		{
			window.open( "index_frames.php", "UserplaneChatWindow", "width=700,height=500,toolbar=0,directories=0,menubar=0,status=0,location=0,scrollbars=0,resizable=1" );
		}
	//-->
	</script>
</head>

<body>
	<h3>Chat:</h3>

	<a href="" onClick="javascript: up_launchChat(); return false;">Launch Webchat</a><br>
		


</body>
</html>
