<?php

//this plugin was devoloped by Alex Misiyuk - founder of Vadoo! 

session_start();

$page = "chat";
//$page = "home";


include "header.php";
//include "include/class_chat.php";


	// Get all user's data.
$sUsername = $user->user_displayname_short;
$sFName = $user->user_info[user_fname];
$sLName = $user->user_info[user_lname];
$sBirthday = $user->profile_info[profilevalue_4];
$sGender = $user->profile_info[profilevalue_5];
$iUserID = $user->user_info[user_id];


//$photoURL = "http://vadoo.org/uploads_user/1000/1/".$user->user_info[user_photo];
$photoURL = $user->user_info[user_photo];


$sProfileStr = $sUsername."|".$sFName."|".$sLName."|".$sBirthday."|".$sGender."|".$photoURL."|".$iUserID;

$_SESSION['mUsername'] = $sProfileStr;


// REDIRECT IF USER IS NOT LOGGED IN OR USER IS NOT ALLOWED TO CHAT
if( !$user->user_exists || !$user->level_info['level_chat_allow'] )
{
  cheader('home.php');
  exit();
}



include "footer.php";
?>