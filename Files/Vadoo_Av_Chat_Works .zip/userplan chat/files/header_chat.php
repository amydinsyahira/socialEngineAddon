<?php

//this plugin was devoloped by Alex Misiyuk - founder of Vadoo! 

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// SET MAIN MENU VARS
$plugin_vars['menu_main'] = "";

// SET USER MENU VARS
if( $user->level_info['level_chat_allow'] )
{
  SE_Language::_preload(3500025);
  $plugin_vars['menu_user'] = Array('file' => 'chat.php', 'icon' => 'chat_chat16.gif', 'title' => 3500025);
}

?>