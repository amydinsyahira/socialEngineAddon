<?php
// ######################## SET PHP ENVIRONMENT ###########################
error_reporting(E_ALL & ~E_NOTICE);
define('THIS_SCRIPT', 'fbconnect_datamap');

// #################### PRE-CACHE TEMPLATES AND DATA ######################
$phrasegroups = array('fbconnect', 'cprofilefield');

$specialtemplates = array();

// ########################## REQUIRE BACK-END ############################
require_once('./global.php');
require_once(DIR . '/includes/facebook/facebook.php');
require_once(DIR . '/includes/functions_fbconnect.php');

print_cp_header($vbphrase['map_facebook_data']);

//if (!$vbulletin->options['fbconnect_importdata'])
	//print_cp_message($vbphrase['data_import_is_off']); 
	
$vbdata = array();
$profile_fields = $db->query_read("
	SHOW COLUMNS
	FROM " . TABLE_PREFIX . "userfield  
");			

$exclude = array('userid', 'temp');
while ($field = $db->fetch_array($profile_fields))
{
	if (!in_array($field['Field'], $exclude))
		$vbdata[$field['Field']] = $vbphrase[$field['Field'] . '_title'];
}
$vbdata['profilepicurl'] = 'Profile Picture';
$vbdata['avatarurl'] = 'Avatar';

$fbdata = array(
	'uid' => 'Facebook UID',
	'name' => 'Name', 
	'first_name' => 'First Name', 
	'last_name' => 'Last Name', 
	'affiliations' => 'Location', 
	'profile_url' => 'Facebook Profile URL',
	'pic' => 'Profile Picture (Max: 100 x 300)px',
	'pic_small' => 'Small Profile Picture (Max: 50 x 150)px',
	'pic_square' => 'Square Profile Picture (Max: 50 x 50)px',
	'profile_url' => 'Facebook Profile URL'
);

if ($_GET['do'] == 'delete')
{
	$vbulletin->input->clean_array_gpc('g', array(
		'vbfield'            => TYPE_STR
	));
	
	$db->query_write("
		DELETE FROM " . TABLE_PREFIX . "fbdatamap		
		WHERE vbfield = '".$db->escape_string($vbulletin->GPC['vbfield'])."'");	
		
	print_cp_message($vbphrase['field_map_deleted'], 'fbconnect_datamap.php');
}

if ($_POST['do'] == 'save')
{
	for ($i = 0; $i < count($_POST['vbfield']); $i++)
	{
		if ($_POST['vbfield'][$i] && $_POST['fbfield'][$i])
		{
			$db->query_write("
				INSERT INTO " . TABLE_PREFIX . "fbdatamap
				(vbfield, fbfield) VALUES ('".$db->escape_string($_POST['vbfield'][$i])."', '".$db->escape_string($_POST['fbfield'][$i])."')
				ON DUPLICATE KEY UPDATE fbfield = '".$db->escape_string($_POST['fbfield'][$i])."'");
		}	
	}
	
	print_cp_message($vbphrase['datamap_updated'], 'fbconnect_datamap.php');
}

print_form_header('fbconnect_datamap', 'save');
print_table_start();
print_table_header($vbphrase['map_facebook_data'], 3);
if (!$vbulletin->options['fbconnect_importdata'])
	print_description_row('<center>' . $vbphrase['data_import_is_off'] . '</center>', 0, 3, 'thead');

echo '<tr><td class="tfoot" align="center"><b>vBulletin Field</b></td><td class="tfoot" align="center"><b>Facebook Field</b></td><td class="tfoot"></td></tr>';
//print_label_row('vBulletin User Profile Field', 'Facebook User Profile Field', '', 3);

$profile_fields = $db->query_read("
	SELECT *
	FROM " . TABLE_PREFIX . "fbdatamap
");

while ($field = $db->fetch_array($profile_fields))
{
	print_datamap_row($vbdata, $fbdata, $field['vbfield'], $field['fbfield']);
}

print_datamap_row($vbdata, $fbdata);

print_submit_row("Save!", '', 3);  
print_table_footer(3, '', '', 0);  

print_cp_footer();
