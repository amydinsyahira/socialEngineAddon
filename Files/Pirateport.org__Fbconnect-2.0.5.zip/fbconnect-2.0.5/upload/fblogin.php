<?
// ####################### SET PHP ENVIRONMENT ###########################
error_reporting(E_ALL & ~E_NOTICE);

// #################### DEFINE IMPORTANT CONSTANTS #######################
define('THIS_SCRIPT', 'fblogin');
define('CSRF_PROTECTION', true);
define('CSRF_SKIP_LIST', 'fblogin');

// ################### PRE-CACHE TEMPLATES AND DATA ######################
// get special phrase groups
$phrasegroups = array('fbconnect', 'register', 'user');

// get special data templates from the datastore
$specialtemplates = array();

// pre-cache templates used by all actions
$globaltemplates = array();

// pre-cache templates used by specific actions
$actiontemplates = array();

// ######################### REQUIRE BACK-END ############################
require_once('./global.php');
require_once('./includes/facebook/facebook.php');
require_once('./includes/functions_fbconnect.php');
require_once(DIR . '/includes/functions_login.php');

if ($vbulletin->facebook == null)
	$vbulletin->facebook = new Facebook($vbulletin->options['fbconnect_apikey'], $vbulletin->options['fbconnect_secret']);
	
$facebook = $vbulletin->facebook;

$fbuid = intval($vbulletin->facebook->get_loggedin_user());

if ($fbuid > 0)
{
	$vbuser = $db->query_first("
			SELECT userid
			FROM " . TABLE_PREFIX . "fbuser AS fbuser
			WHERE fbuid = " . $fbuid . "
			LIMIT 1
		");
		
	if ($vbuser['userid'])
	{				
		$vbulletin->userinfo = $vbulletin->db->query_first("SELECT userid, usergroupid, membergroupids, infractiongroupids, username, password, salt FROM " . TABLE_PREFIX . "user WHERE userid = '" . $vbuser['userid'] . "'");
		if ($vbulletin->userinfo['username'])
		{			
			//set coockies
			vbsetcookie('userid', $vbulletin->userinfo['userid'], true, true, true);
			vbsetcookie('password', md5($vbulletin->userinfo['password'] . COOKIE_SALT), true, true, true);
			
			//login vb user	
			process_new_login('', true, '');
			$path_parts = pathinfo(parse_url($vbulletin->url, PHP_URL_PATH));
			if ($path_parts['basename'] == 'fblogin.php')
				$vbulletin->url = $vbulletin->options['forumhome'] . '.php';
				
			// do redirect
			if (!is_array($vbphrase))
				$vbphrase = array();
				
		    do_login_redirect();
		}
		else
		{
			$db->query_write("DELETE FROM " . TABLE_PREFIX . "fbuser WHERE fbuid = $fbuid");
			$templatename = 'fbconnect_login';	
		}
	}
	else
	{
		//request username to create a new vb user
		$templatename = 'fbconnect_login';		
	}
}
else
{
	eval(standard_error(fetch_error('badlogin', $vbulletin->options['bburl'], $vbulletin->session->vars['sessionurl'])));
}

if ($_GET['do'] == 'login')
{
	$templatename = 'fbconnect_loginform';
}

if ($_POST['do'] == 'addmember')
{	
	$vbulletin->input->clean_array_gpc('p', array(
		'username'            => TYPE_STR
	));
	
	if (!$vbulletin->options['allowregistration'])
	{
		eval(standard_error(fetch_error('noregister')));
	}
	
	$fbuserinfo = $facebook->api_client->users_getInfo($fbuid, array('proxied_email'));
	$fbuserinfo = $fbuserinfo[0];

	
	// init user datamanager class
	$userdata =& datamanager_init('User', $vbulletin, ERRTYPE_ARRAY);
	
	if ($vbulletin->options['moderatenewmembers'])
	{
		$newusergroupid = 4;
	}
	else
	{
		$newusergroupid = ((intval($vbulletin->options['fbconnect_defaultgroup']) > 0) ? $vbulletin->options['fbconnect_defaultgroup'] : 2);
	}
	
	$userdata->set('username', $vbulletin->GPC['username']);	
	
	//generate random password
	$userdata->set('password', generate_password());
	
	// set usergroupid
	$userdata->set('usergroupid', $newusergroupid);

	// set languageid
	$userdata->set('languageid', $vbulletin->userinfo['languageid']);

	// set user title
	$userdata->set_usertitle('', false, $vbulletin->usergroupcache["$newusergroupid"], false, false);
	
	// register IP address
	$userdata->set('ipaddress', IPADDRESS);
	
	$userdata->pre_save();
	
	// check for errors
	if (!empty($userdata->errors))
	{
		$_REQUEST['do'] = 'register';

		$errorlist = '';
		foreach ($userdata->errors AS $index => $error)
		{
			$errorlist .= "<li>$error</li>";
		}

		$username = htmlspecialchars_uni($vbulletin->GPC['username']);
		$show['errors'] = true;
	}
	else
	{
		$show['errors'] = false;
		
		$userdata->set('email', $fbuserinfo['proxied_email']);

		// save the data
		$vbulletin->userinfo['userid']
			= $userid
			= $userdata->save();

		if ($userid)
		{
			//map fbuser to vbuser
			$db->query_write("
				INSERT IGNORE INTO " . TABLE_PREFIX . "fbuser
					(fbuid, userid)
				VALUES
					(" . $fbuid . ", " . intval($userid) . ")
			");
			
			$friendcount = 0;
			if ($vbulletin->options['fbconnect_importfriends'])
			{
				//find friends and add to friend's list							
				$friends = $facebook->api_client->friends_get();
				if (is_array($friends) && count($friends) > 0)
				{			
					$vbfriends = $db->query_read("
						SELECT user.userid
						FROM " . TABLE_PREFIX . "user AS user, " . TABLE_PREFIX . "fbuser AS fbuser
						WHERE fbuser.fbuid IN (" . implode(',', $friends) . ") AND user.userid = fbuser.userid 
					");			
				
				
					while ($friend = $db->fetch_array($vbfriends))
					{
						$db->query_write("
							INSERT IGNORE INTO " . TABLE_PREFIX . "userlist
							(userid, relationid, type, friend)
								VALUES
							(" . intval($userid) . ", " . $friend['userid']  . ", 'buddy', 'yes')
						");
						
						$friendcount++;
					}
				
				}
			}
			
			$vbulletin->userinfo['fbuid'] = $userid;
		
			$userinfo = fetch_userinfo($userid);
			$userdata_rank =& datamanager_init('User', $vbulletin, ERRTYPE_SILENT);
			$userdata_rank->set_existing($userinfo);
			$userdata_rank->set('posts', 0);
			$userdata_rank->set('friendcount', $friendcount);
			$userdata_rank->save();

			// force a new session to prevent potential issues with guests from the same IP, see bug #2459
			require_once(DIR . '/includes/functions_login.php');
			$vbulletin->session->created = false;				
			process_new_login('', false, '');
			
			//post news-feed
			/*
			if ($vbulletin->options['fbconnect_firstlogintemplateid'])
			{
				$tokens = array( 
			        'bbtitle' => $vbulletin->options['bbtitle'], 
					'bburl' => $vbulletin->options['bburl'], 
					'images' => array() 
				);	
				
				try
			    {
			        $vbulletin->facebook->api_client->feed_publishUserAction($vbulletin->options['fbconnect_firstlogintemplateid'], $tokens, '', '', 1);
			    }
			    catch(FacebookRestClientException $ex)
			    {

				}
			}
			*/
				
			$username = $vbulletin->GPC['username'];
			$email = $fbuserinfo['proxied_email'];
								
			// send new user email
			if ($vbulletin->options['newuseremail'] != '')
			{								
				$ipaddress = IPADDRESS;

				eval(fetch_email_phrases('newuser', 0));

				$newemails = explode(' ', $vbulletin->options['newuseremail']);
				foreach ($newemails AS $toemail)
				{
					if (trim($toemail))
					{
						vbmail($toemail, $subject, $message);
					}
				}
			}
			
			if ($newusergroupid == 2)
			{
				if ($vbulletin->options['welcomemail'])
				{
					eval(fetch_email_phrases('welcomemail'));
					vbmail($email, $subject, $message);
				}
			}
			
			$vbulletin->url = str_replace('"', '', $vbulletin->url);
			if (!$vbulletin->url)
			{
				$vbulletin->url = $vbulletin->options['forumhome'] . '.php' . $vbulletin->session->vars['sessionurl_q'];
			}
			else
			{
				$vbulletin->url = iif(strpos($vbulletin->url, 'register.php') !== false, $vbulletin->options['forumhome'] . '.php' . $vbulletin->session->vars['sessionurl_q'], $vbulletin->url);
			}

			if ($vbulletin->options['moderatenewmembers'])
			{
				eval(standard_error(fetch_error('moderateuser', $username, $vbulletin->options['forumhome'], $vbulletin->session->vars['sessionurl_q']), '', false));
			}
			else
			{
				eval(standard_error(fetch_error('registration_complete', $username, $vbulletin->session->vars['sessionurl'], $vbulletin->options['bburl'] . '/' . $vbulletin->options['forumhome'] . '.php'), '', false));
			}
		}
	}
}

eval('print_output("' . fetch_template($templatename) . '");');