<?php

/* $Id: fbconnect_register_create.php 1 2009-07-04 09:36:11Z SocialEngineAddOns $ */

$page = "fbconnect_register_create";
include "header.php";
if(isset($_POST['task'])) { 
	$task = $_POST['task'];
}
else {
	$task = "step1";
}

// SET ERROR VARS
$is_error = 0;

// IF USER IS ALREADY LOGGED IN, FORWARD TO USER HOME PAGE
if($user->user_exists != 0) { header("Location: user_home.php"); exit(); }

if($signup_logged_in != 1) {
  setcookie("signup_id", "", 0, "/");
  setcookie("signup_email", "", 0, "/");
  setcookie("signup_password", "", 0, "/");
  $_COOKIE['signup_id'] = "";
  $_COOKIE['signup_email'] = "";
  $_COOKIE['signup_password'] = "";
  $new_user = new se_user();
  if($task == "step1") { 
    if(isset($_GET['signup_email'])) { $signup_email = $_GET['signup_email']; } else { $signup_email = ""; }
    if(isset($_GET['signup_invite'])) { $signup_invite = $_GET['signup_invite']; } 
    $signup_password = ""; 
    $signup_timezone = $setting['setting_timezone'];
  }
}

if (!empty($fbconnect_setting['signup_setting'])) { // Inherit the website's signup process
		
	// PROCESS INPUT FROM FIRST STEP (OR DOUBLE CHECK VALUES), CONTINUE TO SECOND STEP (OR SECOND STEP PROCESSING)
	if($task == "step1do" || $task == "step2do") { 
	  $signup_email = $_POST['signup_email'];
	  if (!empty($_POST['signup_password'])) {
	    $signup_password = $_POST['signup_password'];
	  } else {
	  	$signup_password =  generate_random_user_password();
	  }
	  $signup_password2 = $signup_password;
	  $step = $_POST['step'];
	    if($task == "step2do" && $step != "1") {
	      $signup_password = base64_decode($signup_password);
	      $signup_password2 = base64_decode($signup_password2);
	    }
	  $signup_username = $_POST['signup_username'];
	  $signup_timezone = $_POST['signup_timezone'];
	  $signup_invite = $_POST['signup_invite'];
	  $signup_cat = $_POST['signup_cat'];
	
	  // GET LANGUAGE PACK SELECTION
	  if($setting[setting_lang_allow] != 1) { $signup_lang = 0; } else { $signup_lang = $_POST['signup_lang']; }
	
	  // TEMPORARILY SET PASSWORD IF RANDOM PASSWORD ENABLED
	  if($setting[setting_signup_randpass] != 0) {
	    $signup_password = "temporary";
	    $signup_password2 = "temporary";
	  }
	
	  // CHECK USER ERRORS
	  $new_user->user_password('', $signup_password, $signup_password2, 0);
	  $new_user->user_account($signup_email, $signup_username);
	  $is_error = $new_user->is_error;
	
	  // CHECK TERMS OF SERVICE AGREEMENT IF NECESSARY
	  if($setting[setting_signup_tos] != 0) {
	    $signup_agree = $_POST['signup_agree'];
	    if($signup_agree != 1) {
	      $is_error = 707;
	    }
	  }
	
    // IF THERE IS NO ERROR, CONTINUE TO STEP 2 OR PROCESS STEP 2
	  if($is_error == 0) {
	    // ONLY IF ON STEP ONE, CONTINUE TO STEP 2 - ELSE GO TO PROCESSING STEP 2
	    if($task == "step1do") { $task = "step2"; }
	
	  // IF THERE WAS AN ERROR, GO BACK TO STEP 1
	  } else {
	    $task = "step1";
	  }
	
	}
	
	if($task == "step1" || $task == "step1do" || $task == "step2" || $task == "step2do") {
	  if($database->database_num_rows($database->database_query("SELECT NULL FROM se_profilecats WHERE profilecat_id='$signup_cat' AND profilecat_dependency='0'")) != 1) {
	    $cat_info = $database->database_fetch_assoc($database->database_query("SELECT profilecat_id FROM se_profilecats WHERE profilecat_dependency='0' ORDER BY profilecat_order LIMIT 1"));
	    $signup_cat = $cat_info[profilecat_id];
	  }
	  if($task == "step2do") { $validate = 1; } else { $validate = 0; }
	  if($task != "step1") { $cat_where = "profilecat_signup='1' AND profilecat_id='$signup_cat'"; } else { $cat_where = "profilecat_signup='1'"; }
	  $field = new se_field("profile");
	  $field->cat_list($validate, 0, 0, $cat_where, "", "profilefield_signup='1'");
	  $cat_array = $field->cats;
	  if ($field->cats[0]['subcats'][0]['fields'][0]['field_title'] == 500370 && empty($field->cats[0]['subcats'][0]['fields'][0]['field_value'])) {
		  $field->cats[0]['subcats'][0]['fields'][0]['field_value']	=  fbconnect_get_first_name();
	  }
	  if ($field->cats[0]['subcats'][0]['fields'][1]['field_title'] == 500373 && empty($field->cats[0]['subcats'][0]['fields'][1]['field_value'])) {
		  $field->cats[0]['subcats'][0]['fields'][1]['field_value']	=  fbconnect_get_last_name();
	  }
	  if($task != "step1" && count($cat_array) == 0) { $task = "step1"; }
	  if($validate == 1) { $is_error = $field->is_error; }
	  if($task != "step1" && count($field->fields_all) == 0) { $task = "step2do"; }
	}
	
  if($task == "step2do") {	
	  // PROFILE FIELD INPUTS PROCESSED AND CHECKED FOR ERRORS ABOVE
	  // IF THERE IS NO ERROR, ADD USER AND USER PROFILE AND CONTINUE TO STEP 3
	  if($is_error == 0) {
	    $new_user->user_create($signup_email, $signup_username, $signup_password, $signup_timezone, $signup_lang, $signup_cat, $field->field_query);
	    
	    // Beucase user is signup through Facebook connect so no need to verifty the email id of user
	     $database->database_query("UPDATE se_users SET user_verified='1' WHERE user_id='{$new_user->user_info[user_id]}' LIMIT 1");
	    // Enter the user's info in FB Connect tables
	    $fbuid = fbconnect_get_fbuid();
	    fbconnect_register($new_user->user_info[user_id], $fbuid, $_SESSION['fbconnect_visibility']);
	    
	    update_stats("signups");

	    
	    if ($_SESSION['fb_reg_import']) {
	      // Saving import settings.
	      $fbusersettings_import = fbconnect_set_user_fbinfo($new_user->user_info[user_id], $_SESSION['fb_reg_import']);
	//      if ($fbusersettings_import != 'successful') {    // Todo : Set message here for unsuccessful import
	//      	
	//      }
	      unset($_SESSION['fb_reg_import']);
	    }
	    
	    $fbconnect_visibility = $_SESSION['fbconnect_visibility'];
	    unset($_SESSION['fbconnect_visibility']);
	
	    /***************************************LOGIN THE USER OVER HERE **********************************************************/
	    $user = new SEUser(Array($new_user->user_info[user_id]));
	    $user->user_setcookies();
	
	   // If the user chose to be visible, and the registration feed parameter is enabled.
	   // We store a value in the session variable, 
	   // this variable will be read by the fbconnect_output_js function.
	   if(  $fbconnect_setting['reg_feed'] && $fbconnect_visibility) {
	     $session_object =& SESession::getInstance();
			 $session_object->set('fbconnect_feed', array(
        'type' => 'registration'
	      ));
	   }
	
	    // OR TO USER FB INVITE, We are taking fb invite step 6
			$task = "step6";
	
	 } else {
	    $task = "step2";
	  }
	}
	
	
	
	// SHOW SECOND STEP
	if($task == "step6") {
	  $step = 6;
		$signup_invite_form = fbconnect_output_friends_invite_form();
	}
	
	
	// SHOW SECOND STEP
	if($task == "step2") {
	  $step = 2;
	  $next_task = "step2do";
	  if(count($field->cats) == 0) { $task = "step1"; }
	  $signup_password = base64_encode($signup_password);
	  $signup_password2 = base64_encode($signup_password2);
	}
	
	
	
	// SHOW FIRST STEP
	if($task == "step1") {
	  $step = 1;
	  $next_task = "step1do";
	
	  if (empty($signup_username)) {
		  $signup_username = fbconnect_suggest_username();
	  }
	  
	  // GET LANGUAGE PACK LIST
	  $lang_packlist = SE_Language::list_packs();
	  ksort($lang_packlist);
	  $lang_packlist = array_values($lang_packlist);
	
	}
	
	
	$last_task = "step6";
	
	
	// SET GLOBAL PAGE TITLE
	$global_page_title[0] = 679;
	$global_page_description[0] = 680;
	
	
	
	// ASSIGN VARIABLES AND INCLUDE FOOTER
	$smarty->assign('is_error', $is_error);
	$smarty->assign('new_user', $new_user);
	$smarty->assign('cats', $field->cats);
	$smarty->assign('signup_email', $signup_email);
	$smarty->assign('signup_password', $signup_password);
	$smarty->assign('signup_password2', $signup_password2);
	$smarty->assign('signup_username', $signup_username);
	$smarty->assign('signup_timezone', $signup_timezone);
	$smarty->assign('signup_lang', $signup_lang);
	$smarty->assign('signup_invite_form', $signup_invite_form);
	$smarty->assign('signup_secure', $signup_secure);
	$smarty->assign('signup_agree', $signup_agree);
	$smarty->assign('signup_cat', $signup_cat);
	$smarty->assign('lang_packlist', $lang_packlist);
	$smarty->assign('next_task', $next_task);
	$smarty->assign('last_task', $last_task);
	$smarty->assign('step', $step);
} 

else { // Enable Quick signup process. 

	
	// PROCESS INPUT FROM FIRST STEP (OR DOUBLE CHECK VALUES), CONTINUE TO SECOND STEP (OR SECOND STEP PROCESSING)
	if($task == "step1do") {
	  $signup_email = $_POST['signup_email'];
	  $step = $_POST['step'];
	  $signup_username = $_POST['signup_username'];
	  $signup_timezone = $_POST['signup_timezone'];
	  $signup_cat = $_POST['signup_cat'];
	
	  // GET LANGUAGE PACK SELECTION
	  if($setting[setting_lang_allow] != 1) { $signup_lang = 0; } else { $signup_lang = $_POST['signup_lang']; }
	  
	  // ASSIGN A RANDOM PASSWORD TO USERS REGISTERING VIA FACEBOOK
	  $signup_password = generate_random_user_password();
	  $signup_password2 = $signup_password;
	

	  // CHECK USER ERRORS
	  $new_user = new se_user();
	  $new_user->user_password('', $signup_password, $signup_password2, 0);
	  $new_user->user_account($signup_email, $signup_username);
	  $is_error = $new_user->is_error;
	
	  // CHECK TERMS OF SERVICE AGREEMENT IF NECESSARY
	  if($setting[setting_signup_tos] != 0) {
	    $signup_agree = $_POST['signup_agree'];
	    if($signup_agree != 1) {
	      $is_error = 707;
	    }
	  }
	  
	  if($is_error != 0) {
	   $task = "step1";	
	  } 
	
			// Below code is for $signup_cat
	 if($task == "step1" || $task == "step1do") {
	  if($database->database_num_rows($database->database_query("SELECT NULL FROM se_profilecats WHERE profilecat_id='$signup_cat' AND profilecat_dependency='0'")) != 1) {
	    $cat_info = $database->database_fetch_assoc($database->database_query("SELECT profilecat_id FROM se_profilecats WHERE profilecat_dependency='0' ORDER BY profilecat_order LIMIT 1"));
	    $signup_cat = $cat_info[profilecat_id];
	  }
	//  if($task == "step1do") { $validate = 1; } else { $validate = 0; }
	  if($task != "step1") { $cat_where = "profilecat_signup='1' AND profilecat_id='$signup_cat'"; } else { $cat_where = "profilecat_signup='1'"; }
	  $field = new se_field("profile");
	  $field->cat_list($validate, 0, 0, $cat_where, "", "profilefield_signup='1'");
	  $cat_array = $field->cats;
	  if($task != "step1" && count($cat_array) == 0) { $task = "step1"; }
	  if($validate == 1) { $is_error = $field->is_error; }
	  if($task != "step1" && count($field->fields_all) == 0) { $task = "step1do"; }
	}
	  // PROFILE FIELD INPUTS PROCESSED AND CHECKED FOR ERRORS ABOVE
	  // IF THERE IS NO ERROR, ADD USER AND USER PROFILE AND CONTINUE TO STEP 3
	  if($is_error == 0) {
	   $new_user->user_create($signup_email, $signup_username, $signup_password, $signup_timezone, $signup_lang, $signup_cat, $field->field_query);
	   
     // Beucase user is signup through Facebook connect so no need to verifty the email id of user
     $database->database_query("UPDATE se_users SET user_verified='1' WHERE user_id='{$new_user->user_info[user_id]}' LIMIT 1");
	    
	        // Enter the user's info in FB Connect tables
	    $fbuid = fbconnect_get_fbuid();
	    fbconnect_register($new_user->user_info[user_id], $fbuid, $_SESSION['fbconnect_visibility']);
	    
	    update_stats("signups");

	    
	    if ($_SESSION['fb_reg_import']) {
	      // Saving import settings.
	      $fbusersettings_import = fbconnect_set_user_fbinfo($new_user->user_info[user_id], $_SESSION['fb_reg_import']);
	      unset($_SESSION['fb_reg_import']);
	    }
	    
	    $fbconnect_visibility = $_SESSION['fbconnect_visibility'];
	    unset($_SESSION['fbconnect_visibility']);
	
	    /***************************************LOGIN THE USER OVER HERE **********************************************************/
	    $user = new SEUser(Array($new_user->user_info[user_id]));
	    $user->user_setcookies();
	
	   // If the user chose to be visible, and the registration feed parameter is enabled.
	   // We store a value in the session variable, 
	   // this variable will be read by the fbconnect_output_js function.
	   if(  $fbconnect_setting['reg_feed'] && $fbconnect_visibility) {
	     $session_object =& SESession::getInstance();
			 $session_object->set('fbconnect_feed', array(
        'type' => 'registration'
	      ));
	   }
	
	    // OR TO USER FB INVITE, We are taking fb invite step 6
			$task = "step6";		
				
	
	  // IF THERE WAS AN ERROR, GO BACK TO STEP 6
	  } else {
	    $task = "step1";
	  }	  
	  
	}
	
	
	if($task == "step6") {
	  $step = 6;
		$signup_invite_form = fbconnect_output_friends_invite_form();
	}
	
	
	
	// SHOW FIRST STEP
	if($task == "step1") {
	  $step = 1;
	  $next_task = "step1do";
	
		if (empty($signup_username)) {
		  $signup_username = fbconnect_suggest_username();
	  }
	  
	  // GET LANGUAGE PACK LIST
	  $lang_packlist = SE_Language::list_packs();
	  ksort($lang_packlist);
	  $lang_packlist = array_values($lang_packlist);
	
	}
	
	
	$last_task = "step6";	
	
	// SET GLOBAL PAGE TITLE
	$global_page_title[0] = 679;
	$global_page_description[0] = 680;	
	
	// ASSIGN VARIABLES AND INCLUDE FOOTER
	$smarty->assign('is_error', $is_error);
	$smarty->assign('new_user', $new_user);
	$smarty->assign('cats', $field->cats);
	$smarty->assign('signup_email', $signup_email);
	$smarty->assign('signup_password', $signup_password);
	$smarty->assign('signup_password2', $signup_password2);
	$smarty->assign('signup_username', $signup_username);
	$smarty->assign('signup_timezone', $signup_timezone);
	$smarty->assign('signup_lang', $signup_lang);
	$smarty->assign('signup_invite_form', $signup_invite_form);
	
	$smarty->assign('signup_agree', $signup_agree);
	$smarty->assign('signup_cat', $signup_cat);
	$smarty->assign('lang_packlist', $lang_packlist);
	$smarty->assign('next_task', $next_task);
	$smarty->assign('last_task', $last_task);
	$smarty->assign('step', $step);
}

include "footer.php";
?>