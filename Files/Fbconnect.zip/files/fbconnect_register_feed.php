<?php
/* $Id: fbconnect_register_feed.php 1 2009-07-04 09:36:11Z SocialEngineAddOns $ */

include "header.php";

$feedid = fbconnect_register_feed_forms();

echo $feedid; exit;

?>