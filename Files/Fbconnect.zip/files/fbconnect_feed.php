<?php
// THIS FILE OUTPUTS THE FACEBOOK FEEDS USED BY 
// THIS FILE CALLED BY actions_add FUNCTION IN THE CLASS_ACTIONSS.PHP AT THE END OF THIS FUNCTION.

/* $Id: fbconnect_feed.php 1 2009-07-04 09:36:11Z SocialEngineAddOns $ */

global $fbuser, $fbconnect_setting, $smarty, $database, $user; 
$session_object =& SESession::getInstance();
if (!empty($fbuser['uid'])) {
  switch ($actiontype_name) {	  
  	    		
    case 'editphoto' :
	    if (empty($fbuser['avatar']) && !empty($fbconnect_setting['editphoto_feed'])) {
	      $session_object->set('fbconnect_feed', array(
        'type' => 'editphoto'
        ));
      }
      //
			// INCLUDE THE JS FILES NECESSARY FOR FACEBOOK CONNECT, This below function has beed called again inside the feed becuase seesiion was expiring in case of edit photo		
			$fbconnect_footer_js = fbconnect_output_js();
			$smarty->assign('fbconnect_footer_js', $fbconnect_footer_js);
    break;

    case 'editstatus' :
	    if (!empty($fbconnect_setting['status_feed']) && !empty($replace[2])) {        
//	      $session_object->set('fbconnect_feed', array(
//        'type' => 'status',
//		    'status_message' => $replace[2]
//	      ));
	      //  IN SOME OF SE SITES SESSION DO NOT SAVE, FOR THEM WE ARE USING DATBASE TABLE
	      $created = time();
	      $database->database_query("DELETE FROM fbconnect_actions WHERE user_id = " . $user->user_info['user_id'] . " AND action_name = 'status'");   
	      $sql = sprintf("INSERT INTO `fbconnect_actions` (`user_id`, `action_name`, `created`, `message1`) VALUES ( " . $user->user_info['user_id'] . ", 'status', $created, '%s')",  mysql_real_escape_string($replace[2])); 
	      $database->database_query($sql);   				
      }
    break;
 
  
    case 'postblog' :
			if (!empty($fbconnect_setting['postblog_feed']) && !empty($replace[2]) && !empty($replace[3])) {        
	      $session_object->set('fbconnect_feed', array(
        'type' => 'postblog',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
      
    case 'newgroup' :
	    if (!empty($fbconnect_setting['newgroup_feed']) && !empty($replace[2])) {        
	      $session_object->set('fbconnect_feed', array(
        'type' => 'newgroup',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
    
   case 'newevent' :
     if (!empty($fbconnect_setting['newevent_feed']) && !empty($replace[2])) {        
       $session_object->set('fbconnect_feed', array(
        'type' => 'newevent',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
    
   case 'newpoll' :
     if (!empty($fbconnect_setting['newpoll_feed']) && !empty($replace[2])) {        
     $session_object->set('fbconnect_feed', array(
        'type' => 'newpoll',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
    
   case 'newalbum' :
		if (!empty($fbconnect_setting['newalbum_feed']) && !empty($replace[2])) {        
		    $session_object->set('fbconnect_feed',  array(
        'type' => 'newalbum',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
    
	  case 'postclassified' : // Social Engine classified plugin only insert the activity feed when user is editing the classified, same thing is following here. 
		if (!empty($fbconnect_setting['postclassified_feed']) && !empty($replace[2])) {        
		    $session_object->set('fbconnect_feed',  array(
        'type' => 'postclassified',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
    
  case 'newmusic' :
		if (!empty($fbconnect_setting['postmusic_feed'])) {        
		    $session_object->set('fbconnect_feed', array(
        'type' => 'postmusic',
	      ));
      }
    break;
    
    
   case 'newvideo' :
		if (!empty($fbconnect_setting['postvideo_feed']) && !empty($replace[2])) {        
		    $session_object->set('fbconnect_feed', array(
        'type' => 'postvideo',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
    
    case 'newyoutubevideo' :
		if (!empty($fbconnect_setting['postyoutube_feed']) && !empty($replace[2])) {        
		    $session_object->set('fbconnect_feed', array(
        'type' => 'postyoutube',
		    'id' => $replace[2],
		    'title' => $replace[3]
	      ));
      }
    break;
	}
}
?>