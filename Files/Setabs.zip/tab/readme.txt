
Prepared for you by: Andx - A member of: 

http://www.yagbu.net
http://www.nulledlounge.com
http://www.nulledscriptz.com
http://www.portaliz.com/forum


FREASH TAB INSTALLATION INSTRUCTIONS For Social Engine

BACKUP BACKUP BACKUP BACKUP

1. Upload all of the files and folders contained in this zip file (in the "/tab" directory) to 
your server, EXCEPT for readme.txt. Be sure to upload the files to the directory on your server 
where you have already installed SocialEngine. Upload all files in ASCII mode, except for the 
images, which you upload in binary mode.

2. Set full permissions (CHMOD 777) on all the files in the "/templates" directory.

That's it.

---------------------------------

MANUAL TAB INSTALLATION INSTRUCTIONS For Social Engine

BACKUP BACKUP BACKUP BACKUP

1. Open up your header.tpl and add around line 22:

<script type="text/javascript" src="./include/js/tabber.js"></script>
<link rel="stylesheet" href="./include/js/tabber.css" TYPE="text/css" MEDIA="screen">

2. Open up your home.tpl and search for {* SHOW LAST SIGNUPS *} - about line 148

3. Delete this and go to step 4.

{* SHOW LAST SIGNUPS *}
  <table cellpadding='0' cellspacing='0' class='portal_table' align='center' width='100%'>
  <tr><td class='header'>{$home33}</td></tr>
  <tr>
  <td class='portal_box'>
    {if $signups|@count > 0}
      {section name=signups_loop loop=$signups max=5}
        {* START NEW ROW *}
        {cycle name="startrow" values="<table cellpadding='0' cellspacing='0' align='center'><tr>,,,,"}
        <td class='portal_member'><a href='{$url->url_create('profile',$signups[signups_loop]->user_info.user_username)}'>{$signups[signups_loop]->user_info.user_username|truncate:15:"...":true}<br><img src='{$signups[signups_loop]->user_photo('./images/nophoto.gif')}' class='photo' width='{$misc->photo_size($signups[signups_loop]->user_photo('./images/nophoto.gif'),'90','90','w')}' border='0'></a></td>
        {* END ROW AFTER 5 RESULTS *}
        {if $smarty.section.signups_loop.last == true}
          </tr></table>
        {else}
          {cycle name="endrow" values=",,,,</tr></table>"}
        {/if}
      {/section}
    {else}
      {$home34}
    {/if}
  </td>
  </tr>
  </table>


{* SHOW MOST POPULAR USERS (MOST FRIENDS) *}
{if $setting.setting_connection_allow != 0}
  <table cellpadding='0' cellspacing='0' class='portal_table' align='center' width='100%'>
  <tr><td class='header'>{$home35}</td></tr>
  <tr>
  <td class='portal_box'>
  {if $friends|@count > 0}
    {section name=friends_loop loop=$friends max=5}
      {* START NEW ROW *}
      {cycle name="startrow2" values="<table cellpadding='0' cellspacing='0' align='center'><tr>,,,,"}
      <td class='portal_member'><a href='{$url->url_create('profile',$friends[friends_loop].friend->user_info.user_username)}'>{$friends[friends_loop].friend->user_info.user_username|truncate:15}<br><img src='{$friends[friends_loop].friend->user_photo('./images/nophoto.gif')}' class='photo' width='{$misc->photo_size($friends[friends_loop].friend->user_photo('./images/nophoto.gif'),'90','90','w')}' border='0'></a><br>{$friends[friends_loop].total_friends} {$home36}</td>
      {* END ROW AFTER 5 RESULTS *}
      {if $smarty.section.friends_loop.last == true}
        </tr></table>
      {else}
        {cycle name="endrow2" values=",,,,</tr></table>"}
      {/if}
    {/section}
  {else}
    {$home37}
  {/if}
  </td>
  </tr>
  </table>
{/if}

{* SHOW LAST LOGINS *}
<table cellpadding='0' cellspacing='0' class='portal_table' align='center' width='100%'>
<tr><td class='header'>{$home38}</td></tr>
<tr>
<td class='portal_box'>
{if $logins|@count > 0}
  {section name=login_loop loop=$logins max=5}
    {* START NEW ROW *}
    {cycle name="startrow3" values="<table cellpadding='0' cellspacing='0' align='center'><tr>,,,,"}
    <td class='portal_member'><a href='{$url->url_create('profile',$logins[login_loop]->user_info.user_username)}'>{$logins[login_loop]->user_info.user_username}<br><img src='{$logins[login_loop]->user_photo('./images/nophoto.gif')}' class='photo' width='{$misc->photo_size($logins[login_loop]->user_photo('./images/nophoto.gif'),'90','90','w')}' border='0'></a></td>
    {* END ROW AFTER 5 RESULTS *}
    {if $smarty.section.login_loop.last == true}
      </tr></table>
    {else}
      {cycle name="endrow3" values=",,,,</tr></table>"}
    {/if}
  {/section}
{else}
  {$home39}
{/if}
</td>
</tr>
</table>


4. And replace with:

{* BEGIN TABS *}
<div class="tabber">
     <div class="tabbertab">
	  <h2>Newest Members</h2>
{* SHOW LAST SIGNUPS *}

    {if $signups|@count > 0}
      {section name=signups_loop loop=$signups max=5}
        {* START NEW ROW *}
        {cycle name="startrow" values="<table cellpadding='0' cellspacing='0' align='center'><tr>,,,,"}
        <td class='portal_member'><a href='{$url->url_create('profile',$signups[signups_loop]->user_info.user_username)}'>{$signups[signups_loop]->user_info.user_username|truncate:15:"...":true}<br><img src='{$signups[signups_loop]->user_photo('./images/nophoto.gif')}' class='photo' width='{$misc->photo_size($signups[signups_loop]->user_photo('./images/nophoto.gif'),'90','90','w')}' border='0'></a></td>
        {* END ROW AFTER 5 RESULTS *}
        {if $smarty.section.signups_loop.last == true}
          </tr></table>
        {else}
          {cycle name="endrow" values=",,,,</tr></table>"}
        {/if}
      {/section}
    {else}
      {$home34}
    {/if}
</div>


     <div class="tabbertab">
	  <h2>Most Popular</h2>
{* SHOW MOST POPULAR USERS (MOST FRIENDS) *}
{if $setting.setting_connection_allow != 0}
  {if $friends|@count > 0}
    {section name=friends_loop loop=$friends max=5}
      {* START NEW ROW *}
      {cycle name="startrow2" values="<table cellpadding='0' cellspacing='0' align='center'><tr>,,,,"}
      <td class='portal_member'><a href='{$url->url_create('profile',$friends[friends_loop].friend->user_info.user_username)}'>{$friends[friends_loop].friend->user_info.user_username|truncate:15}<br><img src='{$friends[friends_loop].friend->user_photo('./images/nophoto.gif')}' class='photo' width='{$misc->photo_size($friends[friends_loop].friend->user_photo('./images/nophoto.gif'),'90','90','w')}' border='0'></a><br>{$friends[friends_loop].total_friends} {$home36}</td>
      {* END ROW AFTER 5 RESULTS *}
      {if $smarty.section.friends_loop.last == true}
        </tr></table>
      {else}
        {cycle name="endrow2" values=",,,,</tr></table>"}
      {/if}
    {/section}
  {else}
    {$home37}
  {/if}
{/if}
</div>


     <div class="tabbertab">
	  <h2>Last Logged In</h2>
{* SHOW LAST LOGINS *}
{if $logins|@count > 0}
  {section name=login_loop loop=$logins max=5}
    {* START NEW ROW *}
    {cycle name="startrow3" values="<table cellpadding='0' cellspacing='0' align='center'><tr>,,,,"}
    <td class='portal_member'><a href='{$url->url_create('profile',$logins[login_loop]->user_info.user_username)}'>{$logins[login_loop]->user_info.user_username}<br><img src='{$logins[login_loop]->user_photo('./images/nophoto.gif')}' class='photo' width='{$misc->photo_size($logins[login_loop]->user_photo('./images/nophoto.gif'),'90','90','w')}' border='0'></a></td>
    {* END ROW AFTER 5 RESULTS *}
    {if $smarty.section.login_loop.last == true}
      </tr></table>
    {else}
      {cycle name="endrow3" values=",,,,</tr></table>"}
    {/if}
  {/section}
{else}
  {$home39}
{/if}
</div>
{* END TABS*}



5. Upload all remaining files to your server

images/shade.gif
images/shadeactive.gif
includes/js/tabber.css
includes/js/tabber.js

That's it.



