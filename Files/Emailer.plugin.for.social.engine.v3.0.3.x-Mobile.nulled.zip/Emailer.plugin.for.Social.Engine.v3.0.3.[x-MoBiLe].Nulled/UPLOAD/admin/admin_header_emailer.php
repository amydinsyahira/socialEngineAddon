<?

// INCLUDE SHARED CLASS FILE
include_once "../include/class_semods.php";

// INCLUDE FUNCTION FILE
include_once "../include/functions_emailer.php";


?>