<?php

$folder = 'main';
include "flvvideo/config.php";

include "header.php";

$userid = intval($user->user_info[user_id]);	
if(!$userid) exit;

$clean = $_POST;
array_walk_recursive($clean, 'clean_post_recursive');

//echo '<pre>'.print_r($_GET, 1).'</pre>';

if($_GET['action'] == 'rate'){
	$videorate_videoid = intval($_GET['id']);
	$videorate_rate = intval($_GET['star']);
	
	if($db->select('se_flvvideorate', 'videorate_videoid', "WHERE videorate_videoid = {$videorate_videoid} AND videorate_userid = '{$user->user_info[user_id]}'"))
		$db->update('se_flvvideorate', "SET videorate_rate = {$videorate_rate} WHERE videorate_userid = '{$user->user_info[user_id]}' AND videorate_videoid = '{$videorate_videoid}'");
	else
		$db->insert('se_flvvideorate', 'videorate_videoid, videorate_rate, videorate_userid', "'{$videorate_videoid}', '{$videorate_rate}', '{$user->user_info[user_id]}'");
}


?>
Thank you for taking your time to rate this video!