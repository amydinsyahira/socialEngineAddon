<?php

$folder = 'main';
include "flvvideo/config.php";

include "header.php";

$userid = intval($user->user_info[user_id]);
if(!$userid) exit;

if($id = intval($_GET['id'])){
	if(!$db->select('se_flvvideo_favorite', 'ffav_id', "WHERE ffav_userid = '{$userid}' AND ffav_refid = '{$id}'"))
		$db->insert('se_flvvideo_favorite', 'ffav_userid, ffav_refid', "'{$userid}', '{$id}'");
}



?>
<script>

	parent.alert("Thank you for using this feature! \n Video added to your favorite folder!");
	
</script>