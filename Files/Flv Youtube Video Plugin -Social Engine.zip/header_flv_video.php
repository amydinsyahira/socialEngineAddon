<?php

/* ------------------------------------------------------------------------- *\
|                                                                             |
| seIM - header_chat.php                                                      |
|                                                                             |
| $Id:: header_chat.php 230 2008-09-12 09:21:53Z                           $: |
|                                                                             |
\* ------------------------------------------------------------------------- */


// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }


// SET MAIN MENU VARS
$plugin_vars['menu_main'] = Array('file' => 'browse_flv_videos.php', 'title' => 4598804);

// SET USER MENU VARS
if( $user->level_info['level_flvvideo_allow'] )
{
  SE_Language::_preload(4598804);
  $plugin_vars['menu_user'] = Array('file' => 'flvvideo.php', 'icon' => 'video_video18.gif', 'title' => 4598804);
}

?>