<?php

$folder = 'main';
include "flvvideo/config.php";

include "header.php";

$userid = intval($user->user_info[user_id]);	

if(!$userid) exit;

//echo '<pre>'.print_r($GLOBALS, 1).'</pre>';

/*error_reporting(E_ALL);
ini_set('display_errors', true);*/

$smarty->assign('pagenum', $_GET['pagenum']);

switch(htmlentities($_GET['action'], ENT_QUOTES)){

	case 'add':
		$page = "flvvideo_add";
		
		$smarty->assign('maxsize', str_replace('M', ' MB', ini_get('upload_max_filesize')));	
		
		
		if($_POST['submit_flvvideo']){
			
			$clean = array_merge($_POST, $_FILES);
			array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="./images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="./images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if($clean['flvvideo_flv']['type'] != 'application/octet-stream' || $clean['flvvideo_flv']['size'] <= 0 || strpos($clean['flvvideo_flv']['name'], '.flv')===FALSE){
				$e = true;
				$err['flvvideo_flv'] = '<img src="./images/error.gif" class="icon" border="0">Please upload .flv video';

			}
			
			
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="./images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);

			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', 'flvvideo/uploads/');
				$flvvideo_flv = get_flv($_FILES['flvvideo_flv'], 'flvvideo/uploads/');
				
				$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type, flvvideo_tag, flvvideo_comment', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$flvvideo_flv}', '{$flvvideo_image}', '{$user->user_info[user_id]}', 'flv', '{$clean['flvvideo_tag']}', '{$clean['flvvideo_comment']}'");
				
				header("refresh:0; url=flvvideo.php");
				exit;
				
			}
		
		}
		
	break;
	
	case 'add2':
		$page = "flvvideo_add_youtube";
		
		if($_POST['submit_flvvideo']){
			
			$clean = array_merge($_POST, $_FILES);
			array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="./images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="./images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if(strlen($clean['flvvideo_flv']) <= 0){
				$e = true;
				$err['flvvideo_flv'] = '<img src="./images/error.gif" class="icon" border="0"> Embed Youtube video must be valid';

			}
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="./images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);
			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', 'flvvideo/uploads/');
				//$flvvideo_flv = get_flv($_FILES['flvvideo_flv'], 'flvvideo/uploads/');
				
				$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type, flvvideo_tag, flvvideo_comment', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$clean['flvvideo_flv']}', '{$flvvideo_image}', '{$user->user_info[user_id]}', 'youtube', '{$clean['flvvideo_tag']}', '{$clean['flvvideo_comment']}'");
				
				header("refresh:0; url=flvvideo.php");
				exit;
				
			}
		
		}
		
	break;
	
	case 'edit':
		
		$id = intval($_GET['id']);

		$smarty->assign('form_action', $_SERVER['REQUEST_URI']);
		
		$page = "flvvideo_edit";
		
		if($_POST['submit_flvvideo']){
			
			
			
			$clean = array_merge($_POST, $_FILES);
			array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="./images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="./images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if(!$clean['flvvideo_flv'] && ($clean['flvvideo_flv']['type'] != 'application/octet-stream' || $clean['flvvideo_flv']['size'] <= 0 || strpos($clean['flvvideo_flv']['name'], '.flv')===FALSE)){
				$e = true;
				$err['flvvideo_flv'] = '<img src="./images/error.gif" class="icon" border="0">Please upload .flv video';

			}
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="./images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);
			
			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				//echo '<pre>'.print_r($clean, 1).'</pre>';
				$video_to_delete = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx', 'WHERE flvvideo_id = '.intval($_GET['id']).' AND flvvideo_user = '.intval($user->user_info[user_id]));
				
				$addclause = '';
				
				if($clean['flvvideo_flv']['size'] > 0){
					unlink('flvvideo/uploads/'.$video_to_delete[0]['flvvideo_flv']);
					$flvvideo_flv = get_flv($_FILES['flvvideo_flv'], 'flvvideo/uploads/');
					$addclause .= ', flvvideo_flv = "'.$flvvideo_flv.'"';
				}
				if($clean['flvvideo_image']['size'] > 0){
					unlink('flvvideo/uploads/'.$video_to_delete[0]['flvvideo_image']);
					$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', 'flvvideo/uploads/');
					$addclause .= ', flvvideo_image = "'.$flvvideo_image.'"';
				}
				
				
				
				$db->update('se_flvvideo', 'SET flvvideo_title = "'.$clean['flvvideo_title'].'", flvvideo_description = "'.$clean['flvvideo_description'].'",flvvideo_tag = "'.$clean['flvvideo_tag'].'", flvvideo_comment = "'.$clean['flvvideo_comment'].'" '.$addclause.' WHERE flvvideo_id = '.$id.' AND flvvideo_user = '.$userid);
				
				//$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$flvvideo_flv}', '{$flvvideo_image}', '{$user->user_info[user_id]}', 'flv'");
				header("refresh:0; url=flvvideo.php?pagenum={$_GET['pagenum']}");
				exit;
			}
			
			
			
			
		}else{
		
			$video = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_comment, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, flvvideo_tag', 'WHERE flvvideo_id = '.$id.' AND flvvideo_user = '.$userid.' AND flvvideo_type = "flv" LIMIT 1');
			array_walk_recursive($video, '_stripslashes');
					
			$smarty->assign('flvvideo_title', $video[0]['flvvideo_title']);
			$smarty->assign('flvvideo_description', $video[0]['flvvideo_description']);
			$smarty->assign('flvvideo_comment', $video[0]['flvvideo_comment']);
			$smarty->assign('flvvideo_tag', $video[0]['flvvideo_tag']);
			
			$err['flvvideo_flv'] = 'leave blank if not intended to change';
			$err['flvvideo_image'] = 'leave blank if not intended to change';
			$smarty->assign('err', $err);
			
			if($video)
				$smarty->assign('video', $video);
			else{
				header("refresh:0; url=flvvideo.php");
				exit;
			}
		
		}
		
	break;
	
	
	case 'edit2':
		
		$smarty->assign('form_action', $_SERVER['REQUEST_URI']);
		
		$id = intval($_GET['id']);
		$userid = intval($user->user_info[user_id]);
		$smarty->assign('form_action', $_SERVER['REQUEST_URI']);
		
		$page = "flvvideo_edit2";
		
		if($_POST['submit_flvvideo']){
			
			
			
			$clean = array_merge($_POST, $_FILES);
			array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="./images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="./images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if(!$clean['flvvideo_flv'] && ($clean['flvvideo_flv']['type'] != 'application/octet-stream' || $clean['flvvideo_flv']['size'] <= 0 || strpos($clean['flvvideo_flv']['name'], '.flv')===FALSE)){
				$e = true;
				$err['flvvideo_flv'] = '<img src="./images/error.gif" class="icon" border="0">Please upload .flv video';

			}
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="./images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);
			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				//echo '<pre>'.print_r($clean, 1).'</pre>';
				$video_to_delete = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx', 'WHERE flvvideo_id = '.intval($_GET['id']).' AND flvvideo_user = '.intval($user->user_info[user_id]));
				
				$addclause = '';
				
				if($clean['flvvideo_image']['size'] > 0){
					unlink('flvvideo/uploads/'.$video_to_delete[0]['flvvideo_image']);
					$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', 'flvvideo/uploads/');
					$addclause .= ', flvvideo_image = "'.$flvvideo_image.'"';
				}
				
				
				$db->update('se_flvvideo', 'SET flvvideo_title = "'.$clean['flvvideo_title'].'", flvvideo_description = "'.$clean['flvvideo_description'].'", flvvideo_tag = "'.$clean['flvvideo_tag'].'", flvvideo_flv = "'.$clean['flvvideo_flv'].'", flvvideo_comment = "'.$clean['flvvideo_comment'].'" '.$addclause.' WHERE flvvideo_id = '.$id.' AND flvvideo_user = '.$userid);
				
				//$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$flvvideo_flv}', '{$flvvideo_image}', '{$user->user_info[user_id]}', 'flv'");
				header("refresh:0; url=flvvideo.php?pagenum={$_GET['pagenum']}");
				exit;
			}
			
			
			
			
		}else{
		
			$video = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_comment, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, flvvideo_tag', 'WHERE flvvideo_id = '.$id.' AND flvvideo_user = '.$userid.' AND flvvideo_type = "youtube" LIMIT 1');
			array_walk_recursive($video, '_stripslashes');
					
			$smarty->assign('flvvideo_title', $video[0]['flvvideo_title']);
			$smarty->assign('flvvideo_description', $video[0]['flvvideo_description']);
			$smarty->assign('flvvideo_comment', $video[0]['flvvideo_comment']);
			$smarty->assign('flvvideo_flv', $video[0]['flvvideo_flv']);
			$smarty->assign('flvvideo_tag', $video[0]['flvvideo_tag']);
			
			
			//$err['flvvideo_flv'] = 'leave blank if not intended to change';
			$err['flvvideo_image'] = 'leave blank if not intended to change';
			$smarty->assign('err', $err);
			
			if($video)
				$smarty->assign('video', $video);
			else{
				header("refresh:0; url=flvvideo.php");
				exit;
			}
		
		}
		
	break;
	
	
	case 'delete':
		
		$video_to_delete = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx', 'WHERE flvvideo_id = '.intval($_GET['id']).' AND flvvideo_user = '.intval($user->user_info[user_id]));
		
		unlink('flvvideo/uploads/'.$video_to_delete[0]['flvvideo_image']);
		unlink('flvvideo/uploads/'.$video_to_delete[0]['flvvideo_flv']);
		
		$db->delete('se_flvvideo', 'WHERE flvvideo_id = '.intval($_GET['id']).' AND flvvideo_user = '.intval($user->user_info[user_id]));
		
		if($video_to_delete) $smarty->assign('isdelete', TRUE);
		
	default:
		
		$table = 'se_flvvideo LEFT JOIN se_flvvideo_visit ON (flvvideo_visit_id = flvvideo_id) LEFT JOIN se_flvvideo_comment ON (comment_id = flvvideo_id)';
		
		$pager_query = array('table'=>$table, 
				'fields'=>' DISTINCT flvvideo_id', 'where'=>'  ', 'pkey'=>'DISTINCT flvvideo_id', 'limit'=>10);//$this->query;
		//$linktype = array('type'=>'ajax', 'url'=>'ajax_gallery.php?', 'spanid'=>'span_gallery');
		
		$pager = new pager_class($pager_query, 'sql', array('pagenum', 'action'));
		
		if(phpversion() < '5'){
			$pager->__construct($pager_query, 'sql', array('pagenum', 'action'));
		}
		
		$page_limit = $pager->limit_stmt;
		//$clause .= $pager->limit_stmt; // append limit to clause
		
		$smarty->assign('pager', $pager->pager);
		//$tpl['gallery_pager'] = ;
		
		
		
		
		$page = "flvvideo";
		$video = $db->select($table, 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, flvvideo_visit_num, count(comment_pkeyid) as totalx', 'WHERE flvvideo_user = '.$userid.' GROUP BY flvvideo_id ORDER BY flvvideo_dateadded DESC '.$page_limit);
		
		array_walk_recursive($video, '_stripslashes');
		
		//if(file_exists("flvvideo/uploads/{$video[['flvvideo_image']}"))
		//<img src="/images/nophoto.gif" style="border:2px solid #BCBCBC; float:left;" />
		
		
		/*foreach($r as $k=>$v){
			
			$video[$k][flvvideo_title] = '--'.$v['flvvideo_title'];
			
		}*/
		
		//echo '<pre>'.print_r($video, 1).'</pre>';
		//if($video) 
		$smarty->assign('video', $video);
		//else $smarty->assign('video', FALSE);
		
	break;

}






include "footer.php";
?>