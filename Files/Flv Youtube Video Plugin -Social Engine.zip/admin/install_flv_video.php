<?php

/* ------------------------------------------------------------------------- *\
|                                                                             |
| seIM - SE Installer                                                         |
|                                                                             |
| $Id:: install_chat.php 250 2008-09-24 07:58:08Z                          $: |
|                                                                             |
\* ------------------------------------------------------------------------- */

$plugin_name = "FLV Video Plugin";
$plugin_version = "3.0x";
$plugin_type = "flv_video";
$plugin_desc = "This plugin installs a FLV Video Uploader and Player on your social network and adds a link to it on your users menu bar.";
$plugin_icon = "video_video18.gif";
$plugin_menu_title = "4598801";	
$plugin_pages_main = "4598845<!>video_video18.gif<!>admin_flv_video.php<~!~>";
$plugin_pages_level = "";//"3500003<!>admin_levels_messengersettings.php<~!~>";
$plugin_url_htaccess = "";


if( $install=="flv_video" )
{
  // ######### INSERT ROW INTO se_plugins
  $sql = "SELECT plugin_id FROM `$database_name`.`se_plugins` WHERE plugin_type='$plugin_type'";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( !$database->database_num_rows($resource) )
  {
    $sql = "
      INSERT INTO
        `$database_name`.`se_plugins`
      (
        plugin_name,
        plugin_version,
        plugin_type,
        plugin_desc,
        plugin_icon,
        plugin_menu_title,
        plugin_pages_main,
        plugin_pages_level,
        plugin_url_htaccess
      )
      VALUES
      (
        '$plugin_name',
        '$plugin_version',
        '$plugin_type',
        '$plugin_desc',
        '$plugin_icon',
        '$plugin_menu_title',
        '$plugin_pages_main',
        '$plugin_pages_level',
        '$plugin_url_htaccess'
      )
    ";
    
    $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  }

  // ######### UPDATE PLUGIN VERSION IN se_plugins
  else
  {
    $sql = "
      UPDATE
        `$database_name`.`se_plugins`
      SET
        plugin_name='$plugin_name',
        plugin_version='$plugin_version',
        plugin_desc='$plugin_desc',
        plugin_icon='$plugin_icon',
        plugin_menu_title='$plugin_menu_title',
        plugin_pages_main='$plugin_pages_main',
        plugin_pages_level='$plugin_pages_level',
        plugin_url_htaccess='$plugin_url_htaccess'
      WHERE
        plugin_type='$plugin_type'
    ";
    
    $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  }
  

  
 
  //######### ADD COLUMNS/VALUES TO LEVELS TABLE
  $sql = "SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_flvvideo_allow'";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( $database->database_num_rows($resource)==0 )
  {
    $sql = "
      ALTER TABLE
        `$database_name`.`se_levels`
      ADD COLUMN `level_flvvideo_allow`       TINYINT   UNSIGNED  NOT NULL default '1'
    ";
    
    $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  }


	// ######### CREATE se_flvvideo
  $sql = "SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_flvvideo_allow'";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( $database->database_num_rows($resource)==0 )
  {
    $sql = "
      ALTER TABLE
        `$database_name`.`se_levels`
      ADD COLUMN `level_flvvideo_allow`       TINYINT   UNSIGNED  NOT NULL default '1'
    ";
    
    $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  }


	// ######### CREATE se_flvvideo
	$sql = "SHOW TABLES FROM `$database_name` LIKE 'se_flvvideo'";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
  if( $database->database_num_rows($resource)==0 )
  {
    $sql = "
	
		CREATE TABLE IF NOT EXISTS `se_flvvideo` (
		  `flvvideo_id` int(11) NOT NULL auto_increment,
		  `flvvideo_title` varchar(255) NOT NULL,
		  `flvvideo_tag` varchar(255) NOT NULL,
		  `flvvideo_description` text NOT NULL,
		  `flvvideo_flv` text NOT NULL,
		  `flvvideo_type` enum('flv','youtube') NOT NULL default 'youtube',
		  `flvvideo_image` varchar(50) NOT NULL,
		  `flvvideo_comment` enum('yes','no') NOT NULL default 'yes',
		  `flvvideo_user` int(9) NOT NULL,
		  `flvvideo_dateadded` timestamp NOT NULL default CURRENT_TIMESTAMP,
		  PRIMARY KEY  (`flvvideo_id`)
		);
	
	";
    
    $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	/*create se_flvvideo_comment table*/
	$sql = "CREATE TABLE IF NOT EXISTS `se_flvvideo_comment` (
		  `comment_pkeyid` int(11) NOT NULL auto_increment,
		  `comment_id` int(10) NOT NULL default '0',
		  `comment_status` enum('active','not active') NOT NULL default 'active',
		  `comment_content` text NOT NULL,
		  `comment_userid` int(10) NOT NULL default '0',
		  `comment_ip` varchar(25) NOT NULL default '',
		  `comment_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
		  PRIMARY KEY  (`comment_pkeyid`),
		  KEY `cwriting_userid` (`comment_userid`)
		);";
	$database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	
	/*create se_flvvideo_visit table*/
	$sql = "CREATE TABLE IF NOT EXISTS `se_flvvideo_visit` (
		  `flvvideo_visit_id` int(11) NOT NULL,
		  `flvvideo_visit_num` int(11) NOT NULL,
		  `flvvideo_visit_last` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
		  PRIMARY KEY  (`flvvideo_visit_id`)
		);";
	$database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	
	/*create se_flvvideorate table*/
	$sql = "CREATE TABLE IF NOT EXISTS `se_flvvideorate` (
		  `videorate_id` int(10) unsigned NOT NULL auto_increment,
		  `videorate_videoid` int(11) NOT NULL,
		  `videorate_rate` smallint(6) NOT NULL,
		  `videorate_userid` int(11) NOT NULL,
		  `videorate_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
		  PRIMARY KEY  (`videorate_id`)
		);";
	$database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
   
	/*create se_flvvideo_favorite table*/
	$sql = "CREATE TABLE IF NOT EXISTS `se_flvvideo_favorite` (
		  `ffav_id` bigint(20) unsigned NOT NULL auto_increment,
		  `ffav_userid` int(10) unsigned NOT NULL default '0',
		  `ffav_refid` int(10) unsigned NOT NULL default '0',
		  `ffav_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
		  PRIMARY KEY  (`ffav_id`)
		);";
	$database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
   }	
	

/*  // ######### CREATE se_userplane_config
  $sql = "SHOW TABLES FROM `$database_name` LIKE 'se_userplane_config'";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( $database->database_num_rows($resource)==0 )
  {
    $sql = "
      CREATE TABLE
        `$database_name`.`se_userplane_config`
      (
        `userplane_config_id`          					INT         UNSIGNED  NOT NULL auto_increment,
        `userplane_config_flashcom`       			VARCHAR(150)               NULL,
        `userplane_config_domainid`       			VARCHAR(150)               NULL,
        `userplane_config_presenceid`       			VARCHAR(150)               NULL,
        `userplane_config_presencepassword`       	VARCHAR(150)               NULL,
        `userplane_config_zoneid`       				VARCHAR(150)               NULL,
        `userplane_config_textzoneid`       			VARCHAR(150)               NULL,
        `userplane_config_photodirectory`       		VARCHAR(255)               NULL,
        
        PRIMARY KEY  (`userplane_config_id`)
      )
    ";
    
    $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
    $sql = "
      INSERT INTO `se_userplane_config`
        (`userplane_config_id`, `userplane_config_flashcom`, `userplane_config_domainid`, `userplane_config_presenceid`, `userplane_config_presencepassword`, `userplane_config_zoneid`, `userplane_config_textzoneid`, `userplane_config_photodirectory`)
      VALUES 
        (1, 'flashcom.yourcompany.userplane.com', 'yourdomain.com', 'presenceID', 'presencePassword', '3621', '193', 'http://<YOUR DOMAIN>/socialnetwork/uploads_user/1000/')
    ";
    
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
  }*/


  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS NOT BEEN INSTALLED)
  $sql = "SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=4598801 LIMIT 1";
  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  if( !$database->database_num_rows($database->database_query($sql)) )
  {
  
  
    $sql = "
      INSERT INTO `se_languagevars`
        (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`)
      VALUES 
        (4598801, 1, 'FLV Video Settings', ''),
        (4598802, 1, 'FLV Video Settings', ''),
        (4598803, 1, 'FLV Video Settings', ''),
		(4598804, 1, 'FLV Videos', ''),
		(4598805, 1, 'Create New FLV Video', ''),
		(4598806, 1, 'Delete FLV Video', ''),
		(4598807, 1, 'Update FLV Video', ''),
		(4598808, 1, 'FLV Video', ''),
		(4598809, 1, 'View All Videos', ''),
		(4598810, 1, 'Manage My Videos', ''),
		(4598811, 1, 'Upload FLV Video', ''),
		(4598812, 1, 'Embed Youtube Video', ''),
		(4598813, 1, 'Search Video', ''),
		(4598814, 1, 'Selected video is successfully deleted!', ''),
		(4598815, 1, 'You haven\'t uploaded video yet!', ''),
		(4598817, 1, 'Edit Video', ''),
		(4598818, 1, 'Delete Video', ''),
		(4598819, 1, 'Video Title', ''),
		(4598820, 1, 'Video Description', ''),
		(4598821, 1, 'Video Tags', ''),
		(4598822, 1, 'Browse FLV Video', ''),
		(4598823, 1, 'Browse FLV Image', ''),
		(4598824, 1, 'Enable Comment', ''),
		(4598825, 1, 'every tags that are separated by comma must be at least 4 characters long', ''),
		(4598826, 1, 'upload video in .flv format', ''),
		(4598827, 1, 'Need to convert video for .flv?', ''),
		(4598828, 1, 'this image will show while the video is not playing', ''),
		(4598829, 1, 'Add New Video', ''),
		(4598830, 1, 'Title', ''),
		(4598831, 1, 'Type', ''),
		(4598832, 1, 'Date Created', ''),
		(4598833, 1, 'Views', ''),
		(4598834, 1, 'Comments', ''),
		(4598835, 1, 'Related Videos', ''),
		(4598836, 1, 'Video Rating', ''),
		(4598837, 1, 'Rate this Video', ''),
		(4598838, 1, 'Comments', ''),
		(4598839, 1, 'Allowed HTML Tags: b, img, a, br ', ''),
		(4598840, 1, 'No related video!', ''),
		(4598841, 1, 'Write Something...', ''),
		(4598842, 1, 'View Video', ''),
		(4598843, 1, 'No video uploaded yet!', ''),
		(4598844, 1, 'By', ''),
		(4598845, 1, 'Manage Videos', ''),
		(4598846, 1, 'View Comments', ''),
		(4598847, 1, 'Add to Favorites', ''),
		(4598848, 1, 'My Favorites', ''),
		(4598849, 1, 'Remove to Favorites', '')";/*,
		(4598844, 1, '', ''),
		(4598845, 1, '', ''),
		(4598846, 1, '', ''),
		(4598847, 1, '', ''),
		(4598848, 1, '', ''),
		(4598849, 1, '', ''),
		(4598850, 1, '', ''),
		(4598851, 1, '', ''),
		(4598852, 1, '', ''),
		(4598853, 1, '', ''),
		(4598854, 1, '', ''),
		(4598855, 1, '', ''),
		(4598856, 1, '', ''),
		(4598857, 1, '', ''),
		(4598858, 1, '', ''),
		(4598859, 1, '', ''),
		(4598860, 1, '', ''),
		(4598861, 1, '', ''),
		(4598862, 1, '', ''),
		(4598863, 1, '', ''),
		(4598864, 1, '', ''),
		(4598865, 1, '', ''),
		(4598866, 1, '', ''),
		(4598867, 1, '', ''),
		(4598868, 1, '', ''),
		(4598869, 1, '', ''),
		(4598870, 1, '', '')
		
		
		
		
    ";*/
    
    $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	
  
	
	
	
	
	
	
  }
  
  
  
/*  // FIX THE LANGUAGE VAR
  $sql = "
    UPDATE 
      se_languagevars
    SET
      languagevar_value='New message from %1\$s'
    WHERE
      languagevar_value='New message from {username}' &&
      languagevar_id=3510035 &&
      languagevar_language_id=1
    LIMIT
      1
  ";*/
  
//  $resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
  
  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS BEEN INSTALLED)
}


/*create flvvideo table*/

?>