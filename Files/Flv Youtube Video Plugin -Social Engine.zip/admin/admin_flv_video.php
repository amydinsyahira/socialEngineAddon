<?php
$page = "flv_video_admin";
include "admin_header.php";

include('../flvvideo/config.php');

$smarty->assign('url_base', $url->url_base);

//echo '<pre>'.print_r($_SESSION, 1).'</pre>';
		
$smarty->assign('pagenum', $_GET['pagenum']);

switch(htmlentities($_GET['action'], ENT_QUOTES)){

	case 'add':
		$page = "flvvideo_admin_add";
		
		$smarty->assign('maxsize', str_replace('M', ' MB', ini_get('upload_max_filesize')));
		
		if($_POST['submit_flvvideo']){
			
			$clean = array_merge($_POST, $_FILES);
			@array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="../images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="../images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if($clean['flvvideo_flv']['type'] != 'application/octet-stream' || $clean['flvvideo_flv']['size'] <= 0 || strpos($clean['flvvideo_flv']['name'], '.flv')===FALSE){
				$e = true;
				$err['flvvideo_flv'] = '<img src="../images/error.gif" class="icon" border="0">Please upload .flv video';

			}
			
			
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="../images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);

			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', '../flvvideo/uploads/');
				$flvvideo_flv = get_flv($_FILES['flvvideo_flv'], '../flvvideo/uploads/');
				
				$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type, flvvideo_tag, flvvideo_comment', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$flvvideo_flv}', '{$flvvideo_image}', '0', 'flv', '{$clean['flvvideo_tag']}', '{$clean['flvvideo_comment']}'");
				
				header("refresh:0; url=admin_flv_video.php");
				exit;
				
			}
		
		}
		
	break;
	
	case 'add2':
		$page = "flvvideo_admin_add_youtube";
		
		if($_POST['submit_flvvideo']){
			
			$clean = array_merge($_POST, $_FILES);
			@array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="../images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="../images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if(strlen($clean['flvvideo_flv']) <= 0){
				$e = true;
				$err['flvvideo_flv'] = '<img src="../images/error.gif" class="icon" border="0"> Embed Youtube video must be valid';

			}
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="../images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);
			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', '../flvvideo/uploads/');
				//$flvvideo_flv = get_flv($_FILES['flvvideo_flv'], 'flvvideo/uploads/');
				
				$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type, flvvideo_tag, flvvideo_comment', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$clean['flvvideo_flv']}', '{$flvvideo_image}', '0', 'youtube', '{$clean['flvvideo_tag']}', '{$clean['flvvideo_comment']}'");
				
				header("refresh:0; url=admin_flv_video.php");
				exit;
				
			}
		
		}
		
	break;
	
	case 'edit':
		
		$id = intval($_GET['id']);
//		$userid = intval($user->user_info[user_id]);
		$smarty->assign('form_action', $_SERVER['REQUEST_URI']);
		
		$page = "flvvideo_admin_edit";
		
		if($_POST['submit_flvvideo']){
			
			
			
			$clean = array_merge($_POST, $_FILES);
			@array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="../images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="../images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if(!$clean['flvvideo_flv'] && ($clean['flvvideo_flv']['type'] != 'application/octet-stream' || $clean['flvvideo_flv']['size'] <= 0 || strpos($clean['flvvideo_flv']['name'], '.flv')===FALSE)){
				$e = true;
				$err['flvvideo_flv'] = '<img src="../images/error.gif" class="icon" border="0">Please upload .flv video';

			}
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="../images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);
			
			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				//echo '<pre>'.print_r($clean, 1).'</pre>';
				$video_to_delete = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx', 'WHERE flvvideo_id = '.intval($_GET['id']));
				
				$addclause = '';
				
				if($clean['flvvideo_flv']['size'] > 0){
					unlink('../flvvideo/uploads/'.$video_to_delete[0]['flvvideo_flv']);
					$flvvideo_flv = get_flv($_FILES['flvvideo_flv'], '../flvvideo/uploads/');
					$addclause .= ', flvvideo_flv = "'.$flvvideo_flv.'"';
				}
				if($clean['flvvideo_image']['size'] > 0){
					unlink('../flvvideo/uploads/'.$video_to_delete[0]['flvvideo_image']);
					$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', '../flvvideo/uploads/');
					$addclause .= ', flvvideo_image = "'.$flvvideo_image.'"';
				}
				
				
				
				$db->update('se_flvvideo', 'SET flvvideo_title = "'.$clean['flvvideo_title'].'", flvvideo_description = "'.$clean['flvvideo_description'].'",flvvideo_tag = "'.$clean['flvvideo_tag'].'", flvvideo_comment = "'.$clean['flvvideo_comment'].'" '.$addclause.' WHERE flvvideo_id = '.$id);
				
				//$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$flvvideo_flv}', '{$flvvideo_image}', '{$user->user_info[user_id]}', 'flv'");
				header("refresh:0; url=admin_flv_video.php?pagenum={$_GET['pagenum']}");
				exit;
			}
			
			
			
			
		}else{
		
			$video = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_comment, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, flvvideo_tag', 'WHERE flvvideo_id = '.$id.' AND flvvideo_type = "flv" LIMIT 1');
			@array_walk_recursive($video, '_stripslashes');
					
			$smarty->assign('flvvideo_title', $video[0]['flvvideo_title']);
			$smarty->assign('flvvideo_description', $video[0]['flvvideo_description']);
			$smarty->assign('flvvideo_comment', $video[0]['flvvideo_comment']);
			$smarty->assign('flvvideo_tag', $video[0]['flvvideo_tag']);
			
			$err['flvvideo_flv'] = 'leave blank if not intended to change';
			$err['flvvideo_image'] = 'leave blank if not intended to change';
			$smarty->assign('err', $err);
			
			if($video)
				$smarty->assign('video', $video);
			else{
				header("refresh:0; url=admin_flv_video.php");
				exit;
			}
		
		}
		
	break;
	
	
	case 'edit2':
		
		$smarty->assign('form_action', $_SERVER['REQUEST_URI']);
		
		$id = intval($_GET['id']);
//		$userid = intval($user->user_info[user_id]);
		$smarty->assign('form_action', $_SERVER['REQUEST_URI']);
		
		$page = "flvvideo_admin_edit2";
		
		if($_POST['submit_flvvideo']){
			
			
			
			$clean = array_merge($_POST, $_FILES);
			@array_walk_recursive($clean, 'clean_post_recursive');
			
			//echo '<pre>'.print_r($clean, 1).'</pre>';
			
			foreach($clean as $k=>$v){
				$smarty->assign($k, $v);
			}
			
			
			$e = false;
			if(strlen($clean['flvvideo_title']) <= 0){
				$e = true;
				$err['flvvideo_title'] = '<img src="../images/error.gif" class="icon" border="0">Video Title must not be empty';
			}
			if(strlen($clean['flvvideo_description']) <= 0){
				$e = true;
				$err['flvvideo_description'] = '<img src="../images/error.gif" class="icon" border="0">Video Description must not be empty';

			}
			if(!$clean['flvvideo_flv'] && ($clean['flvvideo_flv']['type'] != 'application/octet-stream' || $clean['flvvideo_flv']['size'] <= 0 || strpos($clean['flvvideo_flv']['name'], '.flv')===FALSE)){
				$e = true;
				$err['flvvideo_flv'] = '<img src="../images/error.gif" class="icon" border="0">Please upload .flv video';

			}
			$arr_flvvideo_tag = explode(',', $clean['flvvideo_tag']);
			foreach($arr_flvvideo_tag as $v){
			
				$v = trim($v);
			
				if(strlen($v) <= 3){
					$e = true;
					$err['flvvideo_tag'] = '<img src="../images/error.gif" class="icon" border="0">Every tags that are separated by comma must be atleast 4 characters long';
	
				}
					$temp[] = $v;
			}
			$clean['flvvideo_tag'] = implode(', ', $temp);
			
			
			
			if($e == true){
				$smarty->assign('err', $err);			
			}else{
				
				//echo '<pre>'.print_r($clean, 1).'</pre>';
				$video_to_delete = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx', 'WHERE flvvideo_id = '.intval($_GET['id']));
				
				$addclause = '';
				
				if($clean['flvvideo_image']['size'] > 0){
					unlink('../flvvideo/uploads/'.$video_to_delete[0]['flvvideo_image']);
					$flvvideo_image = crop_image($_FILES['flvvideo_image'], '200x200', '../flvvideo/uploads/');
					$addclause .= ', flvvideo_image = "'.$flvvideo_image.'"';
				}
				
				
				$db->update('se_flvvideo', 'SET flvvideo_title = "'.$clean['flvvideo_title'].'", flvvideo_description = "'.$clean['flvvideo_description'].'", flvvideo_tag = "'.$clean['flvvideo_tag'].'", flvvideo_flv = "'.$clean['flvvideo_flv'].'", flvvideo_comment = "'.$clean['flvvideo_comment'].'" '.$addclause.' WHERE flvvideo_id = '.$id);
				
				//$db->insert('se_flvvideo', 'flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_image, flvvideo_user, flvvideo_type', "'{$clean['flvvideo_title']}', '{$clean['flvvideo_description']}', '{$flvvideo_flv}', '{$flvvideo_image}', '{$user->user_info[user_id]}', 'flv'");
				header("refresh:0; url=admin_flv_video.php?pagenum={$_GET['pagenum']}");
				exit;
			}
			
			
			
			
		}else{
		
			$video = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_comment, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, flvvideo_tag', 'WHERE flvvideo_id = '.$id.' AND flvvideo_type = "youtube" LIMIT 1');
			@array_walk_recursive($video, '_stripslashes');
					
			$smarty->assign('flvvideo_title', $video[0]['flvvideo_title']);
			$smarty->assign('flvvideo_description', $video[0]['flvvideo_description']);
			$smarty->assign('flvvideo_comment', $video[0]['flvvideo_comment']);
			$smarty->assign('flvvideo_flv', $video[0]['flvvideo_flv']);
			$smarty->assign('flvvideo_tag', $video[0]['flvvideo_tag']);
			
			
			//$err['flvvideo_flv'] = 'leave blank if not intended to change';
			$err['flvvideo_image'] = 'leave blank if not intended to change';
			$smarty->assign('err', $err);
			
			if($video)
				$smarty->assign('video', $video);
			else{
				header("refresh:0; url=admin_flv_video.php");
				exit;
			}
		
		}
		
	break;
	
	case 'view':
	
	
//		$smarty->assign('user_id', $user->user_info[user_id]);
		
		$page = "flvvideo_admin_play";
		$video = $db->select('se_flvvideo LEFT JOIN se_flvvideo_comment ON (comment_id = flvvideo_id) LEFT JOIN se_flvvideo_visit ON (flvvideo_visit_id = flvvideo_id) LEFT JOIN se_flvvideorate ON (videorate_videoid = flvvideo_id) LEFT JOIN se_users ON (user_id = flvvideo_user)', 
			'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_comment, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, count(comment_pkeyid) as totalx, AVG(videorate_rate) as videorate_rate,flvvideo_visit_num, flvvideo_tag, user_username, user_fname, user_lname ', 'WHERE flvvideo_id = '.$id.' GROUP BY flvvideo_id LIMIT 1');
			
	
		$smarty->assign('average_rate', get_rate(array('rating'=>$video[0]['videorate_rate']), '../icons/flvvideo_star'));
//		$smarty->assign('give_rate', give_rate(array('id'=>intval($video[0]['flvvideo_id']))));
		
		
	
	//	echo $video[0]['flvvideo_tag'];
		
		$related_video = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_tag, flvvideo_image', 'WHERE flvvideo_id != '.intval($video[0]['flvvideo_id']).'  AND MATCH(flvvideo_tag) AGAINST(\''.$video[0]['flvvideo_tag'].'\' IN BOOLEAN MODE)');
		
	//	echo '<pre>--'.print_r($related_video, 1).'</pre>';
	
		if(!$db->select('se_flvvideo_visit', 'flvvideo_visit_id', 'WHERE flvvideo_visit_id = '.$id)){
			$db->insert('se_flvvideo_visit', 'flvvideo_visit_id, flvvideo_visit_num', "'{$id}', '1'");
		}elseif($_SESSION['last_visit_'.$id] !== TRUE){
			$db->update('se_flvvideo_visit', 'SET flvvideo_visit_num = flvvideo_visit_num + 1 WHERE flvvideo_visit_id = '.$id);
			$_SESSION['last_visit_'.$id] = TRUE;
		}
	
		
		@array_walk_recursive($video, '_stripslashes');
		@array_walk_recursive($related_video, '_stripslashes');
		$smarty->assign('video', $video);
		$smarty->assign('related_video', $related_video);
		
		
		
		$pager_query = array('table'=>'se_flvvideo_comment INNER JOIN se_users ON (user_id = comment_userid)', 
				'fields'=>' DISTINCT comment_pkeyid', 'where'=>'  WHERE  comment_id = '.intval($id).' AND comment_status = "active" ', 'pkey'=>'DISTINCT comment_pkeyid', 'limit'=>5);//$this->query;
		$linktype = array('type'=>'ajax', 'url'=>'flvvideo_span_comment.php?id='.$id, 'spanid'=>'span_comment');
		
		$pager = new pager_class($pager_query, 'sql', array('pagenum', 'action'), $linktype);
		
		if(phpversion() < '5'){
			$pager->__construct($pager_query, 'sql', array('pagenum', 'action'), $linktype);
		}
		
		$page_limit = $pager->limit_stmt;
		//$clause .= $pager->limit_stmt; // append limit to clause
		
		$smarty->assign('pager', $pager->pager);
		
		$comment = $db->select('se_flvvideo_comment INNER JOIN se_users ON (user_id = comment_userid)', 'comment_pkeyid, comment_id, comment_status, comment_content, comment_userid, comment_ip, comment_date, DATE_FORMAT(comment_date, "%M %d, %Y %h:%i %p") as comment_datex, user_id, user_fname, user_lname, user_username, user_photo', 'WHERE comment_id = '.$id.' AND comment_status = "active" ORDER BY comment_date DESC '.$page_limit);
		@array_walk_recursive($comment, '_stripslashes');
		
		$smarty->assign('comment', $comment);
	
	
	break;
	
	case 'delete':
		
		$video_to_delete = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx', 'WHERE flvvideo_id = '.intval($_GET['id']));
		
		unlink('../flvvideo/uploads/'.$video_to_delete[0]['flvvideo_image']);
		unlink('../flvvideo/uploads/'.$video_to_delete[0]['flvvideo_flv']);
		
		$db->delete('se_flvvideo', 'WHERE flvvideo_id = '.intval($_GET['id']));
		
		if($video_to_delete) $smarty->assign('isdelete', TRUE);
		
	default:
		
		$table = 'se_flvvideo LEFT JOIN se_flvvideo_visit ON (flvvideo_visit_id = flvvideo_id) LEFT JOIN se_flvvideo_comment ON (comment_id = flvvideo_id) LEFT JOIN se_users ON (user_id = flvvideo_user)';
		
		$pager_query = array('table'=>$table, 
				'fields'=>' DISTINCT flvvideo_id', 'where'=>'  ', 'pkey'=>'DISTINCT flvvideo_id', 'limit'=>10);//$this->query;
		//$linktype = array('type'=>'ajax', 'url'=>'ajax_gallery.php?', 'spanid'=>'span_gallery');
		
		$pager = new pager_class($pager_query, 'sql', array('pagenum', 'action'));
		
		if(phpversion() < '5'){
			$pager->__construct($pager_query, 'sql', array('pagenum', 'action'));
		}
		
		$page_limit = $pager->limit_stmt;
		//$clause .= $pager->limit_stmt; // append limit to clause
		
		$smarty->assign('pager', $pager->pager);
		//$tpl['gallery_pager'] = ;
		
		
		
		
//		$page = "flvvideo";
		$video = $db->select($table, 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, flvvideo_visit_num, count(comment_pkeyid) as totalx, user_username, user_fname, user_lname', 'GROUP BY flvvideo_id ORDER BY flvvideo_dateadded DESC '.$page_limit);
		
		@array_walk_recursive($video, '_stripslashes');
		
		//if(file_exists("flvvideo/uploads/{$video[['flvvideo_image']}"))
		//<img src="/images/nophoto.gif" style="border:2px solid #BCBCBC; float:left;" />
		
		
		/*foreach($r as $k=>$v){
			
			$video[$k][flvvideo_title] = '--'.$v['flvvideo_title'];
			
		}*/
		
		//echo '<pre>'.print_r($video, 1).'</pre>';
		//if($video) 
		$smarty->assign('video', $video);
		//else $smarty->assign('video', FALSE);
		
	break;

}

		
		
		
		
		
		
		
		

include "admin_footer.php";
?>