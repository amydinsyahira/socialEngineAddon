<?php

include "admin_header.php";

include('../flvvideo/config.php');

/*error_reporting(E_ALL);
ini_set('display_errors', true);*/

	if($id = intval($_GET['id'])){
//		$user_id = intval($user->user_info[user_id]);
	
//	if($r = $db->select('se_flvvideo INNER JOIN se_flvvideo_comment ON (flvvideo_id = comment_id)', 'comment_pkeyid, flvvideo_user, comment_userid, flvvideo_id', 'WHERE comment_pkeyid = '.$id.' AND (comment_userid = '.$user_id.' OR flvvideo_user = '.$user_id.') ')){
		//echo '<pre>'.print_r($r, 1).'</pre>';
		$db->delete('se_flvvideo_comment', 'WHERE comment_pkeyid = '.$id);
//	}
}
	
	
?>
<script>
	parent.alert("Comment successfully deleted! \n It will be removed on your next refresh.");
</script>