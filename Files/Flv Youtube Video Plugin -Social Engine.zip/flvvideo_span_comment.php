<?php

$folder = 'main';
include "flvvideo/config.php";

include "header.php";

$userid = intval($user->user_info[user_id]);	
if(!$userid) exit;

/*error_reporting(E_ALL);
ini_set('display_errors', true);*/

	$id = intval($_GET['id']);

	$page = "flvvideo_span_comment";
	
	
	$pager_query = array('table'=>'se_flvvideo_comment INNER JOIN se_users ON (user_id = comment_userid)', 
			'fields'=>' DISTINCT comment_pkeyid', 'where'=>'  ', 'pkey'=>'DISTINCT comment_pkeyid', 'limit'=>5);//$this->query;
	$linktype = array('type'=>'ajax', 'url'=>'flvvideo_span_comment.php?id='.$id, 'spanid'=>'span_comment');
	
	$pager = new pager_class($pager_query, 'sql', array('pagenum', 'action'), $linktype);
	
	if(phpversion() < '5'){
		$pager->__construct($pager_query, 'sql', array('pagenum', 'action'), $linktype);
	}
	
	$page_limit = $pager->limit_stmt;
	//$clause .= $pager->limit_stmt; // append limit to clause
	
	$smarty->assign('pager', $pager->pager);
	
	$comment = $db->select('se_flvvideo_comment INNER JOIN se_users ON (user_id = comment_userid)', 'comment_pkeyid, comment_id, comment_status, comment_content, comment_userid, comment_ip, comment_date, DATE_FORMAT(comment_date, "%M %d, %Y %h:%i %p") as comment_datex, user_id, user_fname, user_lname, user_username, user_photo', 'WHERE comment_id = '.$id.' AND comment_status = "active" ORDER BY comment_date DESC '.$page_limit);
	array_walk_recursive($comment, '_stripslashes');
	
	$smarty->assign('comment', $comment);

include "footer.php";
?>