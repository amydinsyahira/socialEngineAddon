<?php


//---------------######don't change any variables below this line######-------------------------------------------------//






session_start();



/*function __autoload($classname){
	include_once(LIB_DIR."{$classname}.php");
}*/

if(!function_exists('array_walk_recursive')){
	function array_walk_recursive(&$input, $funcname, $userdata = "") {
		if (!is_callable($funcname)) {
			return false;
		}
	
		if (!is_array($input)) {
			return false;
		}
	
		foreach ($input AS $key => $value) {
			if (is_array($input[$key])) {
				array_walk_recursive($input[$key], $funcname, $userdata);
			} else {
				$saved_value = $value;
				$saved_key = $key;
				if (!empty($userdata)) {
					$funcname($value, $key, $userdata);
				} else {
					$funcname($value, $key);
				}
	
				if ($value != $saved_value || $saved_key != $key) {
					unset($input[$saved_key]);
					$input[$key] = $value;
				}
			}
		}
		return true;
	}
}




error_reporting(0);
ini_set('display_errors', false);


if(@$folder == 'main'){
	include_once('include/database_config.php');
	define('LIB_DIR', 'flvvideo/library/');
}else{
	include_once('../include/database_config.php');
	define('LIB_DIR', 'flvvideo/library/');
}

$conf['db_user']=$database_username; 
$conf['db_pass']=$database_password;
$conf['db_name']=$database_name;
$conf['db_host']=$database_host; 
		


include_once(LIB_DIR."classes/database_class.php");
include_once(LIB_DIR."classes/cms_class.php");
include_once(LIB_DIR."includes/function.php");
include_once(LIB_DIR."classes/pager_class.php");

$db = new database_class;

//echo phpversion();

if(phpversion() < '5'){
	$db->__construct();
}

//echo '<pre>'.print_r($_SERVER, 1).'</pre>';

/*$r_userplane = $db->select('se_userplane_config', ' `userplane_config_id` , `userplane_config_flashcom` , `userplane_config_domainid` , `userplane_config_presenceid` , `userplane_config_presencepassword` , `userplane_config_zoneid` , `userplane_config_textzoneid` , `userplane_config_photodirectory` ', 'WHERE userplane_config_id = 1 LIMIT 1');



/*$strFlashcomServer = "flashcom.getubes.userplane.com";
$strDomainID =  "getubes.com";
$strPresenceID =  "1965";
$strPresencePassword =  'Cjek1453';

$strZoneIDBanner =  "3621";
$strZoneIDText =  "193";
define('PHOTO_DIR', 'http://www.getubes.com/socialnetwork/uploads_user/1000/');
* /

//echo $strFlashcomServer;

$strFlashcomServer = $r_userplane[0]['userplane_config_flashcom'];//"flashcom.getubes.userplane.com";
$strDomainID =  $r_userplane[0]['userplane_config_domainid'];//"getubes.com";
$strPresenceID =  $r_userplane[0]['userplane_config_presenceid'];//"1965";
$strPresencePassword =  $r_userplane[0]['userplane_config_presencepassword'];//'Cjek1453';

$strZoneIDBanner = $r_userplane[0]['userplane_config_zoneid'];// "3621";
$strZoneIDText =  $r_userplane[0]['userplane_config_textzoneid'];//"193";



define('PHOTO_DIR', $r_userplane[0]['userplane_config_photodirectory']);
*/

?>