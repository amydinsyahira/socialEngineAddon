<?php
/*
// Author: Teodulo Otoman II [PHP Zend Certified Engineer / Co-Founder]
// Email: jhun.otoman@gmail.com
// URL: http://www.sproads.com
*/

class cms_class extends database_class{

var $level, $table, $element, $content, $action_link, $row, $cms_field, $cms_form, $cms_title, $cms_checker, $cms_data, $cms_filter, $cms_config, $cms_pager, $cms_buttons, $cl, $cms_default_filter, $form_reply, $clean, $action, $cms_arg, $cms_id, $filter, $cms_default, $err, $error_msg;
	
	function __construct($level=0){
		//levels; 0 = view only, 1 = all levels => view,add,edit,delete
		$this->level = $level;
	}
	
	function __call($method, $arguments) {
		$other_classes = array('uploader_class');
		foreach($other_classes as $v){
			if(!$this->cl[$v]) $this->cl[$v] = new $v;
			if (method_exists($this->cl[$v], $method)) return call_user_func_array(array($this->cl[$v], $method), $arguments);
		}
		die('Unknown Method: '.$method);
	}
	
	function begin($element, $query, $cms_config){
		$this->element = $element;
		$this->query = $query;
		$this->cms_config = $cms_config;
		$this->elements_to_array();
		$this->make_sql_query();
		switch($this->level){
			case 1:
				$default_action = 'view';			
				$valid_action = array('view', 'detail', 'add', 'edit', 'delete','delete_selected','reply');
			break;
			case 2:
				$default_action = 'view';			
				$valid_action = array('view', 'detail', 'reply');
			break;
			case 3:
				$default_action = 'view';			
				$valid_action = array('view', 'edit');
			break;
			case 4:
				$default_action = 'view';			
				$valid_action = array('view');
			break;
			case 5:
				$default_action = 'add';
				$valid_action = array('add');
			break;
			case 6:
				$default_action = 'view';			
				$valid_action = array('add', 'view', 'delete', 'detail', 'delete_selected');
			break;
		}
		//$valid_action = $this->level==1 ? array('view', 'detail', 'add', 'edit', 'delete','delete_selected','reply') : array('view', 'detail', 'reply');
		$this->action = @in_array($_GET['action'], $valid_action) ? $_GET['action'] : $default_action;
		$this->template = @$cms_config['template'];
		$this->{'cms_'.$this->action}();
//		$this->content = $this->content;
		return($this->content);
	}
	
	function cms_view(){
		$this->cms_config['view_elements'] = TRUE;
//		$this->elements_to_array();

		if($this->cms_config['filter'] === TRUE)
			$this->createfilter();
		if($this->cms_config['pager'] === TRUE){
			if($this->query['table_type']== 0)
				$pager_query = $this->query;
			else{
				list($table, $fields) = $this->create_multi_table();
				$pager_query = array('table'=>$table, 'fields'=>$fields, 'where'=>$this->query['where'], 'pkey'=>$this->query['pkey'], 'limit'=>$this->query['limit']);//$this->query;
			}

			$pager = new pager_class($pager_query, 'sql');
			$this->query['clause'] .= $pager->limit_stmt;
			$this->cms_pager = $pager->pager;
		}
		$this->title_sort($this->cms_title);
		$this->init_data('db');

//		$this->create_view_elements();
		//$this->row = '';
		if($this->cms_config['show_view_actions'] === TRUE)
			$this->show_view_actions();
		@array_walk_recursive($this->cms_data, '_strip_tags');
		$this->maketemplate();
	}
	
	function cms_detail(){
		$this->cms_config['view_elements'] = TRUE;
		$this->text_to_editor();
//		$this->elements_to_array();
		$this->init_data('db');
		$this->cms_action_link();
		$this->maketemplate();
	}
	
	function cms_edit(){
		$this->text_to_editor();
		$this->cms_add_edit();
	}
	
	function cms_add(){
		$this->cms_add_edit();
	}
	
	function cms_reply(){
		$this->cms_config['view_elements'] = TRUE;
		$this->elements_to_array(TRUE);
//		echo '<pre>'.print_r($this->cms_config['reply']['element'], 1).'</pre>';
		$this->init_data('db');
		$this->cms_action_link();
		$this->make_form_reply();
		$this->maketemplate();
//		$this->elements_to_form(TRUE);
//		echo 'detail';
	}
	
	function cms_add_edit(){
//		$this->elements_to_array();

		if(@$_POST['submit']){
			$this->clean_user_input(array_merge($_POST, $_FILES));
			$e = $this->trigger_mysql();
			if($e === FALSE){
				$this->{'cms_query_'.$this->action}();
				return;
			}
			else{
				$this->error_msg = '<font class="err">Error Detected.</font>';
			}
			$this->init_data('post');
			if($e !== FALSE) array_walk_recursive($this->row, 'clean_strip_post_recursive');
			$this->override_default_value($this->row);
		}elseif($this->action == 'add'){
			$this->init_data('default');
		}elseif($this->action == 'edit'){
				$this->init_data('db');
				array_walk_recursive($this->row, '_stripslashes');
				$this->override_default_value($this->row);
				//echo '~~<pre>'.print_r($this->row).'</pre>';
		}
		
		$btn = $this->action == 'add' ? array(' Add ', ' Reset Form ') : array(' Update ', ' Reset Form ');
		$this->append_buttons($btn);
		$this->elements_to_form();
		$this->cms_action_link();
		$this->maketemplate();
	}
	
	function cms_delete(){
		$this->cms_query_delete(explode(',',$_GET['id']));
	}
	
	function cms_delete_selected(){
		$form_id = mysql_real_escape_string(htmlentities(trim($_GET['form_id']), ENT_QUOTES));
		$form_id = substr_replace($form_id, '', strpos($form_id, '['));
		$this->cms_query_delete($_POST[$form_id]);
		$this->cms_view();
	}
	
	function elements_to_array(){
		$c = 0;
		if(is_array($this->element))
		foreach($this->element as $k=>$v){
			
			if(@in_array($v['0'], $this->cms_config['show_element']) || !@is_array($this->cms_config['show_element']) && @$this->cms_config['descriptive_key'] == true){
			
				@list($this->cms_id[$k], 
							$this->cms_form[$k],
							$this->cms_title[$k],
							$this->cms_checker[$k],
							$this->cms_filter[$k],
							$this->cms_arg[$k],
							$this->cms_default[$k],
							$this->cms_param[$k],
							$this->cms_err[$k],
							$this->cms_txtval[$k]
							) = $v;
			
			}
			elseif(@in_array($v['0'], $this->cms_config['show_element']) || !@is_array($this->cms_config['show_element']))
				@list($this->cms_id[$c], 
							$this->cms_form[$c],
							$this->cms_title[$c],
							$this->cms_checker[$c],
							$this->cms_filter[$c],
							$this->cms_arg[$c],
							$this->cms_default[$c],
							$this->cms_param[$c],
							$this->cms_err[$c],
							$this->cms_txtval[$c]
							) = $v;
			$c++;
			
		}
	}
	
	function init_data($arg){
		switch($arg){
			case 'db':
				if($this->query['table_type']==0)
					$this->row = $this->select($this->query['table'], $this->query['fields'], $this->query['clause']);
				else {
					list($table, $fields) = $this->create_multi_table();
					$this->row = $this->select($table, $fields, $this->query['clause']);
				}
			break;
			case 'post':
				$this->row[] = $this->clean;
			break;
			case 'default':
				$this->row[] = array_combine($this->cms_id, $this->cms_default);
			break;
		}

		$cms_flip_id = array_flip($this->cms_id);
		if(is_array($this->row)){
			$textarea = array_flip(array_keys($this->cms_form, 'textarea'));
			$textarea = array_intersect_key($this->cms_id, $textarea);
//			echo print_r($textarea, 1).'<br />';
			
			foreach($this->row as $v){
				$arr_v = array_intersect_key($v, $cms_flip_id);
				if(@$this->cms_config['view_elements'] === TRUE) $this->create_view_elements($arr_v);
				array_walk($arr_v, 'entity_decode', $textarea);
				$this->cms_data[] = $arr_v;
				@$this->cms_data_pkey[] = $v[$this->query['pkey']];
			}
		}
		else $this->cms_data = FALSE;
	}

	function make_sql_query(){
//		$valid_fields = explode(',', $this->query['fields']);
		$valid_fields = $this->cms_id;
		$valid_fields_reverse = @array_flip($valid_fields);
//		echo '<pre>'.print_r($this->cms_form, 1).'</pre>';
//		echo '<pre>'.print_r($this->cms_id, 1).'</pre>';
//		echo '<pre>'.print_r($valid_fields, 1).'</pre>';
//		foreach($valid_fields as &$v_ref) $v_ref = trim($v_ref);
		//for where clause
		if(@!$this->query['where']) $this->query['where'] = ' WHERE 1 ';
//			echo '<pre>'.print_r($valid_fields, 1).'</pre>';
		foreach($_GET as $k => $v){
			if(@in_array($k, $valid_fields) && trim($v)!=''){
				$key = $valid_fields_reverse[$k];
//				echo '~~'.$this->cms_form[$key];
				switch($this->cms_form[$key]){
					case 'selectdb':
					case 'select':
						$this->query['where'] .= ' AND '.$k.' = "'.$v.'" ';
					break;
					default:
						$this->query['where'] .= ' AND '.$k.' LIKE "%'.$v.'%" ';
					break;
				}
			}
		}
		//for order by
		if(@in_array($_GET['sort'], $valid_fields)){
			$sort = array('ASC','DESC');
			if(@in_array($_GET['by'], $sort)){ $by = $_GET['by'];
				$this->query['order'] = ' ORDER BY '.$_GET['sort'].' '.$by;
			}
		}
		//echo $this->query['where'];
//		@$this->query['clause'] = $this->query['where'].$this->query['order'];
		@$this->query['clause'] = $this->query['where'].@$this->query['group'].$this->query['order'].$edit_limit;//.' '.@$this->query['limit'];
	}
	
	function trigger_mysql(){
		$e = FALSE;
		$e = @$this->cms_config['additional_error'] ? $this->cms_config['additional_error'] : FALSE;
		foreach($this->cms_id as $k => $v){
			$checker = field_checker($this->clean[$v], $this->cms_id[$k], $this->cms_checker[$k]);
			if($checker !== FALSE){
				$this->err[$v] = $checker;
				$e = TRUE;
			}
		}
		return($e);
	}
	
	function cms_query_add(){
		
			global $ffmpeg_upload_data, $get_exif_uploaded;
		
			
			
			$ins_query = $this->cms_query_createdata(FALSE);
			if($this->query['table_type']==1){
				foreach ($this->query['table'] as $k=>$v){
					$fields = explode(',', $this->query['fields'][$k]);
					$i += ($k <= 0) ? 0 : count(explode(',', $this->query['fields'][$k-1]));
					$c = count(explode(',', $this->query['fields'][$k])) + $i;
					unset($values);
					for($x=$i; $x<$c; $x++){
						//echo $ins_query[$x].'<br>';
						if(@$ins_query[$x]) $values[] = $ins_query[$x];
					}
					//echo count($fields).'='.count($values).'<br>';
					if($k <= 0)  $idval = ''; 
					else { $idval = ', LAST_INSERT_ID()'; $fldval = ', '.$this->query['refkey'][$k]; }
					if($this->query[$this->query['table'][$k]]['pre_defined_fields']){
						array_unshift($fields, $this->query[$this->query['table'][$k]]['pre_defined_fields'][0]);
						array_unshift($values, $this->query[$this->query['table'][$k]]['pre_defined_fields'][1]);
					}
					$lastinsertid[$k] = $this->insert($this->query['table'][$k], 
								implode(', ', $fields).$fldval,
								implode(', ', $values).$idval); 
				}
			}else{
				if(@$this->query[$this->query['table']]['pre_defined_fields']){
					array_unshift($this->cms_id, $this->query[$this->query['table']]['pre_defined_fields'][0]);
					array_unshift($ins_query, $this->query[$this->query['table']]['pre_defined_fields'][1]);
				}
				if(@$this->query[$this->query['table']]['pre_defined_fields_multiple']){
				
				
				
					foreach($this->query[$this->query['table']]['pre_defined_fields_multiple'] as $v_pfm){
						array_unshift($this->cms_id, $v_pfm[0]);
						array_unshift($ins_query, $v_pfm[1]);
					}
				}
				$lastinsertid = $this->insert($this->query['table'], 
								implode(', ', $this->cms_id),
								implode(', ', $ins_query)); 
				
								
			}
			$append = $this->append_url();
			
			if(is_array(@$this->query['predefined_mysql']))
				foreach($this->query['predefined_mysql'] as $k=>$v){
					eval("\$v = \"$v\";");
					$predefined_lastinsertid[$k] = $this->query($v);
				}

//			exit;
//			echo '~'.$append;
			if(@$this->cms_config['refresh']){
				
				if(@$this->cms_config['func_to_call_when_successful']) $this->cms_config['func_to_call_when_successful']();
				
				$url = $this->cms_config['refresh'];
				eval("\$url = \"$url\";");
				//echo $url;
				header("Refresh: 2; url={$url}");	
				echo '<br /><br /><div style="" align="center">
						<div style="font-family:Tahoma, Verdana, Arial; font-size:12px; color:#464646; border:1px solid #CCCCCC; padding:10px; width:500px">
							<img src="'.LIVE_DIR.'images/preloader.gif" />
							<br />Request Done. <br />Please wait while we redirect you.<br /> If redirection takes more than 10 seconds please <a href="index.php">click here</a>.
						</div>
					</div>';

				exit;
			}else{
				
				if(@$this->cms_config['func_to_call_when_successful']) $this->cms_config['func_to_call_when_successful']($lastinsertid);
				
			
				//echo '<pre>'.print_r($get_exif_uploaded, 1).'</pre>';	
				
				header("Refresh: 2; url=?{$append}");	
				echo '<br /><br /><div style="" align="center">
						<div style="font-family:Tahoma, Verdana, Arial; font-size:12px; color:#464646; border:1px solid #CCCCCC; padding:10px; width:500px">
							<img src="'.LIVE_DIR.'images/preloader.gif" />
							<br />Request Done. <br />Please wait while we redirect you.<br /> If redirection takes more than 10 seconds please <a href="index.php">click here</a>.
						</div>
					</div>';

				exit;
			}
			
	}
	
	function cms_query_edit(){

			global $ffmpeg_upload_data, $get_exif_uploaded;
		
			$id = intval(@trim($_GET['id']));
			$this->file_unset($id, TRUE);
			$upd_query = $this->cms_query_createdata(TRUE);
			//echo '<br>'.var_dump($upd_query).'<br>';
			if($this->query['table_type']==0)
				$this->update($this->query['table'], 
							'SET '.implode(', ', $upd_query).
							' WHERE '.$this->query['pkey'].' = '.$id).@$this->query['where_sec'];
			else{
				foreach($this->query['table'] as $k=>$v){
					$this->insert_ignore($v, $this->query['refkey'][$k], $id);
					//echo $v.'<br>';
				}
				//echo '<pre>'.print_r($this->query['refkey'], 1).'</pre>';
				list($table, $fields) = $this->create_multi_table();
				$this->update($table, 
						'SET '.implode(', ', $upd_query).
						' WHERE '.$this->query['pkey'].' = '.$id).@$this->query['where_sec'];
			}
			
			if(is_array(@$this->query['predefined_mysql']))
				foreach($this->query['predefined_mysql'] as $k=>$v){
					eval("\$v = \"$v\";");
					$predefined_lastinsertid[$k] = $this->query($v);
				}
			
			if(@$this->cms_config['refresh']){
				$url = $this->cms_config['refresh'];
				eval("\$url = \"$url\";");
//				echo $url;
				header("Refresh: 2; url={$url}");	
				echo '<br /><br /><div style="" align="center">
						<div style="font-family:Tahoma, Verdana, Arial; font-size:12px; color:#464646; border:1px solid #CCCCCC; padding:10px; width:500px">
							<img src="'.LIVE_DIR.'images/preloader.gif" />
							<br />Request Done. <br />Please wait while we redirect you.<br /> If redirection takes more than 10 seconds please <a href="index.php">click here</a>.
						</div>
					</div>';

				exit;
			}else{
				$append = $this->append_url();
				header("Refresh: 2; url=?{$append}");			
				echo '<br /><br /><div style="" align="center">
						<div style="font-family:Tahoma, Verdana, Arial; font-size:12px; color:#464646; border:1px solid #CCCCCC; padding:10px; width:500px">
							<img src="'.LIVE_DIR.'images/preloader.gif" />
							<br />Request Done. <br />Please wait while we redirect you.<br /> If redirection takes more than 10 seconds please <a href="index.php">click here</a>.
						</div>
					</div>';

				exit;
			}
	}
	
	function cms_query_delete($get_id){
		foreach($get_id as $k => $v){
			if(ctype_digit(trim($v))) $id[] = trim($v);
		}
		if(is_array($id)){
			$in_id = implode(', ', $id);
			$this->file_unset($in_id, TRUE);
			$clause = "WHERE {$this->query['pkey']} IN (".$in_id.")".@$this->query['where_sec'];
			if($this->query['table_type']==1){
				list($table, $fields) = $this->create_multi_table();
				$this->delete(implode(', ', $this->query['table']), 'USING '.$table.' '.$clause);
			}
			else $this->delete($this->query['table'], $clause);
			$append = $this->append_url();
			header("Refresh: 2; url=?{$append}");
				echo '<br /><br /><div style="" align="center">
						<div style="font-family:Tahoma, Verdana, Arial; font-size:12px; color:#464646; border:1px solid #CCCCCC; padding:10px; width:500px">
							<img src="'.LIVE_DIR.'images/preloader.gif" />
							<br />Request Done. <br />Please wait while we redirect you.<br /> If redirection takes more than 10 seconds please <a href="index.php">click here</a>.
						</div>
					</div>';

			exit;
		}
	}
	
	function cms_query_createdata($is_edit){
		
		

		foreach($this->cms_id as $k=>$v){
			$q = ($is_edit === TRUE) ? $v .' = ' : '';
			

			
			switch($this->cms_form[$k]){
				case 'password':
					if(!($is_edit === TRUE && strlen($this->clean[$v])<=0))
						$query[] = $q.'MD5("'.$this->clean[$v].'")';
				break;
				case 'image':
					if($this->clean[$v]['size'] > 0){
						$this->clean[$v] = $this->init_uploader($this->clean[$v], $this->cms_arg[$k]);
						if(strlen($this->clean[$v]) > 0)
							$query[] = $q.'"'.$this->clean[$v].'"';
					}elseif($this->action == 'add') $query[] = $q.'""';
				break;
				case 'file':
					if($this->clean[$v]['size'] > 0){
						$this->clean[$v] = $this->init_file_uploader($this->clean[$v], $this->cms_arg[$k]);
						if(strlen($this->clean[$v]) > 0)
							$query[] = $q.'"'.$this->clean[$v].'"';
					}elseif($this->action == 'add') $query[] = $q.'""';
					 
				break;
				case 'ffmpeg_video':
					
//					echo 'entered ffmpeg_video';
//					exit;

					if($this->clean[$v]['size'] > 0){
						$this->clean[$v] = init_ffmpeg_uploader($this->clean[$v], $this->cms_arg[$k]);
						if(strlen($this->clean[$v]) > 0){
							$query[] = $q.'"'.$this->clean[$v].'"';
						}
					}elseif($this->action == 'add') $query[] = $q.'""';

				break;
				default:
					if(is_array($this->clean[$v])) $this->clean[$v] = implode(', ', $this->clean[$v]);
					$query[] = $q.'"'.$this->clean[$v].'"';
				break;
			}
		}
		return($query);
	}
	
	function create_view_elements(&$arr_v){
			if($imgs = array_keys($this->cms_form, 'image')){
				foreach($imgs as $v){
					$asso_key = $this->cms_id[$v];
//					echo $this->cms_arg[$v]['location'].$this->cms_arg[$v]['append'].$arr_v[$asso_key];
					if(@file_exists($this->cms_arg[$v]['location'].$this->cms_arg[$v]['append'].$arr_v[$asso_key]) && $arr_v[$asso_key] != '')
						$arr_v[$asso_key] = '<img src="'.$this->cms_arg[$v]['live'].$this->cms_arg[$v]['append'].$arr_v[$asso_key].'" />';
					elseif(@file_exists($this->cms_arg[$v]['default']))
						$arr_v[$asso_key] = '<img src="'.$this->cms_arg[$v]['default'].'" />';
					else
						$arr_v[$asso_key] = ' - no image - ';
				}
			}
			if($files = array_keys($this->cms_form, 'file')){
				foreach($files as $v){
					$asso_key = $this->cms_id[$v];
					if(@file_exists($this->cms_arg[$v]['location'].$this->cms_arg[$v]['append'].$arr_v[$asso_key]) && $arr_v[$asso_key] != '')
						$arr_v[$asso_key] = '<a href="'.$this->cms_arg[$v]['live'].$arr_v[$asso_key].'" ><img border="0" src="'.LIVE_DIR.'images/icon_download.gif" /></a>';
					elseif(@file_exists($this->cms_arg[$v]['default']))
						$arr_v[$asso_key] = '<img src="'.$this->cms_arg[$v]['default'].'" />';
					else
						$arr_v[$asso_key] = ' --- ';
				}
			}
			if($datephp = array_keys($this->cms_form, 'datephp')){
				foreach($datephp as $v){
						$asso_key = $this->cms_id[$v];
						$arr_v[$asso_key] = date("M d, Y", strtotime($arr_v[$asso_key]));
				}
			}if($datephp = array_keys($this->cms_form, 'datephp-format2')){
				foreach($datephp as $v){
						$asso_key = $this->cms_id[$v];
						$arr_v[$asso_key] = date("d/m/Y", strtotime($arr_v[$asso_key]));
				}
			}
			if($imgs = array_keys($this->cms_form, 'image_ffmpeg')){
				foreach($imgs as $v){
					$asso_key = $this->cms_id[$v];
//					echo $this->cms_arg[$v]['location'].$this->cms_arg[$v]['append'].$arr_v[$asso_key];
					//echo '<pre>'..'</pre>';
					if(@file_exists($this->cms_arg[$v]['location'].$this->cms_arg[$v]['append'].$arr_v[$asso_key]) && $arr_v[$asso_key] != '')
						$arr_v[$asso_key] = '<img src="'.$this->cms_arg[$v]['live'].$this->cms_arg[$v]['append'].$arr_v[$asso_key].'" />';
					elseif(@file_exists($this->cms_arg[$v]['location'].$arr_v[$this->cms_arg[$v]['assoc']].'.jpg') && $arr_v[$this->cms_arg[$v]['assoc']].'.jpg' != '')
						$arr_v[$asso_key] = '<img src="'.$this->cms_arg[$v]['live'].$arr_v[$this->cms_arg[$v]['assoc']].'.jpg" />';
					elseif(@file_exists($this->cms_arg[$v]['default']))
						$arr_v[$asso_key] = '<img src="'.$this->cms_arg[$v]['default'].'" />';
					else
						$arr_v[$asso_key] = ' - no image - ';
				}
			}
//			echo '<pre>'.print_r($this->cms_arg, 1).'</pre>';
	}

	function maketemplate(){
		$cms['template'] = &$this->template;
		$cms['title'] = &$this->cms_title;
		$cms['id'] = &$this->cms_id;
		
		$cms['data'] = &$this->cms_data;
		@array_walk_recursive($cms['data'], '_stripslashes');
		
		$cms['filter'] = &$this->cms_filter;
		$cms['pager'] = &$this->cms_pager;
		$cms['action_link'] = &$this->cms_action_link;
		$cms['buttons'] = &$this->cms_buttons;
		$cms['error_msg'] = &$this->error_msg;
		$cms['config'] = $this->cms_config;
		$cms['clean'] = $this->clean;

		$append = $this->append_url();
		if(@$this->cms_config['with_selected'])
		$cms['with_selected'] = form_element('select', 'select', $this->cms_config['with_selected'], 
				' onchange="javascript: with_selected(this.form, this.value, \'?action=\'+this.value+\''.$append.'\', \'ck[]\')" ', '', $this->cms_config['with_selected']);
		$cms['filter'] = $this->filter;
		$cms['pager'] = $this->cms_pager;
//		$cms['form_param'] = $this->form_param;

		$this->content = load_template($cms);
			
	}

	function show_view_actions(){
		if($this->cms_data !== FALSE){
			if(@$this->cms_config['with_selected']){
				array_unshift($this->cms_title, form_element('ck_all', 'checkbox', '', 
							'onclick="javascript: check_all(this.form, this.checked, \'ck[]\')"'));
			}
				if(@$this->cms_config['action'] !== FALSE) array_push($this->cms_title, '&nbsp;&nbsp;&nbsp;Action&nbsp;&nbsp;&nbsp;');
	
			foreach($this->cms_data as $k=>$v){
				$this->action_link($this->cms_data_pkey[$k]);
				if(@$this->cms_config['with_selected']){
					$checkbox = form_element('ck[]', 'checkbox', $this->cms_data_pkey[$k]);
										//'<input type="checkbox" name="ck[]" id="ck[]" value="'.$this->cms_data_pkey[$k].'">';
					array_unshift($this->cms_data[$k], $checkbox);
				}
					if(@$this->cms_config['action'] !== FALSE) array_push($v, implode('&nbsp;', $this->action_link));
			}
		}
	}

	function cms_action_link(){
		$this->action_link(@intval($_GET['id']));
		$this->cms_action_link = @implode('&nbsp;&nbsp;', $this->action_link);
	}

	function action_link($id){
		$append = $this->append_url();
		if(@$this->cms_config['view'] !== FALSE)
			$this->action_link['view'] = '<a href="?action=detail&id='.$id.$append.'" title="'.@$this->cms_config['detail_title'].'"><img border="0" src="'.LIVE_DIR.'images/icon_view.gif"  alt="view" /></a>';
		if(@$this->cms_config['edit'] !== FALSE)
			$this->action_link['edit'] = '<a href="?action=edit&id='.$id.$append.'" title="'.@$this->cms_config['edit_title'].'" ><img border="0" src="'.LIVE_DIR.'images/icon_edit.gif"  alt="edit" /></a>';
		if(@$this->cms_config['delete'] !== FALSE)
			$this->action_link['delete'] = '<a href="javascript: delete_item(\'?action=delete&id='.$id.$append.'\')" title="'.@$this->cms_config['delete_title'].'"><img border="0" src="'.LIVE_DIR.'images/icon_del.gif"  alt="delete" /></a>';
		if(@$this->cms_config['command1'] === TRUE)
			$this->action_link['reply'] = '<a href="?action=command1&id='.$id.$append.'"><img border="0" src="'.LIVE_DIR.'images/icon_reply.gif"  alt="reply" /></a>';
		if(@$this->cms_config['cancel'] !== FALSE)
			$this->action_link['cancel'] = '<a href="?'.$append.'"><img border="0" src="'.LIVE_DIR.'images/icon_cancel.gif"  alt="cancel" /></a>';
		if(@$this->cms_config['others']){
			$url = $this->cms_config['others'];
			eval("\$url = \"$url\";");
			$this->action_link['others'] = $url;
		}
	}
	
	function append_url(){
		$append = '';
		$exemp = array('action', 'id', 'form_id');
		foreach($_GET as $k => $v){
			if(!in_array($k, $exemp))
				$append .= "&{$k}={$v}";
		}
		return($append);
	}
	
	function append_buttons($value){
		if(in_array('editor', $this->cms_form)){
			$submit_arg = 'onclick="javascript: ';
			foreach($this->cms_form as $k => $v){
				if($v == 'editor'){
					$submit_arg .= 'editor_to_text(this.form, \''.$this->cms_id[$k].'\'); ';
				}
			}
			$submit_arg .= '"';
		}
		$this->cms_buttons = form_element('submit', 'submit', $value[0], @$submit_arg.' class="input_button"').' '.form_element('reset', 'reset', $value[1], 'class="input_button"');
	}
	
	function text_to_editor(){
		if(in_array('editor', $this->cms_form)){
			$GLOBALS['onload_arg'] = ' onload="javascript: ';
			foreach($this->cms_form as $k => $v){
				if($v == 'editor'){
					$GLOBALS['onload_arg'] .= 'loadeditor(\''.$this->cms_id[$k].'\'); text_to_editor(this.form, \''.$this->cms_id[$k].'\'); ';
				}
			}
			$GLOBALS['onload_arg'] .= '"';
//			echo $GLOBALS['onload_arg'];
		}
	}
	
	function elements_to_form(){
//		for($x=0; $x<count($this->cms_data); $x++){
		$y=0; $x=0;

			foreach($this->cms_data[$x] as $k=>$v){
				if(@$this->cms_config['descriptive_key'] == true){
					$this->cms_data[$x][$k] = form_element($this->cms_id[$k], $this->cms_form[$k], @$this->cms_default[$k], @$this->cms_param[$k], @$this->err[$this->cms_id[$k]], @$this->cms_arg[$k], FALSE, @$this->cms_txtval[$k]);
				}else{
					$this->cms_data[$x][$k] = form_element($this->cms_id[$y], $this->cms_form[$y], $this->cms_default[$y], @$this->cms_param[$y], @$this->err[$this->cms_id[$y]], @$this->cms_arg[$y], FALSE, @$this->cms_txtval[$y]);
					//$v = form_element($this->cms_id[$y], $this->cms_form[$y], @$this->cms_default[$y], @$this->cms_param[$y], @$this->err[$this->cms_id[$y]], @$this->cms_arg[$y], FALSE, @$this->cms_txtval[$y]);
					$y++;
				}
			}
//		}
	}
	
	function make_form_reply(){
			foreach($this->cms_config['reply']['element'] as $k=>$v){
				$this->form_reply[] = form_element($v[0], $v[1], @$v[6], @$v[7], @$v[8], @$v[5]);
			}
	}
	
	function override_default_value($value){
//		for($x=0; $x<count($this->row); $x++){
			$x = 0;
			foreach($this->cms_default as $k=>$v){
				$this->cms_default[$k] = $value[$x][$this->cms_id[$k]];
//			}
		}
	}
	
	function override_default_value_filter($value){
//		for($x=0; $x<count($this->row); $x++){
			$x = 0;
			foreach($this->cms_default_filter as $k=>$v){
				//echo $k.'=>'.$v.'<br />';
				$this->cms_default_filter[$k] = @$value[$this->cms_id[$k]];
//			}
		}
	}
	
	function clean_user_input($input){
		array_walk_recursive($input, 'clean_post_recursive');
		$this->clean = $input;
		/*foreach($input as $k => $v)
			if(is_array($v))
				foreach($v as $k2 => $v2) $this->clean[$k][$k2] = mysql_real_escape_string($v2);
			else
				$this->clean[$k] = mysql_real_escape_string($v);
			unset($_POST, $_FILES);*/
	}
	
	function form_param(){
		$form_param = '';
		if(in_array('image', $this->cms_form) || in_array('file', $this->cms_form)) $form_param = 'enctype="multipart/form-data"';
		return($form_param);
	}
	
	function title_sort(&$title){
		if(@$this->cms_config['sort'] !== FALSE)
		foreach($title as $k=>$v){
			$action = '';
			if(@$this->cms_config['get_action'] === TRUE) $action = 'action='.htmlentities($_GET['action']).'&';
			$title[$k] = $v.'<a href="?'.$action.'sort='.$this->cms_id[$k].'&by=ASC"><img src="'.LIVE_DIR.'images/sort_asc.gif" border="0"></a>'
						.'<a href="?'.$action.'sort='.$this->cms_id[$k].'&by=DESC"><img src="'.LIVE_DIR.'images/sort_desc.gif" border="0"></a>';
		}
	}
	
	
	function createfilter(){
		if(in_array(1, $this->cms_filter)){
			$this->cms_default_filter = $this->cms_default;
			$this->override_default_value_filter($_GET);
			foreach($this->cms_filter as $k => $v){
				if($v === TRUE){
					//echo "$k => $v <br />";
					$this->filter[] = '<strong>'.$this->cms_title[$k].'</strong>:&nbsp;'.form_element($this->cms_id[$k], $this->cms_form[$k], @$this->cms_default_filter[$k], @$this->cms_param[$k], FALSE, @$this->cms_arg[$k], TRUE);//$k;
				}
			}
			$this->filter['submit'] = form_element('submit_filter', 'submit', '&nbsp;&nbsp;Filter Result&nbsp;&nbsp;');//$k;
		}
	}
	
	function file_unset($id, $size_ck = FALSE){
		$arr_unset = array('image', 'file', 'ffmpeg_video');
		$unset_type = @array_intersect($this->cms_form, $arr_unset);
		if(count($unset_type) > 0){
			foreach($unset_type as $k=>$v){
				$fields[$k] = $this->cms_id[$k];
			}
			$img_table = is_array($this->query['table']) ? $this->query['table'][0] : $this->query['table'];
			$row = $this->select($img_table, implode(', ', $fields), 'WHERE '.$this->query['pkey'].' IN ('.$id.')');
			foreach($row as $v){
				foreach($fields as $k2=>$v2){
					if($this->clean[$v2]['size'] > 0 || @$this->clean['isdel_'.$v2] == 'on'){
						if(in_array($this->cms_form[$k2], $arr_unset)){
							if(@$this->cms_arg[$k2]['size']){
									foreach($this->cms_arg[$k2]['size'] as $k3=>$v3){
										@unlink($this->cms_arg[$k2]['location'].$k3.$v[$v2]);
									}
							}
							@unlink($this->cms_arg[$k2]['location'].$v[$v2]);
//							echo '~~'.$this->cms_arg[$k2]['location'].$v[$v2];
						}
						//else echo '<br />~~'.$this->cms_arg[$k2]['location'].$v[$v2];
					}
					/*elseif(($this->action == 'delete' || $this->action == 'delete_selected') && $size_ck !== TRUE){ 
						@unlink($this->cms_arg[$k2]['location'].$v[$v2]);
					}*/
					elseif(($this->action == 'delete' || $this->action == 'delete_selected') && $size_ck === TRUE){
						if(@$this->cms_arg[$k2]['size']){
									if(@$this->cms_arg[$k2]['size'])
									foreach($this->cms_arg[$k2]['size'] as $k3=>$v3){
										@unlink($this->cms_arg[$k2]['location'].$k3.$v[$v2]);
									}
							}
							if($v[$v2]) unlink($this->cms_arg[$k2]['location'].$v[$v2]);
							if($this->cms_arg[$k2]['type'] == 'ffmpeg'){
								unlink($this->cms_arg[$k2]['location'].$v[$v2].'.jpg');
								unlink($this->cms_arg[$k2]['location'].$v[$v2].'_r.jpg');
								unlink($this->cms_arg[$k2]['location'].'t_'.$v[$v2].'.jpg');
								unlink($this->cms_arg[$k2]['location'].'r_'.$v[$v2].'.jpg');
							}
					}
				}
			}
		}
	}

	function create_multi_table(){
		$table = '';
		$fields = '';
		$table = @$this->query['table'][0];

		for($k=0; $k<(count($this->query['table'])-1); $k++)
		{
			$table .= @$this->query['join'][$k].@$this->query['table'][$k+1].@$this->query['on'][$k];
		}
		$fields = @implode(', ', @$this->query['fields']);
		return(array($table, $fields));
	}
}
?>