<?php
/*
// Author: Teodulo Otoman II [PHP Zend Certified Engineer / Co-Founder]
// Email: jhun.otoman@gmail.com
// URL: http://www.sproads.com
*/
class pager_class extends database_class{
	var $query, $currPage, $recCount, $appendToURL, $linktype;
	var $limit_stmt, $pager, $exemp, $totalRows;
	
	function __construct($var, $arg='num', $exemp = FALSE, $linktype=FALSE){
		if(strcmp(@$_GET['pager_view'], 'all')==0) return false;
		if($exemp == FALSE) $this->exemp = array('action', 'pagenum');
		else $this->exemp = $exemp;

		$this->linktype = $linktype;
		
		$this->appendToURL = $this->append_url();
		$this->currPage = (trim(is_numeric(@$_GET['pagenum'])))?$_GET['pagenum']:1;
		
		if($arg == 'sql'){ 
			$this->query = $var;
			$this->sql_pager();
		}elseif($arg == 'sql_union'){
			$this->query = $var;
			$this->sql_pager_union();
		}else{
			$this->totalRows = $var[0];
			$this->query['limit'] = $var[1];
		}
		
		//echo '<br />'.$this->totalRows.'<br /><br /><br />';
		
		$this->limit_stmt = ' LIMIT '.($this->currPage-1)*$this->query['limit'].', '.$this->query['limit']; #define limitation query
		$this->get_show_pages();
	}
	
	function sql_pager(){		
		$rec = $this->select($this->query['table'], 'count('.$this->query['pkey'].') as countx ', $this->query['where'].' LIMIT 0,1');
		$this->totalRows = $rec[0]['countx'];
	}

	function sql_pager_union(){		
		$rec = $this->select_union_count($this->query['query']);
		$this->totalRows = $rec;

//		echo var_dump($rec);
//		var_dump($this->totalRows);
		
		//$rec = $this->select_union('Select count('.$this->query['pkey'].') as countx  FROM '.$this->query['query'].' LIMIT 1');
		//$this->totalRows = $rec[0]['countx'];
	}
	
	function get_show_pages(){
		$this->recCount = ($this->totalRows > 0) ? ceil($this->totalRows/$this->query['limit']) : FALSE;
		$this->print_page_links();
	}
	
	function print_page_links(){
//		echo $this->linktype;
		$addpg = 0;
		if($this->currPage>3) $diffpg = 3;
		else $diffpg = $this->currPage-1;
		$subtBy3 = $this->recCount-3;
		if($this->currPage > $subtBy3) 
			$addpg = (($this->currPage-$subtBy3)>0)?$this->currPage-$subtBy3:0;

		if($this->recCount > 1){
			$this->pager.= "";
			

			
			
			
/*pager for canon*/
		

			$this->pager .= '<br><div style="float:left;">';
			
			
			for($totpg = 0; $totpg < 7; $totpg++){
				$pgLink = $this->currPage+$totpg-$diffpg-$addpg;
				if($this->currPage == $pgLink)
				$this->pager.= ($pgLink<=$this->recCount && $pgLink > 0)?"<strong class=\"pagerx\">".$pgLink."</strong>":"";
				else{
					$a_link = ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}{$this->appendToURL}&pagenum={$pgLink}', '{$this->linktype['spanid']}');\" class=\"pager\">" : "<a href=\"{$_SERVER['PHP_SELF']}?{$this->appendToURL}&pagenum={$pgLink}".@$this->query['append']."\" class=\"pager\">";
					$this->pager.= ($pgLink<=$this->recCount && $pgLink > 0) ? $a_link.$pgLink."</a>":"";
				}
			}

			
			$this->pager .= '</div><div style="float:right">';
			
			//if($this->recCount > 7)	{ 
				$prev = ($this->currPage > 1) ? $this->currPage-1 : 1;
				$this->pager.= ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}&pagenum={$prev}', '{$this->linktype['spanid']}');\" class=\"pager previouspager\"><< Previous</a>" : "<a href=\"{$_SERVER['PHP_SELF']}?{$this->appendToURL}&pagenum={$prev}".@$this->query['append']."\" class=\"pager previouspager\"><< Previous</a>";
			//}
			
			$this->pager .= ' || ';
			
			//if($this->recCount > 7)	{ 
				$next = ($this->currPage < $this->recCount) ? $this->currPage+1 : $this->recCount;
				$this->pager.= ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}&pagenum={$next}', '{$this->linktype['spanid']}');\" class=\"pager nextpager\">Next >></a>" : "<a href=\"{$_SERVER['PHP_SELF']}?{$this->appendToURL}&pagenum={$next}".@$this->query['append']."\" class=\"pager nextpager\">Next >></a>";

			//}
			
			//if($this->linktype['type'] != 'ajax') $this->pager.= '&nbsp;&nbsp;<a href="?'.$_SERVER['QUERY_STRING'].'&pager_view=all'.@$this->query['append'].'" class="pager">View All</a>';
			
			$this->pager .= '</div><div style="clear:both"></div>';
			
/*pager for canon*/
			












/*			//if($this->recCount > 7)	{ 
				$prev = ($this->currPage > 1) ? $this->currPage-1 : 1;
				$this->pager.= ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}', '{$this->linktype['spanid']}');\" class=\"pager firstpager\">First</a>" : "<a href=\"?{$this->appendToURL}&pagenum=1".@$this->query['append']."\" class=\"pager lastpager\">First</a>";
				$this->pager.= ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}&pagenum={$prev}', '{$this->linktype['spanid']}');\" class=\"pager previouspager\"><<</a>" : "<a href=\"?{$this->appendToURL}&pagenum={$prev}".@$this->query['append']."\" class=\"pager previouspager\"><<</a>";
			//}
			
			
			for($totpg = 0; $totpg < 7; $totpg++){
				$pgLink = $this->currPage+$totpg-$diffpg-$addpg;
				if($this->currPage == $pgLink)
				$this->pager.= ($pgLink<=$this->recCount && $pgLink > 0)?"<strong class=\"pagerx\">".$pgLink."</strong>":"";
				else{
					$a_link = ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}{$this->appendToURL}&pagenum={$pgLink}', '{$this->linktype['spanid']}');\" class=\"pager\">" : "<a href=\"?{$this->appendToURL}&pagenum={$pgLink}".@$this->query['append']."\" class=\"pager\">";
					$this->pager.= ($pgLink<=$this->recCount && $pgLink > 0) ? $a_link.$pgLink."</a>":"";
				}
			}


			
			//if($this->recCount > 7)	{ 
				$next = ($this->currPage < $this->recCount) ? $this->currPage+1 : $this->recCount;
				$this->pager.= ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}&pagenum={$next}', '{$this->linktype['spanid']}');\" class=\"pager nextpager\">>></a>" : "<a href=\"?{$this->appendToURL}&pagenum={$next}".@$this->query['append']."\" class=\"pager nextpager\">>></a>";
				$this->pager.= ($this->linktype['type'] == 'ajax') ? "<a href=\"javascript: ajax('{$this->linktype['url']}&pagenum={$this->recCount}', '{$this->linktype['spanid']}');\" class=\"pager lastpager\">Last</a>" : "<a href=\"?{$this->appendToURL}&pagenum={$this->recCount}".@$this->query['append']."\"  class=\"pager lastpager\">Last</a>";
			//}

		
			
			if($this->linktype['type'] != 'ajax') $this->pager.= '&nbsp;&nbsp;<a href="?'.$_SERVER['QUERY_STRING'].'&pager_view=all'.@$this->query['append'].'" class="pager">View All</a>';	
			$GLOBALS['ispager'] = true;*/
			
		}
	}
	
	function append_url(){
		$append = '';
		foreach($_GET as $k => $v){
			if(!in_array($k, $this->exemp))
				$append .= "&{$k}={$v}";
		}
		return($append);
	}

}
?>