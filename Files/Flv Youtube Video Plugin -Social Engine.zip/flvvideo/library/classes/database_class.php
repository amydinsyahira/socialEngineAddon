<?php
/*
// Author: Teodulo Otoman II [PHP Zend Certified Engineer / Co-Founder]
// Email: jhun.otoman@gmail.com
// URL: http://www.sproads.com
*/
class database_class{

var $db;
	
	function __construct(){
		global $conf;

		$db = mysql_connect($conf['db_host'], $conf['db_user'], $conf['db_pass']);

		mysql_select_db($conf['db_name'],$db);
		$this->db = $db;
	}
	
	function select($table, $fields, $clause="")
	{
			$query = 'SELECT '.$fields.' FROM '.$table. ' '.$clause;
			//echo '<pre>'.htmlentities($query).'</pre>';
			$result = mysql_query($query) or die("MySQL SELECT error: ".mysql_error()."<br>".$query);

			while ($r = mysql_fetch_array($result,MYSQL_ASSOC)){
					$row[] = $r;
			}
			
			mysql_free_result($result);

			return @$row;
	}
	
/*	function countdb($table,$fields, $clause)
	{
		$fields = $fields;
		$table = $table;
		if($query = mysql_query("SELECT $fields FROM $table $clause"))
			$count = mysql_num_rows($query);
		//echo $count;
		//echo mysql_error();
//		mysql_free_result($query)
		return($count);
	}*/

	function insert($table, $fields, $values, $arg='')
	{
			$query = "INSERT INTO ".$table." (".$fields.") VALUES (".$values.") ".$arg.';';
			//echo '<pre>'.$query.'</pre><br>';
			
			//exit;
			
			mysql_query($query) or die("MySQL INSERT error: ".mysql_error().'<br />'.$query);
			return mysql_insert_id();
	}
	
	function insert_ignore($table, $fields, $values)
	{
			$query = "INSERT IGNORE INTO ".$table." (".$fields.") VALUES(".$values.")";
			//echo $query.'<br>';
			mysql_query($query) or die("MySQL INSERT error: ".mysql_error().'<br />'.$query);
			return mysql_insert_id();
	}

	function update($table, $clause)
	{
			$query = "UPDATE ".$table." ".$clause;
			//echo '<pre>'.$query.'</pre><br>';
			mysql_query($query) or die("MySQL UPDATE error: ".mysql_error().'<pre>'.$query.'</pre><br>');
	}

	function delete($table, $clause)
	{
//		mysql_query("START TRANSACTION");
		$query = "DELETE FROM ".$table." ".$clause;
		//echo $query;
		mysql_query($query) or die("MySQL DELETE error: ".mysql_error().'<br />'.$query);
	}
	
	function query($q){
//		echo '<pre>'.$q.'</pre><br>';
//		exit;
		mysql_query($q) or die("MySQL Query error: ".mysql_error().'<br />'.$q);
		return mysql_insert_id();
//		sleep(1);
	}

	function select_union($q){
		$result = mysql_query($q) or die("MySQL Query error: ".mysql_error().'<br /><pre>'.$q.'</pre>');
//		echo $q.'<br /><br />';

		while ($r = mysql_fetch_array($result,MYSQL_ASSOC)){
				$row[] = $r;
		}
		
		mysql_free_result($result);

		return @$row;
	}
	
	function select_union_count($q){
		$result = mysql_query($q) or die("MySQL Query error: ".mysql_error().'<br /><pre>'.$q.'</pre>');
		//echo $q.'<br /><br />';
//		return($query);
		$total = 0;
		while ($r = mysql_fetch_array($result,MYSQL_ASSOC)){
			$total += $r['countx'];
//			var_dump($r);
		}
		
		mysql_free_result($result);

		return @$total;
	}
}

?>