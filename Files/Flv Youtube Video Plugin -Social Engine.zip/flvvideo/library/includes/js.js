var browser;

//alert('test');

function createRequestObject() {
    var ro;
    browser = navigator.appName;
    if(browser == "Microsoft Internet Explorer"){
        ro = new ActiveXObject("Microsoft.XMLHTTP");
    }else{
        ro = new XMLHttpRequest();
    }
    return ro;
//	asynchronous:true;
}
var http = createRequestObject();

function funcajax(url,id){
	url += "&wbs="+Math.random();
//	alert(url);
	http.open('get', url);
	http.onreadystatechange = function() {
		if(http.readyState == 4) {
//			alert(http.responseText);
			if(http.responseText != null || http.responseText != "") {
				if(id){
					document.getElementById(id).innerHTML = http.responseText;
				}
			}
		}
	}		

	http.send(null);
}

function check_all(frm, arg, id){
//	alert(frm.elements.length);
	for($x=0; $x<frm.elements.length; $x++)
		if(frm.elements[$x].id == id) frm.elements[$x].checked = arg;
//	alert(frm);
}

//var preload = '<br /><br /><br /><center><img src="http://localhost/clubeos/images/preloader.gif" /></center><br /><br /><br />';
var preload = '<div align="center" class="err">Loading ... </div>';

function ajax(url, spanid, type){
//	alert(url+"\n"+spanid+"\n");
	if(type=='float'){
		document.getElementById(spanid).className = 'show_float';
//		document.getElementById(id).className = 'show_float';
	}
	document.getElementById(spanid).innerHTML = preload;
	setTimeout("funcajax('"+url+"', '"+spanid+"');", 500);
//	funcajax(url, spanid)
}

function ajax2(url, spanid, type){
//	alert(url+"\n"+spanid+"\n");
	if(type=='float'){
		document.getElementById(spanid).className = 'show_float';
//		document.getElementById(id).className = 'show_float';
	}
//	document.getElementById(spanid).innerHTML = preload;
	setTimeout("funcajax('"+url+"', '"+spanid+"');", 500);
//	funcajax(url, spanid)
}


/*function ajax_link(url, spanid, linkid){
	alert(url+"\n"+spanid+"\n"+linkid);
}*/

function unfloat(id){
	document.getElementById(id).className = 'float';
}

function with_selected(frm, action, formaction, id){
	var ck = false;
	for($x=0; $x<frm.elements.length; $x++)
		if(frm.elements[$x].id == id && frm.elements[$x].checked == true) ck = true;
	
	if(ck == false){
		alert('No item was checked. \nPlease check at least one item to proceed.');
	}else if(action != ''){
//		alert('No actio was checked. \nPlease check at least one item to proceed.');
		var conf = confirm("Cick OK to confirm");
		if(conf){
			frm.action = formaction+'&form_id='+id;
			frm.submit();
		}
	}
//	alert(action+' => '+ck)
}

function lookup_calendar(id){
	
	
	
	var span_id = document.getElementById('span_'+id);
	var elem_id = document.getElementById(id);
	span_id.className = 'show_float';
//	alert(span_id.className);
//	alert(id);
}

function accept_lookup(id){
	var span_id = document.getElementById('span_'+id);
	var elem_id = document.getElementById(id);
	var mo = document.getElementById(id+'_m');
	var da = document.getElementById(id+'_d');
	var ye = document.getElementById(id+'_y');

	span_id.className = 'float';
	elem_id.value = ye.value+'-'+mo.value+'-'+da.value;
}

function delete_item(url){
	var conf = confirm("Cick OK to confirm");
		if(conf){
			location.replace(url);//frm.submit();
		}
}



/*function URLDecode (encodedString) {
  var output = encodedString;
  var binVal, thisString;
  var myregexp = /(%[^%]{2})/;
  while ((match = myregexp.exec(output)) != null
             && match.length > 1
             && match[1] != '') {
    binVal = parseInt(match[1].substr(1),16);
    thisString = String.fromCharCode(binVal);
    output = output.replace(match[1], thisString);
  } 
   
  return output;

}*/
function callFormatting(sFormatString){
	document.execCommand(sFormatString);
}

function editorCommand(editor, command, option) {
    var mainField;
	var browser;
	
    browser = navigator.appName;
	
    if(browser != "Microsoft Internet Explorer"){  
		mainField = document.getElementById(editor).contentWindow;
	}else{
		mainField = document.getElementById(editor);
	}
	
   try {
        mainField.focus();
        mainField.document.execCommand(command, false, option);
//		document.execCommand(sFormatString);
        mainField.focus();
    } catch (e) { alert("error"); }
}

function loadeditor(editor){
	var browser;
	
    browser = navigator.appName;
	
    if(browser != "Microsoft Internet Explorer"){  
		document.getElementById(editor).contentDocument.designMode='On'; 
	}
}


/*function multibacktocontent(){
	
	var newname;
	var hiddenname;
	var elemlist = document.getElementsByTagName("input");
	var browser = navigator.appName;
	
	for(var x=0;x<elemlist.length;x++){
	
		if(elemlist[x].className == 'hidden'){
			hiddenname = elemlist[x].name;
			newname = elemlist[x].name.replace('hidden','');

			if(browser == "Microsoft Internet Explorer") {
//				alert("multibacktocontent");
				document.getElementById(newname).innerHTML = URLDecode(document.getElementById('hidden'+hiddenname).value);
			}else{
//				alert(URLDecode(document.getElementById(hiddenname).value));
				document.getElementById(newname).contentDocument.body.innerHTML = URLDecode(document.getElementById('hidden'+hiddenname).value);
			}
		}	
		
	}
}*/

function text_to_editor(frm, name){
	var browser = navigator.appName;
	document.getElementById(name).contentDocument.designMode='On'; 
//	alert('~'+document.getElementById('hidden'+name).value);
	if(browser == "Microsoft Internet Explorer") {
		document.getElementById(name).innerHTML = document.getElementById('hidden'+name).value;
	}else{
		document.getElementById(name).contentDocument.body.innerHTML = document.getElementById('hidden'+name).value;
	}
}

function editor_to_text(frm, name){
	var browser = navigator.appName;
	document.getElementById(name).contentDocument.designMode='On'; 
//	alert('~'+document.getElementById('hidden'+name).value);
	if(browser == "Microsoft Internet Explorer") {
		document.getElementById('hidden'+name).value = document.getElementById(name).innerHTML;
	}else{
		document.getElementById('hidden'+name).value = document.getElementById(name).contentDocument.body.innerHTML;

	}
}

function textAreaLimit(limitField, limitCount, limitNum) 
{
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} 
	else {
		limitCount.value = limitNum - limitField.value.length;
	}
//	alert(limitField.value.length+' > '+limitNum);
}

function check_not_empty(elem, frm){
	if(elem.value.length < 1){
		alert('You can\'t send empty content!');
		return false;
	}
	else if(elem.value.length < 3){
		alert('Your content is too short!');
		return false;
	}
	else{
		return true;
	}
}

/*
function multisubmit(thisform){
//	alert("enter");	
	var newname;
	var hiddenname;
	var elemlist = document.getElementsByTagName("input");
	var browser = navigator.appName;
	
	for(var x=0;x<elemlist.length;x++){
	
		if(elemlist[x].className == 'hidden'){
			hiddenname = elemlist[x].name;
			newname = elemlist[x].name.replace('hidden','');

			if(browser == "Microsoft Internet Explorer") {
//				alert("IE");
//				alert(document.getElementById(newname).innerHTML);
				document.getElementById('hidden'+hiddenname).value = document.getElementById(newname).innerHTML;
	
			}else{
//				alert("mozilla");
//alert('hidden'+hiddenname + newname);
//				alert(document.getElementById(newname).contentDocument.body.innerHTML);
				document.getElementById('hidden'+hiddenname).value = document.getElementById(newname).contentDocument.body.innerHTML;

			}
		}	
		
	}
				thisform.method = 'POST';
				//thisform.action = url;
				thisform.submit();	
} 

function ranksubmit(thisform){
//	alert("enter");	
	var newname;
	var hiddenname;
	var elemlist = document.getElementsByTagName("select");
	var browser = navigator.appName;
	
	for(var x=0;x<elemlist.length;x++){
	
		if(elemlist[x].className == 'hidden'){
			hiddenname = elemlist[x].name;
			newname = elemlist[x].name.replace('hidden','');

			if(browser == "Microsoft Internet Explorer") {
//				alert("IE");
//				alert(document.getElementById(newname).innerHTML);
				document.getElementById('hidden'+hiddenname).value = document.getElementById(newname).innerHTML;
	
			}else{
//				alert("mozilla");
//alert('hidden'+hiddenname + newname);
//				alert(document.getElementById(newname).contentDocument.body.innerHTML);
				document.getElementById('hidden'+hiddenname).value = document.getElementById(newname).contentDocument.body.innerHTML;

			}
		}	
		
	}
				thisform.method = 'POST';
				//thisform.action = url;
				thisform.submit();	
}*/


/*function submitone(thisform,url){
//	alert("enter");	
	var browser = navigator.appName;
//	alert(thisform);
//	alert(browser);

	if(browser == "Microsoft Internet Explorer") {
//		alert("IE");
//		alert(document.getElementById(newname).innerHTML);
		document.getElementById("hiddencontent").value = document.getElementById("content").innerHTML;
		thisform.submit();	
	
	}else{
//		alert("mozilla");
//		alert(document.getElementById(newname).contentDocument.body.innerHTML);
		document.getElementById("hiddencontent").value = document.getElementById("content").contentDocument.body.innerHTML;
//		alert();
		thisform.method = 'POST';
		thisform.action = url;
//		document.myform.submit();
		thisform.submit();
	}

	//thisform.method = 'POST';
	//thisform.action = url;

}*/
function expand(id, live_dir){
	var img = 'img_'+id;
	var div = 'div_'+id;
	if(document.getElementById(div).className == 'hide'){
		document.getElementById(div).className = 'unhide';
		document.getElementById(img).src = live_dir+"images/icon_minus.gif";
//		alert("<?=LIVE_DIR?>images/icon_minus.gif");
	}else if(document.getElementById(div).className == 'unhide'){
		document.getElementById(div).className = 'hide';
		document.getElementById(img).src = live_dir+"images/icon_plus.gif";
//		alert("<?=LIVE_DIR?>images/icon_minus.gif");
	}
	//alert(document.getElementById(div).className);
}

function classname(id, classx){
	document.getElementById(id).className = classx;
}