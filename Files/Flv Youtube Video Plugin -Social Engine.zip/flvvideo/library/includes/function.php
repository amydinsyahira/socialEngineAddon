<?php
/*
// Author: Teodulo Otoman II [PHP Zend Certified Engineer / Co-Founder]
// Email: jhun.otoman@gmail.com
// URL: http://www.sproads.com
*/

//echo 'execution time: '.ini_get("max_execution_time").'<br>max input time: '.ini_get("max_input_time").'<br>memory limit: '.ini_get("memory_limit").'<br>max size: '.ini_get("post_max_size").'<br>upload max filesize: '.ini_get("upload_max_filesize").'<br>';

function __autoload($classname){
	if($classname != 'ffmpeg_movie') include_once(LIB_DIR."classes/{$classname}.php");
}

function form_element($cms_id, $cms_form, $cms_default='', $cms_param='', $err='', $arg='', $filter=FALSE, $txtvalue=''){

	switch($cms_form){
		case 'textbox':
//			echo '~~'.$cms_default;
			$element = '<input type="text" name="'.$cms_id.'" id="'.$cms_id.'" value="'.@stripslashes(htmlentities($cms_default)).'" '.$cms_param.'/>'.$err.$txtvalue;
		break;
		case 'hidden':
			$element = '<input type="hidden" name="'.$cms_id.'" id="'.$cms_id.'" value="'.@stripslashes(htmlentities($cms_default)).'" '.$cms_param.'/>'.$err;
		break;
		case 'textarea':
			$err = ($err) ? $err.'<br>' : $err;
			$element = $txtvalue.$err.'<textarea name="'.$cms_id.'" id="'.$cms_id.'" '.$cms_param.'>'.@stripslashes(htmlentities($cms_default)).'</textarea>';
		break;
		case 'textarea_limit':
//			list($textarea, $char_counter) = textarea_elements($arg['limit'], $cms_id, $cms_default);
			$textarea = '<textarea name="'.$cms_id.'" rows="8" style="overflow:auto; width:98%" onKeyDown="textAreaLimit(this.form.'.$cms_id.',this.form.'.$cms_id.'_ctr,'.$arg['limit'].');" onKeyUp="textAreaLimit(this.form.'.$cms_id.',this.form.'.$cms_id.'_ctr,'.$arg['limit'].');" '.$cms_param.'>'.$cms_default.'</textarea>';
			$char_counter = '<input name="charCtr" type="text" id="'.$cms_id.'_ctr" value="'.($arg['limit']-strlen($cms_default)).'" size="5" maxlength="4" readonly="readonly"  class="input" />';
			if($err)  $err .= '<br/>';
			$element = $err.
				'<div style="padding:5px 0px 2px 0px" align="left">'.$textarea.'</div>'.
				'<div style="float:right" style="white-space:nowrap">Characters Remaining: '.$char_counter.'&nbsp;&nbsp;</div>';
		break;
		case 'fckeditor':
			include_once(FCK_LIBRARY."fckeditor.php") ;
			$sBasePath = FCK_BASEDIR;

			$oFCKeditor = new FCKeditor($cms_id) ;
			$oFCKeditor->BasePath = $sBasePath ;
			$oFCKeditor->Value = $cms_default;
			
			ob_start();
			echo $err;
			$oFCKeditor->Create() ;
			$element = ob_get_contents();
			ob_end_clean();

		break;
		case 'fckeditor_basic':
			include_once(FCK_LIBRARY."fckeditor.php") ;
			$sBasePath = FCK_BASEDIR;
			

			$oFCKeditor = new FCKeditor($cms_id) ;
			$oFCKeditor->BasePath = $sBasePath ;
			$oFCKeditor->Value = $cms_default;
			$oFCKeditor->ToolbarSet = 'Basic';
			ob_start();
			echo $err;
			$oFCKeditor->Create() ;
			$element = ob_get_contents();
			ob_end_clean();
		break;
		case 'textpassword':
			$element = '<input type="password" name="'.$cms_id.'" id="'.$cms_id.'" value="'.stripslashes($cms_default).'" '.$cms_param.'/>'.$err;
		break;
		case 'checkbox':
			$element = '<input type="'.$cms_form.'" name="'.$cms_id.'" id="'.$cms_id.'" value="'.stripslashes($cms_default).'" '.$cms_param.' class="no_border" />'.$err;
		break;
		case 'select':
			if($filter === TRUE) $arg = array(''=>'All') + $arg;
			$element = '<select name="'.$cms_id.'" id="'.$cms_id.'" '.$cms_param.'>';
			foreach($arg as $k => $v){
				$sel = ($k == $cms_default) ? 'selected="selected"' : '';
				$element .= '<option value="'.$k.'" '.$sel.'>'.$v.'</option>';
			}
			$element .= '</select>'.$err;
		break;
		case 'select-multiple':
			if($filter === TRUE) $arg = array(''=>'All') + $arg;
			$element = '<select name="'.$cms_id.'[]" id="'.$cms_id.'[]" '.$cms_param.' multiple="multiple">';
			
			$sel = (@in_array($k, $cms_default)) ? 'selected="selected"' : '';
			$element .= '<option value="" '.$sel.' selected="selected"> - Please Select - </option>';
			
			foreach($arg as $k => $v){
				$sel = (@in_array($k, $cms_default)) ? 'selected="selected"' : '';
				$element .= '<option value="'.$k.'" '.$sel.'>'.$v.'</option>';
			}
			$element .= '</select>'.$err;
		break;
		case 'selectdb':
			global $db;
			
			//echo '--'.$arg['db_clause'];
			
			$row = $db->select($arg['db_table'], implode(', ', $arg['db_fields']), @$arg['db_clause']);
			
			if($filter === TRUE) { $row = ($row) ? array(''=>array($arg['db_fields'][0]=>'', $arg['db_fields'][1]=>'All')) + $row : array(''=>array($arg['db_fields'][0]=>'', $arg['db_fields'][1]=>'All')); }
			$element = '<select name="'.$cms_id.'" id="'.$cms_id.'" '.$cms_param.'>';
			$element .= '<option value=""> - </option>';
			foreach($row as $v){
				$value = $v[$arg['db_fields'][0]];
				$sel = (trim($value) == trim($cms_default)) ? 'selected="selected"' : '';
				$element .= '<option value="'.trim($value).'" '.$sel.'>'.$v[$arg['db_fields'][1]].'</option>';
			}
			$element .= '</select>'.$err;
		break;
		case 'selectdb-multiple':
			global $db;
			$row = $db->select($arg['db_table'], implode(', ', $arg['db_fields']), @$arg['db_clause']);
			
			if($filter === TRUE) { $row = ($row) ? array(''=>array($arg['db_fields'][0]=>'', $arg['db_fields'][1]=>'All')) + $row : array(''=>array($arg['db_fields'][0]=>'', $arg['db_fields'][1]=>'All')); }
			$element = $err.'<br /><select name="'.$cms_id.'[]" id="'.$cms_id.'[]" '.$cms_param.' multiple="multiple">';
			$element .= '<option value=""> - </option>';
			foreach($row as $v){
				$value = $v[$arg['db_fields'][0]];
				$sel = (@in_array($value, $cms_default)) ? 'selected="selected"' : '';
				$element .= '<option value="'.$value.'" '.$sel.'>'.$v[$arg['db_fields'][1]].'</option>';
			}
			$element .= '</select>';
		break;
		case 'radio':
			if($filter === TRUE) $arg = array(''=>'All') + $arg;
			$element = '';
			foreach($arg as $k => $v){
				if(!isset($cms_default)) $cms_default = $k;
				$check = $cms_default == $k ? ' checked="checked" ' : '';
				$element .= '<input type="'.$cms_form.'" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$k.'" '.$cms_param.$check.'/>'.$v;
			}
			$element .= $err;
		break;
		case 'password':
			global $cms;
			//$msg = (!$err && $cms->action=='edit') ? '&nbsp;*please leave blank if not intended to change' : '';
			$msg = '';
			$element = '<input type="'.( @$_POST[$cms_id] ? 'password' : 'text').'" name="'.$cms_id.'" '.$cms_param.' onfocus="this.type=\'password\'" onclick="this.type=\'password\'" value="'.@$_POST[$cms_id].'" />';
			$element .= '&nbsp;&nbsp;&nbsp;<strong>Confirm:</strong> <input type="password" name="conf_'.$cms_id.'" id="conf_'.$cms_id.'" '.$cms_param.' value="'.@$_POST['conf_'.$cms_id].'"/>'.$msg.$err;
		break;
		case 'username':
			global $cms;
			if($cms->action == 'edit') { $readonly = 'readonly = "readonly"'; $msg = '*username is not editable'; };
			$element = '<input type="text" name="'.$cms_id.'" id="'.$cms_id.'" value="'.stripslashes($cms_default).'" '.$cms_param.' '.@$readonly.'/>'.@$msg.$err;
		break;
		case 'username-editable':
			global $cms;
			$element = '<input type="text" name="'.$cms_id.'" id="'.$cms_id.'" value="'.stripslashes($cms_default).'" '.$cms_param.' />'.$err;
		break;
		case 'email_confirm':
			global $cms;
			$msg = (!$err && $cms->action=='edit') ? '&nbsp;*please leave blank if not intended to change' : '';
			$element = '<input type="textbox" name="'.$cms_id.'" '.$cms_param.' value="'.stripslashes($cms_default).'" />';
			$element .= '&nbsp;&nbsp;&nbsp;<strong>Email Confirm:</strong> <input type="textbox" name="conf_'.$cms_id.'" id="conf_'.$cms_id.'" '.$cms_param.' value="'.stripslashes($cms->clean['conf_'.$cms_id]).'"/>'.$msg.$err;
		break;
		case 'date':
			$cms_default = stripslashes($cms_default);
			@list($today['y'], $today['m'], $today['d']) = explode('-', $cms_default);
			
			$element = '<span><input type="text" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.'/> 
			<a href="javascript: lookup_calendar(\''.$cms_id.'\');">[look-up]</a>&nbsp;</span>
				<span id="span_'.$cms_id.'" class="float">'.load_template(array('template'=>TPL.'look_up_date.tpl.php', 'id'=>$cms_id, 'value'=>$cms_default, 'today'=>$today)).'</span>'.$err;
		break;
		case 'date_calendar':
			$cms_default = stripslashes($cms_default);
			@list($today['y'], $today['m'], $today['d']) = explode('-', $cms_default);
			
			$element = '<span><input type="text" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.'/> 
			<a href="javascript: lookup_calendar(\''.$cms_id.'\');">[look-up]</a>&nbsp;</span>
				<span id="span_'.$cms_id.'" class="float">'.load_template(array('template'=>TPL.'look_up_calendar.tpl.php', 'id'=>$cms_id, 'value'=>$cms_default, 'today'=>$today)).'</span>'.$err;
		break;
		case 'time':
			$element = '<select name="'.$cms_id.'" id="'.$cms_id.'" '.$cms_param.'>';
			for($temp=0; $temp<2; $temp++){
			if($temp == 0) { $zone = 'AM'; $plhour = 0; }
			else{ $zone = 'PM';  $plhour = 12; }
			
				for($h=0; $h<12; $h++){
					for($m=0;$m<=59; $m+=15){
						$h = str_pad($h, 2, 0, STR_PAD_LEFT);
						$m = str_pad($m, 2, 0, STR_PAD_RIGHT);
						$tv = "$h:$m";
						$tk = ($h+$plhour).":$m:00";
						$slctstat = ($cms_default == $tk) ? "selected = 'selected'" : '';
						$element .= "<option value=\"$tk\" $slctstat >$tv $zone</option>";
					}
				}
			}
			$element .= "</select>";
//			<input type="text"  value="'.$cms_default.'" />';
		break;
		case 'image':
			global $cms;
			if(!$err && @$cms->action=='edit'){
				$msg = '&nbsp;*browse other to change';
				$is_del = '<br /><input type="checkbox" name="isdel_'.$cms_id.'" id="isdel_'.$cms_id.'" /> Check to delete<br />';
			}
			//echo $arg['location'].$arg['append'].$cms_default;
			$img = file_exists($arg['location'].$arg['append'].$cms_default) && $cms_default != '' 
						? '<img src="'.$arg['live'].$arg['append'].$cms_default.'" /><br />' : '';
			$element = $img.'<input type="file" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.'/>'.@$msg.$err.$txtvalue.@$is_del;
		break;
		case 'image_ffmpeg':
			global $cms;
			$msg = (!$err && $cms->action=='edit') ? '&nbsp;*please leave blank if not intended to change' : '';
//			echo $arg['location'].$arg['append'].$cms_default;
			$img = file_exists($arg['location'].$arg['append'].$cms_default) && $cms_default != '' 
						? '<img src="'.$arg['live'].$arg['append'].$cms_default.'" /><br />' : '';
			$element = $img.'<input type="file" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.'/>'.$msg.$err;
		break;
		case 'file':
			global $cms;
			
			$file = file_exists($arg['location'].$cms_default) && $cms_default != '' 
						? '<a href="'.$arg['live'].$cms_default.'"><img src="../images/icon_download.gif" border="0" /></a>&nbsp;' : '';
			
			$msg = (!$err && $cms->action=='edit') ? '&nbsp;*please leave blank if not intended to change' : '';
			$element = $file.'<input type="file" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.'/>'.$msg.$err.$txtvalue;
		break;
		case 'ffmpeg_video':
			global $cms;
			$msg = (!$err && $cms->action=='edit') ? '&nbsp;*please leave blank if not intended to change' : '';
			$element = '<input type="file" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.'/>'.$msg.$err.$txtvalue;
		break;
		case 'editor':
//			$element .= $contentofeditor;
			$element = $err.'<br>'.displayeditor($cms_id,"500","100%",$cms_default);
		break;
		case 'xml-pkey':
//			$element .= $contentofeditor;
			$element = '<em>auto generated content</em>';
		break;
		case 'submit':
			$element = '<input type="'.$cms_form.'" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.' />';
		 break;
		case 'reset':
			$element = '<input type="'.$cms_form.'" name="'.$cms_id.'" id="'.$cms_id.'" value="'.$cms_default.'" '.$cms_param.'/>';
		break;
/*		case 'select':
			$element = '<select name="'.$cms_id.'" id="'.$cms_id.'" '.$cms_param.'>';
			foreach($arg as $k=>$v){
				$element .= '<option value="'.$k.'">'.$v.'</option>';
			}
			$element .= '</select>';
		break;*/
		case 'datetext':
//			echo '~~'.strtotime($cms_default);
			$element = date('m y d', strtotime($cms_default));
		break;
		default:
			$element = 'Undefined Form Element: '.$cms_form;
		break;
	}
	return($element);
}

function field_checker($value, $id, $check='none'){
	$errmsg = FALSE;
	switch($check){
		case 'not_empty':
			if(strlen(trim($value)) <= 0) $errmsg = '<span class="err"> *must not be empty&nbsp;</span>';
			//echo $errmsg.'<br>';
		break;
		case 'username':
			global $cms, $db;
			$strlen = strlen(trim($value));
			$key = array_keys($cms->cms_id, $id);
			$row = $db->select($cms->cms_arg[$key[0]]['table'], 'count('.$cms->cms_arg[$key[0]]['field'].') as countx', 'WHERE '.$cms->cms_arg[$key[0]]['field'].' = "'.addslashes(trim($value)).'"');
			//echo $row[0]['countx'];
			if($strlen < 4){
				$errmsg = '<span class="err"> *must be at least 4 characters&nbsp;</span>';
			}elseif($row[0]['countx'] > 0 && $cms->action != 'edit'){
				$errmsg = '<span class="err"> *username must be unique&nbsp;</span>';
			}
			else $errmsg = FALSE;
		break;
		case 'username-editable':
			global $cms, $db, $query;
			$pkey = $query['pkey'];
			$strlen = strlen(trim($value));
			$key = array_keys($cms->cms_id, $id);
			$row = $db->select($cms->cms_arg[$key[0]]['table'], 'count('.$cms->cms_arg[$key[0]]['field'].') as countx', 'WHERE '.$cms->cms_arg[$key[0]]['field'].' = "'.addslashes(trim($value)).'" AND '.$pkey.' <> '.intval(@trim($_GET['id'])).' GROUP BY '.$cms->cms_arg[$key[0]]['field']);
			
			
			if($row[0]['countx'] > 0 && $value){
				$errmsg = '<span class="err"> *username must be unique&nbsp;</span>';
			}
			else $errmsg = FALSE;
		break;
		case 'password':
			global $cms;
			$strlen = strlen(trim($value));
			if($strlen <= 0 && $cms->action == 'edit') $errmsg = FALSE;
			elseif($strlen < 4 || $strlen > 16) $errmsg = '<span class="err"> *must be 4 to 16 characters&nbsp;</span>';
			elseif($value != $cms->clean['conf_'.$id]) $errmsg = '<span class="err"> *password not matched&nbsp;</span>';
		break;
		case 'password-optional':
			global $cms;
			$strlen = strlen(trim($value));
			if($strlen <= 0) $errmsg = FALSE;
			elseif($strlen < 4 || $strlen > 16) $errmsg = '<span class="err"> *must be 4 to 16 characters&nbsp;</span>';
			elseif($value != $cms->clean['conf_'.$id]) $errmsg = '<span class="err"> *password not matched&nbsp;</span>';
		break;
		case 'email':
			if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $value)) 
				$errmsg = "<span class='err'> *invalid email address&nbsp;</span>";
		break;
		case 'email-unique':
			
			global $cms, $db, $query;
			$pkey = $query['pkey'];
			
			if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $value)) 
				$errmsg = "<span class='err'> *invalid email address&nbsp;</span>";
			else{
				global $cms, $db;
				$key = array_keys($cms->cms_id, $id);
				$row = $db->select($cms->cms_arg[$key[0]]['table'], 'count('.$cms->cms_arg[$key[0]]['field'].') as countx', 'WHERE '.$cms->cms_arg[$key[0]]['field'].' = "'.addslashes(trim($value)).'" '.@$cms->cms_arg[$key[0]]['query'].' AND '.$pkey.' <> '.intval(@trim($_GET['id'])));
				if($row[0]['countx'] > 0) $errmsg = '<span class="err"> *email has been taken&nbsp;</span>';
			}
		break;
		case 'email_confirm':
			global $cms;
			if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $value)) 
				$errmsg = "<span class='err'> *invalid email address&nbsp;</span>";
			elseif($value != $cms->clean['conf_'.$id]) $errmsg = '<span class="err"> *email address not matched&nbsp;</span>';
		break;
		case 'date':
			//echo '--'.$value;
			@list($y, $m, $d) = explode('-', $value);
			if(!@checkdate($m, $d, $y)){
				$errmsg = "<span class='err'> *invalid date&nbsp;</span>";
			}
		break;
		case 'date-optional':
			//echo '--'.$value;
			@list($y, $m, $d) = explode('-', $value);
			
			if($value == '0000-00-00' || $value == ''){
				
			}elseif(!@checkdate($m, $d, $y)){
				$errmsg = "<span class='err'> *invalid date&nbsp;</span>";
			}
		break;
		case 'float':
			if(!is_float(trim($value))) $errmsg = "<span class='err'> *invalid float number&nbsp;</span>";
		break;
		case 'numeric':
			if(!is_numeric(trim($value))) $errmsg = "<span class='err'> *invalid numeric&nbsp;</span>";
		break;
		case 'price':
			if(!eregi("^[0-9]+(\.)[0-9]{2}$", $value)) 
				$errmsg = "<span class='err'> *invalid price format&nbsp;</span>";
		break;
		case 'euro-price':
			if(!eregi("^[0-9]+(\,)[0-9]{2}$", $value)) 
				$errmsg = "<span class='err'> *invalid euro price format&nbsp;</span>";
		break;
		case 'ordernum':
			if(!is_numeric(trim($value)) || $value <= 0 || $value > 9999 ) $errmsg = "<span class='err'> *invalid order number (must be 1 to 9999)&nbsp;</span>";
		break;
		case 'image':
			global $cms;
			$key = array_keys($cms->cms_id, $id);
			if($value['size'] <= 0 && $cms->action == 'edit') $errmsg = FALSE;
			elseif($value['size'] <= 0)
				$errmsg = '<span class="err"> *must be a valid image path&nbsp;</span>';
			elseif(!in_array($value['type'], $cms->cms_arg[$key[0]]['type'])){
				foreach($cms->cms_arg[$key[0]]['type'] as $v) { $vt = explode('/', $v); $valid_types[] = $vt[1]; }
				$errmsg = '<span class="err"> *file type not supported ['.implode(', ', $valid_types).']&nbsp;</span>';
			}elseif($value['error'] != UPLOAD_ERR_OK)
				$errmsg = '<span class="err"> *please re-upload image&nbsp;</span>';
		break;
		case 'image-optional':
			global $cms;
			$key = array_keys($cms->cms_id, $id);
			if($value['size'] <= 0 && $cms->action == 'edit') $errmsg = FALSE;
			elseif($value['size'] <= 0 && !$value['tmp_name'])
				$errmsg = FALSE;
			elseif($value['size'] <= 0)
				$errmsg = '<span class="err"> *must be a valid image path&nbsp;</span>';
			elseif(!in_array($value['type'], $cms->cms_arg[$key[0]]['type'])){
				foreach($cms->cms_arg[$key[0]]['type'] as $v) { $vt = explode('/', $v); $valid_types[] = $vt[1]; }
				$errmsg = '<span class="err"> *file type not supported ['.implode(', ', $valid_types).']&nbsp;</span>';
			}elseif($value['error'] != UPLOAD_ERR_OK)
				$errmsg = '<span class="err"> *please re-upload image&nbsp;</span>';
		break;
		case 'file':
			global $cms;
			$key = array_keys($cms->cms_id, $id);
			//echo '<pre>'.print_r($value, 1).'</pre>';
			if($value['size'] <= 0 && $cms->action == 'edit') $errmsg = FALSE;
			elseif($value['size'] <= 0)
				$errmsg = '<span class="err"> *must be a valid file path &nbsp;</span>';
			elseif($cms->cms_arg[$key[0]]['type']!= false && !in_array($value['type'], $cms->cms_arg[$key[0]]['type'])){
				foreach($cms->cms_arg[$key[0]]['type'] as $v) { $vt = explode('/', $v); $valid_types[] = $vt[1]; }
				$errmsg = '<span class="err"> *file type not supported ['.implode(', ', $valid_types).']&nbsp;</span>';
			}elseif($value['error'] != UPLOAD_ERR_OK)
				$errmsg = '<span class="err"> *please re-upload file&nbsp;</span>';
		break;
		case 'file-optional':
			global $cms;
			$key = array_keys($cms->cms_id, $id);
//			echo '<pre>'.print_r($value, true).print_r($cms->cms_arg[$key[0]], true).'</pre>';
//			exit;
			//echo @$value['size'];
			if($value['size'] <= 0 && $cms->action == 'edit') $errmsg = FALSE;
			elseif($value['size'] <= 0 && !@$value['tmp_name'])
				$errmsg = FALSE;
			elseif($value['size'] <= 0 && $value['name'])
				$errmsg = '<span class="err"> *must be a valid file path</span>';
			elseif($cms->cms_arg[$key[0]]['type']!= false && !in_array($value['type'], $cms->cms_arg[$key[0]]['type'])){
//				echo '~~'.$cms->cms_arg[$key[0]]['type'];
				foreach($cms->cms_arg[$key[0]]['type'] as $v) { $vt = explode('/', $v); $valid_types[] = $vt[1]; }
				$errmsg = '<span class="err"> *file type not supported ['.implode(', ', $valid_types).']</span>';
			}elseif($value['error'] != UPLOAD_ERR_OK)
				$errmsg = '<span class="err"> *please re-upload file&nbsp;</span>';
		break;
		case 'ffmpeg_video':
			global $cms;
			$key = array_keys($cms->cms_id, $id);
			$type = array('video/x-msvideo', 'video/mpeg', 'video/mpg', 'video/mp4', 'video/m4v', 'audio/mpeg', 'audio/mpg', 'video/wav', 'video/x-m4v', 'video/quicktime', 'application/octet-stream', 'video/x-mpg', 'video/mpeg2', 'application/x-pn-mpg', 'video/x-mpeg', 'video/x-mpeg2a', 'audio/mpeg', 'audio/x-mpeg', 'image/mpg');
			
			//echo '<pre>--'.print_r($value, 1).'</pre>';
			//exit;
			
			if($value['size'] <= 0 && $cms->action == 'edit') $errmsg = FALSE;
			elseif($value['size'] <= 0){
				$errmsg = '<span class="err"> *must be a valid file path &nbsp;</span>';
				//continue 1;
			}
			/*elseif(!in_array($value['type'], $type)){
				$errmsg = '<span class="err"> *must be either .mpg, .mpeg, mp4, m4v, mp3, wav or .avi file &nbsp;</span>';
				//continue 1;
			}*/elseif($value['error'] != UPLOAD_ERR_OK){
				$errmsg = '<span class="err"> *please re-upload file&nbsp;</span>';
				//continue 1;
			}
				//$errmsg = '<span class="err"> *testing upload&nbsp;</span>';
		break;
		case 'unique_no_space':
			global $cms, $db, $query;
			$pkey = $query['pkey'];
			$key = array_keys($cms->cms_id, $id);
			$row = $db->select($cms->cms_arg[$key[0]]['table'], 'count('.$cms->cms_arg[$key[0]]['field'].') as countx', 'WHERE '.$cms->cms_arg[$key[0]]['field'].' = "'.addslashes(trim($value)).'" '.@$cms->cms_arg[$key[0]]['query'].' AND '.$pkey.' <> '.intval(@trim($_GET['id'])));
			if(!$value){
				$errmsg = '<span class="err"> *must not be empty&nbsp;</span>';
			}elseif(strpos($value, ' ') > 0){
				$errmsg = '<span class="err"> *must not contain space&nbsp;</span>';
			}
			elseif($row[0]['countx'] > 0){
				$errmsg = '<span class="err"> *must be unique&nbsp;</span>';
			}
			else $errmsg = FALSE;
		break;
		case 'unique':
			global $cms, $db, $query;
			$pkey = $query['pkey'];
			$key = array_keys($cms->cms_id, $id);
			$row = $db->select($cms->cms_arg[$key[0]]['table'], 'count('.$cms->cms_arg[$key[0]]['field'].') as countx', 'WHERE '.$cms->cms_arg[$key[0]]['field'].' = "'.addslashes(trim($value)).'" '.@$cms->cms_arg[$key[0]]['query'].' AND '.$pkey.' <> '.intval(@trim($_GET['id'])));
			if(!$value){
				$errmsg = '<span class="err"> *must not be empty&nbsp;</span>';
			}elseif($row[0]['countx'] > 0){
				$errmsg = '<span class="err"> *must be unique&nbsp;</span>';
			}
			else $errmsg = FALSE;
		break;
		case 'none':
			$errmsg = FALSE;
		break;
		default:
			$errmsg = '<span class="err">Undefined Field Checker: '.$check.'&nbsp;</span>';
		break;
	}
	
	return($errmsg);
	
}

function load_template($tpl){
	if(file_exists($tpl['template']) && $tpl['template'] != ''){
		ob_start();

		foreach($tpl as $k=>$v) { 
			$$k = $v; //echo "$k = $v <br>"; 
		}
		//echo $template;
		include($template);
		$content = ob_get_contents();
		ob_end_clean();
	}
	else
		die('Template: '.$tpl['template'].' is missing.');
	
	return($content);
}

function entity_decode(&$item, $key, $textarea)
{
//	$item = '<pre style="margin:0px;">'.wordwrap(@html_entity_decode($item), 250, '<br />', 0).'</pre>';
//	echo $key.'=>'.$item.'<br />';
//	if($GLOBALS['element'])
//	echo print_r(array_keys($GLOBALS['element'], $key), 1).'<br />';
//	echo '<pre>'.print_r($textarea).'</pre>';
//	echo '<pre>'.print_r($id).'</pre>';
	if(in_array($key, $textarea)){
//		echo 'do';
//		$item = '<pre style="margin:0px;">'.wordwrap(@html_entity_decode($item), 60, '<br />', 1).'</pre>';
		$item = @html_entity_decode($item);
	}
}

function active_link($url){
	global $phpself;
//		echo "$url == $phpself";
	if($url == $phpself) return 'active';
}
function historynav($user='admin'){
	global $title, $phpself, $action;
	$historynav = '';
	switch ($user){
		case 'admin':
			//echo @$action;
			if(@$action) $historynav = '<a href="admin.php">Home</a> >> <a href="'.$_SERVER['PHP_SELF'].'">'.$title.'</a> >> '.ucfirst($action);
			elseif($phpself != 'admin.php') $historynav = '<a href="admin.php">Home</a> >> '.$title;
		break;
		case 'teacher':
			if($phpself != 'teacher.php') $historynav = '<a href="teacher.php">HOME</a> >> '.$title;
		break;
	}
	return $historynav;
}

function redirect($type, $text, $url){
	header($url);
	switch ($type){
		case 'db':
			echo '<center><br /><br /><img src="'.LIVE_DIR.'images/preloader.gif" /><br /><br />
				<strong class="err">'.mysql_affected_rows().' row[s] '.$text.'. Please wait while we redirect you.</strong>
				</center>';
		break;
		default:
			echo '<center><br /><br /><img src="'.LIVE_DIR.'images/preloader.gif" /><br /><br /></center>';
		break;
	}
	exit;
}

function clean_post($post){
	foreach ($post as $k => $v) {
		if(is_array($v)){
			foreach ($v as $k2=>$v2){
				$clean[$k][$k2] = mysql_real_escape_string($v2);
			}
		}else $clean[$k] = mysql_real_escape_string($v);
	}
	return($clean);
	//array_wa
}

function clean_post_recursive(&$item, $key){
//	$item  = mysql_real_escape_string(strip_tags($item, "<br><table><td><tr><p><hr><div><span><b><strong><em><img><a><li><ul><input>"));
//	$item  = mysql_real_escape_string($item);
	$item  = addslashes($item);
}

function clean_strip_post_recursive(&$item, $key){
	$item  = stripslashes($item);
}

function _stripslashes(&$item, $key){
	$item = stripslashes($item);
}

function _strip_tags(&$item, $key){
	$item  = strip_tags($item, "<input><img><a>");
}
function _strip_slash(&$item, $key){
	$item  = strip_tags(stripslashes($item));
}
function _stripslashes_htmlentities(&$item, $key){
	$item = stripslashes($item);
	$item = htmlentities($item);
}
function stripslash_then_addslash(&$item, $key){
	$item = stripslashes($item);
	$item = addslashes($item);
}

function array_trim(&$v){
	$v = trim($v);
	//echo $v;
}

function arrwalk_intval(&$item, $key){
	$item = intval($item);
}

function append_get_to_url($exemp){
	$appendurl = '';
	foreach($_GET as $k => $v){
		if(!in_array($k, $exemp))
			$appendurl .= "&{$k}={$v}";
	}
	return($appendurl);
}

/*function output_holder($value, $key, $user){
	//echo $value;
	if(is_array($value))
	foreach($value as $v){
		if(is_array($v)){}// array_walk($v, 'output_holder', $user);
		else echo '<pre>'.$v.$user.'</pre><br>';
	}else echo '<pre>'.htmlentities($value).$user.'</pre><br>';

	//echo '<pre>'.print_r($v, 1).'</pre>';
	//echo $k.'=>'.$v.'~~'.$user.'<br>';
}*/
//function 

function checkbrowser(){
	$useragent = $_SERVER['HTTP_USER_AGENT'];

	if (preg_match('|MSIE ([0-9].[0-9]{1,2})|',$useragent,$matched)) {
			$browser = 'ie';
	} elseif (preg_match( '|Opera ([0-9].[0-9]{1,2})|',$useragent,$matched)) {
			$browser = 'opera';
	} elseif(preg_match('|Firefox/([0-9\.]+)|',$useragent,$matched)) {
			$browser = 'firefox';
	} elseif(preg_match('|Safari/([0-9\.]+)|',$useragent,$matched)) {
			$browser = 'safari';
	} else {
		$browser= 'other';
	}
  
	 return($browser);
}

function displayeditor($name,$height,$width,$value){
	$browser = checkbrowser();
	if($browser == 'firefox' || $browser == 'safari'){
		
		$contentofeditor = ('<table border="0" width="100%">
					 <tr>
						<!--<td width="50">&nbsp;</td>-->
						<td><div align="center"><a href="javascript:editorCommand(\''.$name.'\', \'bold\', \'\')">	
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/bold.gif" width="22" height="22" border="0" alt="Bold" title="Bold"></a>&nbsp;
						<a href="javascript:editorCommand(\''.$name.'\', \'underline\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/underline.gif" width="22" border="0" height="22" alt="Underline" title="Underline"></a>&nbsp;
						<a href="javascript:editorCommand(\''.$name.'\', \'italic\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/italic.gif" width="22" border="0" height="22" alt="Italic" title="Italic"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'JustifyLeft\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/justifyleft.gif" width="22" border="0" height="22" alt="Align Left" title="Align Left"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'JustifyCenter\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/justifycenter.gif" width="22" border="0" height="22" alt="Align Center" title="Align Center"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'JustifyRight\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/justifyright.gif" width="22" border="0" height="22" alt="Align Right" title="Align Right"></a>&nbsp;
					
						<a href= "javascript:editorCommand(\''.$name.'\', \'InsertOrderedList\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/numlist.gif" width="22" border="0" height="22" alt="Ordered List" title="Undo"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'InsertUnOrderedList\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/bullist.gif" width="22" border="0" height="22" alt="Unordered List" title="Redo"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'Indent\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/indent.gif" width="22" border="0" height="22" alt="Indent" title="Indent"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'Outdent\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/outdent.gif" width="22" border="0" height="22" alt="Outdent" title="Outdent"></a></div></td>
					 </tr>
					 <tr><td colspan="10" onmouseover="javascript:loadeditor(\''.$name.'\')" onclick="javascript:loadeditor(\''.$name.'\')">
					 <iframe style="border:#A9A9A9 solid 1px" class="iframe_content" id="'.$name.'" src="" name="'.$name.'" width="'.$width.'px" height="'.$height.'px"></iframe>
					 <input type="hidden" name="'.$name.'" value="'.$value.'" id="hidden'.$name.'" class="hidden" >
					 </td></tr>
					 </table><br />');
	
	}else{
	
		$contentofeditor = ('<table border="0" width="100%">
					 <tr>
						<!--<td width="50">&nbsp;</td>-->
						<td><div align="center"><a href="javascript:editorCommand(\''.$name.'\', \'bold\', \'\')">	
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/bold.gif" width="22" height="22" border="0" alt="Bold" title="Bold"></a>&nbsp;
						<a href="javascript:editorCommand(\''.$name.'\', \'underline\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/underline.gif" width="22" border="0" height="22" alt="Underline" title="Underline"></a>&nbsp;
						<a href="javascript:editorCommand(\''.$name.'\', \'italic\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/italic.gif" width="22" border="0" height="22" alt="Italic" title="Italic"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'JustifyLeft\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/justifyleft.gif" width="22" border="0" height="22" alt="Align Left" title="Align Left"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'JustifyCenter\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/justifycenter.gif" width="22" border="0" height="22" alt="Align Center" title="Align Center"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'JustifyRight\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/justifyright.gif" width="22" border="0" height="22" alt="Align Right" title="Align Right"></a>&nbsp;
					
						<a href= "javascript:editorCommand(\''.$name.'\', \'InsertOrderedList\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/numlist.gif" width="22" border="0" height="22" alt="InsertOrderedList" title="InsertOrderedList"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'InsertUnOrderedList\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/numlist.gif" width="22" border="0" height="22" alt="InsertUnOrderedList" title="InsertUnOrderedList"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'Indent\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/indent.gif" width="22" border="0" height="22" alt="Indent" title="Indent"></a>&nbsp;
						<a href= "javascript:editorCommand(\''.$name.'\', \'Outdent\', \'\')" >
							<img class="editor_icon" src="'.LIVE_DIR.'images/editor/outdent.gif" width="22" border="0" height="22" alt="Outdent" title="Outdent"></a></div></td>
					 </tr>
					<tr><td colspan="10">
					 <DIV class="iframe_content" ID="'.$name.'" CONTENTEDITABLE STYLE="height:'.$height.'px;background-color:#FFFFFF; overflow:auto; width:'.$width.'px; text-align:left; border:#A9A9A9 solid 1px;">
					 '.html_entity_decode($value).'</DIV>
					 <input type="hiddenx" name="'.$name.'" value="'.stripslashes($value).'" id="hidden'.$name.'" class="hidden" >
					 </td></tr>
					 </table><br />');
	
	}

	return($contentofeditor);
}



function init_ffmpeg_uploader($clean, $arg){

	global $ffmpeg_upload_data;
	
	/*error_reporting(E_ALL);
	ini_set('display_errors', true);*/
	
	//echo $clean['name'].'<br>';
	
	

	
	$filename = substr($clean['tmp_name'], strrpos($clean['tmp_name'], '/')+1).'_'.uniqid().substr($clean['name'], strrpos($clean['name'], '.'));
	$filename_of_flv = substr_replace($filename, '.flv', strrpos($filename, '.'));
	
	$srcFile = $arg['location'].$filename;
	$destFile = $arg['location'].$filename_of_flv;

	if (move_uploaded_file($clean['tmp_name'], $srcFile)) {

	} else {
	    echo "Possible file upload attack!<br>";
	    exit;
	}
	
	
	$extension = substr($clean['name'], strrpos($clean['name'], '.')+1);
	switch($extension){
		case 'avi':
		case 'mp3':
		case 'mpg':
		case 'mpeg':
		case 'AVI':
		case 'MP3':
		case 'MPG':
		case 'MPEG':
			
            $cmd = "ffmpeg -i $srcFile -copyts -ar 44100 -s 470x330 $destFile";
            @exec("$cmd", $output);
			
            /*echo $cmd;
            
            var_dump($output);
            
            exit;*/
            
		break;
		
		case 'flv':
		case 'FLV':
			
			copy($srcFile, $destFile);
			
		break;
		
/*		case 'wmv':
		case 'WMV':
			
			$cmd = "ffmpeg -i {$srcFile} -copyts -ar 44100 -s 470x330 {$destFile}";
			//$config[path_to_ffmpeg] -i $raw_video_path -copyts -ar 44100 -s 320x240 $new_flv
			exec("$cmd", $debug);
			echo '<pre> Debug for wmv: '.print_r($debug, 1).'</pre>';
			exit;
		break;*/
		
		default:
			
			
			$raw_video_path = $srcFile;
			$new_flv = $destFile;
			$path_to_mencoder = '/usr/local/bin/mencoder';
			$debugmodex = 0;
			
			$mencoder_cmd = "$path_to_mencoder $raw_video_path -o $new_flv -of lavf -oac mp3lame -lameopts abr:br=56 -ovc lavc -lavcopts vcodec=flv:vbitrate=800:mbd=2:mv0:trell:v4mv:cbp:last_pred=3 -lavfopts i_certify_that_my_video_stream_does_not_use_b_frames -vf scale=320:233 -srate 22050";
            @exec("$mencoder_cmd 2>&1", $output);
            
            //If no flv was created. Attempt to convert with -vop swicth and not -vf
            if (!file_exists($new_flv)) {
                $mencoder_cmd = "$path_to_mencoder $raw_video_path -o $new_flv -of lavf -oac mp3lame -lameopts abr:br=56 -ovc lavc -lavcopts vcodec=flv:vbitrate=800:mbd=2:mv0:trell:v4mv:cbp:last_pred=3 -lavfopts i_certify_that_my_video_stream_does_not_use_b_frames -vop scale=450:400 -srate 22050";
                @exec("$mencoder_cmd 2>&1", $output);
            }
            
            //If no flv was created. Attempt to convert with no -lavcopts i_certify_etc_etc
            if (!file_exists($new_flv)) {
                $mencoder_cmd = "$path_to_mencoder $raw_video_path -o $new_flv -of lavf -oac mp3lame -lameopts abr:br=56 -ovc lavc -lavcopts vcodec=flv:vbitrate=800:mbd=2:mv0:trell:v4mv:cbp:last_pred=3 -vf scale=450:400 -srate 22050";
                @exec("$mencoder_cmd 2>&1", $output);
            }
			
			
            //debugging
            $debug_1 = $mencoder_cmd . "\n";//file line of debug
            foreach ($output as $outputline) {
                $debug_1 = $debug_1 . $outputline . "\n";
                if ($debugmodex == 1) {//no debug mode
                    echo ("$outputline<br>");
                }
            }

			/*$cmd ="/usr/local/bin/mencoder {$srcFile} -o {$destFile} -of lavf -oac mp3lame -lameopts abr:br=56 -ovc lavc -lavcopts vcodec=flv:vbitrate=800:mbd=2:mv0:trell:v4mv:cbp:last_pred=3 -vf scale=470:330 2>&1";
			exec($cmd, $debug);
			
			
			if(!file_exists($destFile) || filesize($destFile) == 0){
				
				unlink($destFile);
				
				$cmd ="/usr/local/bin/mencoder {$srcFile} -o {$destFile} -of lavf -oac mp3lame -lameopts abr:br=56 -ovc lavc -lavcopts vcodec=flv:vbitrate=800:mbd=2:mv0:trell:v4mv:cbp:last_pred=3 -vf scale=470:330 -srate 22050 2>&1";
				exec($cmd, $debug);
				
			}
			
			
			if(!file_exists($destFile) || filesize($destFile) == 0){
				
				unlink($destFile);
				
				$cmd ="/usr/local/bin/mencoder {$srcFile} -o {$destFile} -of lavf -oac mp3lame -lameopts abr:br=56 -ovc lavc -lavcopts vcodec=flv:vbitrate=800:mbd=2:mv0:trell:v4mv:cbp:last_pred=3 -srate 2205 2>&1";
				exec($cmd);
				
				
			}*/
			
		break;
		
	}
	
	
	
//	exit;


	
	//$movie = new ffmpeg_movie( $destFile, false );
	$ffmpeg_upload_data['filename'] = $filename_of_flv;
	$ffmpeg_upload_data['image'] = $filename_of_flv.'.jpg';
	//$ffmpeg_upload_data['numFrames'] = $movie->getFrameCount();
	
	
	
	
	
	
//	echo 'Filename of FLV: '.$destFile.'<br>';
	
	$check_duration = 'ffmpeg -i ' . $destFile;
	$durationfile = '';
	@exec("$check_duration 2>&1", $durationoutput);
	
//	echo '<pre>'.print_r($durationoutput, 1).'</pre><br><br>';
		
	foreach ($durationoutput as $outputline) {
		
		$durationfile = $durationfile . $outputline . "\n";
	
	}
	
    if (preg_match('/uration:.(.*?)\./', $durationfile, $regs)) {
        $duration = $regs[1];//duration already in 00:00:00 format
        $sec = date("s", strtotime($duration));//change back to seconds for use in getting middle of video
    }
    else {
        $sec = 2;
        //$duration = sec2hms($sec);//covert to 00:00:00 i.e. hrs:min:sec
    }
    
    if(preg_match('/([0-9]+x[0-9]+)/', $durationfile, $regs)){
    	//var_dump($regs);
    	
    	$wh = explode('x', $regs[0]);
		$h = $wh[1];
		$w = $wh[0];
		
		$srcWidth = 490;
		$srcHeight = round(($h * $srcWidth) / $w);
		if($srcHeight % 10 != 0) $srcHeight = $srcHeight + (10 - ($srcHeight % 10));
		
		$srcWidth_gd = 200;
		$srcHeight_gd = round(($h * $srcWidth_gd) / $w);
		if($srcHeight_gd % 10 != 0) $srcHeight_gd = $srcHeight_gd + (10 - ($srcHeight_gd % 10));
		
		$srcWidth_gd2 = 250;
		$srcHeight_gd2 = round(($h * $srcWidth_gd2) / $w);
		if($srcHeight_gd2 % 10 != 0) $srcHeight_gd2 = $srcHeight_gd2 + (10 - ($srcHeight_gd2 % 10));
		
		$srcWidth_gd3 = 120;
		$srcHeight_gd3 = round(($h * $srcWidth_gd3) / $w);
		if($srcHeight_gd3 % 10 != 0) $srcHeight_gd3 = $srcHeight_gd3 + (10 - ($srcHeight_gd3 % 10));
    	
    }

	$sec = str_pad(floor($sec/60), 2, '0', STR_PAD_LEFT).':'.str_pad(intval($sec%60), 2, '0', STR_PAD_LEFT);
	//$ffmpeg_upload_data['duration'] = $sec;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    //$ffmpeg_cmd2 = "$config[path_to_ffmpeg] -i $new_flv -ss $thumb_position -t 00:00:01 -s 120x90 -r 1 -f mjpeg $output_file";
	exec("ffmpeg -i {$srcFile} -t 00:00:05 -s {$srcWidth_gd}x{$srcHeight_gd} -r 1 -f mjpeg {$destFile}.jpg 2>&1",$debug);
	exec("ffmpeg -i {$srcFile} -t 00:00:05 -s {$srcWidth_gd2}x{$srcHeight_gd2} -r 1 -f mjpeg {$arg['location']}r_{$filename_of_flv}.jpg 2>&1");
	exec("ffmpeg -i {$srcFile} -t 00:00:05 -s {$srcWidth_gd3}x{$srcHeight_gd3} -r 1 -f mjpeg {$arg['location']}t_{$filename_of_flv}.jpg 2>&1");	
    
	if (filesize($destFile.'.jpg') == 0) {
		
		exec("ffmpeg -i $srcFile -deinterlace -an -ss 1 -t 00:00:05 -r 1 -y -vcodec mjpeg -f mjpeg {$destFile}.jpg 2>&1",$debug);
		exec("ffmpeg -i $srcFile -deinterlace -an -ss 1 -t 00:00:05 -r 1 -y -vcodec mjpeg -f mjpeg {$arg['location']}r_{$filename_of_flv}.jpg 2>&1");
		exec("ffmpeg -i $srcFile -deinterlace -an -ss 1 -t 00:00:05 -r 1 -y -vcodec mjpeg -f mjpeg {$arg['location']}t_{$filename_of_flv}.jpg 2>&1");	

    }
//		var_dump($debug);

	unlink($srcFile);

	$ffmpeg_upload_data['filename'] = $filename_of_flv;
	$ffmpeg_upload_data['image'] = $filename_of_flv.'.jpg';
	//$ffmpeg_upload_data['numFrames'] = $movie->getFrameCount();
	$ffmpeg_upload_data['duration'] = $sec;
	
//	echo '<pre>'.print_r($ffmpeg_upload_data, 1).'</pre><br><br>';
//	exit;
	
	return($filename_of_flv);

}


function init_ffmpeg_uploader_old($clean, $arg){

	global $ffmpeg_upload_data;
	
	// Set our source file
	
//	echo 'entered init_ffmpeg_uploader()';
//	exit;
	
/*	error_reporting(E_ALL);
	ini_set('display_errors', true);*/
	
	//echo '<pre>'.$_FILES.'</pre>';
	
	$filename = substr($clean['tmp_name'], strrpos($clean['tmp_name'], '/')+1).'_'.uniqid().substr($clean['name'], strrpos($clean['name'], '.'));
	$filename_of_flv = substr_replace($filename, '.flv', strrpos($filename, '.'));
	
	$srcFile = $arg['location'].$filename;
	$destFile = $arg['location'].$filename_of_flv;
	//$ffmpegPath = $arg['location']."ffmpeg";
	//$flvtool2Path = $arg['location']."flvtool2";

	//copy($clean['tmp_name'], $srcFile);
	
	if (move_uploaded_file($clean['tmp_name'], $srcFile)) {

	} else {
	    echo "Possible file upload attack!<br>";
	    exit;
	}

	$ffmpegObj = new ffmpeg_movie($srcFile);

	$ffmpegPath = 'ffmpeg';
	$flvtool2Path = "flvtool2";
	
	$h = $ffmpegObj->getFrameHeight();
	$w = $ffmpegObj->getFrameWidth();
	
	$srcWidth = 490;
	$srcHeight = round(($h * $srcWidth) / $w);
	if($srcHeight % 10 != 0) $srcHeight = $srcHeight + (10 - ($srcHeight % 10));
	
	$srcWidth_gd = 200;
	$srcHeight_gd = round(($h * $srcWidth_gd) / $w);
	if($srcHeight_gd % 10 != 0) $srcHeight_gd = $srcHeight_gd + (10 - ($srcHeight_gd % 10));
	
	$srcWidth_gd2 = 250;
	$srcHeight_gd2 = round(($h * $srcWidth_gd2) / $w);
	if($srcHeight_gd2 % 10 != 0) $srcHeight_gd2 = $srcHeight_gd2 + (10 - ($srcHeight_gd2 % 10));
	
	$srcWidth_gd3 = 120;
	$srcHeight_gd3 = round(($h * $srcWidth_gd3) / $w);
	if($srcHeight_gd3 % 10 != 0) $srcHeight_gd3 = $srcHeight_gd3 + (10 - ($srcHeight_gd3 % 10));
	
	
	
	//$srcAR = @intval($ffmpegObj->getAudioSampleRate())>22050 || @intval($ffmpegObj->getAudioSampleRate())==0 ? 44100 : @intval($ffmpegObj->getAudioSampleRate());
	//$srcAB = @intval($ffmpegObj->getAudioBitRate()/1000)==0 ? "224k" : @intval($ffmpegObj->getAudioBitRate()/1000) ;
//	$srcAR = 44100;
//	$srcAB = "224k";
	
//	$srcAR = ($temp_ar = $ffmpegObj->getAudioSampleRate()) ? $temp_ar : 22000;
	$srcAR = 44100;
	$srcAB = intval($ffmpegObj->getAudioBitRate());
	
	$srcBR = $ffmpegObj->getBitRate();
	$srcFPS = $ffmpegObj->getFrameRate();
	$flvtool = $flvtool2Path == 1 ? "| {$flvtoll2Path} -U stdin {$destFile}" : NULL;
	
//	echo "AR = {$srcAR} <br /> AB = {$srcAB}";
//	exit;
	
	
//	echo "ffmpeg -i {$srcFile} -ar {$srcAR} -ab {$srcAB} -f flv -s 470x330 -acodec pcm_s16le {$destFile}";
//	exit;
//ffmpeg -i /home/taxpayer/docs/tcs/uploads/video_car.avi -ar 44100 -ab 64000 -b 574412 -r 10 -g 80 -f flv -s 470x334 -acodec pcm_s16le /home/taxpayer/docs/tcs/uploads/video_car.flv

//ffmpeg -i /home/taxpayer/docs/tcs/uploads/video_car.avi -ar 22050 -ab 32 -f flv -s 320x240 -acodec pcm_s16le /home/taxpayer/docs/tcs/uploads/video_car.flv | flvtool2 -U stdin /home/taxpayer/docs/tcs/uploads/video_car.flv



//	      ffmpeg -i video_bike.mpeg  -ar 44100 -ab 32 -f flv -s 470x330 -sameq phpbCsNks_48b17b0fdcaf5.flv
//	exec("ffmpeg -i {$srcFile} -ar {$srcAR} -ab {$srcAB} -f flv -s 470x330 -acodec pcm_s16le {$destFile}"); //working
//	exec("ffmpeg -i {$srcFile} -ar 44100 -ab 32 -f flv -s 470x330 -sameq {$destFile}"); //working

	$destsize = ($arg['size']) ? $arg['size'] : '470x330';

	exec("ffmpeg -i {$srcFile} -copyts -ar 44100 -s {$destsize} {$destFile}");

	
	
	//exec("ffmpeg -1 myfile.avi -sameq -target vcd /tmp/vcd.mpg");
	
//	echo "ffmpeg -i {$srcFile} -ar {$srcAR} -ab {$srcAB} -f flv -s 470x330 -acodec pcm_s16le {$destFile}";
//	exit;
//	exec("{$ffmpegPath} -i {$srcFile} -ar {$srcAR} -ab {$srcAB} -b {$srcBR} -r {$srcFPS} -g 80 -f flv -s 470x334 -acodec pcm_s16le -ac 2 {$destFile} {$flvtool}");
//	exec("{$ffmpegPath} -i {$srcFile} {$destFile}");
	//ffmpeg -i video.avi -ar 22050 -ab 32 -f flv -s 320x240 video.flv
	
	//exec('ffmpeg -i '.$srcFile.' '.$destFile);
	
	$movie = new ffmpeg_movie( $destFile );
	$ffmpeg_upload_data['filename'] = $filename_of_flv;
	$ffmpeg_upload_data['image'] = $filename_of_flv.'.jpg';
	$ffmpeg_upload_data['numFrames'] = $movie->getFrameCount();
	
	$sec = $movie->getDuration();
	$sec = str_pad(floor($sec/60), 2, '0', STR_PAD_LEFT).':'.str_pad(intval($sec%60), 2, '0', STR_PAD_LEFT);
	
	$ffmpeg_upload_data['duration'] = $sec;
	
//	echo 'Num Frames: '.$numFrames.'<br> Duration: '.$duration;

	$screeshot = intval($ffmpeg_upload_data['numFrames']/2);
	exec("ffmpeg -i {$srcFile} -s {$srcWidth_gd}x{$srcHeight_gd} -vframes {$screeshot} -f mjpeg {$destFile}.jpg");
	exec("ffmpeg -i {$srcFile} -s {$srcWidth_gd2}x{$srcHeight_gd2} -vframes {$screeshot} -f mjpeg {$arg['location']}r_{$filename_of_flv}.jpg");
	exec("ffmpeg -i {$srcFile} -s {$srcWidth_gd3}x{$srcHeight_gd3} -vframes {$screeshot} -f mjpeg {$arg['location']}t_{$filename_of_flv}.jpg");
	//exec("ffmpeg -i {$srcFile} -s 800x600 -vframes 2 -f mjpeg {$arg['location']}thumbnail.jpg");
	
//	echo "ffmpeg -i {$srcFile} -s {$srcWidth_gd3}x{$srcHeight_gd3} -vframes {$screeshot} -f mjpeg t_{$destFile}.jpg";
	
//	exit;
	
	//echo $destFile.'<br>'.$destFile.'.jpg<br>'."{$srcWidth_gd2}x{$srcHeight_gd2}";
	

	
	
	unlink($srcFile);

	
	return($filename_of_flv);
	
	// Make multiples function

}




function crop_image($files, $dimension, $dir){
	
	if($files['size']<=0) return;
	//compose filename
	$kw = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	$max = strlen($kw)-1;
	$filename = '';

	for($x=0;$x<=8;$x++) $filename .= $kw[rand(0, $max)];
	
	//$filename .= time();
	$filename = $filename.basename($files['tmp_name'], '.tmp');
	
	//crop image
	list($img['old_width'], $img['old_height']) = getimagesize($files['tmp_name']);
	
	
	$ratio_orig = $img['old_width']/$img['old_height'];
	
	
	
	@list($img['new_width'], $img['new_height']) = explode('x', $dimension);
	
	//echo '<pre>'.print_r($img, 1).'</pre>';
	
	if ($img['new_width']/$img['new_height'] > $ratio_orig) {
		$img['new_width'] = $img['new_height']*$ratio_orig;
	} else {
		$img['new_height'] = $img['new_width']/$ratio_orig;
	}
	
	if($img['old_width'] <= $img['new_width']) $img['new_width'] = $img['old_width'];
	if($img['old_height'] <= $img['new_height']) $img['new_height'] = $img['old_height'];
	
	$img['new_width'] = round($img['new_width']);
	$img['new_height'] = round($img['new_height']);
	
	$img['thumb'] = imagecreatetruecolor($img['new_width'], $img['new_height']);
	
	
	
	//create image
	switch($files['type']){
		case 'image/jpeg':
		case 'image/pjpeg':
		case 'image/jpg':
			$img['source'] = imagecreatefromjpeg($files['tmp_name']);
			imagecopyresampled($img['thumb'], $img['source'], 0, 0, 0, 0, $img['new_width'], $img['new_height'], $img['old_width'], $img['old_height']);
			//imagecopyresized( $img['thumb'], $img['source'], @$img['adjust_w'], @$img['adjust_h'], 0, 0, $img['new_width'], $img['new_height'], $img['old_width'], $img['old_height']);
			//$this->file_extension('.jpg');
			$filename = $filename.'.jpg';
			imagejpeg($img['thumb'], $dir.$filename, 90);
			//echo $dir.$filename;
		break;
		case 'image/gif':
			$img['source'] = imagecreatefromgif($files['tmp_name']);
			imagecopyresampled($img['thumb'], $img['source'], 0, 0, 0, 0, $img['new_width'], $img['new_height'], $img['old_width'], $img['old_height']);
			//$this->file_extension('.gif');
			$filename = $filename.'.gif';
			imagegif($img['thumb'], $dir.$filename, 90);
		break;
		case 'image/png':
			$img['source'] = imagecreatefrompng($files['tmp_name']);
			imagecopyresampled($img['thumb'], $img['source'], 0, 0, 0, 0, $img['new_width'], $img['new_height'], $img['old_width'], $img['old_height']);
			//$this->file_extension('.png');
			$filename = $filename.'.png';
			imagepng($img['thumb'], $dir.$filename, 9);
		break;
	}
	
	 return($filename);
	
	
	
}


function get_flv($files, $dir){
	
	if($files['size']<=0) return;
	
	$kw = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	$max = strlen($kw)-1;
	$filename = '';

	for($x=0;$x<=8;$x++) $filename .= $kw[rand(0, $max)];
	
	//$filename .= time();
	$filename = $filename.basename($files['tmp_name'], '.tmp');
	
	copy($files['tmp_name'], $dir.$filename.'.flv');
	
	//echo $filename;
	
	return($filename.'.flv');

}






function get_rate($arg, $append='star', $halfbreak=""){
	
	global $db;
	
	if($arg && @$arg['rating']){
		$rate = $arg['rating'];
	}
	
	//average rate;
	$content = '';
	for($x=0.99; $x<@$rate; $x++){
		if(intval($x) == 5) $content .= $halfbreak;
		$content .= '<img src="images/'.$append.'1.gif" />';
	}
	if((@$rate - (intval(@$rate))) > 0){
		if(intval($x) == 5) $content .= $halfbreak;
		$content .= '<img src="images/'.$append.'half.gif" />';
		$x++;
	}
	for($x=$x; $x<5; $x++){
		
		if(intval($x) == 5) $content .= $halfbreak;
		$content .= '<img src="images/'.$append.'0	.gif" />';
		
	}
	
	
	return($content);
}

function give_rate($arg = false, $append='icons/flvvideo_star'){
	
	global $db;
	
	$content = '';
	
	//if(@$_SESSION['login_id'] && @$arg['mini'] != true){
	
	$content .= '<div onmouseout="star_gallery_out(1)">
		<img src="images/'.$append.'0.gif" id="star1" onmouseover="star_gallery_over(1)" onmouseout="star_gallery_out(1)" onclick="star_gallery_rate(1, '.$arg['id'].')" /><img src="images/'.$append.'0.gif" id="star2" onmouseover="star_gallery_over(2)" onmouseout="star_gallery_out(2)" onclick="star_gallery_rate(2, '.$arg['id'].')" /><img src="images/'.$append.'0.gif" id="star3" onmouseover="star_gallery_over(3)" onmouseout="star_gallery_out(3)" onclick="star_gallery_rate(3, '.$arg['id'].')" /><img src="images/'.$append.'0.gif" id="star4" onmouseover="star_gallery_over(4)" onmouseout="star_gallery_out(4)" onclick="star_gallery_rate(4, '.$arg['id'].')" /><img src="images/'.$append.'0.gif" id="star5" onmouseover="star_gallery_over(5)" onmouseout="star_gallery_out(5)" onclick="star_gallery_rate(5, '.$arg['id'].')" /></div>';
	//average rate;

	/*}
	else{
	
	}*/
	
	return($content);
}
?>