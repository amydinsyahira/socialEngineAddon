<?php




$folder = 'main';
include "flvvideo/config.php";

include "header.php";

$userid = intval($user->user_info[user_id]);	
if(!$userid) exit;

$title = '4598808';
$smarty->assign('title', $title);
$smarty->assign('url_base', $url->url_base);


/*error_reporting(E_ALL);
ini_set('display_errors', true);*/




if($id = intval($_GET['id'])){

	//echo $id;


	$smarty->assign('user_id', $user->user_info[user_id]);
	
	
	$page = "flvvideo_play";
	$video = $db->select('se_flvvideo LEFT JOIN se_flvvideo_comment ON (comment_id = flvvideo_id) LEFT JOIN se_flvvideo_visit ON (flvvideo_visit_id = flvvideo_id) LEFT JOIN se_flvvideorate ON (videorate_videoid = flvvideo_id) LEFT JOIN se_users ON (user_id = flvvideo_user)', 
		'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_comment, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, count(comment_pkeyid) as totalx, AVG(videorate_rate) as videorate_rate,flvvideo_visit_num, flvvideo_tag, user_username, user_fname, user_lname ', 'WHERE flvvideo_id = '.$id.' GROUP BY flvvideo_id LIMIT 1');

	$smarty->assign('average_rate', get_rate(array('rating'=>$video[0]['videorate_rate']), 'icons/flvvideo_star'));
	$smarty->assign('give_rate', give_rate(array('id'=>intval($video[0]['flvvideo_id']))));
	
	

//	echo $video[0]['flvvideo_tag'];
	
	$related_video = $db->select('se_flvvideo', 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_tag, flvvideo_image', 'WHERE flvvideo_id != '.intval($video[0]['flvvideo_id']).'  AND MATCH(flvvideo_tag) AGAINST(\''.$video[0]['flvvideo_tag'].'\' IN BOOLEAN MODE)');
	
//	echo '<pre>--'.print_r($related_video, 1).'</pre>';

	if(!$db->select('se_flvvideo_visit', 'flvvideo_visit_id', 'WHERE flvvideo_visit_id = '.$id)){
		$db->insert('se_flvvideo_visit', 'flvvideo_visit_id, flvvideo_visit_num', "'{$id}', '1'");
	}elseif($_SESSION['last_visit_'.$id] !== TRUE){
		$db->update('se_flvvideo_visit', 'SET flvvideo_visit_num = flvvideo_visit_num + 1 WHERE flvvideo_visit_id = '.$id);
		$_SESSION['last_visit_'.$id] = TRUE;
	}

	
	array_walk_recursive($video, '_stripslashes');
	array_walk_recursive($related_video, '_stripslashes');
	$smarty->assign('video', $video);
	$smarty->assign('related_video', $related_video);
	
	
	
	$pager_query = array('table'=>'se_flvvideo_comment INNER JOIN se_users ON (user_id = comment_userid)', 
			'fields'=>' DISTINCT comment_pkeyid', 'where'=>'  WHERE  comment_id = '.intval($id).' AND comment_status = "active" ', 'pkey'=>'DISTINCT comment_pkeyid', 'limit'=>5);//$this->query;
	$linktype = array('type'=>'ajax', 'url'=>'flvvideo_span_comment.php?id='.$id, 'spanid'=>'span_comment');
	
	$pager = new pager_class($pager_query, 'sql', array('pagenum', 'action'), $linktype);
	
	if(phpversion() < '5'){
		$pager->__construct($pager_query, 'sql', array('pagenum', 'action'), $linktype);
	}
	
	$page_limit = $pager->limit_stmt;
	//$clause .= $pager->limit_stmt; // append limit to clause
	
	$smarty->assign('pager', $pager->pager);
	
	$comment = $db->select('se_flvvideo_comment INNER JOIN se_users ON (user_id = comment_userid)', 'comment_pkeyid, comment_id, comment_status, comment_content, comment_userid, comment_ip, comment_date, DATE_FORMAT(comment_date, "%M %d, %Y %h:%i %p") as comment_datex, user_id, user_fname, user_lname, user_username, user_photo', 'WHERE comment_id = '.$id.' AND comment_status = "active" ORDER BY comment_date DESC '.$page_limit);
	array_walk_recursive($comment, '_stripslashes');
	
	$smarty->assign('comment', $comment);
	
}else{
	$page = "flvvideo_view";
	
	if($kw = addslashes($_GET['kw'])){
		
		$smarty->assign('kw', stripslashes($_GET['kw']));
		
		$addwhere = 'AND (flvvideo_title LIKE "%'.$kw.'%" OR flvvideo_description LIKE "%'.$kw.'%" OR flvvideo_type LIKE "%'.$kw.'%" )';
		$addfield = ' ,( ((MATCH (flvvideo_title) AGAINST (\''.$kw.'\' IN BOOLEAN MODE))*50) + ((MATCH (flvvideo_description) AGAINST (\''.$kw.'\' IN BOOLEAN MODE))*10) + ((MATCH (flvvideo_type) AGAINST (\''.$kw.'\' IN BOOLEAN MODE))*20) +1) as relevance ';
		
	}
	
	if($_GET['action']=='remove_favorite'){
		$db->delete('se_flvvideo_favorite', 'WHERE ffav_refid = '.intval($_GET['id_to_delete']).' AND ffav_userid = "'.$userid.'" LIMIT 1');
		header("refresh:0; url=".$_SERVER['HTTP_REFERER']);
		exit;
	}
	if($_GET['action']=='my_favorites' || $_GET['action']=='remove_favorite'){
		$inner_join = ' INNER JOIN se_flvvideo_favorite ON (ffav_refid = flvvideo_id AND ffav_userid = "'.$userid.'") ';
		$title = '4598848';
		$smarty->assign('favorite', 1);
	}
	
	$smarty->assign('title', $title);
	
	$table = 'se_flvvideo '.$inner_join.' LEFT JOIN se_flvvideo_visit ON (flvvideo_visit_id = flvvideo_id) LEFT JOIN se_flvvideo_comment ON (comment_id = flvvideo_id) LEFT JOIN se_users ON (user_id = flvvideo_user)';
	
	$pager_query = array('table'=>$table, 
			'fields'=>' DISTINCT flvvideo_id', 'where'=>' WHERE 1 '.$addwhere, 'pkey'=>'DISTINCT flvvideo_id', 'limit'=>10);//$this->query;
	//$linktype = array('type'=>'ajax', 'url'=>'ajax_gallery.php?', 'spanid'=>'span_gallery');
	
	$pager = new pager_class($pager_query, 'sql', array('pagenum', 'action'));
	
	if(phpversion() < '5'){
		$pager->__construct($pager_query, 'sql', array('pagenum', 'action'));
	}
	
	$page_limit = $pager->limit_stmt;
	//$clause .= $pager->limit_stmt; // append limit to clause
	
	$smarty->assign('pager', $pager->pager);
	//$tpl['gallery_pager'] = ;
	
	$video = $db->select($table, 'flvvideo_id, flvvideo_title, flvvideo_description, flvvideo_flv, flvvideo_type, flvvideo_image, flvvideo_user, flvvideo_dateadded, DATE_FORMAT(flvvideo_dateadded, "%M %d %Y") as flvvideo_dateaddedx, flvvideo_visit_num, count(comment_pkeyid) as totalx, user_username, user_fname, user_lname '.$addfield, ' WHERE 1 '.$addwhere.' GROUP BY flvvideo_id ORDER BY '.$addorder.' flvvideo_dateadded DESC '.$page_limit);
	
	array_walk_recursive($video, '_stripslashes');
	
	/*foreach($r as $k=>$v){
		
		$video[$k][flvvideo_title] = '--'.$v['flvvideo_title'];
		
	}*/
	
	//echo '<pre>'.print_r($video, 1).'</pre>';
	//if($video) 
	$smarty->assign('video', $video);
	
}









include "footer.php";
?>