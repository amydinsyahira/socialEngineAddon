<?php

$folder = 'main';
include "flvvideo/config.php";

include "header.php";

$userid = intval($user->user_info[user_id]);	
if(!$userid) exit;

$clean = $_POST;
array_walk_recursive($clean, 'clean_post_recursive');

if($_POST['comment_content'] != 'Write Something...' && strlen($_POST['comment_content']) > 0){
	$db->insert('se_flvvideo_comment', 'comment_id, comment_content, comment_userid, comment_ip', "'{$clean['comment_id']}', '".nl2br(addslashes(strip_tags($_POST['comment_content'], "<b><img><br><a>")))."', '{$user->user_info[user_id]}', '{$_SERVER['REMOTE_ADDR']}'");
	echo 'Saving Comment...';
	
}



?>
<script>

	parent.document.getElementById("comment_form_sent").style.display = "";
	parent.document.getElementById("comment_form").style.display = "none";
	
</script>