CREATE TABLE IF NOT EXISTS `shout` (
  `intGuestID` int(11) NOT NULL auto_increment,
  `strNome` varchar(25) NOT NULL,
  `strEmail` varchar(100) NOT NULL,
  `dtmPubblicazione` int(12) NOT NULL,
  `strCommento` varchar(255) NOT NULL,
  `strPhoto` varchar(100) NOT NULL,
  PRIMARY KEY  (`intGuestID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;