<?php
require_once('includes/funzioni_php.php');
require_once('includes/func.php');
include "header.php";
$action = @$_GET['action'];
$action = ricevoGet($action);

if(strlen($action) == 0){	
	//Imposto la variabile per gestire gli errori
	$strErrore = "";
	//Recupero tutti dati
	$strNome = $user->user_info[user_username];
	if (isset($strNome)) {
	$strPhoto = $user->user_info[user_photo];
	$strEmail = $_POST['email'];
	$strCommento = $_POST['commento'];
	//creo array per trattamento dati
	$clean = array($strNome,$strEmail,$strPhoto,$strCommento);
	//tratto i dati e verifico magic quotes
	for ($i=0; $i<sizeof($clean); $i++){
	
		$stringToClean= $clean[$i];
		preg_replace('=((<CR>|<LF>|0x0A/%0A|0x0D/%0D|\\n|\\r)\S).*=i','', $stringToClean);
		$clean[$i] = ricevoPost($stringToClean);
		
	}
	//creo array per contenere dati puliti
	$html=array();
	
	for ($i=0; $i<sizeof($clean); $i++){
	
	$html[$i] = invioDb($clean[$i]);
	
	}
	// estraggo i dati dall'array
	$strNome = $html[0];
	$strEmail = $html[1];
	$photo = $html[2];
	$Commento = $html[3];
	
	//prendo la data dal server
	$dtmPubblicazione = time ();
	$dtmPubblicazione = invioDb($dtmPubblicazione) ;
	
	
	//Controllo presenza errori
	if($strErrore == ""){
			//query sql
			$strSQL = "INSERT INTO shout ("
					. " intGuestID,"
					. " strNome,"
					. " strEmail,"
					. " strPhoto,"
					. " dtmPubblicazione,"
					. " strCommento) VALUES("
					. " '$intGuestID',"
					. " '$strNome',"
					. " '$strEmail',"
					. " '$photo',"
					. " '$dtmPubblicazione',"
			    	. " '$Commento')";
		}
		
		//Eseguo la query SQL
		if(mysql_query($strSQL)){
			
			require_once('includes/show_shoutbox.php');
				
		}else{
		
			echo "answer=Errore: ".mysql_error();
		}
	}
		
}

//azione di lista per creare xml senza inserimenti a database
if($action == "lista"){

require_once('includes/show_shoutbox.php');

}

  
	
?>
