<?php
require_once('magic_quotes.php');
?>
