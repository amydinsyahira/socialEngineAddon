<?php

	//funzione scrivo sul file xml
function Write_to_file($text){
	//dov'� il file xml?
	$dir='xml/';
	$file="file.xml";
	$filepath= $dir. $file;

	$connect=@fopen($filepath, "a");
	fputs($connect, $text);
	fclose($connect);
		
	}
	
function Check_file(){
	//mi piace ripetere..
	$dir='xml/';
	$file="file.xml";
	$filepath= $dir. $file;

	if(file_exists($filepath)){
	
	unlink($dir . basename($file));
	
	
	}
	}
	
Check_file();
// passando xpage si pu� variare il numero dei risultati della query default a 10
$news_per_page = @$_GET['xpage'];

	if(strlen($news_per_page) == 0){
		$news_per_page = 400;
	}else {
		$news_per_page=ricevoGet($news_per_page);
		$news_per_page=invioDb($news_per_page);
	}
	//Pagina di inizio
	if(!IsSet($_GET['start'])){
		$start = 0;
	}else{
		$start = $_GET['start'];
		$start=ricevoGet($start);
		$start=invioDb($start);
	}
	
	
	$strSQL = "SELECT * FROM shout";

	//Eseguo la query SQL
	//Qui controllo quanti sono i records presenti nella tabella per effettuare la paginazione !
	$result = mysql_query($strSQL);
	$tot_rec = mysql_num_rows($result);
	//Numero pagine
	$num_page = ceil($tot_rec/$news_per_page);
	$current_page = ceil(($start/$news_per_page) + 1);
	//Libero la memoria
	mysql_free_result($result);
	//Fine questione paginazione :-)
	
	$strSQL .= " ORDER BY dtmPubblicazione DESC LIMIT 0, 15";
	
	//Eseguo la query visualizzo i risultati
	$result = mysql_query($strSQL);
	
	//scrivo l'inizio del file xml
	Write_to_file("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"."\n");
	Write_to_file("<shoutbox>"."\n");
	//Scorro gli ultimi 10 articoli inseriti
	while($row = mysql_fetch_array($result)){
	
	//Recupero i Dati essenziali
	$strNome = $row['strNome'];
	$strPhoto = $row['strPhoto'];
	$strEmail = $row['strEmail'];
	$date = $row['dtmPubblicazione'];
	$strCommento = $row['strCommento'];

	
	
	$clean = array($strNome,$strEmail,$strPhoto,$strCommento,$date);
	//tratto dati ricevuti da db
	for ($i=0; $i<sizeof($clean); $i++){
	
		$stringToClean= $clean[$i];
		$clean[$i] = ricevoDb($stringToClean);
		
	}
	
	// estraggo i dati dall'array
	$strNome = $clean[0];
	$strEmail = $clean[1];
	$strPhoto = $clean[2];
	$Commento = $clean[3];
	$date = $clean[4];
	//funzione per interpretare il commento eventuali bbcodes 
	$commento = fInterpreta($Commento);	
	
		
	Write_to_file("<item nome=\"$strNome\" data=\"$date\" eMail=\"$strEmail\" photo=\"$strPhoto\" messaggio=\"$commento\"></item>"."\n");
	
}

	//Libero la memoria
	mysql_free_result($result);
	//scrivo la fine dell'xml
	Write_to_file("</shoutbox>"."\n");
	
	//se il file a questo punto esiste mando l'echo a flash
	$dir='xml/';
	$file="file.xml";
	$filepath= $dir. $file;

	if(file_exists($filepath)){
	
	echo "answer=true";
	
	}

?>