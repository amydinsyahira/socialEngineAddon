<?php


//Funzione per interpretare il testo
function fInterpreta($string)
{
	$string = trim(str_replace("<br />", "", $string));

	//CHR 13
	$string = trim(str_replace(chr(13), " ", $string));
	$string = trim(str_replace(chr(10), "", $string));	
	$string = trim(str_replace("<br>", "", $string));
	
	//No HTML
	$string = trim(str_replace("<", "'", $string));
	$string = trim(str_replace(">", "'", $string));
	$string = trim(str_replace("\"", "'", $string));
			
	//removing & or xml will be invalid
	$string = trim(str_replace("&", "", $string));

	
	//Ritorno il valore
	return $string;
}
?>
