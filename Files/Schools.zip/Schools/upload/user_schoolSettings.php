<?php
$page = "user_schoolSettings";
include "header.php";

////////GET LANG IDS
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'user_schoolSettings.', '') AS `key`
				FROM `schools_langKey` WHERE `defVarName` LIKE '%user_schoolSettings.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aSttng = array();
$sSql = "	SELECT 
					* 
				FROM `school_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
if( $aSttng['userlevels'] != "")
	$aSttng['userlevels'] = explode(",", $aSttng['userlevels']);
$smarty->assign('aSchoolSetting', $aSttng);
//////////////////////////////////////////////////////////////////////////
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);

$smarty->assign('bModDisabled', TRUE);
$smarty->assign('bPrompt', FALSE);
if( is_array($aSttng['userlevels']) && in_array($user->user_info['user_level_id'], $aSttng['userlevels']) && $aSttng['moderator'] == 1 )
{
	$smarty->assign('bModDisabled', FALSE);
	if( isset($_REQUEST['id']) )
	{
		$_REQUEST['id'] = mysql_real_escape_string($_REQUEST['id']);
		$sql = "	SELECT 
							`s`.`is_private`,
							`p`.`file`,
							`s`.`name`,
							`s`.`country`,
							`s`.`state`,
							`s`.`city`,
							`s`.`address`
						FROM `school_mem` AS `m`
						INNER JOIN `schools` AS `s` 
						ON `s`.`id` = `m`.`school_id`
						LEFT JOIN `school_pic` AS `p`
						ON `p`.`pic_id` = `s`.`def_pic`
						WHERE
							`m`.`school_id` = '{$_REQUEST['id']}' && 
							`m`.`user_id` = '{$iUserId}' &&
							`m`.`is_admin` = '1' ";
		$result = mysql_query($sql);
		if( $aRow = mysql_fetch_assoc($result) )
		{
			if( isset($_POST['submit']) )
			{
				//GET POST DATA
				$aRow = $_POST['aInfo'];
				$aRow['name'] = mysql_real_escape_string($aRow['name']);
				$aRow['country'] = mysql_real_escape_string($aRow['country']);
				$aRow['city'] = mysql_real_escape_string($aRow['city']);
				$aRow['address'] = mysql_real_escape_string($aRow['address']);
				if( isset($aRow['is_private']) && $aSttng['schoolsPrivate'] == 1 )
					$sInsert =  $aRow['is_private'] == 1 ? " `is_private` = 1, " : " `is_private` = 0, ";
				else
					$sInsert =  "";
				if( $aRow['state2'] != "" && $aRow['state2'] != "Other State or Province" )
					$aRow['state'] = mysql_real_escape_string($aRow['state2']);
				else
					$aRow['state'] = mysql_real_escape_string($aRow['state']);
				
				
				//UPDATE SCHOOL
				$sql = "UPDATE 
								`schools` 
							SET 
								`name` = '{$aRow['name']}',
								`country` = '{$aRow['country']}',
								`state` = '{$aRow['state']}',
								`city` = '{$aRow['city']}',
								{$sInsert}
								`address` = '{$aRow['address']}'
							WHERE
								`id` = '{$_REQUEST['id']}' ";
				$result = mysql_query($sql);
				
				//UPDATE IMAGE
				if(!isset($_FILES) && isset($HTTP_POST_FILES))
					$_FILES = $HTTP_POST_FILES;
				$fsize = $_FILES['newImage']['size'];
				if($fsize > 0)
				{
					$ftype = $_FILES['newImage']['type'];
					if($ftype == "image/jpeg" ||  $ftype == "image/gif" || $ftype == "image/pjpeg")
					{ 
						$imagename = basename($_FILES['newImage']['name']);
						$intDot = strripos($imagename, '.');
						$sPt1 = substr($imagename, 0, $intDot);
						$sPt2 = substr($imagename, $intDot);
						$sql = "SELECT*FROM `school_pic` WHERE `file` = '".$imagename."' LIMIT 1";
						$result = mysql_query($sql);
						while( ($row = mysql_fetch_assoc($result)) )
						{
							$imagename = str_shuffle($sPt1).$sPt2;
							$sql = "SELECT*FROM `school_pic` WHERE `file` = '".$imagename."' LIMIT 1";
							$result = mysql_query($sql);
						}
						$imagename2 = "./file/schools/" . $imagename;
						$result = @move_uploaded_file($_FILES['newImage']['tmp_name'], $imagename2);
						if($result)
						{
							chmod($imagename2, 0644);
							$sSql = "	INSERT INTO `school_pic` 
												(`school_id`, `file`, `time`) 
											VALUES 
												('{$iSchoolId}', '{$imagename}', '{$iTime}') ";
							$result = mysql_query($sSql);
							$iPicId = mysql_insert_id();
							$sql = "	UPDATE `schools`
											SET `def_pic` = '{$iPicId}'
											WHERE `id`= '{$_REQUEST['id']}' ";
							$result = mysql_query($sql);
							$aRow['file'] = $imagename;
						}
					}
				}
				
				$aRow['country'] = stripslashes($aRow['country']);
				$aRow['state'] = stripslashes($aRow['state2']);
				$aRow['city'] = stripslashes($aRow['city']);
				$aRow['address'] = stripslashes($aRow['address']);
				$smarty->assign('bPrompt', "infoUpdated");
			}
			elseif( isset($_POST['approve']) )
			{
				$aPending = $_POST['pending'];
				foreach($aPending as $v)
				{
					$temp = mysql_real_escape_string($v);
					$sql = "	UPDATE `school_mem` 
									SET `status` = '1' 
									WHERE 
										`school_id` = '{$_REQUEST['id']}' && 
										`status` = '3' && 
										`id` = '{$temp}' ";
					$result = mysql_query($sql);
				}
			}
			elseif( isset($_POST['deny']) )
			{
				$aPending = $_POST['pending'];
				foreach($aPending as $v)
				{
					$temp = mysql_real_escape_string($v);
					$sql = "	DELETE FROM `school_mem` 
									WHERE 
										`school_id` = '{$_REQUEST['id']}' && 
										`status` = '3' && 
										`id` = '{$temp}' ";
					$result = mysql_query($sql);
				}
			}
			
			$aCountry= array(''=>'', 31 => 'Afghanistan', 33 => 'Algeria', 34 => 'Andorra', 35 => 'Angola', 36 => 'Antigua And Barbuda', 37 => 'Argentina', 38 => 'Armenia', 39 => 'Australia', 40 => 'Austria', 41 => 'Azerbaijan', 42 => 'Bahamas', 43 => 'Bahrain', 44 => 'Bangladesh', 45 => 'Barbados', 46 => 'Belarus', 47 => 'Belgium', 48 => 'Belize', 49 => 'Benin', 222 => 'Bermuda', 50 => 'Bhutan', 51 => 'Bolivia', 52 => 'Bosnia And Herzegovina', 53 => 'Botswana', 54 => 'Brazil', 55 => 'Brunei Darussalam', 56 => 'Bulgaria', 57 => 'Burkina Faso', 58 => 'Burundi', 59 => 'Cambodia', 60 => 'Cameroon', 61 => 'Canada', 62 => 'Cape Verde', 63 => 'Central African Republic', 64 => 'Chad', 65 => 'Chile', 66 => 'China', 67 => 'Colombia', 68 => 'Comoros', 69 => 'Costa Rica', 70 => 'Croatia', 71 => 'Cuba', 72 => 'Cyprus', 73 => 'Czech Republic', 74 => 'Denmark', 75 => 'Djibouti', 76 => 'Dominica', 77 => 'Dominican Republic', 78 => 'Ecuador', 79 => 'Egypt', 80 => 'El Salvador', 81 => 'Equatorial Guinea', 82 => 'Eritrea', 83 => 'Estonia', 84 => 'Ethiopia', 85 => 'Fiji', 86 => 'Finland', 87 => 'France', 88 => 'Gabon', 89 => 'Gambia', 90 => 'Georgia', 91 => 'Germany', 92 => 'Ghana', 93 => 'Greece', 94 => 'Grenada', 95 => 'Guatemala', 96 => 'Guinea', 97 => 'Guinea-bissau', 98 => 'Guyana', 99 => 'Haiti', 100 => 'Honduras', 101 => 'Hong Kong', 102 => 'Hungary', 103 => 'Iceland', 104 => 'India', 105 => 'Indonesia', 106 => 'Iran', 107 => 'Iraq', 108 => 'Ireland', 109 => 'Israel', 110 => 'Italy', 111 => 'Ivory Coast', 112 => 'Jamaica', 113 => 'Japan', 114 => 'Jordan', 115 => 'Kazakhstan', 116 => 'Kenya', 117 => 'Kiribati', 118 => 'Korea (north)', 119 => 'Korea (south)', 120 => 'Kuwait', 121 => 'Kyrgyzstan', 122 => 'Laos', 123 => 'Latvia', 124 => 'Lebanon', 125 => 'Lesotho', 126 => 'Liberia', 127 => 'Libya', 128 => 'Liechtenstein', 129 => 'Lithuania', 130 => 'Luxembourg', 131 => 'Macedonia', 132 => 'Madagascar', 
											133 => 'Malawi', 134 => 'Malaysia', 135 => 'Maldives', 136 => 'Mali', 137 => 'Malta', 138 => 'Marshall Islands', 139 => 'Mauritania', 140 => 'Mauritius', 141 => 'Mexico', 142 => 'Micronesia', 143 => 'Moldova', 144 => 'Monaco', 145 => 'Mongolia', 146 => 'Morocco', 147 => 'Mozambique', 148 => 'Myanmar', 149 => 'Namibia', 150 => 'Nauru', 151 => 'Nepal', 152 => 'Netherlands', 153 => 'New Zealand', 154 => 'Nicaragua', 155 => 'Niger', 156 => 'Nigeria', 157 => 'Norway', 158 => 'Oman', 159 => 'Pakistan', 160 => 'Palau', 161 => 'Panama', 162 => 'Papua New Guinea', 163 => 'Paraguay', 164 => 'Peru', 165 => 'Philippines', 166 => 'Poland', 167 => 'Portugal', 168 => 'Puerto Rico', 169 => 'Qatar', 170 => 'Romania', 171 => 'Russia', 172 => 'Rwanda', 173 => 'Saint Kitts And Nevis', 174 => 'Saint Lucia', 175 => 'Samoa', 176 => 'San Marino', 177 => 'Sao Tome And Principe', 178 => 'Saudi Arabia', 179 => 'Scotland', 180 => 'Senegal', 181 => 'Seychelles', 182 => 'Sierra Leone', 183 => 'Singapore', 184 => 'Slovak Republic', 185 => 'Slovenia', 186 => 'Solomon Islands', 187 => 'Somalia', 188 => 'South Africa', 189 => 'Spain', 190 => 'Sri Lanka', 191 => 'Sudan', 192 => 'Suriname', 193 => 'Swaziland', 194 => 'Sweden', 195 => 'Switzerland', 196 => 'Syria', 197 => 'Taiwan', 198 => 'Tajikistan', 199 => 'Tanzania', 200 => 'Thailand', 201 => 'Togo', 202 => 'Tonga', 203 => 'Trinidad And Tobago', 204 => 'Tunisia', 205 => 'Turkey', 206 => 'Turkmenistan', 207 => 'Tuvalu', 208 => 'Uganda', 209 => 'Ukraine', 210 => 'United Arab Emirates', 211 => 'United Kingdom', 212 => 'United States', 213 => 'Uruguay', 214 => 'Uzbekistan', 215 => 'Vanuatu', 216 => 'Venezuela', 217 => 'Viet Nam', 218 => 'Yemen', 219 => 'Yugoslavia', 220 => 'Zambia', 221 => 'Zimbabwe');
			$aState = array(''=>'', 222 => 'Alabama', 223 => 'Alaska', 224 => 'Arizona', 225 => 'Arkansas', 226 => 'California', 227 => 'Colorado', 228 => 'Connecticut', 229 => 'Delaware', 230 => 'District Of Columbia', 231 => 'Florida', 232 => 'Georgia', 233 => 'Hawaii', 234 => 'Idaho', 235 => 'Illinois', 236 => 'Indiana', 237 => 'Iowa', 238 => 'Kansas', 239 => 'Kentucky', 240 => 'Louisiana', 241 => 'Maine', 242 => 'Maryland', 243 => 'Massachusetts', 244 => 'Michigan', 245 => 'Minnesota', 246 => 'Mississippi', 247 => 'Missouri', 248 => 'Montana', 249 => 'Nebraska', 250 => 'Nevada', 251 => 'New Hampshire', 252 => 'New Jersey', 253 => 'New Mexico', 254 => 'New York', 255 => 'North Carolina', 256 => 'North Dakota', 257 => 'Ohio', 258 => 'Oklahoma', 259 => 'Oregon', 260 => 'Pennsylvania', 261 => 'Rhode Island', 262 => 'South Carolina', 263 => 'South Dakota', 264 => 'Tennessee', 265 => 'Texas', 266 => 'Utah', 267 => 'Vermont', 268 => 'Virginia', 269 => 'Washington', 270 => 'West Virginia', 271 => 'Wisconsin', 272 => 'Wyoming');
			$aRow['id'] = $_REQUEST['id'];
			$aRow['name'] = stripslashes($aRow['name']);
			$smarty->assign('aSchool', $aRow);
			$smarty->assign('aCountry', $aCountry);
			$smarty->assign('aState', $aState);
			
			//IF PRIVATE, GET PENDING USERS
			if( $aRow['is_private'] == 1 && $aSttng['schoolsPrivate'] == 1 )
			{
				$iPage = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 0;
				$iLimit = ($iPage == "" ? 0 : ($iPage-1)*10);
				$iLimit2 = 10;
				$sql = "SELECT
								`id`,
								`user_id`
							FROM `school_mem`
							WHERE 
								`school_id` = '{$aRow['id']}' &&
								`status` = '3' 
							ORDER BY `id` ASC
							LIMIT ".$iLimit.", ".$iLimit2;
				$result=mysql_query($sql);
				$aPending = array();
				while( ($aRow = mysql_fetch_assoc($result)) )
				{
					$tempUser = new se_user(Array($aRow['user_id']));
					$aRow['photo'] = $tempUser->user_photo();
					$aRow['name'] = $tempUser->user_info['user_username'];
					$aPending[] = $aRow;
				}
				
				$sql = "	SELECT
									COUNT(*) AS `cnt`
								FROM `school_mem`
								WHERE 
									`school_id` = '{$aRow['id']}' &&
									`status` = '3' ";
				$rResult = mysql_query($sql);
				$aRow = mysql_fetch_assoc($rResult);
				$iNum = $aRow['cnt'];
				$iPgMax = ceil($iNum/$iLimit2);	 	 
				$smarty->assign('iNum', $iNum);
				$smarty->assign('iPgMax', $iPgMax);
				$smarty->assign('iPage', $iPage==0 ? 1 : $iPage );
				$smarty->assign('aPending', $aPending);
			}
		}else
			$smarty->assign('bPrompt', "permissionDenied");
		
	}else
		$smarty->assign('bPrompt', "pageNotFound");
}

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>