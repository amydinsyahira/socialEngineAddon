<?
$page = "admin_school";
include "admin_header.php";

if(isset($_POST['submit']))
{
	$bSubmit = true;
	$sql = "SELECT * FROM `school_options`";
	$result = mysql_query($sql);
	if( is_array($_POST['userlevels']) )
		$_POST['userlevels'] = implode(",", $_POST['userlevels']);
	else
		$_POST['userlevels'] = "";
	while($row = mysql_fetch_array($result))
	{
		$var = $row['var'];
		if(isset($_POST[$var]))
		{
			$sql2 = "UPDATE `school_options` SET `value` = '" . $_POST[$var] . "' WHERE `var` = '$var' LIMIT 1";
			$result2 = mysql_query($sql2);
		}
		
		if( $row['var'] == 'moderator' )
			$bModerator = $row['value'] == 1 ? TRUE : FALSE;
	}
	//Set all pending users for each school to members
	if( $_POST['moderator'] == 0 && $bModerator)
	{
		$sql = "UPDATE `school_mem` SET `status` = '1' WHERE `status` = '3' ";
		$result = mysql_query($sql);
	}
}

$sql = "SELECT * FROM `school_options`";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result)){
	$var = $row['var'];
	$value = $row['value'];
	$options[$var] = $value;
}
$options['userlevels'] = explode(",", $options['userlevels']);
foreach($options['userlevels'] as $k=>$v)
	$options['userlevels'][$k] = trim($v);
$smarty->assign('aOptions', $options);

$aUserLevels = array();
$sql = 'SELECT 
				`level_id`, `level_name` 
			FROM `se_levels` ';
$result = mysql_query($sql);
while( $aRow=mysql_fetch_assoc($result) )
{
	$aUserLevels[ $aRow['level_id'] ]['name'] = $aRow['level_name'];
	if( is_numeric(array_search($aRow['level_id'], $options['userlevels'])) )
		$aUserLevels[ $aRow['level_id'] ]['sel'] = 1;
}
$smarty->assign('aUserLevels', $aUserLevels);
include "admin_footer.php";
?>