<?
$page = "admin_schoolsAdd";
include "admin_header.php";

$aCountry= array(''=>'', 31 => 'Afghanistan', 33 => 'Algeria', 34 => 'Andorra', 35 => 'Angola', 36 => 'Antigua And Barbuda', 37 => 'Argentina', 38 => 'Armenia', 39 => 'Australia', 40 => 'Austria', 41 => 'Azerbaijan', 42 => 'Bahamas', 43 => 'Bahrain', 44 => 'Bangladesh', 45 => 'Barbados', 46 => 'Belarus', 47 => 'Belgium', 48 => 'Belize', 49 => 'Benin', 222 => 'Bermuda', 50 => 'Bhutan', 51 => 'Bolivia', 52 => 'Bosnia And Herzegovina', 53 => 'Botswana', 54 => 'Brazil', 55 => 'Brunei Darussalam', 56 => 'Bulgaria', 57 => 'Burkina Faso', 58 => 'Burundi', 59 => 'Cambodia', 60 => 'Cameroon', 61 => 'Canada', 62 => 'Cape Verde', 63 => 'Central African Republic', 64 => 'Chad', 65 => 'Chile', 66 => 'China', 67 => 'Colombia', 68 => 'Comoros', 69 => 'Costa Rica', 70 => 'Croatia', 71 => 'Cuba', 72 => 'Cyprus', 73 => 'Czech Republic', 74 => 'Denmark', 75 => 'Djibouti', 76 => 'Dominica', 77 => 'Dominican Republic', 78 => 'Ecuador', 79 => 'Egypt', 80 => 'El Salvador', 81 => 'Equatorial Guinea', 82 => 'Eritrea', 83 => 'Estonia', 84 => 'Ethiopia', 85 => 'Fiji', 86 => 'Finland', 87 => 'France', 88 => 'Gabon', 89 => 'Gambia', 90 => 'Georgia', 91 => 'Germany', 92 => 'Ghana', 93 => 'Greece', 94 => 'Grenada', 95 => 'Guatemala', 96 => 'Guinea', 97 => 'Guinea-bissau', 98 => 'Guyana', 99 => 'Haiti', 100 => 'Honduras', 101 => 'Hong Kong', 102 => 'Hungary', 103 => 'Iceland', 104 => 'India', 105 => 'Indonesia', 106 => 'Iran', 107 => 'Iraq', 108 => 'Ireland', 109 => 'Israel', 110 => 'Italy', 111 => 'Ivory Coast', 112 => 'Jamaica', 113 => 'Japan', 114 => 'Jordan', 115 => 'Kazakhstan', 116 => 'Kenya', 117 => 'Kiribati', 118 => 'Korea (north)', 119 => 'Korea (south)', 120 => 'Kuwait', 121 => 'Kyrgyzstan', 122 => 'Laos', 123 => 'Latvia', 124 => 'Lebanon', 125 => 'Lesotho', 126 => 'Liberia', 127 => 'Libya', 128 => 'Liechtenstein', 129 => 'Lithuania', 130 => 'Luxembourg', 131 => 'Macedonia', 132 => 'Madagascar', 133 => 'Malawi', 134 => 'Malaysia', 135 => 'Maldives', 136 => 'Mali', 137 => 'Malta', 138 => 'Marshall Islands', 139 => 'Mauritania', 140 => 'Mauritius', 141 => 'Mexico', 142 => 'Micronesia', 143 => 'Moldova', 144 => 'Monaco', 145 => 'Mongolia', 146 => 'Morocco', 147 => 'Mozambique', 148 => 'Myanmar', 149 => 'Namibia', 150 => 'Nauru', 151 => 'Nepal', 152 => 'Netherlands', 153 => 'New Zealand', 154 => 'Nicaragua', 155 => 'Niger', 156 => 'Nigeria', 157 => 'Norway', 158 => 'Oman', 159 => 'Pakistan', 160 => 'Palau', 161 => 'Panama', 162 => 'Papua New Guinea', 163 => 'Paraguay', 164 => 'Peru', 165 => 'Philippines', 166 => 'Poland', 167 => 'Portugal', 168 => 'Puerto Rico', 169 => 'Qatar', 170 => 'Romania', 171 => 'Russia', 172 => 'Rwanda', 173 => 'Saint Kitts And Nevis', 174 => 'Saint Lucia', 175 => 'Samoa', 176 => 'San Marino', 177 => 'Sao Tome And Principe', 178 => 'Saudi Arabia', 179 => 'Scotland', 180 => 'Senegal', 181 => 'Seychelles', 182 => 'Sierra Leone', 183 => 'Singapore', 184 => 'Slovak Republic', 185 => 'Slovenia', 186 => 'Solomon Islands', 187 => 'Somalia', 188 => 'South Africa', 189 => 'Spain', 190 => 'Sri Lanka', 191 => 'Sudan', 192 => 'Suriname', 193 => 'Swaziland', 194 => 'Sweden', 195 => 'Switzerland', 196 => 'Syria', 197 => 'Taiwan', 198 => 'Tajikistan', 199 => 'Tanzania', 200 => 'Thailand', 201 => 'Togo', 202 => 'Tonga', 203 => 'Trinidad And Tobago', 204 => 'Tunisia', 205 => 'Turkey', 206 => 'Turkmenistan', 207 => 'Tuvalu', 208 => 'Uganda', 209 => 'Ukraine', 210 => 'United Arab Emirates', 211 => 'United Kingdom', 212 => 'United States', 213 => 'Uruguay', 214 => 'Uzbekistan', 215 => 'Vanuatu', 216 => 'Venezuela', 217 => 'Viet Nam', 218 => 'Yemen', 219 => 'Yugoslavia', 220 => 'Zambia', 221 => 'Zimbabwe');
$aState = array(''=>'', 222 => 'Alabama', 223 => 'Alaska', 224 => 'Arizona', 225 => 'Arkansas', 226 => 'California', 227 => 'Colorado', 228 => 'Connecticut', 229 => 'Delaware', 230 => 'District Of Columbia', 231 => 'Florida', 232 => 'Georgia', 233 => 'Hawaii', 234 => 'Idaho', 235 => 'Illinois', 236 => 'Indiana', 237 => 'Iowa', 238 => 'Kansas', 239 => 'Kentucky', 240 => 'Louisiana', 241 => 'Maine', 242 => 'Maryland', 243 => 'Massachusetts', 244 => 'Michigan', 245 => 'Minnesota', 246 => 'Mississippi', 247 => 'Missouri', 248 => 'Montana', 249 => 'Nebraska', 250 => 'Nevada', 251 => 'New Hampshire', 252 => 'New Jersey', 253 => 'New Mexico', 254 => 'New York', 255 => 'North Carolina', 256 => 'North Dakota', 257 => 'Ohio', 258 => 'Oklahoma', 259 => 'Oregon', 260 => 'Pennsylvania', 261 => 'Rhode Island', 262 => 'South Carolina', 263 => 'South Dakota', 264 => 'Tennessee', 265 => 'Texas', 266 => 'Utah', 267 => 'Vermont', 268 => 'Virginia', 269 => 'Washington', 270 => 'West Virginia', 271 => 'Wisconsin', 272 => 'Wyoming');
$smarty->assign('aCountry', $aCountry);
$smarty->assign('aState', $aState);

$aSchool = array();
$smarty->assign('iType', 0);
if ( isset($_POST['submit']) ) 
{
	$aSchool['name'] = $_POST['name'];
	$aSchool['country'] = $_POST['country'];
	$aSchool['state'] = $_POST['otherState'] != "Other State or Province" && $_POST['otherState'] != "" ? $_POST['otherState'] : $_POST['state'];
	$aSchool['city'] = $_POST['city'];
	$aSchool['address'] = $_POST['address'];
	
	if( $_POST['user'] != "" )
	{
		$sql = "SELECT `user_id` FROM `se_users` WHERE `user_username` = '{$_POST['user']}' ";
		$result = mysql_query($sql);
		if( $aRow = mysql_fetch_assoc($result) )
			$aSchool['admin'] = $aRow['user_id'];
	}

	//Create school if name isset
	if( $aSchool['name'] != "" )
	{
		$sql = "INSERT INTO `schools` 
						(`name`, `country`, `state`, `city`, `address`)
					VALUES
						('{$aSchool['name']}', '{$aSchool['country']}', '{$aSchool['state']}', '{$aSchool['city']}', '{$aSchool['address']}')";
		$result = mysql_query($sql);
		if( $iSchoolId = mysql_insert_id() )
		{
			//Add Admin
			if( array_key_exists('admin', $aSchool) )
			{
				$iTime = time();
				$sql = "INSERT INTO `school_mem` 
								(`school_id`, `user_id`, `status`, `time`, `is_admin`)
							VALUES
								('{$iSchoolId}', '{$aSchool['admin']}', '1', '{$iTime}', '1')";
				$result = mysql_query($sql);
			}
			
			//Add Image
			if(!isset($_FILES) && isset($HTTP_POST_FILES))
				$_FILES = $HTTP_POST_FILES;
			$fsize = $_FILES['newImage']['size'];
			if($fsize > 0)
			{
				$ftype = $_FILES['newImage']['type'];
				if($ftype == "image/jpeg" ||  $ftype == "image/gif" || $ftype == "image/pjpeg")
				{ 
					$imagename = basename($_FILES['newImage']['name']);
					$intDot = strripos($imagename, '.');
					$sPt1 = substr($imagename, 0, $intDot);
					$sPt2 = substr($imagename, $intDot);
					$sql = "SELECT*FROM `school_pic` WHERE `file` = '".$imagename."' LIMIT 1";
					$result = mysql_query($sql);
					while( ($row = mysql_fetch_assoc($result)) )
					{
						$imagename = str_shuffle($sPt1).$sPt2;
						$sql = "SELECT*FROM `school_pic` WHERE `file` = '".$imagename."' LIMIT 1";
						$result = mysql_query($sql);
					}
					$imagename2 = "../file/schools/" . $imagename;
					$result = @move_uploaded_file($_FILES['newImage']['tmp_name'], $imagename2);
					if($result)
					{
						chmod($imagename2, 0644);
						$sSql = "	INSERT INTO `school_pic` 
											(`school_id`, `file`, `time`) 
										VALUES 
											('{$iSchoolId}', '{$imagename}', '{$iTime}') ";
						$result = mysql_query($sSql);
						$iPicId = mysql_insert_id();
						$sql = "	UPDATE `schools`
										SET `def_pic` = '{$iPicId}'
										WHERE `id`= '{$iSchoolId}' ";
						$result = mysql_query($sql);
					}
				}
			}
		}
		$smarty->assign('iType', 1);
		unset($aSchool);
	}
	//ELSE ERRORS
	else
	{
		$aSchool['name'] = stripslashes($_POST['name']);
		$aSchool['country'] = stripslashes($_POST['country']);
		$aSchool['state'] =stripslashes($_POST['state']);
		$aSchool['city'] = stripslashes($_POST['city']);
		$aSchool['address'] = stripslashes($_POST['address']);
		$aSchool['user'] = stripslashes($_POST['user']);
		$aSchool['type'] = stripslashes($_POST['type']);
		$smarty->assign('iType', 2);
	}
}
$smarty->assign('aSchool', $aSchool);

include "admin_footer.php";
?>