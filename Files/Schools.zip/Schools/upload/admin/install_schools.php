<?php
$aLangList = array();
$sSql = 'SELECT `language_id`, `language_default` FROM `se_languages` ';
$rResult = mysql_query($sSql);
while( ($aRow = mysql_fetch_assoc($rResult)) )
{
	$aLangList[] = $aRow['language_id'];
	if( $aRow['language_default'] == 1 )
	{
		$iDefaultKey = count($aLangList);
		$iDefaultId = $aRow['language_id'];
	}
}
$iDefaultKey = count($aLangList) - $iDefaultKey;

$sSql = 'SELECT `languagevar_id` FROM `se_languagevars` ORDER BY `languagevar_id` DESC LIMIT 1';
$rResult = mysql_query($sSql);
$aRow = mysql_fetch_assoc($rResult);
$iLast = $aRow['languagevar_id'];

$sSql = 'SELECT `languagevar_id` FROM `se_languagevars` WHERE `languagevar_value` = "SEG Schools" && `languagevar_default` = "admin_home" ';
$rResult = mysql_query($sSql);
if( ($aRow = mysql_fetch_assoc($rResult) ) )
	$iPlugin = $aRow['languagevar_id'];
else
{
	$iPlugin = $iLast + 1;
	$sSql = '	INSERT INTO 
					`se_languagevars` 
				(`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
				VALUES 
				('.$iPlugin.', "1", "SEG Schools", "admin_home")
			';
	$rResult = mysql_query($sSql);
}

$aLangData = array();
//Create Schools
$aLangData[1]['value'] = 'Add School'; $aLangData[1]['default'] = 'user_createSchool'; $aLangData[1]['defaultKey'] = 'user_createSchool.add_school';
$aLangData[2]['value'] = 'Feature has been disabled'; $aLangData[2]['default'] = ' user_createSchool, '; $aLangData[2]['defaultKey'] = 'user_createSchool.feature_has_been_disabled';
$aLangData[3]['value'] ='(Notice)'; $aLangData[3]['default'] = ' user_createSchool, '; $aLangData[3]['defaultKey'] = 'user_createSchool.notice';
$aLangData[4]['value'] = 'Your school has been added'; $aLangData[4]['default'] = ' user_createSchool, '; $aLangData[4]['defaultKey'] = 'user_createSchool.your_school_has_been_added';
$aLangData[5]['value'] = 'Your school could not be added'; $aLangData[5]['default'] = ' user_createSchool, '; $aLangData[5]['defaultKey'] = 'user_createSchool.your_school_could_not_be_added';
$aLangData[6]['value'] = 'School Name'; $aLangData[6]['default'] = ' user_createSchool, '; $aLangData[6]['defaultKey'] = 'user_createSchool.school_name';
$aLangData[7]['value'] = 'Country'; $aLangData[7]['default'] = ' user_createSchool, '; $aLangData[7]['defaultKey'] = 'user_createSchool.country';
$aLangData[8]['value'] = 'State'; $aLangData[8]['default'] = ' user_createSchool, '; $aLangData[8]['defaultKey'] = 'user_createSchool.state';
$aLangData[9]['value'] = 'City'; $aLangData[9]['default'] = ' user_createSchool, '; $aLangData[9]['defaultKey'] = 'user_createSchool.city';
$aLangData[10]['value'] = 'Address'; $aLangData[10]['default'] = ' user_createSchool, '; $aLangData[10]['defaultKey'] = 'user_createSchool.address';
$aLangData[11]['value'] = "Upload Picture"; $aLangData[11]['default'] = ' user_createSchool, '; $aLangData[11]['defaultKey'] = 'user_createSchool.upload_picture';
//Browse Schools
$aLangData[12]['value'] = 'Browse Schools'; $aLangData[12]['default'] = ' schoolBrowse, '; $aLangData[12]['defaultKey'] = 'schoolBrowse.browse_schools';
$aLangData[13]['value'] = 'Search Schools'; $aLangData[13]['default'] = ' schoolBrowse, '; $aLangData[13]['defaultKey'] = 'schoolBrowse.search_schools';
$aLangData[14]['value'] = 'Find'; $aLangData[14]['default'] = ' schoolBrowse, '; $aLangData[14]['defaultKey'] = 'schoolBrowse.find';
$aLangData[15]['value'] = 'Name'; $aLangData[15]['default'] = ' schoolBrowse, '; $aLangData[15]['defaultKey'] = 'schoolBrowse.name';
$aLangData[16]['value'] = 'Country'; $aLangData[16]['default'] = ' schoolBrowse, '; $aLangData[16]['defaultKey'] = 'schoolBrowse.country';
$aLangData[17]['value'] = 'State'; $aLangData[17]['default'] = ' schoolBrowse, '; $aLangData[17]['defaultKey'] = 'schoolBrowse.state';
$aLangData[18]['value'] = 'City'; $aLangData[18]['default'] = ' schoolBrowse, '; $aLangData[18]['defaultKey'] = 'schoolBrowse.city';
$aLangData[19]['value'] = 'Address'; $aLangData[19]['default'] = ' schoolBrowse, '; $aLangData[19]['defaultKey'] = 'schoolBrowse.address';
$aLangData[20]['value'] = 'No schools found.'; $aLangData[20]['default'] = ' schoolBrowse, '; $aLangData[20]['defaultKey'] = 'schoolBrowse.no_schools_found';
$aLangData[32]['value'] = 'Feature has been disabled'; $aLangData[32]['default'] = ' schoolBrowse, '; $aLangData[32]['defaultKey'] = 'schoolBrowse.feature_has_been_disabled';
$aLangData[33]['value'] = '(Notice)'; $aLangData[33]['default'] = ' schoolBrowse, '; $aLangData[33]['defaultKey'] = 'schoolBrowse.notice';
$aLangData[67]['value'] = 'Join'; $aLangData[67]['default'] = ' schoolBrowse, '; $aLangData[67]['defaultKey'] = 'schoolBrowse.join';
$aLangData[68]['value'] = 'Enrolled'; $aLangData[68]['default'] = ' schoolBrowse, '; $aLangData[68]['defaultKey'] = 'schoolBrowse.enrolled';
$aLangData[69]['value'] = 'Pending'; $aLangData[69]['default'] = ' schoolBrowse, '; $aLangData[69]['defaultKey'] = 'schoolBrowse.pending';
$aLangData[93]['value'] = 'Add a School'; $aLangData[93]['default'] = ' schoolBrowse, '; $aLangData[93]['defaultKey'] = 'schoolBrowse.add_a_school';
//My Schools
$aLangData[21]['value'] = 'My Schools'; $aLangData[21]['default'] = ' user_mySchools, '; $aLangData[21]['defaultKey'] = 'user_mySchools.my_schools';
$aLangData[22]['value'] = 'Name'; $aLangData[22]['default'] = ' user_mySchools, '; $aLangData[22]['defaultKey'] = 'user_mySchools.name';
$aLangData[23]['value'] = 'Country'; $aLangData[23]['default'] = ' user_mySchools, '; $aLangData[23]['defaultKey'] = 'user_mySchools.country';
$aLangData[24]['value'] = 'Member Type'; $aLangData[24]['default'] = ' user_mySchools, '; $aLangData[24]['defaultKey'] = 'user_mySchools.member_type';
$aLangData[25]['value'] = 'Moderator'; $aLangData[25]['default'] = ' user_mySchools, '; $aLangData[25]['defaultKey'] = 'user_mySchools.moderator';
$aLangData[26]['value'] = 'Regular Member'; $aLangData[26]['default'] = ' user_mySchools, '; $aLangData[26]['defaultKey'] = 'user_mySchools.regular_member';
$aLangData[27]['value'] = 'Manage School'; $aLangData[27]['default'] = ' user_mySchools, '; $aLangData[27]['defaultKey'] = 'user_mySchools.manage_school';
$aLangData[28]['value'] = 'You are not a member of any schools'; $aLangData[28]['default'] = ' user_mySchools, '; $aLangData[28]['defaultKey'] = 'user_mySchools.you_are_not_a_member_of_any_schools';
$aLangData[29]['value'] = 'Feature has been disabled'; $aLangData[29]['default'] = ' user_mySchools, '; $aLangData[29]['defaultKey'] = 'user_mySchools.feature_has_been_disabled';
$aLangData[30]['value'] = '(Notice)'; $aLangData[30]['default'] = ' user_mySchools, '; $aLangData[30]['defaultKey'] = 'user_mySchools.notice';
$aLangData[31]['value'] = 'You are now a moderator for a school'; $aLangData[31]['default'] = ' user_mySchools, '; $aLangData[31]['defaultKey'] = 'user_mySchools.you_are_now_a_moderator_for_a_school';
$aLangData[88]['value'] = 'Leave School'; $aLangData[88]['default'] = ' user_mySchools, '; $aLangData[88]['defaultKey'] = 'user_mySchools.leave_school';
$aLangData[94]['value'] = 'Add a School'; $aLangData[94]['default'] = ' user_mySchools, '; $aLangData[94]['defaultKey'] = 'user_mySchools.add_a_school';
//School Settings
$aLangData[34]['value'] = 'Manage School';  $aLangData[34]['default'] = ' user_schoolSettings, '; $aLangData[34]['defaultKey'] = 'user_schoolSettings.manage_school';
$aLangData[35]['value'] = '(Notice)'; $aLangData[35]['default'] = ' user_schoolSettings, '; $aLangData[35]['defaultKey'] = 'user_schoolSettings.notice';
$aLangData[36]['value'] = 'Feature has been disabled'; $aLangData[36]['default'] = ' user_schoolSettings, '; $aLangData[36]['defaultKey'] = 'user_schoolSettings.feature_has_been_disabled';
$aLangData[37]['value'] = 'You do not have permission to view this page';  $aLangData[37]['default'] = ' user_schoolSettings, '; $aLangData[37]['defaultKey'] = 'user_schoolSettings.you_do_not_have_permission_to_view_this_page';
$aLangData[38]['value'] = 'Page cannot be found'; $aLangData[38]['default'] = ' user_schoolSettings, '; $aLangData[38]['defaultKey'] = 'user_schoolSettings.page_cannot_be_found';
$aLangData[39]['value'] = 'School info have been updated'; $aLangData[39]['default'] = ' user_schoolSettings, '; $aLangData[39]['defaultKey'] = 'user_schoolSettings.school_info_has_been_updated';
$aLangData[40]['value'] = 'Edit School'; $aLangData[40]['default'] = ' user_schoolSettings, '; $aLangData[40]['defaultKey'] = 'user_schoolSettings.edit_school';
$aLangData[41]['value'] = 'School Name'; $aLangData[41]['default'] = ' user_schoolSettings, '; $aLangData[41]['defaultKey'] = 'user_schoolSettings.school_name';
$aLangData[42]['value'] = 'Country'; $aLangData[42]['default'] = ' user_schoolSettings, '; $aLangData[42]['defaultKey'] = 'user_schoolSettings.country';
$aLangData[43]['value'] = 'State'; $aLangData[43]['default'] = ' user_schoolSettings, '; $aLangData[43]['defaultKey'] = 'user_schoolSettings.state';
$aLangData[44]['value'] = 'City'; $aLangData[44]['default'] = ' user_schoolSettings, '; $aLangData[44]['defaultKey'] = 'user_schoolSettings.city';
$aLangData[45]['value'] = 'Address'; $aLangData[45]['default'] = ' user_schoolSettings, '; $aLangData[45]['defaultKey'] = 'user_schoolSettings.address';
$aLangData[46]['value'] = 'Set School to Private'; $aLangData[46]['default'] = ' user_schoolSettings, '; $aLangData[46]['defaultKey'] = 'user_schoolSettings.set_school_to_private';
$aLangData[47]['value'] = 'Yes'; $aLangData[47]['default'] = ' user_schoolSettings, '; $aLangData[47]['defaultKey'] = 'user_schoolSettings.yes';
$aLangData[48]['value'] = 'No'; $aLangData[48]['default'] = ' user_schoolSettings, '; $aLangData[48]['defaultKey'] = 'user_schoolSettings.no';
$aLangData[49]['value'] = 'Upload Picture'; $aLangData[49]['default'] = ' user_schoolSettings, '; $aLangData[49]['defaultKey'] = 'user_schoolSettings.upload_picture';
$aLangData[50]['value'] = 'Change School Info'; $aLangData[50]['default'] = ' user_schoolSettings, '; $aLangData[50]['defaultKey'] = 'user_schoolSettings.change_school_info';
$aLangData[51]['value'] = 'Pending member requests'; $aLangData[51]['default'] = ' user_schoolSettings, '; $aLangData[51]['defaultKey'] = 'user_schoolSettings.pending_member_requests';
$aLangData[52]['value'] = 'No member requests'; $aLangData[52]['default'] = ' user_schoolSettings, '; $aLangData[52]['defaultKey'] = 'user_schoolSettings.no_member_requests';
$aLangData[53]['value'] = 'Approve'; $aLangData[53]['default'] = ' user_schoolSettings, '; $aLangData[53]['defaultKey'] = 'user_schoolSettings.approve';
$aLangData[54]['value'] = 'Deny'; $aLangData[54]['default'] = ' user_schoolSettings, '; $aLangData[54]['defaultKey'] = 'user_schoolSettings.deny';
//School Members
$aLangData[55]['value'] = 'Members';  $aLangData[55]['default'] = ' schoolMembers, '; $aLangData[55]['defaultKey'] = 'schoolMembers.members';
$aLangData[56]['value'] = '(Notice)'; $aLangData[56]['default'] = ' schoolMembers, '; $aLangData[56]['defaultKey'] = 'schoolMembers.notice';
$aLangData[57]['value'] = 'Feature has been disabled'; $aLangData[57]['default'] = ' schoolMembers, '; $aLangData[57]['defaultKey'] = 'schoolMembers.feature_has_been_disabled';
$aLangData[58]['value'] = 'You do not have permission to view this page';  $aLangData[58]['default'] = ' schoolMembers, '; $aLangData[58]['defaultKey'] = 'schoolMembers.you_do_not_have_permission_to_view_this_page';
$aLangData[59]['value'] = 'Page cannot be found'; $aLangData[59]['default'] = ' schoolMembers, '; $aLangData[59]['defaultKey'] = 'schoolMembers.page_cannot_be_found';
$aLangData[60]['value'] = 'Search Members'; $aLangData[60]['default'] = ' schoolMembers, '; $aLangData[60]['defaultKey'] = 'schoolMembers.search_members';
$aLangData[61]['value'] = 'Find'; $aLangData[61]['default'] = ' schoolMembers, '; $aLangData[61]['defaultKey'] = 'schoolMembers.find';
$aLangData[62]['value'] = 'Name'; $aLangData[62]['default'] = ' schoolMembers, '; $aLangData[62]['defaultKey'] = 'schoolMembers.name';
$aLangData[63]['value'] = 'Graduation Year'; $aLangData[63]['default'] = ' schoolMembers, '; $aLangData[63]['defaultKey'] = 'schoolMembers.graduation_year';
$aLangData[64]['value'] = 'Ban'; $aLangData[64]['default'] = ' schoolMembers, '; $aLangData[64]['defaultKey'] = 'schoolMembers.ban';
$aLangData[65]['value'] = 'Unban'; $aLangData[65]['default'] = ' schoolMembers, '; $aLangData[65]['defaultKey'] = 'schoolMembers.unban';
$aLangData[66]['value'] = 'No members for this school'; $aLangData[66]['default'] = ' schoolMembers, '; $aLangData[66]['defaultKey'] = 'schoolMembers.no_members_for_school';
$aLangData[87]['value'] = 'View School'; $aLangData[87]['default'] = ' schoolMembers, '; $aLangData[87]['defaultKey'] = 'schoolMembers.view_school';
$aLangData[89]['value'] = 'Regular Member'; $aLangData[89]['default'] = ' schoolMembers, '; $aLangData[89]['defaultKey'] = 'schoolMembers.regular_member';
$aLangData[90]['value'] = 'Moderator'; $aLangData[90]['default'] = ' schoolMembers, '; $aLangData[90]['defaultKey'] = 'schoolMembers.moderator';
$aLangData[91]['value'] = 'Member type'; $aLangData[91]['default'] = ' schoolMembers, '; $aLangData[91]['defaultKey'] = 'schoolMembers.member_type';
$aLangData[92]['value'] = 'Action'; $aLangData[92]['default'] = ' schoolMembers, '; $aLangData[92]['defaultKey'] = 'schoolMembers.action';
//Profile
$aLangData[70]['value'] = 'Schools'; $aLangData[70]['default'] = ' profile, '; $aLangData[70]['defaultKey'] = 'profile.schools';
$aLangData[71]['value'] = 'My Schools'; $aLangData[71]['default'] = ' profile, '; $aLangData[71]['defaultKey'] = 'profile.my_schools';
$aLangData[72]['value'] = 'Browse Schools'; $aLangData[72]['default'] = ' profile, '; $aLangData[72]['defaultKey'] = 'profile.browse_schools';
//Schools
$aLangData[73]['value'] = '(Notice)'; $aLangData[73]['default'] = ' schools, '; $aLangData[73]['defaultKey'] = 'schools.notice';
$aLangData[74]['value'] = 'Feature has been disabled'; $aLangData[74]['default'] = ' schools, '; $aLangData[74]['defaultKey'] = 'schools.feature_has_been_disabled';
$aLangData[75]['value'] = 'You do not have permission to view this page'; $aLangData[75]['default'] = ' schools, '; $aLangData[75]['defaultKey'] = 'schools.you_do_not_have_permission_to_view_this_page';
$aLangData[76]['value'] = 'Page cannot be found'; $aLangData[76]['default'] = ' schools, '; $aLangData[76]['defaultKey'] = 'schools.page_cannot_be_found';
$aLangData[77]['value'] = 'Country'; $aLangData[77]['default'] = ' schools, '; $aLangData[77]['defaultKey'] = 'schools.country';
$aLangData[78]['value'] = 'State'; $aLangData[78]['default'] = ' schools, '; $aLangData[78]['defaultKey'] = 'schools.state';
$aLangData[79]['value'] = 'City'; $aLangData[79]['default'] = ' schools, '; $aLangData[79]['defaultKey'] = 'schools.city';
$aLangData[80]['value'] = 'Address'; $aLangData[80]['default'] = ' schools, '; $aLangData[80]['defaultKey'] = 'schools.address';
$aLangData[81]['value'] = 'Rating'; $aLangData[81]['default'] = ' schools, '; $aLangData[81]['defaultKey'] = 'schools.rating';
$aLangData[82]['value'] = 'Terrible'; $aLangData[82]['default'] = ' schools, '; $aLangData[82]['defaultKey'] = 'schools.terrible';
$aLangData[83]['value'] = 'Ok'; $aLangData[83]['default'] = ' schools, '; $aLangData[83]['defaultKey'] = 'schools.ok';
$aLangData[84]['value'] = 'Awesome'; $aLangData[84]['default'] = ' schools, '; $aLangData[84]['defaultKey'] = 'schools.awesome';
$aLangData[85]['value'] = 'Rate'; $aLangData[85]['default'] = ' schools, '; $aLangData[85]['defaultKey'] = 'schools.rate';
$aLangData[86]['value'] = 'View Members'; $aLangData[86]['default'] = ' schools, '; $aLangData[86]['defaultKey'] = 'schools.view_members';

//$aLangData[95]['value'] = 'View Members'; $aLangData[95]['default'] = ' schools, '; $aLangData[95]['defaultKey'] = 'schools.view_members';
foreach($aLangData as $k=>$v)
{
	$sSql = 'SELECT `languagevar_id` FROM `se_languagevars` WHERE `languagevar_value` = "'.$v['value'].'" && `languagevar_default` = "'.$v['default'].'" && `languagevar_language_id` = "'.$iDefaultId.'" ';
	$rResult = mysql_query($sSql);
	if( ($aRow = mysql_fetch_assoc($rResult) ) )
		$aLangData[$k]['id'] = $aRow['languagevar_id'];
	else
	{
		$aTemp = array();
		foreach($aLangList as $v2)
		{
			$iLast++;
			$aTemp[] = '("'.$iLast.'", "'.$v2.'", "'.$v['value'].'", "'.$v['default'].'")';
		}
		$sSql = '	INSERT INTO 
							`se_languagevars` 
						(`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) 
						VALUES '.implode(', ', $aTemp);
		$rResult = mysql_query($sSql);
		$aLangData[$k]['id'] = $iLast - $iDefaultKey;
	}
}

$sql = 'CREATE TABLE `schools_langKey` ('
        . ' `id` INT(12) NOT NULL AUTO_INCREMENT PRIMARY KEY, '
        . ' `defVarName` VARCHAR(250) NOT NULL, '
        . ' `languagevar_id` INT(12) NOT NULL '
        . ' )'
        . ' ENGINE = myisam;';
$result=mysql_query($sql);

$aSttngs = array();
$sSql = 'SELECT * FROM `schools_langKey` ';
$rResult = mysql_query($sSql);
while( ($aRow = mysql_fetch_assoc($rResult)) )
	$aSttngs[$aRow['defVarName']] = $aRow;

if( !array_key_exists('AdminTitle', $aSttngs) )
{
	$sSql = 'INSERT INTO `schools_langKey` (`defVarName`, `languagevar_id`) VALUES ("AdminTitle", "'.$iPlugin.'") ';
	$rResut = mysql_query($sSql);
}

foreach($aLangData as $k=>$v)
	if( !array_key_exists($v['defaultKey'], $aSttngs) )
	{
		$sSql = "INSERT INTO `schools_langKey` (`defVarName`, `languagevar_id`) VALUES ('{$v['defaultKey']}', '{$v['id']}') ";
		$rResut = mysql_query($sSql);
	}

$plugin_name = "Schools Plugin"; // Plugin's Title
$plugin_version = 1.00; // Plugin's Version
$plugin_type = "Schools"; // Plugin's Unique Identifying Name
$plugin_desc = "Social Engine Guru Schools Plugin"; // Plugin's Description
$plugin_icon = "school.gif"; // Plugin's Icon
$plugin_pages_main = "$iPlugin<!>school.gif<!>admin_school.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";

if($install == "Schools") 
{
	//######### INSERT ROW INTO se_plugins
	if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
	$database->database_query("INSERT INTO se_plugins (plugin_name, plugin_version, plugin_type, plugin_desc, plugin_icon, plugin_pages_main, plugin_pages_level, plugin_url_htaccess) VALUES ('$plugin_name', '$plugin_version', '$plugin_type', '$plugin_desc', '$plugin_icon', '$plugin_pages_main', '$plugin_pages_level', '$plugin_url_htaccess')");
	//######### UPDATE PLUGIN VERSION IN se_plugins
	} else {
	$database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name', plugin_version='$plugin_version', plugin_desc='$plugin_desc', plugin_icon='$plugin_icon', plugin_pages_main='$plugin_pages_main', plugin_pages_level='$plugin_pages_level', plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
	}
}

$sql = 'CREATE TABLE IF NOT EXISTS `schools` ('
			. ' `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, '
			. ' `name` TEXT NOT NULL, '
			. ' `country` SMALLINT(3) NOT NULL, '
			. ' `state` VARCHAR(250) NOT NULL, '
			. ' `city` VARCHAR(250) NOT NULL, '
			. ' `address` VARCHAR(250) NOT NULL, '
			. ' `votes` INT(12) NOT NULL, '
			. ' `total` INT(14) NOT NULL, '
			. ' `is_private` TINYINT(1) NOT NULL, '
			. ' `def_pic` INT(12) NOT NULL '
			. ' )'
			. ' ENGINE = myisam;';
$result = mysql_query($sql);

//status 0=not enrolled, 1= enrolled, 2=banned, 3=pending
//voted: 0=no 1=yes
$sql2 = 'CREATE TABLE IF NOT EXISTS `school_mem` ('
        . ' `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, '
        . ' `school_id` INT(12) NOT NULL, '
        . ' `user_id` VARCHAR(100) NOT NULL, '
        . ' `voted` TINYINT(1) NOT NULL, '
        . ' `status` TINYINT(1) NOT NULL, '
        . ' `year` INT(12) NOT NULL, '
        . ' `time` INT(12) NOT NULL, '
        . ' `is_admin` VARCHAR(6) NOT NULL '
        . ' )'
        . ' ENGINE = myisam;';
$result2 = mysql_query($sql2);

$sql3 = 'CREATE TABLE IF NOT EXISTS `school_comment` ('
        . ' `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, '
        . ' `school_id` VARCHAR(100) NOT NULL, '
        . ' `cid` INT(10) NOT NULL, '
        . ' `time` INT(12) NOT NULL, '
		. ' `text` TEXT NOT NULL '
        . ' )'
        . ' ENGINE = myisam;';
$result3 = mysql_query($sql3);

$sql = 'CREATE TABLE IF NOT EXISTS `school_pic` ('
        . ' `pic_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, '
        . ' `user_id` INT(10) NOT NULL, '
        . ' `school_id` INT(10) NOT NULL, '
        . ' `file` VARCHAR(100) NOT NULL, '
		. ' `description` TEXT NOT NULL, '
		. ' `order` INT(5) NOT NULL, '
        . ' `time` INT(12) NOT NULL '
        . ' )'
        . ' ENGINE = myisam;';
$result = mysql_query($sql);

$sql = 'CREATE TABLE IF NOT EXISTS `school_options` (`id` INT(12) NOT NULL AUTO_INCREMENT, `var` VARCHAR(250) NOT NULL, `value` VARCHAR(250) NOT NULL, PRIMARY KEY (`id`)) ENGINE = MyISAM';
$result = mysql_query($sql);

//options
$var = array();
$value = array();

// 1 = yes, 0 = no

$var[] = "canBan";
$value[] = "1";

$var[] = "moderator";
$value[] = "1";

$var[] = "createSch";
$value[] = "1";

$var[] = "schoolsPrivate";
$value[] = "0";

$var[] = "userlevels";
$value[] = "0,1,2,3,4,5";

$var[] = "footerlink";
$value[] = "1";


$count = count($var);

for($i=0;$i<$count;$i++)
{
	$sql = "SELECT * FROM `school_options` WHERE `var` = '" . $var[$i] . "'";
	$result = mysql_query($sql);
	$num = mysql_num_rows($result);
	if($num == 0){
		$sql = "INSERT INTO `school_options` (`var`, `value`) VALUES ('" . $var[$i] . "', '" . $value[$i] . "')";
		$result = mysql_query($sql);
	}
}

?>