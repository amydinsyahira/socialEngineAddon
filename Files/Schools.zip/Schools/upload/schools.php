<?php
$page = "schools";
include "header.php";
////////GET LANG IDS
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'schools.', '') AS `key`
				FROM `schools_langKey` WHERE `defVarName` LIKE '%schools.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aSttng = array();
$sSql = "	SELECT 
					* 
				FROM `school_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
if( $aSttng['userlevels'] != "")
	$aSttng['userlevels'] = explode(",", $aSttng['userlevels']);
$smarty->assign('aSchoolSetting', $aSttng);
//////////////////////////////////////////////////////////////////////////////////////////////////////
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);

$smarty->assign('bPage', FALSE);
if( isset($_REQUEST['id']) )
{
	$_REQUEST['id'] = mysql_real_escape_string($_REQUEST['id']);
	$sql = "	SELECT 
						`m`.`user_id`,
						`m`.`is_admin`,
						`m`.`voted`,
						`p`.`file`,
						`s`.`is_private`,
						`s`.`name`,
						`s`.`country`,
						`s`.`state`,
						`s`.`city`,
						`s`.`address`,
						`s`.`votes`,
						`s`.`total`
					FROM `schools` AS `s`
					LEFT JOIN `school_mem` AS `m` 
					ON `m`.`school_id` = `s`.`id` && `m`.`user_id` = '{$iUserId}'
					LEFT JOIN `school_pic` AS `p`
					ON `p`.`pic_id` = `s`.`def_pic`
					WHERE
						`s`.`id` = '{$_REQUEST['id']}' ";
	$result = mysql_query($sql);
	if( $aRow = mysql_fetch_assoc($result) )
	{
		if( $aRow['is_private'] == 1 && $aSttng['schoolsPrivate'] == 1 && isset($aRow['user_id']) || $aSttng['schoolsPrivate'] == 0 || $aRow['is_private'] == 0 )
		{
			if( isset($_POST['voted'], $_POST['vote'], $aRow['user_id']) && $_POST['vote'] > 0 && $_POST['vote'] < 6 && $aRow['voted'] == 0 )
			{
				$sql = "UPDATE
								`school_mem`
							SET `voted` = '1'
							WHERE `user_id` = '{$aRow['user_id']}' && `school_id` =  '{$_REQUEST['id']}' ";
				$result = mysql_query($sql);
				$sql = "UPDATE
								`schools`
							SET 
								`votes` = `votes`+1,
								`total` = `total`+'{$_POST['vote'] }'
							WHERE `id` =  '{$_REQUEST['id']}' ";
				$result = mysql_query($sql);
				$aRow['voted'] = 1;
				$aRow['votes'] = $aRow['votes']+1;
				$aRow['total'] = $aRow['total']+$_POST['vote'];
			}
			
			$aCountry= array(''=>'', 31 => 'Afghanistan', 33 => 'Algeria', 34 => 'Andorra', 35 => 'Angola', 36 => 'Antigua And Barbuda', 37 => 'Argentina', 38 => 'Armenia', 39 => 'Australia', 40 => 'Austria', 41 => 'Azerbaijan', 42 => 'Bahamas', 43 => 'Bahrain', 44 => 'Bangladesh', 45 => 'Barbados', 46 => 'Belarus', 47 => 'Belgium', 48 => 'Belize', 49 => 'Benin', 222 => 'Bermuda', 50 => 'Bhutan', 51 => 'Bolivia', 52 => 'Bosnia And Herzegovina', 53 => 'Botswana', 54 => 'Brazil', 55 => 'Brunei Darussalam', 56 => 'Bulgaria', 57 => 'Burkina Faso', 58 => 'Burundi', 59 => 'Cambodia', 60 => 'Cameroon', 61 => 'Canada', 62 => 'Cape Verde', 63 => 'Central African Republic', 64 => 'Chad', 65 => 'Chile', 66 => 'China', 67 => 'Colombia', 68 => 'Comoros', 69 => 'Costa Rica', 70 => 'Croatia', 71 => 'Cuba', 72 => 'Cyprus', 73 => 'Czech Republic', 74 => 'Denmark', 75 => 'Djibouti', 76 => 'Dominica', 77 => 'Dominican Republic', 78 => 'Ecuador', 79 => 'Egypt', 80 => 'El Salvador', 81 => 'Equatorial Guinea', 82 => 'Eritrea', 83 => 'Estonia', 84 => 'Ethiopia', 85 => 'Fiji', 86 => 'Finland', 87 => 'France', 88 => 'Gabon', 89 => 'Gambia', 90 => 'Georgia', 91 => 'Germany', 92 => 'Ghana', 93 => 'Greece', 94 => 'Grenada', 95 => 'Guatemala', 96 => 'Guinea', 97 => 'Guinea-bissau', 98 => 'Guyana', 99 => 'Haiti', 100 => 'Honduras', 101 => 'Hong Kong', 102 => 'Hungary', 103 => 'Iceland', 104 => 'India', 105 => 'Indonesia', 106 => 'Iran', 107 => 'Iraq', 108 => 'Ireland', 109 => 'Israel', 110 => 'Italy', 111 => 'Ivory Coast', 112 => 'Jamaica', 113 => 'Japan', 114 => 'Jordan', 115 => 'Kazakhstan', 116 => 'Kenya', 117 => 'Kiribati', 118 => 'Korea (north)', 119 => 'Korea (south)', 120 => 'Kuwait', 121 => 'Kyrgyzstan', 122 => 'Laos', 123 => 'Latvia', 124 => 'Lebanon', 125 => 'Lesotho', 126 => 'Liberia', 127 => 'Libya', 128 => 'Liechtenstein', 129 => 'Lithuania', 130 => 'Luxembourg', 131 => 'Macedonia', 132 => 'Madagascar', 
												133 => 'Malawi', 134 => 'Malaysia', 135 => 'Maldives', 136 => 'Mali', 137 => 'Malta', 138 => 'Marshall Islands', 139 => 'Mauritania', 140 => 'Mauritius', 141 => 'Mexico', 142 => 'Micronesia', 143 => 'Moldova', 144 => 'Monaco', 145 => 'Mongolia', 146 => 'Morocco', 147 => 'Mozambique', 148 => 'Myanmar', 149 => 'Namibia', 150 => 'Nauru', 151 => 'Nepal', 152 => 'Netherlands', 153 => 'New Zealand', 154 => 'Nicaragua', 155 => 'Niger', 156 => 'Nigeria', 157 => 'Norway', 158 => 'Oman', 159 => 'Pakistan', 160 => 'Palau', 161 => 'Panama', 162 => 'Papua New Guinea', 163 => 'Paraguay', 164 => 'Peru', 165 => 'Philippines', 166 => 'Poland', 167 => 'Portugal', 168 => 'Puerto Rico', 169 => 'Qatar', 170 => 'Romania', 171 => 'Russia', 172 => 'Rwanda', 173 => 'Saint Kitts And Nevis', 174 => 'Saint Lucia', 175 => 'Samoa', 176 => 'San Marino', 177 => 'Sao Tome And Principe', 178 => 'Saudi Arabia', 179 => 'Scotland', 180 => 'Senegal', 181 => 'Seychelles', 182 => 'Sierra Leone', 183 => 'Singapore', 184 => 'Slovak Republic', 185 => 'Slovenia', 186 => 'Solomon Islands', 187 => 'Somalia', 188 => 'South Africa', 189 => 'Spain', 190 => 'Sri Lanka', 191 => 'Sudan', 192 => 'Suriname', 193 => 'Swaziland', 194 => 'Sweden', 195 => 'Switzerland', 196 => 'Syria', 197 => 'Taiwan', 198 => 'Tajikistan', 199 => 'Tanzania', 200 => 'Thailand', 201 => 'Togo', 202 => 'Tonga', 203 => 'Trinidad And Tobago', 204 => 'Tunisia', 205 => 'Turkey', 206 => 'Turkmenistan', 207 => 'Tuvalu', 208 => 'Uganda', 209 => 'Ukraine', 210 => 'United Arab Emirates', 211 => 'United Kingdom', 212 => 'United States', 213 => 'Uruguay', 214 => 'Uzbekistan', 215 => 'Vanuatu', 216 => 'Venezuela', 217 => 'Viet Nam', 218 => 'Yemen', 219 => 'Yugoslavia', 220 => 'Zambia', 221 => 'Zimbabwe');
			$aState = array(''=>'', 222 => 'Alabama', 223 => 'Alaska', 224 => 'Arizona', 225 => 'Arkansas', 226 => 'California', 227 => 'Colorado', 228 => 'Connecticut', 229 => 'Delaware', 230 => 'District Of Columbia', 231 => 'Florida', 232 => 'Georgia', 233 => 'Hawaii', 234 => 'Idaho', 235 => 'Illinois', 236 => 'Indiana', 237 => 'Iowa', 238 => 'Kansas', 239 => 'Kentucky', 240 => 'Louisiana', 241 => 'Maine', 242 => 'Maryland', 243 => 'Massachusetts', 244 => 'Michigan', 245 => 'Minnesota', 246 => 'Mississippi', 247 => 'Missouri', 248 => 'Montana', 249 => 'Nebraska', 250 => 'Nevada', 251 => 'New Hampshire', 252 => 'New Jersey', 253 => 'New Mexico', 254 => 'New York', 255 => 'North Carolina', 256 => 'North Dakota', 257 => 'Ohio', 258 => 'Oklahoma', 259 => 'Oregon', 260 => 'Pennsylvania', 261 => 'Rhode Island', 262 => 'South Carolina', 263 => 'South Dakota', 264 => 'Tennessee', 265 => 'Texas', 266 => 'Utah', 267 => 'Vermont', 268 => 'Virginia', 269 => 'Washington', 270 => 'West Virginia', 271 => 'Wisconsin', 272 => 'Wyoming');
			
			if( is_numeric($aRow['country']) && array_key_exists($aRow['country'], $aCountry) )
				$aRow['country'] = $aCountry[ $aRow['country'] ];
			if( is_numeric($aRow['state']) && array_key_exists($aRow['state'], $aState) )
				$aRow['state'] =$aState[ $aRow['state'] ];	
			$aRow['rating'] = $aRow['votes']>0 ? round($aRow['total']/$aRow['votes'], 2) : "None";
			$aRow['id'] = $_REQUEST['id'];
			$aRow['name'] = stripslashes($aRow['name']);
			$smarty->assign('aSchoolInfo', $aRow);
			
			//ADD COMMENTS
			if( isset($_POST['comment']) && $iUserId)
			{
				$sComment = $_POST['comment_body'];
				$iTime = time();
				$sql = "INSERT INTO `school_comment` 
							(`cid`, `school_id`, `text`, `time`) 
							VALUES
							('{$iUserId}', '{$_REQUEST['id']}', '{$sComment}', '{$iTime}')";
				$result = mysql_query($sql);
			}
			//REMOVE COMMENT
			elseif( isset($_GET['delete']) )
			{
				if( $iUserId == $aProfileInfo['userid'] )
					$sql = "DELETE FROM `school_comment` 
								WHERE 
									`id` = '{$_GET['delete']}' ";
				else
					$sql = "DELETE FROM `school_comment` 
								WHERE 
									`id` = '{$_GET['delete']}' && `cid` = '{$iUserId}' ";
				$result = mysql_query($sql);
			}
			
			//GET COMMENTS
			$iPage = isset($_REQUEST['page']) ? $_REQUEST['page']*1 : 0;
			$iLimit = ($iPage == "" ? 0 : ($iPage-1)*5);
			$iLimit2 = 5;
			$sLimit = " LIMIT ".$iLimit.', '.$iLimit2;
			$aComments = array();
			$sql = "SELECT
							`id`,
							`text`,
							`cid` AS `userid`,
							`time`
						FROM `school_comment` 
						WHERE 
							`school_id` = '{$_REQUEST['id']}' 
						ORDER BY `time` DESC {$sLimit }";
			$result = mysql_query($sql);
			while($aRow = mysql_fetch_assoc($result) )
			{
				$tempUser = new se_user(Array($aRow['userid']));
				$aRow['photo'] = $tempUser->user_photo();
				$aRow['name'] = $tempUser->user_info['user_username'];
				$aRow['time'] = date("m/d/Y g:i A", $aRow['time']);
				$aRow['comment'] = stripslashes($aRow['text']);
				$aComments[] = $aRow;
			}
			$sql1 = "	SELECT 
								COUNT(*) AS `cnt`
							FROM `school_comment`
							WHERE
								`school_id` = '{$_REQUEST['id']}'  ";
			$result1 = mysql_query($sql1);
			$aRow = mysql_fetch_assoc($result1);
			$iNum = $aRow['cnt'];
			$iPgMax = ceil($iNum/$iLimit2);	 
			$smarty->assign('iNum', $iNum);
			$smarty->assign('iPgMax', $iPgMax);
			$smarty->assign('iPage', $iPage==0 ? 1 : $iPage );
			
		$smarty->assign('comments', $aComments);
			
		}else
				$smarty->assign('bPrompt', "permissionDenied");
	}else
		$smarty->assign('bPrompt', "pageNotFound");
}else
		$smarty->assign('bPrompt', "pageNotFound");

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>