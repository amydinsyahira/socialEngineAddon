<?


// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'profile.', '') AS `key`
				FROM `schools_langKey` WHERE `defVarName` LIKE '%profile.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign_by_ref('aCustLangSchool', $aValues);

// PRELOAD LANGUAGE
SE_Language::_preload($aValues['schools']);

$aSttng = array();
$sSql = "	SELECT 
					* 
				FROM `school_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
if( $aSttng['userlevels'] != "")
	$aSttng['userlevels'] = explode(",", $aSttng['userlevels']);

//Set Menu Items
	//User Login Menu Item
if( is_array($aSttng['userlevels']) && in_array($user->user_info['user_level_id'], $aSttng['userlevels']) )
	$plugin_vars['menu_user'] = Array('file' => 'user_mySchools.php', 'icon' => 'school.gif', 'title' => $aValues['my_schools']);
	//Main Menu Item
$plugin_vars['menu_main'] = Array('file' => 'schoolBrowse.php', 'title' => $aValues['browse_schools']);

// SET PROFILE MENU VARS
if( $page=="profile" )
{
	if( is_array($aSttng['userlevels']) && in_array($owner->user_info['user_level_id'], $aSttng['userlevels']) )
	{
		// START EXTRA PROFILES
			$schoolProfiles = array();
			$sql = "SELECT 
							`s`.`id`,
							`s`.`name`,
							`p`.`file`
						FROM `school_mem` AS `m`
						INNER JOIN `schools` AS `s`
						ON `s`.`id` = `m`.`school_id`
						LEFT JOIN `school_pic` AS `p`
						ON `p`.`school_id` = `s`.`id` && `p`.`pic_id` = `s`.`def_pic`
						WHERE `m`.`user_id` = '{$owner->user_info['user_id']}' && `m`.`status` = '1'
						ORDER BY RAND() 
						LIMIT 4";
			$result = mysql_query($sql);
			while ( $aRow = mysql_fetch_assoc($result) )
			{
				$aRow['name'] = stripslashes($aRow['name']);
				$schoolProfiles[] = $aRow;
			}

		  // ASSIGN ENTRIES SMARY VARIABLE
			$smarty->assign_by_ref('schoolProfiles', $schoolProfiles);
			$smarty->assign('total_schools', count($schoolProfiles));  
			$smarty->assign('iUserId', $owner->user_info['user_level_id']);  

		  if( count($schoolProfiles)>0 )
		  {
			$plugin_vars['menu_profile_tab'] = array('file'=> 'profile_school_list.tpl', 'title' => $aValues['schools'], 'name' => 'Schools');
		  }
	}
}

// Use new template hooks
if( is_a($smarty, 'SESmarty') )
{
  $plugin_vars['uses_tpl_hooks'] = TRUE;

  if( !empty($plugin_vars['menu_main']) )
    $smarty->assign_hook('menu_main', $plugin_vars['menu_main']); 
 
  if( !empty($plugin_vars['menu_user']) )
    $smarty->assign_hook('menu_user_apps', $plugin_vars['menu_user']);
	
  if( !empty($plugin_vars['menu_profile_tab']) )
    $smarty->assign_hook('profile_tab', $plugin_vars['menu_profile_tab']);
}

// SET MAIN MENU VARS
//$plugin_vars[menu_main] = Array('file' => 'gamelist.php', 'title' => $aRow['languagevar_id']);

?>