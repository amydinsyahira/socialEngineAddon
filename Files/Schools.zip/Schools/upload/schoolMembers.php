<?php
$page = "schoolMembers";
include "header.php";
////////GET LANG IDS 
$aValues = array();
$sSql = "	SELECT 
					`languagevar_id`, 
					REPLACE(`defVarName`, 'schoolMembers.', '') AS `key`
				FROM `schools_langKey` WHERE `defVarName` LIKE '%schoolMembers.%' ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aValues[ $aRow['key'] ] = $aRow['languagevar_id'];
$smarty->assign('aCusLang', $aValues);
/////////SETTINGS
$aSttng = array();
$sSql = "	SELECT 
					* 
				FROM `school_options` ";
$rResult = mysql_query($sSql);
while( ($aRow=mysql_fetch_assoc($rResult)) )
	$aSttng[ $aRow['var'] ] = stripslashes($aRow['value']);
if( $aSttng['userlevels'] != "")
	$aSttng['userlevels'] = explode(",", $aSttng['userlevels']);
$smarty->assign('aSchoolSetting', $aSttng);
//////////////////////////////////////////////////////////////////////////
$iUserId = isset($user->user_info['user_id']) ? $user->user_info['user_id'] : FALSE;
$smarty->assign('iUserId', $iUserId);

$smarty->assign('bModDisabled', TRUE);
$smarty->assign('bPrompt', FALSE);
if( is_array($aSttng['userlevels']) && in_array($user->user_info['user_level_id'], $aSttng['userlevels']) )
{
	$smarty->assign('bModDisabled', FALSE);
	if( isset($_REQUEST['id']) )
	{
		$_REQUEST['id'] = mysql_real_escape_string($_REQUEST['id']);
		$sql = "	SELECT 
							`m`.`user_id`,
							`m`.`is_admin`,
							`s`.`is_private`,
							`s`.`name`,
							`s`.`country`,
							`s`.`state`,
							`s`.`city`,
							`s`.`address`
						FROM `schools` AS `s`
						LEFT JOIN `school_mem` AS `m` 
						ON `m`.`school_id` = `s`.`id` && `m`.`user_id` = '{$iUserId}'
						WHERE
							`s`.`id` = '{$_REQUEST['id']}' ";
		$result = mysql_query($sql);
		if( $aRow = mysql_fetch_assoc($result) )
		{
			if( $aRow['is_private'] == 0 || $aRow['is_private'] == 1 && $aSttng['schoolsPrivate'] == 1 && isset($aRow['user_id']) || $aSttng['schoolsPrivate'] == 0)
			{
				if( $aRow['is_admin'] == 1 && $aSttng['moderator'] == 1 && $aSttng['canBan'] )
				{
					if( isset($_GET['iBan']) )
					{
						$_GET['iBan'] = mysql_real_escape_string($_GET['iBan']);
						$sql = "	UPDATE `school_mem`
										SET 
											`status` = '2' 
										WHERE 
											`user_id` = '{$_GET['iBan']}' && 
											`school_id` = '{$_REQUEST['id']}' ";
						$result = mysql_query($sql);
					}
					elseif( isset($_GET['iBan']) )
					{
						$_GET['iBan'] = mysql_real_escape_string($_GET['iUnBan']);
						$sql = "	UPDATE `school_mem`
										SET 
											`status` = '1' 
										WHERE 
											`user_id` = '{$_GET['iUnBan']}' && 
											`school_id` = '{$_REQUEST['id']}' ";
						$result = mysql_query($sql);
					}
				}
				
				$smarty->assign('aSchoolInfo', $aRow);
				$smarty->assign('schoolId', $_REQUEST['id']);
				$sSearch = isset($_GET['sSearch']) ? mysql_real_escape_string(urldecode($_GET['sSearch'])) : "";
				
				$iPage = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 0;
				$iLimit = ($iPage == "" ? 0 : ($iPage-1)*10);
				$iLimit2 = 10;
				$sql="	SELECT 
								`m`.`user_id`,
								`m`.`is_admin`,
								`m`.`status`,
								`m`.`year`
							FROM `school_mem` AS `m`
							INNER JOIN `se_users` AS `u`
							ON `u`.`user_id` = `m`.`user_id`
							WHERE 
							".($sSearch != "" ? "	
								`u`.`user_username` LIKE '%".$sSearch."%' &&" : "")." 
								`m`.`school_id` = '{$_REQUEST['id']}' &&
								(`m`.`status` = '1' || `m`.`status` = '2')
							ORDER BY `u`.`user_username`
							LIMIT ".$iLimit.", ".$iLimit2;
				$result=mysql_query($sql);
				$aMembers = array();
				while( ($aRow = mysql_fetch_assoc($result)) )
				{
					$tempUser = new se_user(Array($aRow['user_id']));
					$aRow['photo'] = $tempUser->user_photo();
					$aRow['name'] = $tempUser->user_info['user_username'];
					$aRow['year'] = is_numeric($aRow['year']) && $aRow['year'] != 0 ? $aRow['year'] : FALSE;
					$aMembers[] = $aRow;
				}
				$sSql = "	SELECT
									COUNT(*) AS `cnt`
								FROM `school_mem` AS `m`
								INNER JOIN `se_users` AS `u`
								ON `u`.`user_id` = `m`.`user_id`
								WHERE 
									".($sSearch != "" ? "	
									`u`.`user_username` LIKE '%".$sSearch."%' &&" : "")." 
									`m`.`school_id` = '{$_REQUEST['id']}' &&
									(`m`.`status` = '1' || `m`.`status` = '2')";
				$rResult = mysql_query($sSql);
				$aRow = mysql_fetch_assoc($rResult);
				$iNum = $aRow['cnt'];
				$iPgMax = ceil($iNum/$iLimit2);	 	 
				$smarty->assign('iNum', $iNum);
				$smarty->assign('iPgMax', $iPgMax);
				$smarty->assign('iPage', $iPage==0 ? 1 : $iPage );
				$smarty->assign('aMembers', $aMembers);
				$smarty->assign('sSearchInput', urldecode(stripslashes($sSearch)));
				$smarty->assign('sSearch', $sSearch);
			}else
				$smarty->assign('bPrompt', "permissionDenied");
		}else
			$smarty->assign('bPrompt', "pageNotFound");
	}else
		$smarty->assign('bPrompt', "pageNotFound");
}

// ASSIGN SMARTY VARIABLES AND INCLUDE FOOTER
include "footer.php";
?>