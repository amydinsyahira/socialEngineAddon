### Step 1: 


Make a backup of everything. Its better to be safe than sorry!


### Step 2: 


Upload the contents of the 'upload' folder to your social engine directory. 
Usually this directory will be /public_html or /www


### Step 3: 


To run the school installer in your plugin section of your admin panel

### Step 4:

CHMOD all the files and folders under file/schools to 777

