<?

switch($page) {

  // CODE FOR PROFILE PAGE
  case "profile":
	$adsandpages = new se_adsandpages($owner->user_info[user_id]);
	$sort_by = "se_adsandpagesmembers.adsandpagesmember_rank DESC, se_adsandpagess.adsandpages_title";
	$where = "(se_adsandpagesmembers.adsandpagesmember_status='1')";

	// GET TOTAL adsandpagesS
	$total_adsandpagess = $adsandpages->adsandpages_total($where);

	// GET adsandpagesS ARRAY
	$adsandpagess = $adsandpages->adsandpages_list(0, $total_adsandpagess, $sort_by, $where, 1);

	// ASSIGN adsandpagesS SMARY VARIABLE
	$smarty->assign('adsandpagess', $adsandpagess);
	$smarty->assign('total_adsandpagess', $total_adsandpagess);
	break;



}
?>