<?
$page = "user_adsandpages_browse";
include "header.php";

if(isset($_POST['adsandpagescat_id'])) { $adsandpagescat_id = $_POST['adsandpagescat_id']; } elseif(isset($_GET['adsandpagescat_id'])) { $adsandpagescat_id = $_GET['adsandpagescat_id']; } else { $adsandpagescat_id = ""; }
if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }

// CREATE adsandpages OBJECT
$adsandpages = new se_adsandpages();


// SHOW CATEGORIES PAGE
if($adsandpagescat_id == "") {

  // GET adsandpages CATEGORIES
  $adsandpagescats = $database->database_query("SELECT se_adsandpagescats.*, count(se_adsandpagess.adsandpages_id) AS total_cat_adsandpagess FROM se_adsandpagescats LEFT JOIN se_adsandpagess ON se_adsandpagescats.adsandpagescat_id=se_adsandpagess.adsandpages_adsandpagescat_id AND se_adsandpagess.adsandpages_search='1' WHERE se_adsandpagescats.adsandpagescat_dependency='0' adsandpages BY se_adsandpagescats.adsandpagescat_id");

  // LOOP THROUGH adsandpages CATEGORIES AND SUBCATEGORIES
  $categories = Array();
  $adsandpagess_totalincats = 0;
  while($adsandpagescat = $database->database_fetch_assoc($adsandpagescats)) {

    // LOOP THROUGH SUBCATS AND PUT THEM INTO AN ARRAY
    $adsandpagessubcats = $database->database_query("SELECT se_adsandpagescats.*, count(se_adsandpagess.adsandpages_id) AS total_subcat_adsandpagess FROM se_adsandpagescats LEFT JOIN se_adsandpagess ON se_adsandpagescats.adsandpagescat_id=se_adsandpagess.adsandpages_adsandpagescat_id AND se_adsandpagess.adsandpages_search='1' WHERE se_adsandpagescats.adsandpagescat_dependency='$adsandpagescat[adsandpagescat_id]' adsandpages BY se_adsandpagescats.adsandpagescat_id");
    $total_subcat_adsandpagess = 0;
    $subcategory_array = Array();
    while($adsandpagessubcat = $database->database_fetch_assoc($adsandpagessubcats)) {
      $subcategory_array[] = Array('subcategory_id' => $adsandpagessubcat[adsandpagescat_id],
					'subcategory_title' => $adsandpagessubcat[adsandpagescat_title],
					'subcategory_totaladsandpagess' => $adsandpagessubcat[total_subcat_adsandpagess]);
      $total_subcat_adsandpagess += $adsandpagessubcat[total_subcat_adsandpagess];
    }

    // GET TOTAL adsandpagesS IN THIS CATEGORY AND ALL ITS SUBCATS
    $total_cat_adsandpagess = $adsandpagescat[total_cat_adsandpagess]+$total_subcat_adsandpagess;

    // PUT CATEGORY DATA INTO AN ARRAY
    $categories[] = Array('adsandpagescat_id' => $adsandpagescat[adsandpagescat_id],
  			'adsandpagescat_title' => $adsandpagescat[adsandpagescat_title],
			'adsandpagescat_totaladsandpagess' => $total_cat_adsandpagess,
			'adsandpagescat_subcats' => $subcategory_array);
    $adsandpagess_totalincats += $total_cat_adsandpagess;
  }

  // DETERMINE HOW MANY adsandpagesS EXIST THAT ARE UNCATEGORIZED
  $total_adsandpagess = $adsandpages->adsandpages_total("(adsandpages_search='1')");
  $adsandpagess_totalnocat = $total_adsandpagess - $adsandpagess_totalincats;

}





// SHOW adsandpagesS WITHIN A CATEGORY
if($adsandpagescat_id != "") {

  $where = "(adsandpages_search='1'";

  // SHOW CATEGORIZED adsandpagesS
  if($adsandpagescat_id > 0) {

    // GET INFORMATION ABOUT THIS CATEGORY, MAKE SURE IT EXISTS
    $category_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_id='$adsandpagescat_id' LIMIT 1");
    if($database->database_num_rows($category_query) != 1) { header("Location: user_adsandpages_browse.php"); exit; }
    $category_info = $database->database_fetch_assoc($category_query);

    // GET SUBCATEGORIES
    $subcategory_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_dependency='$adsandpagescat_id'");

    // BUILD QUERY AND CREATE SUBCATS ARRAY
    $where .= " AND (adsandpages_adsandpagescat_id='$adsandpagescat_id'";
    while($subcategory = $database->database_fetch_assoc($subcategory_query)) {
      $where .= " OR adsandpages_adsandpagescat_id='$subcategory[adsandpagescat_id]'";
    }
    $where .= ")";


  // SHOW UNCATEGORIZED adsandpagesS
  } else {
    $where .= " AND adsandpages_adsandpagescat_id='0'";
  }

  $where .= ")";

  // GET TOTAL adsandpagesS
  $total_adsandpagess = $adsandpages->adsandpages_total($where);

  // MAKE adsandpages PAGES
  $adsandpagess_per_page = 20;
  $page_vars = make_page($total_adsandpagess, $adsandpagess_per_page, $p);

  // GET adsandpagesS
  $adsandpages_array = $adsandpages->adsandpages_list($page_vars[0], $adsandpagess_per_page, "adsandpages_id DESC", $where, 1);

}


// ASSIGN SMARTY VARIABLES AND DISPLAY BROWSE adsandpagesS PAGE
$smarty->assign('adsandpagess_totalnocat', $adsandpagess_totalnocat);
$smarty->assign('total_adsandpagess', $total_adsandpagess);
$smarty->assign('categories', $categories);
$smarty->assign('adsandpagescat_id', $adsandpagescat_id);
$smarty->assign('adsandpagescat_title', $category_info[adsandpagescat_title]);
$smarty->assign('adsandpagess', $adsandpages_array);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($adsandpages_array));
include "footer.php";
?>