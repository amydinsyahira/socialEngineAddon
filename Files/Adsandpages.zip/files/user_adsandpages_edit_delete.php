<?
$page = "user_adsandpages_edit_delete";
include "header.php";

if(isset($_GET['task'])) { $task = $_GET['task']; } elseif(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }
if(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } elseif(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } else { $adsandpages_id = 0; }

// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank != 2) { header("Location: user_adsandpages.php"); exit(); }




if($task == "dodelete") {
  $adsandpages->adsandpages_delete($adsandpages->adsandpages_info[adsandpages_id]);
  header("Location: user_adsandpages.php");
  exit();
}






// ASSIGN VARIABLES AND SHOW DELETE adsandpagesS PAGE
$smarty->assign('adsandpages', $adsandpages);
include "footer.php";
?>