<?
$page = "adsandpages";
include "header.php";

if(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_adsandpages] == 0) {
  $page = "error";
  $smarty->assign('error_header', $adsandpages[28]);
  $smarty->assign('error_message', $adsandpages[30]);
  $smarty->assign('error_submit', $adsandpages[39]);
  include "footer.php";
}


// INITIALIZE adsandpages OBJECT
$adsandpages_test = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
if($adsandpages_test->adsandpages_exists == 0) { 
  $page = "error";
  $smarty->assign('error_header', $adsandpages[28]);
  $smarty->assign('error_message', $adsandpages[41]);
  $smarty->assign('error_submit', $adsandpages[39]);
  include "footer.php";
}
$adsandpages = $adsandpages_test;


// GET PRIVACY LEVEL
$privacy_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$allowed_privacy = true_privacy($adsandpages->adsandpages_info[adsandpages_privacy], $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$is_adsandpages_private = 0;
if($privacy_level < $allowed_privacy) { $is_adsandpages_private = 1; }



// UPDATE adsandpages VIEWS IF adsandpages VISIBLE
if($is_adsandpages_private == 0) {
  $adsandpages_views = $adsandpages->adsandpages_info[adsandpages_views]+1;
  $database->database_query("UPDATE se_adsandpagess SET adsandpages_views='$adsandpages_views' WHERE adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
}

// GET adsandpages LEADER INFO
$adsandpagesowner_info = $database->database_fetch_assoc($database->database_query("SELECT user_id, user_username FROM se_users WHERE user_id='".$adsandpages->adsandpages_info[adsandpages_user_id]."'"));

// GET adsandpages CATEGORY
$adsandpages_category = "";
$adsandpages_category_query = $database->database_query("SELECT adsandpagescat_id, adsandpagescat_title FROM se_adsandpagescats WHERE adsandpagescat_id='".$adsandpages->adsandpages_info[adsandpages_adsandpagescat_id]."' LIMIT 1");
if($database->database_num_rows($adsandpages_category_query) == 1) {
  $adsandpages_category_info = $database->database_fetch_assoc($adsandpages_category_query);
  $adsandpages_category = $adsandpages_category_info[adsandpagescat_title];
}

// GET adsandpages FIELDS
$adsandpages->adsandpages_fields(0, 1);

// GET adsandpages COMMENTS
$comment = new se_comment('adsandpages', 'adsandpages_id', $adsandpages->adsandpages_info[adsandpages_id]);
$total_comments = $comment->comment_total();
$comments = $comment->comment_list(0, 10);


// GET TOTAL MEMBERS AND MEMBER ARRAY
$where = "(se_adsandpagesmembers.adsandpagesmember_status='1')";
$total_members = $adsandpages->adsandpages_member_total($where);
$members = $adsandpages->adsandpages_member_list(0, 5, "RAND()", $where);


// CHECK IF USER IS ALLOWED TO COMMENT
$allowed_to_comment = 1;
$comment_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]);
$allowed_comment = true_privacy($adsandpages->adsandpages_info[adsandpages_comments], $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]);
if($comment_level < $allowed_comment) { $allowed_to_comment = 0; }


// GET CUSTOM adsandpages STYLE IF ALLOWED
if($adsandpages->adsandpagesowner_level_info[level_adsandpages_style] != 0 & $is_adsandpages_private == 0) { 
  $adsandpagesstyle_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesstyle_css FROM se_adsandpagesstyles WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1")); 
  $global_css = $adsandpagesstyle_info[adsandpagesstyle_css];
}




// GET adsandpages DISCUSSION TOPICS
$total_topics = $adsandpages->adsandpages_topic_total();
$topics = $adsandpages->adsandpages_topic_list(0, 3);

// CHECK IF USER IS ALLOWED TO POST IN DISCUSSION
$allowed_to_discuss = 1;
$discussion_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion]);
$allowed_discussion = true_privacy($adsandpages->adsandpages_info[adsandpages_discussion], $adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion]);
if($discussion_level < $allowed_discussion) { $allowed_to_discuss = 0; }






// SHOW FILES IN THIS ALBUM
$adsandpagesalbum_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesalbum_id FROM se_adsandpagesalbums WHERE adsandpagesalbum_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1"));
$total_files = $adsandpages->adsandpages_media_total($adsandpagesalbum_info[adsandpagesalbum_id]);
$file_array = $adsandpages->adsandpages_media_list(0, 5, "RAND()", "(adsandpagesmedia_adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]')");




// ASSIGN VARIABLES AND DISPLAY adsandpages PAGE
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('adsandpagesowner_info', $adsandpagesowner_info);
$smarty->assign('adsandpages_category', $adsandpages_category);
$smarty->assign('comments', $comments);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('members', $members);
$smarty->assign('total_members', $total_members);
$smarty->assign('is_adsandpages_private', $is_adsandpages_private);
$smarty->assign('allowed_to_comment', $allowed_to_comment);
$smarty->assign('fields', $adsandpages->adsandpages_fields);
$smarty->assign('files', $file_array);
$smarty->assign('total_files', $total_files);
$smarty->assign('topics', $topics);
$smarty->assign('total_topics', $total_topics);
$smarty->assign('allowed_to_discuss', $allowed_to_discuss);
include "footer.php";
?>