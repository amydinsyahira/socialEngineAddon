<?
$page = "user_adsandpages_edit_members_remove";
include "header.php";

if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['member_id'])) { $member_id = $_POST['member_id']; } elseif(isset($_GET['member_id'])) { $member_id = $_GET['member_id']; } else { $member_id = 0; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// VALIDATE MEMBER
$member_query = $database->database_query("SELECT se_adsandpagesmembers.*, se_users.user_username FROM se_adsandpagesmembers LEFT JOIN se_users ON se_adsandpagesmembers.adsandpagesmember_user_id=se_users.user_id WHERE se_adsandpagesmembers.adsandpagesmember_id='$member_id' LIMIT 1");
if($database->database_num_rows($member_query) != 1) { header("Location: user_adsandpages_edit_members.php"); exit; }
$member_info = $database->database_fetch_assoc($member_query);


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == 0 | $adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank <= $member_info[adsandpagesmember_rank]) { header("Location: user_adsandpages_edit_members.php"); exit(); }

// DELETE USER
if($task == "doremove") {
  $database->database_query("DELETE FROM se_adsandpagesmembers WHERE adsandpagesmember_id='$member_info[adsandpagesmember_id]' AND adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1");
  header("Location: user_adsandpages_edit_members.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit;
}


// ASSIGN SMARTY VARIABLES AND DISPLAY REMOVE MEMBER PAGE
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('member_id', $member_id);
include "footer.php";
?>