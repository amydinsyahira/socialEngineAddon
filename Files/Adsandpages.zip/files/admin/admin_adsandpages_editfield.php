<?
$page = "admin_adsandpages_editfield";
include "admin_header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['adsandpagesfield_id'])) { $adsandpagesfield_id = $_POST['adsandpagesfield_id']; } elseif(isset($_GET['adsandpagesfield_id'])) { $adsandpagesfield_id = $_GET['adsandpagesfield_id']; } else { $adsandpagesfield_id = 0; }

// VALIDATE FIELD ID AND GET FIELD INFO
$field = $database->database_query("SELECT * FROM se_adsandpagesfields WHERE adsandpagesfield_id='$adsandpagesfield_id'");
if($database->database_num_rows($field) != 1) {
  header("Location: admin_adsandpages.php");
  exit();
}
$field_info = $database->database_fetch_assoc($field);


// INITIALIZE ERROR VARS
$is_error = 0;
$error_message = "";



// CANCEL EDIT FIELD
if($task == "cancel") {
  header("Location: admin_adsandpages.php");
  exit();




// CONFIRM FIELD DELETION
} elseif($task == "confirmdeletefield") {

  // SET HIDDEN INPUT ARRAYS FOR TWO TASKS
  $confirm_hidden = Array(Array('name' => 'task', 'value' => 'deletefield'),
			  Array('name' => 'adsandpagesfield_id', 'value' => $field_info[adsandpagesfield_id]));
  $cancel_hidden = Array(Array('name' => 'task', 'value' => 'main'),
			  Array('name' => 'adsandpagesfield_id', 'value' => $field_info[adsandpagesfield_id]));

  // LOAD CONFIRM PAGE WITH APPROPRIATE VARIABLES
  $smarty->assign('confirm_form_action', 'admin_adsandpages_editfield.php');
  $smarty->assign('cancel_form_action', 'admin_adsandpages_editfield.php');
  $smarty->assign('confirm_hidden', $confirm_hidden);
  $smarty->assign('cancel_hidden', $cancel_hidden);
  $smarty->assign('headline', $admin_adsandpages_editfield[35]);
  $smarty->assign('instructions', $admin_adsandpages_editfield[36]);
  $smarty->assign('confirm_submit', $admin_adsandpages_editfield[34]);
  $smarty->assign('cancel_submit', $admin_adsandpages_editfield[24]);
  $smarty->display("admin_confirm.tpl");
  exit();  





// DELETE FIELD
} elseif($task == "deletefield") {
  
  // DELETE ALL FIELD COLUMNS
  $fields = $database->database_query("SELECT adsandpagesfield_id FROM se_adsandpagesfields WHERE adsandpagesfield_id='$field_info[adsandpagesfield_id]' OR adsandpagesfield_dependency='$field_info[adsandpagesfield_id]'");
  while($field = $database->database_fetch_assoc($fields)) {
    $column = "adsandpagesvalue_".$field[adsandpagesfield_id];
    $database->database_query("ALTER TABLE se_adsandpagesvalues DROP COLUMN $column");
  }

  // DELETE ALL FIELDS
  $database->database_query("DELETE FROM se_adsandpagesfields WHERE adsandpagesfield_id='$field_info[adsandpagesfield_id]' OR adsandpagesfield_dependency='$field_info[adsandpagesfield_id]'");

  // RETURN TO ADMIN adsandpages SETTINGS
  header("Location: admin_adsandpages.php");
  exit();








// TRY TO EDIT FIELD
} elseif($task == "editfield") {

  // GET ALL POSTED VARS AND RESET OTHER VARS
  $field_title = $_POST['field_title'];
  $field_type = $_POST['field_type'];
  $field_style = $_POST['field_style'];
  $field_desc = $_POST['field_desc'];
  $field_error = $_POST['field_error'];
  $field_required = $_POST['field_required'];
  $field_maxlength = $_POST['field_maxlength'];
  $field_regex = $_POST['field_regex'];
  $box1_display = "none";
  $box3_display = "none";
  $box4_display = "none";
  $num_select_options = 1;
  $select_options = Array('0' => Array('select_id' => 0,
			 		'select_label' => '',
					'select_dependency' => '0',
					'select_dependent_field_id' => '',
					'select_dependent_label' => ''));
  $num_radio_options = 1;
  $radio_options = Array('0' => Array('radio_id' => 0,
					'radio_label' => '',
					'radio_dependency' => '0',
					'radio_dependent_field_id' => '',
					'radio_dependent_label' => ''));


  // FIELD TYPE IS TEXT FIELD
  if($field_type == "1") {
    $box1_display = "block";
    $column_type = "varchar(250)";


  // FIELD TYPE IS TEXTAREA
  } elseif($field_type == "2") {
    $column_type = "text";


  // FIELD TYPE IS SELECT BOX
  } elseif($field_type == "3") {
    $box3_display = "block";
    $column_type = "int(2)";
    $select_options = Array();
    $old_num_select_options = $_POST['num_select_options'];
    $num_select_options = 0;
    // PULL OPTIONS INTO NEW ARRAY
    for($i=0;$i<$old_num_select_options;$i++) {
      $var_label = "select_label$i";
      $var_dependency = "select_dependency$i";
      $var_dependent_label = "select_dependent_label$i";
      $var_dependent_field_id = "select_dependent_field_id$i";
      
      $select_label = $_POST[$var_label];
      $select_dependency = $_POST[$var_dependency];
      $select_dependent_label = $_POST[$var_dependent_label];
      $select_dependent_field_id = $_POST[$var_dependent_field_id];
      
      
      if(str_replace(" ", "", $select_label) != "") {
        $select_options[$num_select_options] = Array('select_id' => $num_select_options,
			 			     'select_label' => $select_label,
						     'select_dependency' => $select_dependency,
						     'select_dependent_field_id' => $select_dependent_field_id,
						     'select_dependent_label' => $select_dependent_label);

        $options[$num_select_options] = Array('option_id' => $num_select_options,
			 		      'option_label' => $select_label,
					      'option_dependency' => $select_dependency,
					      'option_dependent_field_id' => $select_dependent_field_id,
					      'option_dependent_label' => $select_dependent_label);

        $num_select_options++;

      }
    }


    // IF NO OPTIONS HAVE BEEN SPECIFIED
    if($num_select_options == 0) {
      $num_select_options = 1;
      $select_options = Array('0' => Array('select_id' => 0,
			 		   'select_label' => '',
					   'select_dependency' => '0',
					   'select_dependent_field_id' => '',
					   'select_dependent_label' => ''));
      $is_error = 1;
      $error_message = $admin_adsandpages_editfield[18];
    }



  // FIELD TYPE IS RADIO BUTTON
  } elseif($field_type == "4") {
    $box4_display = "block";
    $column_type = "int(2)";
    $radio_options = Array();
    $old_num_radio_options = $_POST['num_radio_options'];
    $num_radio_options = 0;
    // PULL OPTIONS INTO NEW ARRAY
    for($i=0;$i<$old_num_radio_options;$i++) {
      $var_label = "radio_label$i";
      $var_dependency = "radio_dependency$i";
      $var_dependent_label = "radio_dependent_label$i";
      $var_dependent_field_id = "radio_dependent_field_id$i";
      
      $radio_label = $_POST[$var_label];
      $radio_dependency = $_POST[$var_dependency];
      $radio_dependent_label = $_POST[$var_dependent_label];
      $radio_dependent_field_id = $_POST[$var_dependent_field_id];
      
      
      if(str_replace(" ", "", $radio_label) != "") {
        $radio_options[$num_radio_options] = Array('radio_id' => $num_radio_options,
			 			     'radio_label' => $radio_label,
						     'radio_dependency' => $radio_dependency,
						     'radio_dependent_field_id' => $radio_dependent_field_id,
						     'radio_dependent_label' => $radio_dependent_label);

        $options[$num_radio_options] = Array('option_id' => $num_radio_options,
			 		     'option_label' => $radio_label,
					     'option_dependency' => $radio_dependency,
					     'option_dependent_field_id' => $radio_dependent_field_id,
					     'option_dependent_label' => $radio_dependent_label);

        $num_radio_options++;

      }
    }

    // IF NO OPTIONS HAVE BEEN SPECIFIED
    if($num_radio_options == 0) {
      $num_radio_options = 1;
      $radio_options = Array('0' => Array('radio_id' => 0,
					  'radio_label' => '',
					  'radio_dependency' => '0',
					  'radio_dependent_field_id' => '',
					  'radio_dependent_label' => '')); 
      $is_error = 1;
      $error_message = $admin_adsandpages_editfield[18];
    }


  // FIELD TYPE IS DATE FIELD
  } elseif($field_type == "5") {
    $column_type = "int(14)";


  // FIELD TYPE NOT SPECIFIED
  } else {
    $is_error = 1;
    $error_message = $admin_adsandpages_editfield[26];
  }


  // FIELD TITLE IS EMPTY
  if(str_replace(" ", "", $field_title) == "") {
    $is_error = 1;
    $error_message = $admin_adsandpages_editfield[28];
  }


  // EDIT FIELD IF NO ERROR
  if($is_error == 0) {
    $database->database_query("UPDATE se_adsandpagesfields SET adsandpagesfield_title='$field_title', adsandpagesfield_desc='$field_desc', adsandpagesfield_error='$field_error', adsandpagesfield_type='$field_type', adsandpagesfield_style='$field_style', adsandpagesfield_maxlength='$field_maxlength', adsandpagesfield_required='$field_required', adsandpagesfield_regex='$field_regex' WHERE adsandpagesfield_id='$field_info[adsandpagesfield_id]'");
    $column_name = "adsandpagesvalue_".$field_info[adsandpagesfield_id];
    $database->database_query("ALTER TABLE se_adsandpagesvalues MODIFY $column_name $column_type NOT NULL");

    // EDIT DEPENDENT FIELDS
    $field_options = "";
    for($d=0;$d<count($options);$d++) {

      $option = $options[$d];
      $option_label = str_replace("<~!~>", "", str_replace("<!>", "", $option[option_label]));
      $option_dependent_label = str_replace("<~!~>", "", str_replace("<!>", "", $option[option_dependent_label]));
      $dep_field = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_title FROM se_adsandpagesfields WHERE adsandpagesfield_id='$option[option_dependent_field_id]'");
      $dep_field_info_id = "";

      if($database->database_num_rows($dep_field) == "1") {
        $dep_field_info = $database->database_fetch_assoc($dep_field);
        if($option[option_dependency] == "1") {
          // MODIFY EXISTING DEPENDENT FIELD
          $dep_field_info_id = $dep_field_info[adsandpagesfield_id];
          $database->database_query("UPDATE se_adsandpagesfields SET adsandpagesfield_title='$option_dependent_label' WHERE adsandpagesfield_id='$dep_field_info[adsandpagesfield_id]'");
        } else {
          // DELETE DEPENDENT FIELD IF DEPENDENCY IS NO LONGER REQUIRED
          $database->database_query("DELETE FROM se_adsandpagesfields WHERE adsandpagesfield_id='$dep_field_info[adsandpagesfield_id]'");
          $column_name = "adsandpagesvalue_".$dep_field_info[adsandpagesfield_id];
          $database->database_query("ALTER TABLE se_adsandpagesvalues DROP COLUMN $column_name");
        }
      } else {
        if($option[option_dependency] == "1") {
          // ADD NEW DEPENDENT FIELD
          $dep_field_order = $database->database_num_rows($database->database_query("SELECT adsandpagesfield_id FROM se_adsandpagesfields WHERE adsandpagesfield_dependency='$field_info[adsandpagesfield_id]'"))+1;
          $database->database_query("INSERT INTO se_adsandpagesfields (adsandpagesfield_title, adsandpagesfield_desc, adsandpagesfield_order, adsandpagesfield_type, adsandpagesfield_style, adsandpagesfield_dependency, adsandpagesfield_maxlength, adsandpagesfield_options, adsandpagesfield_required, adsandpagesfield_regex) VALUES ('$option_dependent_label', '', '$dep_field_order', '1', '', '$field_info[adsandpagesfield_id]', '100', '', '0', '')");
          $dep_field_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesfield_id FROM se_adsandpagesfields WHERE adsandpagesfield_title='$option_dependent_label' AND adsandpagesfield_desc='' AND adsandpagesfield_order='$dep_field_order' AND adsandpagesfield_type='1' AND adsandpagesfield_style='' AND adsandpagesfield_dependency='$field_info[adsandpagesfield_id]' AND adsandpagesfield_maxlength='100' AND adsandpagesfield_options='' AND adsandpagesfield_required='0' AND adsandpagesfield_regex='' ORDER BY adsandpagesfield_id DESC LIMIT 1"));
          $column_name = "adsandpagesvalue_".$dep_field_info[adsandpagesfield_id];
          $database->database_query("ALTER TABLE se_adsandpagesvalues ADD $column_name varchar(250) NOT NULL");
          $dep_field_info_id = $dep_field_info[adsandpagesfield_id];
        }
      }


      $field_options .= "$option[option_id]<!>$option_label<!>$option[option_dependency]<!>$dep_field_info_id<~!~>";
    }

    // INSERT OPTIONS
    $database->database_query("UPDATE se_adsandpagesfields SET adsandpagesfield_options='$field_options' WHERE adsandpagesfield_id='$field_info[adsandpagesfield_id]'");

    header("Location: admin_adsandpages.php");
    exit();
  }






// EDIT FIELD FORM
} else {
  $field_title = $field_info[adsandpagesfield_title];
  $field_type = $field_info[adsandpagesfield_type];
  $field_style = $field_info[adsandpagesfield_style];
  $field_desc = $field_info[adsandpagesfield_desc];
  $field_error = $field_info[adsandpagesfield_error];
  $field_maxlength = $field_info[adsandpagesfield_maxlength];
  $field_regex = $field_info[adsandpagesfield_regex];
  $field_required = $field_info[adsandpagesfield_required];
  $field_options = $field_info[adsandpagesfield_options];

  $num_select_options = 1;
  $select_options = Array('0' => Array('select_id' => 0,
			 		'select_label' => '',
					'select_dependency' => '0',
					'select_dependent_label' => ''));
  $num_radio_options = 1;
  $radio_options = Array('0' => Array('radio_id' => 0,
					'radio_label' => '',
					'radio_dependency' => '0',
					'radio_dependent_label' => ''));

  $box1_display = "none";
  $box3_display = "none";
  $box4_display = "none";
  if($field_type == "1") {
    $box1_display = "block";
  } elseif($field_type == "3") {
    $box3_display = "block";
    // PULL OPTIONS INTO NEW ARRAY    
    $field_options = explode("<~!~>", $field_options);
    $num_select_options = 0;
    for($i=0;$i<count($field_options);$i++) {
      if(str_replace(" ", "", $field_options[$i]) != "") {
        $options = explode("<!>", $field_options[$i]);
        $select_id = $options[0];
        $select_label = $options[1];
        $select_dependency = $options[2];
        $select_dependent_field_id = $options[3];
        $select_dependent_label = "";
        if($select_dependency == "1") { 
          $dep_field = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_title FROM se_adsandpagesfields WHERE adsandpagesfield_id='$select_dependent_field_id'");
          if($database->database_num_rows($dep_field) != "1") {
            $select_dependency = "0";
          } else {
            $select_dependency = "1";
            $dep_field_info = $database->database_fetch_assoc($dep_field);
            $select_dependent_label = $dep_field_info[adsandpagesfield_title];
          }
        } else { 
          $select_dependency_0 = " SELECTED"; 
        }
        $select_options[$num_select_options] = Array('select_id' => $select_id,
			 			     'select_label' => $select_label,
						     'select_dependency' => $select_dependency,
						     'select_dependent_field_id' => $select_dependent_field_id,
						     'select_dependent_label' => $select_dependent_label);
        $num_select_options++;
      }
    }

    // IF NO OPTIONS HAVE BEEN SPECIFIED
    if($num_select_options == 0) {
      $num_select_options = 1;
      $select_options = Array('0' => Array('select_id' => 0,
			 		   'select_label' => '',
					   'select_dependency' => '0',
					   'select_dependent_field_id' => '',
					   'select_dependent_label' => ''));
    }

  } elseif($field_type == "4") {
    $box4_display = "block";
    // PULL OPTIONS INTO NEW ARRAY    
    $field_options = explode("<~!~>", $field_options);
    $num_radio_options = 0;
    for($i=0;$i<count($field_options);$i++) {
      if(str_replace(" ", "", $field_options[$i]) != "") {
        $options = explode("<!>", $field_options[$i]);
        $radio_id = $options[0];
        $radio_label = $options[1];
        $radio_dependency = $options[2];
        $radio_dependent_field_id = $options[3];
        $radio_dependent_label = "";
        if($radio_dependency == "1") { 
          $dep_field = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_title FROM se_adsandpagesfields WHERE adsandpagesfield_id='$radio_dependent_field_id'");
          if($database->database_num_rows($dep_field) != "1") {
            $radio_dependency = "0";
          } else {
            $radio_dependency = "1";
            $dep_field_info = $database->database_fetch_assoc($dep_field);
            $radio_dependent_label = $dep_field_info[adsandpagesfield_title];
          }
        } else { 
          $radio_dependency_0 = " SELECTED"; 
        }
        $radio_options[$num_radio_options] = Array('radio_id' => $radio_id,
			 			     'radio_label' => $radio_label,
						     'radio_dependency' => $radio_dependency,
						     'radio_dependent_field_id' => $radio_dependent_field_id,
						     'radio_dependent_label' => $radio_dependent_label);
        $num_radio_options++;
      }
    }

    // IF NO OPTIONS HAVE BEEN SPECIFIED
    if($num_radio_options == 0) {
      $num_radio_options = 1;
      $radio_options = Array('0' => Array('radio_id' => 0,
			 		  'radio_label' => '',
					  'radio_dependency' => '0',
					  'radio_dependent_field_id' => '',
					  'radio_dependent_label' => ''));
    }
  }
  

}



// ASSIGN VARIABLES AND SHOW ADD FIELD PAGE
$smarty->assign('is_error', $is_error);
$smarty->assign('error_message', $error_message);
$smarty->assign('field_id', $field_info[adsandpagesfield_id]);
$smarty->assign('field_title', $field_title);
$smarty->assign('field_type', $field_type);
$smarty->assign('field_style', $field_style);
$smarty->assign('field_desc', $field_desc);
$smarty->assign('field_error', $field_error);
$smarty->assign('field_regex', $field_regex);
$smarty->assign('field_maxlength', $field_maxlength);
$smarty->assign('num_select_options', $num_select_options);
$smarty->assign('select_options', $select_options);
$smarty->assign('num_radio_options', $num_radio_options);
$smarty->assign('radio_options', $radio_options);
$smarty->assign('box1_display', $box1_display);
$smarty->assign('box3_display', $box3_display);
$smarty->assign('box4_display', $box4_display);
$smarty->assign('field_required', $field_required);
$smarty->display("$page.tpl");
exit();
?>