<?
$page = "admin_adsandpages_editdepfield";
include "admin_header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['adsandpagesfield_id'])) { $adsandpagesfield_id = $_POST['adsandpagesfield_id']; } elseif(isset($_GET['adsandpagesfield_id'])) { $adsandpagesfield_id = $_GET['adsandpagesfield_id']; } else { $adsandpagesfield_id = 0; }

// VALIDATE DEPENDENT FIELD ID AND GET DEPENDENT FIELD INFO
$dep_field = $database->database_query("SELECT * FROM se_adsandpagesfields WHERE adsandpagesfield_id='$adsandpagesfield_id' AND adsandpagesfield_dependency <> '0'");
if($database->database_num_rows($dep_field) != 1) {
  header("Location: admin_adsandpages.php");
  exit();
}
$dep_field_info = $database->database_fetch_assoc($dep_field);

// VALIDATE PARENT FIELD ID AND GET PARENT FIELD INFO
$field = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_title FROM se_adsandpagesfields WHERE adsandpagesfield_id='$dep_field_info[adsandpagesfield_dependency]'");
if($database->database_num_rows($field) != 1) {
  header("Location: admin_adsandpages.php");
  exit();
}
$field_info = $database->database_fetch_assoc($field);




// CANCEL EDIT FIELD
if($task == "cancel") {
  header("Location: admin_adsandpages.php");
  exit();







} elseif($task == "editdepfield") {

  $field_title = $_POST['field_title'];
  $field_style = $_POST['field_style'];
  $field_required = $_POST['field_required'];
  $field_maxlength = $_POST['field_maxlength'];
  $field_regex = $_POST['field_regex'];

  $database->database_query("UPDATE se_adsandpagesfields SET adsandpagesfield_title='$field_title', adsandpagesfield_style='$field_style', adsandpagesfield_maxlength='$field_maxlength', adsandpagesfield_required='$field_required', adsandpagesfield_regex='$field_regex' WHERE adsandpagesfield_id='$dep_field_info[adsandpagesfield_id]'");
  header("Location: admin_adsandpages.php");
  exit();

} else {

  $field_parent_id = $field_info[adsandpagesfield_id];
  $field_parent_title = $field_info[adsandpagesfield_title];
  $field_title = $dep_field_info[adsandpagesfield_title];
  $field_style = $dep_field_info[adsandpagesfield_style];
  $field_required = $dep_field_info[adsandpagesfield_required];
  $field_maxlength = $dep_field_info[adsandpagesfield_maxlength];
  $field_regex = $dep_field_info[adsandpagesfield_regex];
  $dep_field_id = $dep_field_info[adsandpagesfield_id];

}







// ASSIGN VARIABLES AND SHOW EDIT DEPENDENT FIELD PAGE
$smarty->assign('field_parent_id', $field_parent_id);
$smarty->assign('field_parent_title', $field_parent_title);
$smarty->assign('field_id', $dep_field_id);
$smarty->assign('field_title', $field_title);
$smarty->assign('field_style', $field_style);
$smarty->assign('field_regex', $field_regex);
$smarty->assign('field_required', $field_required);
$smarty->assign('field_maxlength', $field_maxlength);
$smarty->display("$page.tpl");
exit();
?>