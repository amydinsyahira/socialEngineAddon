<?

// INCLUDE adsandpagesS LANGUAGE FILE
include "../lang/lang_".$global_lang."_adsandpages.php";

// INCLUDE adsandpagesS CLASS FILE
include "../include/class_adsandpages.php";

// INCLUDE adsandpagesS FUNCTION FILE
include "../include/functions_adsandpages.php";

?>