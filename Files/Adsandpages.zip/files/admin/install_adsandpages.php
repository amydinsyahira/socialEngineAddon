<?

$plugin_name = "Ads and Pages Plugin";
$plugin_version = 2.40;
$plugin_type = "adsandpages";
$plugin_desc = "This plugin lets your users create their own Ads and Page. These Ads and Page encourage interactivity between users based on mutual interests and characteristics. Users can become leaders, create private adsandpagess, invite members, browse each other\'s memberships, and much more.";
$plugin_icon = "adsandpages16.gif";
$plugin_pages_main = "View User Ads and Page<!>admin_viewadsandpages.php<~!~>Global adsandpages Settings<!>admin_adsandpages.php<~!~>";
$plugin_pages_level = "Ads and Page Settings<!>admin_levels_adsandpagessettings.php<~!~>";
$plugin_url_htaccess = "";


if($install == "adsandpages") {

  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
					plugin_version,
					plugin_type,
					plugin_desc,
					plugin_icon,
					plugin_pages_main,
					plugin_pages_level,
					plugin_url_htaccess
					) VALUES (
					'$plugin_name',
					'$plugin_version',
					'$plugin_type',
					'$plugin_desc',
					'$plugin_icon',
					'$plugin_pages_main',
					'$plugin_pages_level',
					'$plugin_url_htaccess')");


  //######### UPDATE PLUGIN VERSION IN se_plugins
  } else {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='$plugin_desc',
					plugin_icon='$plugin_icon',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
  }



  //######### CREATE se_adsandpagesalbums
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesalbums'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesalbums` (
    `adsandpagesalbum_id` int(9) NOT NULL auto_increment,
    `adsandpagesalbum_adsandpages_id` int(9) NOT NULL default '0',
    `adsandpagesalbum_datecreated` int(14) NOT NULL default '0',
    `adsandpagesalbum_dateupdated` int(14) NOT NULL default '0',
    `adsandpagesalbum_title` varchar(50) NOT NULL default '',
    `adsandpagesalbum_desc` text NULL,
    `adsandpagesalbum_search` int(1) NOT NULL default '0',
    `adsandpagesalbum_privacy` int(1) NOT NULL default '0',
    `adsandpagesalbum_comments` int(1) NOT NULL default '0',
    `adsandpagesalbum_cover` int(9) NOT NULL default '0',
    `adsandpagesalbum_views` int(9) NOT NULL default '0',
    PRIMARY KEY  (`adsandpagesalbum_id`),
    KEY `INDEX` (`adsandpagesalbum_adsandpages_id`)
    )");
  }
  



  //######### CREATE se_adsandpagescats
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagescats'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagescats` (
    `adsandpagescat_id` int(9) NOT NULL auto_increment,
    `adsandpagescat_dependency` int(9) NOT NULL default '0',
    `adsandpagescat_title` varchar(100) NOT NULL default '',
    PRIMARY KEY  (`adsandpagescat_id`)
    )");
  }




  //######### CREATE se_adsandpagescomments
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagescomments'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagescomments` (
    `adsandpagescomment_id` int(9) NOT NULL auto_increment,
    `adsandpagescomment_adsandpages_id` int(9) NOT NULL default '0',
    `adsandpagescomment_authoruser_id` int(9) NOT NULL default '0',
    `adsandpagescomment_date` int(14) NOT NULL default '0',
    `adsandpagescomment_body` text NULL,
    PRIMARY KEY  (`adsandpagescomment_id`),
    KEY `INDEX` (`adsandpagescomment_adsandpages_id`,`adsandpagescomment_authoruser_id`)
    )");
  }




  //######### CREATE se_adsandpagesfields
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesfields'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesfields` (
    `adsandpagesfield_id` int(9) NOT NULL auto_increment,
    `adsandpagesfield_order` int(3) NOT NULL default '0',
    `adsandpagesfield_dependency` int(9) NOT NULL default '0',
    `adsandpagesfield_title` varchar(100) NOT NULL default '',
    `adsandpagesfield_desc` text NULL,
    `adsandpagesfield_error` varchar(250) NOT NULL default '',
    `adsandpagesfield_type` int(1) NOT NULL default '0',
    `adsandpagesfield_style` varchar(200) NOT NULL default '',
    `adsandpagesfield_maxlength` int(3) NOT NULL default '0',
    `adsandpagesfield_options` text NULL,
    `adsandpagesfield_required` int(1) NOT NULL default '0',
    `adsandpagesfield_regex` varchar(250) NOT NULL default '',
    PRIMARY KEY  (`adsandpagesfield_id`)
    )");
  }




  //######### CREATE se_adsandpagesmedia
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesmedia'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesmedia` (
    `adsandpagesmedia_id` int(9) NOT NULL auto_increment,
    `adsandpagesmedia_adsandpagesalbum_id` int(9) NOT NULL default '0',
    `adsandpagesmedia_date` int(14) NOT NULL default '0',
    `adsandpagesmedia_title` varchar(50) NOT NULL default '',
    `adsandpagesmedia_desc` text NULL,
    `adsandpagesmedia_ext` varchar(8) NOT NULL default '',
    `adsandpagesmedia_filesize` int(9) NOT NULL default '0',
    PRIMARY KEY  (`adsandpagesmedia_id`),
    KEY `INDEX` (`adsandpagesmedia_adsandpagesalbum_id`)
    )");
  }




  //######### CREATE se_adsandpagesmediacomments
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesmediacomments'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesmediacomments` (
    `adsandpagesmediacomment_id` int(9) NOT NULL auto_increment,
    `adsandpagesmediacomment_adsandpagesmedia_id` int(9) NOT NULL default '0',
    `adsandpagesmediacomment_authoruser_id` int(9) NOT NULL default '0',
    `adsandpagesmediacomment_date` int(14) NOT NULL default '0',
    `adsandpagesmediacomment_body` text NULL,
    PRIMARY KEY  (`adsandpagesmediacomment_id`),
    KEY `INDEX` (`adsandpagesmediacomment_adsandpagesmedia_id`,`adsandpagesmediacomment_authoruser_id`)
    )");
  }




  //######### CREATE se_adsandpagesmembers
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesmembers'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesmembers` (
    `adsandpagesmember_id` int(9) NOT NULL auto_increment,
    `adsandpagesmember_user_id` int(9) NOT NULL default '0',
    `adsandpagesmember_adsandpages_id` int(9) NOT NULL default '0',
    `adsandpagesmember_status` int(1) NOT NULL default '0',
    `adsandpagesmember_approved` int(1) NOT NULL default '0',
    `adsandpagesmember_rank` int(1) NOT NULL default '0',
    `adsandpagesmember_title` varchar(50) NOT NULL default '',
    PRIMARY KEY  (`adsandpagesmember_id`),
    KEY `INDEX` (`adsandpagesmember_user_id`,`adsandpagesmember_adsandpages_id`)
    )");
  }



  //######### CREATE se_adsandpagesposts
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesposts'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesposts` (
    `adsandpagespost_id` int(9) NOT NULL auto_increment,
    `adsandpagespost_adsandpagestopic_id` int(9) NOT NULL default '0',
    `adsandpagespost_authoruser_id` int(9) NOT NULL default '0',
    `adsandpagespost_date` int(14) NOT NULL default '0',
    `adsandpagespost_body` text NULL,
    PRIMARY KEY  (`adsandpagespost_id`),
    KEY `INDEX` (`adsandpagespost_adsandpagestopic_id`,`adsandpagespost_authoruser_id`)
    )");
  }



  //######### CREATE se_adsandpagess
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagess'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagess` (
    `adsandpages_id` int(9) NOT NULL auto_increment,
    `adsandpages_user_id` int(9) NOT NULL default '0',
    `adsandpages_adsandpagescat_id` int(9) NOT NULL default '0',
    `adsandpages_datecreated` int(14) NOT NULL default '0',
    `adsandpages_dateupdated` int(14) NOT NULL default '0',
    `adsandpages_views` int(9) NOT NULL default '0',
    `adsandpages_title` varchar(100) NOT NULL default '',
    `adsandpages_desc` text NULL,
    `adsandpages_photo` varchar(10) NOT NULL default '',
    `adsandpages_search` int(1) NOT NULL default '0',
    `adsandpages_privacy` int(1) NOT NULL default '0',
    `adsandpages_comments` int(1) NOT NULL default '0',
    `adsandpages_approval` int(1) NOT NULL default '0',
    PRIMARY KEY  (`adsandpages_id`),
    KEY `INDEX` (`adsandpages_user_id`)
    )");
  }

  //######### ADD DISCUSSION BOARD COLUMNS/VALUES TO adsandpagesS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_adsandpagess LIKE 'adsandpages_discussion'")) == 0) {
    $database->database_query("ALTER TABLE se_adsandpagess ADD COLUMN `adsandpages_discussion` int(1) NOT NULL default '0'");
    $database->database_query("UPDATE se_adsandpagess SET adsandpages_discussion='0'");
  }


  //######### CREATE se_adsandpagesstyles
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesstyles'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesstyles` (
    `adsandpagesstyle_id` int(9) NOT NULL auto_increment,
    `adsandpagesstyle_adsandpages_id` int(9) NOT NULL default '0',
    `adsandpagesstyle_css` text NULL,
    PRIMARY KEY  (`adsandpagesstyle_id`),
    KEY `INDEX` (`adsandpagesstyle_adsandpages_id`)
    )");
  }



  //######### CREATE se_adsandpagestopics
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagestopics'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagestopics` (
    `adsandpagestopic_id` int(9) NOT NULL auto_increment,
    `adsandpagestopic_adsandpages_id` int(9) NOT NULL default '0',
    `adsandpagestopic_date` int(14) NOT NULL default '0',
    `adsandpagestopic_subject` varchar(50) NOT NULL default '',
    `adsandpagestopic_views` int(9) NOT NULL default '0',
    PRIMARY KEY  (`adsandpagestopic_id`),
    KEY `INDEX` (`adsandpagestopic_adsandpages_id`)
    )");
  }


  //######### CREATE se_adsandpagesvalues
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_adsandpagesvalues'")) == 0) {
    $database->database_query("CREATE TABLE `se_adsandpagesvalues` (
    `adsandpagesvalue_id` int(9) NOT NULL auto_increment,
    `adsandpagesvalue_adsandpages_id` int(9) NOT NULL default '0',
    PRIMARY KEY  (`adsandpagesvalue_id`),
    KEY `adsandpagesvalue_adsandpages_id` (`adsandpagesvalue_adsandpages_id`)
    )");
  }


  //######### INSERT se_actiontypes
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newadsandpages'")) == 0) {
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_desc, actiontype_enabled, actiontype_text) VALUES ('newadsandpages', 'action_newadsandpages.gif', 'When I create a adsandpages.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; created a new adsandpages: &lt;a href=&#039;adsandpages.php?adsandpages_id=[id]&#039;&gt;[title]&lt;/a&gt;')");
  }
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='joinadsandpages'")) == 0) {
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_desc, actiontype_enabled, actiontype_text) VALUES ('joinadsandpages', 'action_joinadsandpages.gif', 'When I join a adsandpages.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; joined a adsandpages: &lt;a href=&#039;adsandpages.php?adsandpages_id=[id]&#039;&gt;[title]&lt;/a&gt;')");
  }
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='leaveadsandpages'")) == 0) {
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_desc, actiontype_enabled, actiontype_text) VALUES ('leaveadsandpages', 'action_leaveadsandpages.gif', 'When I leave a adsandpages.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; left a adsandpages: &lt;a href=&#039;adsandpages.php?adsandpages_id=[id]&#039;&gt;[title]&lt;/a&gt;')");
  }
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='adsandpagescomment'")) == 0) {
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_desc, actiontype_enabled, actiontype_text) VALUES ('adsandpagescomment', 'action_postcomment.gif', 'When I post a comment about a adsandpages.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; posted a comment on the adsandpages &lt;a href=&#039;adsandpages.php?adsandpages_id=[id]&#039;&gt;[title]&lt;/a&gt;:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt;')");
  }
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='adsandpagesmediacomment'")) == 0) {
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_desc, actiontype_enabled, actiontype_text) VALUES ('adsandpagesmediacomment', 'action_postcomment.gif', 'When I post a comment about a adsandpages photo.', 1, '&lt;a href=&#039;profile.php?user=[username]&#039;&gt;[username]&lt;/a&gt; posted a comment on the adsandpages &lt;a href=&#039;adsandpages.php?adsandpages_id=[id]&#039;&gt;[title]&lt;/a&gt;&#039;s &lt;a href=&#039;adsandpages_album_file.php?adsandpages_id=[id]&amp;adsandpagesmedia_id=[id2]&#039;&gt;photo&lt;/a&gt;:&lt;div style=&#039;padding: 10px 20px 10px 20px;&#039;&gt;[comment]&lt;/div&gt;')");
  }


  //######### ADD COLUMNS/VALUES TO LEVELS TABLE IF adsandpagesS HAVE NEVER BEEN INSTALLED
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_levels LIKE 'level_adsandpages_allow'")) == 0 AND $database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_levels LIKE 'type_adsandpages_allow'")) == 0) {
    $database->database_query("ALTER TABLE se_levels 
					ADD COLUMN `level_adsandpages_allow` int(1) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_photo` int(1) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_photo_width` varchar(3) NOT NULL default '',
					ADD COLUMN `level_adsandpages_photo_height` varchar(3) NOT NULL default '',
					ADD COLUMN `level_adsandpages_photo_exts` varchar(50) NOT NULL default '',
					ADD COLUMN `level_adsandpages_titles` int(1) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_officers` int(1) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_approval` int(1) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_style` int(1) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_album_exts` text NULL,
					ADD COLUMN `level_adsandpages_album_mimes` text NULL,
					ADD COLUMN `level_adsandpages_album_storage` bigint(11) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_album_maxsize` bigint(11) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_album_width` varchar(4) NOT NULL default '',
					ADD COLUMN `level_adsandpages_album_height` varchar(4) NOT NULL default '',
					ADD COLUMN `level_adsandpages_maxnum` int(3) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_search` int(1) NOT NULL default '0',
					ADD COLUMN `level_adsandpages_privacy` varchar(10) NOT NULL default '',
					ADD COLUMN `level_adsandpages_comments` varchar(10) NOT NULL default ''");
    $database->database_query("UPDATE se_levels SET level_adsandpages_allow='1', level_adsandpages_photo='1', level_adsandpages_photo_width='200', level_adsandpages_photo_height='200', level_adsandpages_photo_exts='jpeg,jpg,gif,png', level_adsandpages_titles='1', level_adsandpages_officers='1', level_adsandpages_approval='1', level_adsandpages_style='1', level_adsandpages_album_exts='jpg,gif,jpeg,png,bmp,mp3,mpeg,avi,mpa,mov,qt,swf', level_adsandpages_album_mimes='image/jpeg,image/pjpeg,image/jpg,image/jpe,image/pjpg,image/x-jpeg,image/x-jpg,image/gif,image/x-gif,image/png,image/x-png,image/bmp,audio/mpeg,video/mpeg,video/x-msvideo,video/avi,video/quicktime,application/x-shockwave-flash', level_adsandpages_album_storage='5242880', level_adsandpages_album_maxsize='2048000', level_adsandpages_album_width='500', level_adsandpages_album_height='500', level_adsandpages_maxnum='10', level_adsandpages_search='1', level_adsandpages_privacy='012345', level_adsandpages_comments='01234567'");

  //######### CHANGE COLUMNS TO LEVELS TABLE IF adsandpagesS HAVE BEEN INSTALLED
  } elseif($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_levels LIKE 'type_adsandpages_allow'")) != 0) {
    $database->database_query("ALTER TABLE se_levels 
					CHANGE type_adsandpages_allow level_adsandpages_allow int(1) NOT NULL default '0',
					CHANGE type_adsandpages_photo level_adsandpages_photo int(1) NOT NULL default '0',
					CHANGE type_adsandpages_photo_width level_adsandpages_photo_width varchar(3) NOT NULL default '',
					CHANGE type_adsandpages_photo_height level_adsandpages_photo_height varchar(3) NOT NULL default '',
					CHANGE type_adsandpages_photo_exts level_adsandpages_photo_exts varchar(50) NOT NULL default '',
					CHANGE type_adsandpages_titles level_adsandpages_titles int(1) NOT NULL default '0',
					CHANGE type_adsandpages_officers level_adsandpages_officers int(1) NOT NULL default '0',
					CHANGE type_adsandpages_approval level_adsandpages_approval int(1) NOT NULL default '0',
					CHANGE type_adsandpages_style level_adsandpages_style int(1) NOT NULL default '0',
					CHANGE type_adsandpages_album_exts level_adsandpages_album_exts text NULL,
					CHANGE type_adsandpages_album_mimes level_adsandpages_album_mimes text NULL,
					CHANGE type_adsandpages_album_storage level_adsandpages_album_storage bigint(11) NOT NULL default '0',
					CHANGE type_adsandpages_album_maxsize level_adsandpages_album_maxsize bigint(11) NOT NULL default '0',
					CHANGE type_adsandpages_album_width level_adsandpages_album_width varchar(4) NOT NULL default '',
					CHANGE type_adsandpages_album_height level_adsandpages_album_height varchar(4) NOT NULL default '',
					CHANGE type_adsandpages_maxnum level_adsandpages_maxnum int(3) NOT NULL default '0',
					CHANGE type_adsandpages_search level_adsandpages_search int(1) NOT NULL default '0',
					CHANGE type_adsandpages_privacy level_adsandpages_privacy varchar(10) NOT NULL default '',
					CHANGE type_adsandpages_comments level_adsandpages_comments varchar(10) NOT NULL default ''");
  }

  //######### ADD DISCUSSION BOARD COLUMNS/VALUES TO LEVELS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_levels LIKE 'level_adsandpages_discussion'")) == 0) {
    $database->database_query("ALTER TABLE se_levels ADD COLUMN `level_adsandpages_discussion` varchar(10) NOT NULL default ''");
    $database->database_query("UPDATE se_levels SET level_adsandpages_discussion='01234567'");
  }

  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_permission_adsandpages'")) == 0) {
    $database->database_query("ALTER TABLE se_settings 
					ADD COLUMN `setting_permission_adsandpages` int(1) NOT NULL default '0',
					ADD COLUMN `setting_email_adsandpagesinvite_subject` varchar(200) NOT NULL default '',
					ADD COLUMN `setting_email_adsandpagesinvite_message` text NULL,
					ADD COLUMN `setting_email_adsandpagescomment_subject` varchar(200) NOT NULL default '',
					ADD COLUMN `setting_email_adsandpagescomment_message` text NULL,
					ADD COLUMN `setting_email_adsandpagesmediacomment_subject` varchar(200) NOT NULL default '',
					ADD COLUMN `setting_email_adsandpagesmediacomment_message` text NULL,
					ADD COLUMN `setting_email_adsandpagesmemberrequest_subject` varchar(200) NOT NULL default '',
					ADD COLUMN `setting_email_adsandpagesmemberrequest_message` text NULL");
    $database->database_query("UPDATE se_settings SET setting_permission_adsandpages='1', setting_email_adsandpagesinvite_subject='You have been invited to join [adsandpagesname].', setting_email_adsandpagesinvite_message='Hello [username],\n\nYou have been invited to join a adsandpages named [adsandpagesname]. Please click the following link to login:\n\n[link]\n\nBest Regards,\nSocial Network Administration', setting_email_adsandpagescomment_subject='New adsandpages Comment', setting_email_adsandpagescomment_message='Hello [username],\n\nA new comment has been posted by [commenter] about the adsandpages &quot;[adsandpagesname]&quot;. Please click the following link to view it:\n\n[link]\n\nBest Regards,\nSocial Network Administration', setting_email_adsandpagesmediacomment_subject='New adsandpages Photo Comment', setting_email_adsandpagesmediacomment_message='Hello [username],\n\nA new comment has been posted by [commenter] on one of the photos in the adsandpages &quot;[adsandpagesname]&quot;. Please click the following link to view it:\n\n[link]\n\nBest Regards,\nSocial Network Administration', setting_email_adsandpagesmemberrequest_subject='New adsandpages Membership Request', setting_email_adsandpagesmemberrequest_message='Hello [username],\n\n[requester] would like to join your adsandpages &quot;[adsandpagesname]&quot;. Please click the following link to login and confirm their membership:\n\n[link]\n\nBest Regards,\nSocial Network Administration'");
  }

  //######### ADD DISCUSSION BOARD COLUMNS/VALUES TO SETTINGS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_adsandpages_discussion_code'")) == 0) {
    $database->database_query("ALTER TABLE se_settings ADD COLUMN `setting_adsandpages_discussion_code` int(1) NOT NULL default '0'");
    $database->database_query("UPDATE se_settings SET setting_adsandpages_discussion_code='1'");
  }

  //######### ADD COLUMNS/VALUES TO USER SETTINGS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_usersettings LIKE 'usersetting_notify_adsandpagesinvite'")) == 0) {
    $database->database_query("ALTER TABLE se_usersettings 
					ADD COLUMN `usersetting_notify_adsandpagesinvite` int(1) NOT NULL default '0',
					ADD COLUMN `usersetting_notify_adsandpagescomment` int(1) NOT NULL default '0',
					ADD COLUMN `usersetting_notify_adsandpagesmediacomment` int(1) NOT NULL default '0',
					ADD COLUMN `usersetting_notify_adsandpagesmemberrequest` int(1) NOT NULL default '0'");
    $database->database_query("UPDATE se_usersettings SET usersetting_notify_adsandpagesinvite='1', usersetting_notify_adsandpagescomment='1', usersetting_notify_adsandpagesmediacomment='1', usersetting_notify_adsandpagesmemberrequest='1'");
  }

}  

?>
