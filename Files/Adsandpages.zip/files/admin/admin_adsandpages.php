<?
$page = "admin_adsandpages";
include "admin_header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }


// SET RESULT VARIABLE
$result = 0;


// CHANGE adsandpages ORDER
if($task == "order") {
  if(isset($_GET['adsandpagesfield_id'])) { $adsandpagesfield_id = $_GET['adsandpagesfield_id']; } else { $adsandpagesfield_id = 0; }

  // VALIDATE adsandpages FIELD ID
  $adsandpages = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_order FROM se_adsandpagesfields WHERE adsandpagesfield_id='$adsandpagesfield_id'");
  if($database->database_num_rows($adsandpages) != 1) { exit(); }
  $adsandpages_down_info = $database->database_fetch_assoc($adsandpages);

  // MAKE SURE adsandpages FIELD IS NOT LAST
  $max = $database->database_fetch_assoc($database->database_query("SELECT max(adsandpagesfield_order) as adsandpagesfield_order FROM se_adsandpagesfields"));
  if($adsandpages_down_info[adsandpagesfield_order] == $max[adsandpagesfield_order]) { exit(); }

  // SELECT adsandpages FIELD TO BE MOVED UP
  $new = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesfield_order FROM se_adsandpagesfields WHERE adsandpagesfield_order > '$adsandpages_down_info[adsandpagesfield_order]' ORDER BY adsandpagesfield_order LIMIT 1"));
  $adsandpages_up_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_order FROM se_adsandpagesfields WHERE adsandpagesfield_order='$new[adsandpagesfield_order]' LIMIT 1"));


  // SWAP adsandpages FIELD ORDERS
  $database->database_query("UPDATE se_adsandpagesfields SET adsandpagesfield_order='$adsandpages_down_info[adsandpagesfield_order]' WHERE adsandpagesfield_id='$adsandpages_up_info[adsandpagesfield_id]'");
  $database->database_query("UPDATE se_adsandpagesfields SET adsandpagesfield_order='$adsandpages_up_info[adsandpagesfield_order]' WHERE adsandpagesfield_id='$adsandpages_down_info[adsandpagesfield_id]'");

  echo "<html><head><script type=\"text/javascript\">";
  echo "window.parent.ChangeOrder($adsandpages_down_info[adsandpagesfield_id], $adsandpages_up_info[adsandpagesfield_id]);";
  echo "</script></head><body></body></html>";
  exit();


// SAVE CHANGES
} elseif($task == "dosave") {
  $setting_permission_adsandpages = $_POST['setting_permission_adsandpages'];
  $discussion_code = $_POST['discussion_code'];
  $setting_email_adsandpagesinvite_subject = $_POST['setting_email_adsandpagesinvite_subject'];
  $setting_email_adsandpagesinvite_message = $_POST['setting_email_adsandpagesinvite_message'];
  $setting_email_adsandpagescomment_subject = $_POST['setting_email_adsandpagescomment_subject'];
  $setting_email_adsandpagescomment_message = $_POST['setting_email_adsandpagescomment_message'];
  $setting_email_adsandpagesmediacomment_subject = $_POST['setting_email_adsandpagesmediacomment_subject'];
  $setting_email_adsandpagesmediacomment_message = $_POST['setting_email_adsandpagesmediacomment_message'];
  $setting_email_adsandpagesmemberrequest_subject = $_POST['setting_email_adsandpagesmemberrequest_subject'];
  $setting_email_adsandpagesmemberrequest_message = $_POST['setting_email_adsandpagesmemberrequest_message'];

    // SAVE adsandpages CATEGORIES
    $max_adsandpagescat_id = 0;
    $old_adsandpagescats = $database->database_query("SELECT adsandpagescat_id FROM se_adsandpagescats WHERE adsandpagescat_dependency='0' ORDER BY adsandpagescat_id");
    while($old_adsandpagescat_info = $database->database_fetch_assoc($old_adsandpagescats)) {
      $var = "adsandpagescat_title".$old_adsandpagescat_info[adsandpagescat_id];
      $adsandpagescat_title = $_POST[$var];
      if(str_replace(" ", "", $adsandpagescat_title) == "") {
        $database->database_query("DELETE FROM se_adsandpagescats WHERE adsandpagescat_id='$old_adsandpagescat_info[adsandpagescat_id]' OR adsandpagescat_dependency='$old_adsandpagescat_info[adsandpagescat_id]'");
	$database->database_query("UPDATE se_adsandpagess SET adsandpages_adsandpagescat_id='0' WHERE adsandpages_adsandpagescat_id='$old_adsandpagescat_info[adsandpagescat_id]'");
      } else {
        $database->database_query("UPDATE se_adsandpagescats SET adsandpagescat_title='$adsandpagescat_title' WHERE adsandpagescat_id='$old_adsandpagescat_info[adsandpagescat_id]'");

          // SAVE DEP adsandpages CATEGORIES
          $max_dep_adsandpagescat_id = 0;
          $old_dep_adsandpagescats = $database->database_query("SELECT adsandpagescat_id FROM se_adsandpagescats WHERE adsandpagescat_dependency='$old_adsandpagescat_info[adsandpagescat_id]' ORDER BY adsandpagescat_id");
          while($old_dep_adsandpagescat_info = $database->database_fetch_assoc($old_dep_adsandpagescats)) {
            $var = "adsandpagescat_title".$old_adsandpagescat_info[adsandpagescat_id]."_".$old_dep_adsandpagescat_info[adsandpagescat_id];
            $dep_adsandpagescat_title = $_POST[$var];
            if(str_replace(" ", "", $dep_adsandpagescat_title) == "") {
              $database->database_query("DELETE FROM se_adsandpagescats WHERE adsandpagescat_id='$old_dep_adsandpagescat_info[adsandpagescat_id]'");
	      $database->database_query("UPDATE se_adsandpagess SET adsandpages_adsandpagescat_id='0' WHERE adsandpages_adsandpagescat_id='$old_dep_adsandpagescat_info[adsandpagescat_id]'");
            } else {
              $database->database_query("UPDATE se_adsandpagescats SET adsandpagescat_title='$dep_adsandpagescat_title' WHERE adsandpagescat_id='$old_dep_adsandpagescat_info[adsandpagescat_id]'");
            }  
            $max_dep_adsandpagescat_id = $old_dep_adsandpagescat_info[adsandpagescat_id];
          }

          $var = "num_subcat_".$old_adsandpagescat_info[adsandpagescat_id];
          $num_dep_adsandpagescats = $_POST[$var];
          $dep_adsandpagescat_count = 0;
          for($t=$max_dep_adsandpagescat_id+1;$t<$num_dep_adsandpagescats;$t++) {
            $var = "adsandpagescat_title".$old_adsandpagescat_info[adsandpagescat_id]."_$t";
            $dep_adsandpagescat_title = $_POST[$var];
            if(str_replace(" ", "", $dep_adsandpagescat_title) != "") {
              $database->database_query("INSERT INTO se_adsandpagescats (adsandpagescat_title, adsandpagescat_dependency) VALUES ('$dep_adsandpagescat_title', '$old_adsandpagescat_info[adsandpagescat_id]')");
            }
          }
      }  
      $max_adsandpagescat_id = $old_adsandpagescat_info[adsandpagescat_id];
    }

    $num_adsandpagescats = $_POST['num_adsandpagescategories'];
    $adsandpagescat_count = 0;
    for($t=$max_adsandpagescat_id+1;$t<=$num_adsandpagescats;$t++) {
      $var = "adsandpagescat_title$t";
      $adsandpagescat_title = $_POST[$var];
      if(str_replace(" ", "", $adsandpagescat_title) != "") {
        $database->database_query("INSERT INTO se_adsandpagescats (adsandpagescat_title) VALUES ('$adsandpagescat_title')");
        $old_adsandpagescat_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagescat_id FROM se_adsandpagescats WHERE adsandpagescat_title='$adsandpagescat_title' ORDER BY adsandpagescat_id DESC LIMIT 1"));

          // SAVE DEP adsandpages CATEGORIES
          $var = "num_subcat_".$t;
          $num_dep_adsandpagescats = $_POST[$var];
          $dep_adsandpagescat_count = 0;
          for($d=0;$d<$num_dep_adsandpagescats;$d++) {
            $var = "adsandpagescat_title".$t."_$d";
            $dep_adsandpagescat_title = $_POST[$var];
            if(str_replace(" ", "", $dep_adsandpagescat_title) != "") {
              $database->database_query("INSERT INTO se_adsandpagescats (adsandpagescat_title, adsandpagescat_dependency) VALUES ('$dep_adsandpagescat_title', '$old_adsandpagescat_info[adsandpagescat_id]')");
            }
          }
      }
    }

  // SAVE CHANGES
  $database->database_query("UPDATE se_settings SET 
			setting_permission_adsandpages='$setting_permission_adsandpages',
			setting_adsandpages_discussion_code = '$discussion_code',
			setting_email_adsandpagesinvite_subject='$setting_email_adsandpagesinvite_subject',
			setting_email_adsandpagesinvite_message='$setting_email_adsandpagesinvite_message',
			setting_email_adsandpagescomment_subject='$setting_email_adsandpagescomment_subject',
			setting_email_adsandpagescomment_message='$setting_email_adsandpagescomment_message',
			setting_email_adsandpagesmediacomment_subject='$setting_email_adsandpagesmediacomment_subject',
			setting_email_adsandpagesmediacomment_message='$setting_email_adsandpagesmediacomment_message',
			setting_email_adsandpagesmemberrequest_subject='$setting_email_adsandpagesmemberrequest_subject',
			setting_email_adsandpagesmemberrequest_message='$setting_email_adsandpagesmemberrequest_message'");

  $setting = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_settings LIMIT 1"));
  $result = 1;
}





// SET FIELD ARRAY VAR
$field_array = Array();
$fields = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_title FROM se_adsandpagesfields WHERE adsandpagesfield_dependency='0' ORDER BY adsandpagesfield_order");
$num_fields = $database->database_num_rows($fields);
$field_count = 0;
$prev_adsandpagesfield_id = 0;
    
// LOOP OVER NON DEPENDENT FIELDS
while($field_info = $database->database_fetch_assoc($fields)) {

  // SET DEPENDENT FIELD ARRAY VAR
  $dep_field_array = Array();

  // GET DEPENDENT FIELDS FOR ORIGINAL FIELD
  $dep_fields = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_title FROM se_adsandpagesfields WHERE adsandpagesfield_dependency='$field_info[adsandpagesfield_id]' ORDER BY adsandpagesfield_order");
  $num_dep_fields = $database->database_num_rows($dep_fields);
  $dep_field_count = 0;
    
  // LOOP OVER DEPENDENT FIELDS
  while($dep_field_info = $database->database_fetch_assoc($dep_fields)) {

    // SET DEPENDENT TITLE IF NOTHING
    if(str_replace(" ", "", $dep_field_info[adsandpagesfield_title]) == "") {
      $dep_field_title = 'Untitled';
    } else {
      $dep_field_title = $dep_field_info[adsandpagesfield_title];
    }

    // SET DEPENDENT FIELD ARRAY AND INCREMENT DEPENDENT FIELD COUNT
    $dep_field_array[$dep_field_count] = Array('dep_adsandpagesfield_id' => $dep_field_info[adsandpagesfield_id], 
					       'dep_adsandpagesfield_title' => $dep_field_title, 
					       'dep_adsandpagesfield_order' => $dep_field_order);
    $dep_field_count++;
  } 
    

  // SET FIELD ARRAY AND INCREMENT FIELD COUNT
  $field_array[$field_count] = Array('adsandpagesfield_id' => $field_info[adsandpagesfield_id], 
				     'adsandpagesfield_title' => $field_info[adsandpagesfield_title], 
				     'adsandpagesfield_order' => $field_order,
				     'dep_adsandpagesfields' => $dep_field_array,
				     'prev_adsandpagesfield_id' => $prev_adsandpagesfield_id);
  $field_count++;
  $prev_adsandpagesfield_id = $field_info[adsandpagesfield_id];
} 



// GET adsandpages CATEGORIES
$categories_array = Array();
$categories_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_dependency='0' ORDER BY adsandpagescat_id");
while($category = $database->database_fetch_assoc($categories_query)) {
  // GET DEPENDENT adsandpages CATS
  $dep_categories_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_dependency='$category[adsandpagescat_id]' ORDER BY adsandpagescat_id");
  $dep_adsandpagescat_array = Array();
  while($dep_category = $database->database_fetch_assoc($dep_categories_query)) {
    $dep_adsandpagescat_array[] = Array('dep_adsandpagescat_id' => $dep_category[adsandpagescat_id],
					'dep_adsandpagescat_title' => $dep_category[adsandpagescat_title]);
  }

  $max_dep_adsandpagescat_id = $database->database_fetch_assoc($database->database_query("SELECT max(adsandpagescat_id) AS max_adsandpagescat_id FROM se_adsandpagescats WHERE adsandpagescat_dependency='$category[adsandpagescat_id]'"));
  $num_dep_cats = $max_dep_adsandpagescat_id[max_adsandpagescat_id]+1;

  $categories_array[] = Array('adsandpagescat_id' => $category[adsandpagescat_id],
				'adsandpagescat_title' => $category[adsandpagescat_title],
				'dep_adsandpagescats' => $dep_adsandpagescat_array,
				'adsandpagescat_num_deps' => $num_dep_cats);
}
$max_adsandpagescat_id = $database->database_fetch_assoc($database->database_query("SELECT max(adsandpagescat_id) AS max_adsandpagescat_id FROM se_adsandpagescats"));
$num_cats = $max_adsandpagescat_id[max_adsandpagescat_id];







// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('fields', $field_array);
$smarty->assign('total_adsandpagesfields', $field_count);
$smarty->assign('num_cats', $num_cats);
$smarty->assign('categories', $categories_array);
$smarty->assign('permission_adsandpages', $setting[setting_permission_adsandpages]);
$smarty->assign('setting_adsandpages_discussion_code', $setting[setting_adsandpages_discussion_code]);
$smarty->assign('setting_email_adsandpagesinvite_subject', $setting[setting_email_adsandpagesinvite_subject]);
$smarty->assign('setting_email_adsandpagesinvite_message', $setting[setting_email_adsandpagesinvite_message]);
$smarty->assign('setting_email_adsandpagescomment_subject', $setting[setting_email_adsandpagescomment_subject]);
$smarty->assign('setting_email_adsandpagescomment_message', $setting[setting_email_adsandpagescomment_message]);
$smarty->assign('setting_email_adsandpagesmediacomment_subject', $setting[setting_email_adsandpagesmediacomment_subject]);
$smarty->assign('setting_email_adsandpagesmediacomment_message', $setting[setting_email_adsandpagesmediacomment_message]);
$smarty->assign('setting_email_adsandpagesmemberrequest_subject', $setting[setting_email_adsandpagesmemberrequest_subject]);
$smarty->assign('setting_email_adsandpagesmemberrequest_message', $setting[setting_email_adsandpagesmemberrequest_message]);
$smarty->display("$page.tpl");
exit();
?>