<?
$page = "admin_levels_adsandpagessettings";
include "admin_header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }
if(isset($_POST['level_id'])) { $level_id = $_POST['level_id']; } elseif(isset($_GET['level_id'])) { $level_id = $_GET['level_id']; } else { $level_id = 0; }

// VALIDATE LEVEL ID
$level = $database->database_query("SELECT * FROM se_levels WHERE level_id='$level_id'");
if($database->database_num_rows($level) != 1) { 
  header("Location: admin_levels.php");
  exit();
}
$level_info = $database->database_fetch_assoc($level);


// SET RESULT AND ERROR VARS
$result = 0;
$is_error = 0;




// SAVE CHANGES
if($task == "dosave") {
  $level_adsandpages_allow = $_POST['level_adsandpages_allow'];
  $level_adsandpages_photo = $_POST['level_adsandpages_photo'];
  $level_adsandpages_photo_width = $_POST['level_adsandpages_photo_width'];
  $level_adsandpages_photo_height = $_POST['level_adsandpages_photo_height'];
  $level_adsandpages_photo_exts = str_replace(", ", ",", $_POST['level_adsandpages_photo_exts']);
  $level_adsandpages_titles = $_POST['level_adsandpages_titles'];
  $level_adsandpages_officers = $_POST['level_adsandpages_officers'];
  $level_adsandpages_approval = $_POST['level_adsandpages_approval'];
  $level_adsandpages_style = $_POST['level_adsandpages_style'];
  $level_adsandpages_album_exts = str_replace(", ", ",", $_POST['level_adsandpages_album_exts']);
  $level_adsandpages_album_mimes = str_replace(", ", ",", $_POST['level_adsandpages_album_mimes']);
  $level_adsandpages_album_storage = $_POST['level_adsandpages_album_storage'];
  $level_adsandpages_album_maxsize = $_POST['level_adsandpages_album_maxsize'];
  $level_adsandpages_album_width = $_POST['level_adsandpages_album_width'];
  $level_adsandpages_album_height = $_POST['level_adsandpages_album_height'];
  $level_adsandpages_maxnum = $_POST['level_adsandpages_maxnum'];
  $level_adsandpages_search = $_POST['level_adsandpages_search'];

  // GET adsandpages PRIVACY SETTING
  $adsandpages_privacy_0 = $_POST['adsandpages_privacy_0'];
  $adsandpages_privacy_1 = $_POST['adsandpages_privacy_1'];
  $adsandpages_privacy_2 = $_POST['adsandpages_privacy_2'];
  $adsandpages_privacy_3 = $_POST['adsandpages_privacy_3'];
  $adsandpages_privacy_4 = $_POST['adsandpages_privacy_4'];
  $adsandpages_privacy_5 = $_POST['adsandpages_privacy_5'];
  $level_adsandpages_privacy = $adsandpages_privacy_0.$adsandpages_privacy_1.$adsandpages_privacy_2.$adsandpages_privacy_3.$adsandpages_privacy_4.$adsandpages_privacy_5;

  // GET adsandpages COMMENTS SETTING
  $adsandpages_comments_0 = $_POST['adsandpages_comments_0'];
  $adsandpages_comments_1 = $_POST['adsandpages_comments_1'];
  $adsandpages_comments_2 = $_POST['adsandpages_comments_2'];
  $adsandpages_comments_3 = $_POST['adsandpages_comments_3'];
  $adsandpages_comments_4 = $_POST['adsandpages_comments_4'];
  $adsandpages_comments_5 = $_POST['adsandpages_comments_5'];
  $adsandpages_comments_6 = $_POST['adsandpages_comments_6'];
  $adsandpages_comments_7 = $_POST['adsandpages_comments_7'];
  $level_adsandpages_comments = $adsandpages_comments_0.$adsandpages_comments_1.$adsandpages_comments_2.$adsandpages_comments_3.$adsandpages_comments_4.$adsandpages_comments_5.$adsandpages_comments_6.$adsandpages_comments_7;

  // GET adsandpages DISCUSSION SETTING
  $adsandpages_discussion_0 = $_POST['adsandpages_discussion_0'];
  $adsandpages_discussion_1 = $_POST['adsandpages_discussion_1'];
  $adsandpages_discussion_2 = $_POST['adsandpages_discussion_2'];
  $adsandpages_discussion_3 = $_POST['adsandpages_discussion_3'];
  $adsandpages_discussion_4 = $_POST['adsandpages_discussion_4'];
  $adsandpages_discussion_5 = $_POST['adsandpages_discussion_5'];
  $adsandpages_discussion_6 = $_POST['adsandpages_discussion_6'];
  $adsandpages_discussion_7 = $_POST['adsandpages_discussion_7'];
  $level_adsandpages_discussion = $adsandpages_discussion_0.$adsandpages_discussion_1.$adsandpages_discussion_2.$adsandpages_discussion_3.$adsandpages_discussion_4.$adsandpages_discussion_5.$adsandpages_discussion_6.$adsandpages_discussion_7;

  // CHECK THAT A NUMBER BETWEEN 1 AND 999 WAS ENTERED FOR WIDTH AND HEIGHT
  if(!is_numeric($level_adsandpages_photo_width) OR !is_numeric($level_adsandpages_photo_height) OR $level_adsandpages_photo_width < 1 OR $level_adsandpages_photo_height < 1 OR $level_adsandpages_photo_width > 999 OR $level_adsandpages_photo_height > 999) {
    $is_error = 1;
    $error_message = $admin_levels_adsandpagesettings[48];
  }

  // CHECK THAT A NUMBER BETWEEN 1 AND 204800 (200MB) WAS ENTERED FOR MAXSIZE
  if(!is_numeric($level_adsandpages_album_maxsize) OR $level_adsandpages_album_maxsize < 1 OR $level_adsandpages_album_maxsize > 204800) {
    $is_error = 1;
    $error_message = $admin_levels_adsandpagesettings[49];
  }

  // CHECK THAT WIDTH AND HEIGHT ARE NUMBERS
  if(!is_numeric($level_adsandpages_album_width) OR !is_numeric($level_adsandpages_album_height)) {
    $is_error = 1;
    $error_message = $admin_levels_adsandpagesettings[50];
  }

  // CHECK THAT MAX ALBUMS IS A NUMBER
  if(!is_numeric($level_adsandpages_maxnum) OR $level_adsandpages_maxnum < 1 OR $level_adsandpages_maxnum > 999) {
    $is_error = 1;
    $error_message = $admin_levels_adsandpagesettings[51];
  }

  // IF THERE WERE NO ERRORS, SAVE CHANGES
  if($is_error == 0) {

    // IF ALLOW OFFICERS WAS SET FROM YES TO NO, DEMOTE ALL OFFICERS TO MEMBERS
    if($level_adsandpages_officers == 0 AND $level_info[level_adsandpages_officers] == 1) {
      $database->database_query("UPDATE se_adsandpagesmembers SET adsandpagesmember_rank='0' WHERE adsandpagesmember_rank='1'");
    }

    // SAVE OTHER SETTINGS
    $level_adsandpages_album_maxsize = $level_adsandpages_album_maxsize*1024;
    $database->database_query("UPDATE se_levels SET 
			level_adsandpages_search='$level_adsandpages_search',
			level_adsandpages_discussion='$level_adsandpages_discussion',
			level_adsandpages_comments='$level_adsandpages_comments',
			level_adsandpages_privacy='$level_adsandpages_privacy',
			level_adsandpages_allow='$level_adsandpages_allow',
			level_adsandpages_photo='$level_adsandpages_photo',
			level_adsandpages_photo_width='$level_adsandpages_photo_width',
			level_adsandpages_photo_height='$level_adsandpages_photo_height',
			level_adsandpages_photo_exts='$level_adsandpages_photo_exts',
			level_adsandpages_titles='$level_adsandpages_titles',
			level_adsandpages_officers='$level_adsandpages_officers',
			level_adsandpages_approval='$level_adsandpages_approval',
			level_adsandpages_style='$level_adsandpages_style',
			level_adsandpages_album_exts='$level_adsandpages_album_exts',
			level_adsandpages_album_mimes='$level_adsandpages_album_mimes',
			level_adsandpages_album_storage='$level_adsandpages_album_storage',
			level_adsandpages_album_maxsize='$level_adsandpages_album_maxsize',
			level_adsandpages_album_width='$level_adsandpages_album_width',
			level_adsandpages_album_height='$level_adsandpages_album_height',
			level_adsandpages_maxnum='$level_adsandpages_maxnum' WHERE level_id='$level_info[level_id]'");
    if($level_adsandpages_search == 0) { $database->database_query("UPDATE se_adsandpages, se_users SET adsandpages_search='1' WHERE se_users.user_level_id='$level_info[level_id]' AND se_adsandpages.adsandpages_user_id=se_users.user_id"); }
    $level_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_levels WHERE level_id='$level_info[level_id]'"));
    $result = 1;
  }
}








// ADD SPACES BACK AFTER COMMAS
$level_adsandpages_photo_exts = str_replace(",", ", ", $level_info[level_adsandpages_photo_exts]);
$level_adsandpages_album_exts = str_replace(",", ", ", $level_info[level_adsandpages_album_exts]);
$level_adsandpages_album_mimes = str_replace(",", ", ", $level_info[level_adsandpages_album_mimes]);
$level_adsandpages_album_maxsize = $level_info[level_adsandpages_album_maxsize]/1024;

// GET CURRENT adsandpages PRIVACY SETTING
$count = 0;
while($count < 6) {
  if(adsandpages_privacy_levels($count) != "") {
    if(strpos($level_info[level_adsandpages_privacy], "$count") !== FALSE) { $privacy_selected = 1; } else { $privacy_selected = 0; }
    $privacy_options[$count] = Array('privacy_name' => "adsandpages_privacy_".$count,
				'privacy_value' => $count,
				'privacy_option' => adsandpages_privacy_levels($count),
				'privacy_selected' => $privacy_selected);
  }
  $count++;
}

// GET CURRENT adsandpages COMMENT SETTINGS
$count = 0;
while($count < 10) {
  if(adsandpages_privacy_levels($count) != "") {
    if(strpos($level_info[level_adsandpages_comments], "$count") !== FALSE) { $comment_selected = 1; } else { $comment_selected = 0; }
    $comment_options[$count] = Array('comment_name' => "adsandpages_comments_".$count,
				'comment_value' => $count,
				'comment_option' => adsandpages_privacy_levels($count),
				'comment_selected' => $comment_selected);
  }
  $count++;
}

// GET CURRENT adsandpages DISCUSSION SETTINGS
$count = 0;
while($count < 10) {
  if(adsandpages_privacy_levels($count) != "") {
    if(strpos($level_info[level_adsandpages_discussion], "$count") !== FALSE) { $discussion_selected = 1; } else { $discussion_selected = 0; }
    $discussion_options[$count] = Array('discussion_name' => "adsandpages_discussion_".$count,
					'discussion_value' => $count,
					'discussion_option' => adsandpages_privacy_levels($count),
					'discussion_selected' => $discussion_selected);
  }
  $count++;
}





// ASSIGN VARIABLES AND SHOW USER adsandpages PAGE
$smarty->assign('level_id', $level_info[level_id]);
$smarty->assign('level_name', $level_info[level_name]);
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('error_message', $error_message);
$smarty->assign('adsandpages_allow', $level_info[level_adsandpages_allow]);
$smarty->assign('adsandpages_photo', $level_info[level_adsandpages_photo]);
$smarty->assign('adsandpages_photo_width', $level_info[level_adsandpages_photo_width]);
$smarty->assign('adsandpages_photo_height', $level_info[level_adsandpages_photo_height]);
$smarty->assign('adsandpages_photo_exts', $level_adsandpages_photo_exts);
$smarty->assign('adsandpages_titles', $level_info[level_adsandpages_titles]);
$smarty->assign('adsandpages_officers', $level_info[level_adsandpages_officers]);
$smarty->assign('adsandpages_approval', $level_info[level_adsandpages_approval]);
$smarty->assign('adsandpages_style', $level_info[level_adsandpages_style]);
$smarty->assign('adsandpages_album_exts', $level_adsandpages_album_exts);
$smarty->assign('adsandpages_album_mimes', $level_adsandpages_album_mimes);
$smarty->assign('adsandpages_album_storage', $level_info[level_adsandpages_album_storage]);
$smarty->assign('adsandpages_album_maxsize', $level_adsandpages_album_maxsize);
$smarty->assign('adsandpages_album_width', $level_info[level_adsandpages_album_width]);
$smarty->assign('adsandpages_album_height', $level_info[level_adsandpages_album_height]);
$smarty->assign('adsandpages_maxnum', $level_info[level_adsandpages_maxnum]);
$smarty->assign('adsandpages_search', $level_info[level_adsandpages_search]);
$smarty->assign('adsandpages_privacy', $privacy_options);
$smarty->assign('adsandpages_comments', $comment_options);
$smarty->assign('adsandpages_discussion', $discussion_options);
$smarty->display("$page.tpl");
exit();
?>