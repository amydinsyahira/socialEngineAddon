<?
$page = "adsandpages_album_file";
include "header.php";

// MAKE SURE MEDIA VARS ARE SET IN URL
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['adsandpagesmedia_id'])) { $adsandpagesmedia_id = $_POST['adsandpagesmedia_id']; } elseif(isset($_GET['adsandpagesmedia_id'])) { $adsandpagesmedia_id = $_GET['adsandpagesmedia_id']; } else { $adsandpagesmedia_id = 0; }
if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_adsandpages] == 0) {
  $smarty->assign('error_header', $adsandpages_album_file[15]);
  $smarty->assign('error_message', $adsandpages_album_file[17]);
  $smarty->assign('error_submit', $adsandpages_album_file[25]);
  $smarty->display("error.tpl");
  exit();
}


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
if($adsandpages->adsandpages_exists == 0) { header("Location: home.php"); exit(); }

// GET adsandpages ALBUM INFO
$adsandpagesalbum_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_adsandpagesalbums WHERE adsandpagesalbum_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1"));


// MAKE SURE MEDIA EXISTS
$adsandpagesmedia_query = $database->database_query("SELECT * FROM se_adsandpagesmedia WHERE adsandpagesmedia_id='$adsandpagesmedia_id' AND adsandpagesmedia_adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]' LIMIT 1");
if($database->database_num_rows($adsandpagesmedia_query) != 1) { header("Location: adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }
$adsandpagesmedia_info = $database->database_fetch_assoc($adsandpagesmedia_query);

// GET PRIVACY LEVEL
$privacy_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$allowed_privacy = true_privacy($adsandpages->adsandpages_info[adsandpages_privacy], $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$is_adsandpages_private = 0;
if($privacy_level < $allowed_privacy) { header("Location: adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }


// UPDATE ALBUM VIEWS
$adsandpagesalbum_views_new = $adsandpagesalbum_info[adsandpagesalbum_views] + 1;
$database->database_query("UPDATE se_adsandpagesalbums SET adsandpagesalbum_views='$adsandpagesalbum_views_new' WHERE adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]' LIMIT 1");

// CHECK IF USER IS ALLOWED TO COMMENT
$allowed_to_comment = 1;
$comment_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]);
$allowed_comment = true_privacy($adsandpages->adsandpages_info[adsandpages_comments], $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]);
if($comment_level < $allowed_comment) { $allowed_to_comment = 0; }


// IF A COMMENT IS BEING POSTED
if($task == "dopost" & $allowed_to_comment != 0) {

  $comment_date = time();
  $comment_body = $_POST['comment_body'];

  // RETRIEVE AND CHECK SECURITY CODE IF NECESSARY
  if($setting[setting_comment_code] != 0) {
    session_start();
    $code = $_SESSION['code'];
    if($code == "") { $code = randomcode(); }
    $comment_secure = $_POST['comment_secure'];

    if($comment_secure != $code) { $is_error = 1; }
  }

  // MAKE SURE COMMENT BODY IS NOT EMPTY
  $comment_body = censor(str_replace("\r\n", "<br>", $comment_body));
  $comment_body = preg_replace('/(<br>){3,}/is', '<br><br>', $comment_body);
  $comment_body = ChopText($comment_body);
  if(str_replace(" ", "", $comment_body) == "") { $is_error = 1; $comment_body = ""; }

  // ADD COMMENT IF NO ERROR
  if($is_error == 0) {
    $database->database_query("INSERT INTO se_adsandpagesmediacomments (adsandpagesmediacomment_adsandpagesmedia_id, adsandpagesmediacomment_authoruser_id, adsandpagesmediacomment_date, adsandpagesmediacomment_body) VALUES ('$adsandpagesmedia_info[adsandpagesmedia_id]', '".$user->user_info[user_id]."', '$comment_date', '$comment_body')");

    // INSERT ACTION IF USER EXISTS
    if($user->user_exists != 0) {
      $commenter = $user->user_info[user_username];
      $comment_body_encoded = $comment_body;
      if(strlen($comment_body_encoded) > 250) { 
        $comment_body_encoded = substr($comment_body_encoded, 0, 240);
        $comment_body_encoded .= "...";
      }
      $comment_body_encoded = htmlspecialchars(str_replace("<br>", " ", $comment_body_encoded));
      $actions->actions_add($user, "adsandpagesmediacomment", Array('[username]', '[id]', '[id2]', '[title]', '[comment]'), Array($commenter, $adsandpages->adsandpages_info[adsandpages_id], $adsandpagesmedia_info[adsandpagesmedia_id], $adsandpages->adsandpages_info[adsandpages_title], $comment_body_encoded));
    } else { 
      $commenter = $adsandpages_album_file[14];
    }

    // SEND COMMENT NOTIFICATION IF NECESSARY
    $adsandpagesowner_info = $database->database_fetch_assoc($database->database_query("SELECT se_users.user_id, se_users.user_username, se_users.user_email, se_usersettings.usersetting_notify_adsandpagesmediacomment FROM se_users LEFT JOIN se_usersettings ON se_users.user_id=se_usersettings.usersetting_user_id WHERE se_users.user_id='".$adsandpages->adsandpages_info[adsandpages_user_id]."'"));
    if($adsandpagesowner_info[usersetting_notify_adsandpagesmediacomment] == 1 & $adsandpagesowner_info[user_id] != $user->user_info[user_id]) { 
      send_generic($adsandpagesowner_info[user_email], "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>", $setting[setting_email_adsandpagesmediacomment_subject], $setting[setting_email_adsandpagesmediacomment_message], Array('[username]', '[commenter]', '[adsandpagesname]', '[link]'), Array($adsandpagesowner_info[user_username], $commenter, $adsandpages->adsandpages_info[adsandpages_title], "<a href=\"".$url->url_base."adsandpages_album_file.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagesmedia_id=$adsandpagesmedia_info[adsandpagesmedia_id]\">".$url->url_base."adsandpages_album_file.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagesmedia_id=$adsandpagesmedia_info[adsandpagesmedia_id]</a>")); 
    }
  }

  echo "<html><head><script type=\"text/javascript\">";
  echo "window.parent.addComment('$is_error', '$comment_body', '$comment_date');";
  echo "</script></head><body></body></html>";
  exit();
}



// GET adsandpages MEDIA COMMENTS
$comment = new se_comment('adsandpagesmedia', 'adsandpagesmedia_id', $adsandpagesmedia_info[adsandpagesmedia_id]);
$total_comments = $comment->comment_total();
$comments = $comment->comment_list(0, $total_comments);




// CREATE BACK MENU LINK
$back = $database->database_query("SELECT adsandpagesmedia_id FROM se_adsandpagesmedia WHERE adsandpagesmedia_adsandpagesalbum_id='$adsandpagesmedia_info[adsandpagesmedia_adsandpagesalbum_id]' AND adsandpagesmedia_id<'$adsandpagesmedia_info[adsandpagesmedia_id]' ORDER BY adsandpagesmedia_id DESC LIMIT 1");
if($database->database_num_rows($back) == 1) {
  $back_info = $database->database_fetch_assoc($back);
  $link_back = $url->base."adsandpages_album_file.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagesmedia_id=$back_info[adsandpagesmedia_id]";
} else {
  $link_back = "#";
}

// CREATE FIRST MENU LINK
$first = $database->database_query("SELECT adsandpagesmedia_id FROM se_adsandpagesmedia WHERE adsandpagesmedia_adsandpagesalbum_id='$adsandpagesmedia_info[adsandpagesmedia_adsandpagesalbum_id]' ORDER BY adsandpagesmedia_id ASC LIMIT 1");
if($database->database_num_rows($first) == 1 AND $link_back != "#") {
  $first_info = $database->database_fetch_assoc($first);
  $link_first = $url->base."adsandpages_album_file.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagesmedia_id=$first_info[adsandpagesmedia_id]";
} else {
  $link_first = "#";
}

// CREATE NEXT MENU LINK
$next = $database->database_query("SELECT adsandpagesmedia_id FROM se_adsandpagesmedia WHERE adsandpagesmedia_adsandpagesalbum_id='$adsandpagesmedia_info[adsandpagesmedia_adsandpagesalbum_id]' AND adsandpagesmedia_id>'$adsandpagesmedia_info[adsandpagesmedia_id]' ORDER BY adsandpagesmedia_id ASC LIMIT 1");
if($database->database_num_rows($next) == 1) {
  $next_info = $database->database_fetch_assoc($next);
  $link_next = $url->base."adsandpages_album_file.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagesmedia_id=$next_info[adsandpagesmedia_id]";
} else {
  $link_next = "#";
}

// CREATE END MENU LINK
$end = $database->database_query("SELECT adsandpagesmedia_id FROM se_adsandpagesmedia WHERE adsandpagesmedia_adsandpagesalbum_id='$adsandpagesmedia_info[adsandpagesmedia_adsandpagesalbum_id]' ORDER BY adsandpagesmedia_id DESC LIMIT 1");
if($database->database_num_rows($end) == 1 AND $link_next != "#") {
  $end_info = $database->database_fetch_assoc($end);
  $link_end = $url->base."adsandpages_album_file.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagesmedia_id=$end_info[adsandpagesmedia_id]";
} else {
  $link_end = "#";
}



// GET CUSTOM adsandpages STYLE IF ALLOWED
if($adsandpages->adsandpagesowner_level_info[level_adsandpages_style] != 0 & $is_adsandpages_private == 0) { 
  $adsandpagesstyle_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesstyle_css FROM se_adsandpagesstyles WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1")); 
  $global_css = $adsandpagesstyle_info[adsandpagesstyle_css];
}





// ASSIGN VARIABLES AND DISPLAY ALBUM FILE PAGE
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('adsandpagesmedia_info', $adsandpagesmedia_info);
$smarty->assign('comments', $comments);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('allowed_to_comment', $allowed_to_comment);
$smarty->assign('link_first', $link_first);
$smarty->assign('link_back', $link_back);
$smarty->assign('link_next', $link_next);
$smarty->assign('link_end', $link_end);
include "footer.php";
?>