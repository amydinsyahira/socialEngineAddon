<?
$page = "user_adsandpages_settings";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// SET VARS
$result = 0;

// SAVE NEW SETTINGS
if($task == "dosave") {
  $usersetting_notify_adsandpagesinvite = $_POST['usersetting_notify_adsandpagesinvite'];
  $usersetting_notify_adsandpagescomment = $_POST['usersetting_notify_adsandpagescomment'];
  $usersetting_notify_adsandpagesmediacomment = $_POST['usersetting_notify_adsandpagesmediacomment'];
  $usersetting_notify_adsandpagesmemberrequest = $_POST['usersetting_notify_adsandpagesmemberrequest'];

  // UPDATE DATABASE
  $database->database_query("UPDATE se_usersettings SET usersetting_notify_adsandpagesinvite='$usersetting_notify_adsandpagesinvite', usersetting_notify_adsandpagescomment='$usersetting_notify_adsandpagescomment', usersetting_notify_adsandpagesmediacomment='$usersetting_notify_adsandpagesmediacomment', usersetting_notify_adsandpagesmemberrequest='$usersetting_notify_adsandpagesmemberrequest' WHERE usersetting_user_id='".$user->user_info[user_id]."'");
  $user = new se_user(Array($user->user_info[user_id]));
  $result = 1;
}

// ASSIGN USER SETTINGS
$user->user_settings();

// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('result', $result);
include "footer.php";
?>