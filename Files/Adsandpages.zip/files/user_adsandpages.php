<?
$page = "user_adsandpages";
include "header.php";

// SET VARIABLES AND INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id]);
$sort_by = "se_adsandpagesmembers.adsandpagesmember_rank DESC, se_adsandpagess.adsandpages_title";
$where = "(se_adsandpagesmembers.adsandpagesmember_status='1')";

// GET TOTAL adsandpagesS
$total_adsandpagess = $adsandpages->adsandpages_total($where);

// GET adsandpagesS ARRAY
$adsandpages_array = $adsandpages->adsandpages_list(0, $total_adsandpagess, $sort_by, $where, 1);

// ASSIGN VARIABLES AND SHOW VIEW adsandpagesS PAGE
$smarty->assign('adsandpagess', $adsandpages_array);
$smarty->assign('total_adsandpagess', $total_adsandpagess);
include "footer.php";
?>