<?
$page = "adsandpages_comments";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }
if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_adsandpages] == 0) {
  $page = "error";
  $smarty->assign('error_header', $adsandpages_comments[20]);
  $smarty->assign('error_message', $adsandpages_comments[22]);
  $smarty->assign('error_submit', $adsandpages_comments[23]);
  include "footer.php";
}


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
if($adsandpages->adsandpages_exists == 0) { header("Location: home.php"); exit(); }

// GET PRIVACY LEVEL
$privacy_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$allowed_privacy = true_privacy($adsandpages->adsandpages_info[adsandpages_privacy], $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$is_adsandpages_private = 0;
if($privacy_level < $allowed_privacy) { header("Location: adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }


// SET VARS
$is_error = 0;
$refresh = 0;
$allowed_to_comment = 1;


// CHECK IF USER IS ALLOWED TO COMMENT
$comment_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]);
$allowed_comment = true_privacy($adsandpages->adsandpages_info[adsandpages_comments], $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]);
if($comment_level < $allowed_comment) { $allowed_to_comment = 0; }



// IF A COMMENT IS BEING POSTED
if($task == "dopost" & $allowed_to_comment != 0) {
  $comment_date = time();
  $comment_body = $_POST['comment_body'];

  // RETRIEVE AND CHECK SECURITY CODE IF NECESSARY
  if($setting[setting_comment_code] != 0) {
    session_start();
    $code = $_SESSION['code'];
    if($code == "") { $code = randomcode(); }
    $comment_secure = $_POST['comment_secure'];

    if($comment_secure != $code) { $is_error = 1; }
  }

  // MAKE SURE COMMENT BODY IS NOT EMPTY
  $comment_body = censor(str_replace("\r\n", "<br>", $comment_body));
  $comment_body = preg_replace('/(<br>){3,}/is', '<br><br>', $comment_body);
  $comment_body = ChopText($comment_body);
  if(str_replace(" ", "", $comment_body) == "") { $is_error = 1; $comment_body = ""; }

  // ADD COMMENT IF NO ERROR
  if($is_error == 0) {
    $database->database_query("INSERT INTO se_adsandpagescomments (adsandpagescomment_adsandpages_id, adsandpagescomment_authoruser_id, adsandpagescomment_date, adsandpagescomment_body) VALUES ('".$adsandpages->adsandpages_info[adsandpages_id]."', '".$user->user_info[user_id]."', '$comment_date', '$comment_body')");

    // INSERT ACTION IF USER EXISTS
    if($user->user_exists != 0) {
      $commenter = $user->user_info[user_username];
      $comment_body_encoded = $comment_body;
      if(strlen($comment_body_encoded) > 250) { 
        $comment_body_encoded = substr($comment_body_encoded, 0, 240);
        $comment_body_encoded .= "...";
      }
      $comment_body_encoded = htmlspecialchars(str_replace("<br>", " ", $comment_body_encoded));
      $actions->actions_add($user, "adsandpagescomment", Array('[username]', '[id]', '[title]', '[comment]'), Array($commenter, $adsandpages->adsandpages_info[adsandpages_id], $adsandpages->adsandpages_info[adsandpages_title], $comment_body_encoded));
    } else { 
      $commenter = $adsandpages_comments[12];
    }

    // GET adsandpages LEADER INFO AND SEND NOTIFICATION IF COMMENTER IS NOT LEADER
    $adsandpagesowner_info = $database->database_fetch_assoc($database->database_query("SELECT se_users.user_id, se_users.user_username, se_users.user_email, se_usersettings.usersetting_notify_adsandpagescomment FROM se_users LEFT JOIN se_usersettings ON se_users.user_id=se_usersettings.usersetting_user_id WHERE se_users.user_id='".$adsandpages->adsandpages_info[adsandpages_user_id]."'"));
    if($adsandpagesowner_info[usersetting_notify_adsandpagescomment] == 1 & $adsandpagesowner_info[user_id] != $user->user_info[user_id]) { 
      send_generic($adsandpagesowner_info[user_email], "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>", $setting[setting_email_adsandpagescomment_subject], $setting[setting_email_adsandpagescomment_message], Array('[username]', '[commenter]', '[adsandpagesname]', '[link]'), Array($adsandpagesowner_info[user_username], $commenter, $adsandpages->adsandpages_info[adsandpages_title], "<a href=\"".$url->url_base."adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."\">".$url->url_base."adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."</a>")); 
    }
  }

  echo "<html><head><script type=\"text/javascript\">";
  echo "window.parent.addComment('$is_error', '$comment_body', '$comment_date');";
  echo "</script></head><body></body></html>";
  exit();
}



// START COMMENT OBJECT
$comment = new se_comment('adsandpages', 'adsandpages_id', $adsandpages->adsandpages_info[adsandpages_id]);

// GET TOTAL COMMENTS
$total_comments = $comment->comment_total();

// MAKE COMMENT PAGES
$comments_per_page = 10;
$page_vars = make_page($total_comments, $comments_per_page, $p);

// GET adsandpages COMMENTS
$comments = $comment->comment_list($page_vars[0], $comments_per_page);


// GET CUSTOM adsandpages STYLE IF ALLOWED
if($adsandpages->adsandpagesowner_level_info[level_adsandpages_style] != 0) { 
  $adsandpagesstyle_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesstyle_css FROM se_adsandpagesstyles WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1")); 
  $global_css = $adsandpagesstyle_info[adsandpagesstyle_css];
}


// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('comments', $comments);
$smarty->assign('allowed_to_comment', $allowed_to_comment);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($comments));
include "footer.php";
?>