<?
$page = "user_adsandpages_add";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// INITIALIZE VARIABLES
$is_error = 0;
$error_message = "";
$adsandpages_title = "";
$adsandpages_desc = "";
$adsandpages_privacy = true_privacy(0, $user->level_info[level_adsandpages_privacy]);
$adsandpages_comments = true_privacy(0, $user->level_info[level_adsandpages_comments]);
$adsandpages_discussion = true_privacy(0, $user->level_info[level_adsandpages_discussion]);
$adsandpages_search = 1;
$adsandpagescat_id = 0;
$subadsandpagescat_id = 0;




// INITIALIZE adsandpages OBJECT
$new_adsandpages = new se_adsandpages($user->user_info[user_id], 0);



// RETRIEVE AND/OR VALIDATE adsandpages FIELDS
if($task == "doadd") { $validate = 1; } else { $validate = 0; }
$new_adsandpages->adsandpages_fields($validate, 0);
if($validate == 1) { $is_error = $new_adsandpages->is_error; $error_message = $new_adsandpages->error_message; }


// CHECK TO MAKE SURE USER HAS LESS THAN MAX NUMBER OF adsandpagesS ALLOWED
$owned_where = "(se_adsandpagess.adsandpages_user_id='".$user->user_info[user_id]."')";
$total_adsandpagess_owned = $new_adsandpages->adsandpages_total($owned_where);
if($total_adsandpagess_owned >= $user->level_info[level_adsandpages_maxnum]) {
  $is_error = 1;
  $error_message = $user_adsandpages_add[2];
  $task = "main";
}



// ATTEMPT TO ADD adsandpages
if($task == "doadd") {
  $adsandpages_title = censor($_POST['adsandpages_title']);
  $adsandpages_desc = censor(str_replace("\r\n", "<br>", $_POST['adsandpages_desc']));
  $adsandpagescat_id = $_POST['adsandpagescat_id'];
  $subadsandpagescat_id = $_POST['subadsandpagescat_id'];
  $adsandpages_approval = $_POST['adsandpages_approval'];
  $adsandpages_search = $_POST['adsandpages_search'];
  $adsandpages_privacy = $_POST['adsandpages_privacy'];
  $adsandpages_comments = $_POST['adsandpages_comments'];
  $adsandpages_discussion = $_POST['adsandpages_discussion'];
 
  // CHECK TO MAKE SURE TITLE HAS BEEN ENTERED
  if(str_replace(" ", "", $adsandpages_title) == "") {
    $is_error = 1;
    $error_message = $user_adsandpages_add[1];
  }

  // CHECK THAT PRIVACY IS NOT BLANK
  if($adsandpages_privacy == "") { $adsandpages_privacy = true_privacy(0, $user->level_info[level_adsandpages_privacy]); }
  if($adsandpages_comments == "") { $adsandpages_comments = true_privacy(0, $user->level_info[level_adsandpages_comments]); }
  if($adsandpages_discussion == "") { $adsandpages_discussion = true_privacy(0, $user->level_info[level_adsandpages_discussion]); }

  // CHECK THAT SEARCH IS NOT BLANK
  if($user->level_info[level_adsandpages_search] == 0) { $adsandpages_search = 1; }

  // CHECK THAT APPROVAL IS NOT BLANK
  if($user->level_info[level_adsandpages_approval] == 0) { $adsandpages_approval = 0; }


  // IF NO ERROR, SAVE adsandpages
  if($is_error == 0) {

    if($subadsandpagescat_id != 0) { $adsandpagescat_id = $subadsandpagescat_id; }
    $adsandpages_id = $new_adsandpages->adsandpages_create($adsandpages_title, $adsandpages_desc, $adsandpagescat_id, $adsandpages_search, $adsandpages_privacy, $adsandpages_comments, $adsandpages_discussion, $adsandpages_approval);

    // INSERT ACTION
    $adsandpages_title_short = $adsandpages_title;
    if(strlen($adsandpages_title_short) > 100) { $adsandpages_title_short = substr($adsandpages_title_short, 0, 97); $adsandpages_title_short .= "..."; }
    $actions->actions_add($user, "newadsandpages", Array('[username]', '[id]', '[title]'), Array($user->user_info[user_username], $adsandpages_id, $adsandpages_title_short));

    header("Location: user_adsandpages_edit.php?adsandpages_id=$adsandpages_id&justadded=1");
    exit();
  }
}






// GET adsandpages CATEGORIES
$categories_array = Array();
$categories_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_dependency='0' ORDER BY adsandpagescat_id");
while($category = $database->database_fetch_assoc($categories_query)) {
  $dep_categories_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_dependency='$category[adsandpagescat_id]' ORDER BY adsandpagescat_id");
  $dep_adsandpagescat_array = Array();
  while($dep_category = $database->database_fetch_assoc($dep_categories_query)) {
    $dep_adsandpagescat_array[] = Array('subadsandpagescat_id' => $dep_category[adsandpagescat_id],
				'subadsandpagescat_title' => $dep_category[adsandpagescat_title]);
  }

  $categories_array[] = Array('adsandpagescat_id' => $category[adsandpagescat_id],
				'adsandpagescat_title' => $category[adsandpagescat_title],
				'subcats' => $dep_adsandpagescat_array);
}





// GET AVAILABLE adsandpages PRIVACY OPTIONS
$privacy_options = Array();
for($p=0;$p<strlen($user->level_info[level_adsandpages_privacy]);$p++) {
  $privacy_level = substr($user->level_info[level_adsandpages_privacy], $p, 1);
  if(adsandpages_privacy_levels($privacy_level) != "") {
    $privacy_options[] = Array('privacy_id' => "adsandpages_privacy".$privacy_level,
				'privacy_value' => $privacy_level,
				'privacy_option' => adsandpages_privacy_levels($privacy_level));
  }
}


// GET AVAILABLE adsandpages COMMENTS OPTIONS
$comment_options = Array();
for($p=0;$p<strlen($user->level_info[level_adsandpages_comments]);$p++) {
  $comment_level = substr($user->level_info[level_adsandpages_comments], $p, 1);
  if(adsandpages_privacy_levels($comment_level) != "") {
    $comment_options[] = Array('comment_id' => "adsandpages_comment".$comment_level,
				'comment_value' => $comment_level,
				'comment_option' => adsandpages_privacy_levels($comment_level));
  }
}

// GET AVAILABLE adsandpages DISCUSSION OPTIONS
$discussion_options = Array();
for($p=0;$p<strlen($user->level_info[level_adsandpages_discussion]);$p++) {
  $discussion_level = substr($user->level_info[level_adsandpages_discussion], $p, 1);
  if(adsandpages_privacy_levels($discussion_level) != "") {
    $discussion_options[] = Array('discussion_id' => "adsandpages_discussion".$discussion_level,
				'discussion_value' => $discussion_level,
				'discussion_option' => adsandpages_privacy_levels($discussion_level));
  }
}


// ASSIGN VARIABLES AND SHOW ADD adsandpagesS PAGE
$smarty->assign('is_error', $is_error);
$smarty->assign('error_message', $error_message);
$smarty->assign('fields', $new_adsandpages->adsandpages_fields);
$smarty->assign('cats', $categories_array);
$smarty->assign('adsandpages_title', $adsandpages_title);
$smarty->assign('adsandpages_desc', str_replace("<br>", "\r\n", $adsandpages_desc));
$smarty->assign('adsandpages_search', $adsandpages_search);
$smarty->assign('adsandpages_privacy', $adsandpages_privacy);
$smarty->assign('adsandpages_comments', $adsandpages_comments);
$smarty->assign('adsandpages_discussion', $adsandpages_discussion);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
$smarty->assign('discussion_options', $discussion_options);
$smarty->assign('adsandpagescat_id', $adsandpagescat_id);
$smarty->assign('subadsandpagescat_id', $subadsandpagescat_id);
include "footer.php";
?>