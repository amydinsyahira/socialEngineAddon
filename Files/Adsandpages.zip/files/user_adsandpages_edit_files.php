<?
$page = "user_adsandpages_edit_files";
include "header.php";

if(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } elseif(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == 0 | $adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }


// GET adsandpages ALBUM INFO
$adsandpagesalbum_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_adsandpagesalbums WHERE adsandpagesalbum_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1"));





// UPDATE FILES IN THIS adsandpages ALBUM
if($task == "doupdate") {

  // GET TOTAL FILES
  $total_files = $adsandpages->adsandpages_media_total($adsandpagesalbum_info[adsandpagesalbum_id]);

  // DELETE NECESSARY FILES
  $adsandpages->adsandpages_media_delete(0, $total_files, "adsandpagesmedia_id ASC", "(adsandpagesmedia_adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]')");

  // UPDATE NECESSARY FILES
  $media_array = $adsandpages->adsandpages_media_update(0, $total_files, "adsandpagesmedia_id ASC", "(adsandpagesmedia_adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]')");

  // SET ALBUM COVER AND UPDATE DATE
  $newdate = time();
  $adsandpagesalbum_info[adsandpagesalbum_cover] = $_POST['adsandpagesalbum_cover'];
  if(!in_array($adsandpagesalbum_info[adsandpagesalbum_cover], $media_array)) { $adsandpagesalbum_info[adsandpagesalbum_cover] = $media_array[0]; }
  $database->database_query("UPDATE se_adsandpagesalbums SET adsandpagesalbum_cover='$adsandpagesalbum_info[adsandpagesalbum_cover]', adsandpagesalbum_dateupdated='$new_date' WHERE adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]'");

  // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
  $adsandpages->adsandpages_lastupdate();

  // SHOW SUCCESS MESSAGE
  $result = 1;

}






// SHOW FILES IN THIS ALBUM
$total_files = $adsandpages->adsandpages_media_total($adsandpagesalbum_info[adsandpagesalbum_id]);
$file_array = $adsandpages->adsandpages_media_list(0, $total_files, "adsandpagesmedia_id ASC", "(adsandpagesmedia_adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]')");





// ASSIGN VARIABLES AND SHOW USER EDIT adsandpages PAGE
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('result', $result);
$smarty->assign('files', $file_array);
$smarty->assign('files_total', $total_files);
$smarty->assign('adsandpagesalbum_id', $adsandpagesalbum_info[adsandpagesalbum_id]);
include "footer.php";
?>