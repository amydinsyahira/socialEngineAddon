<?

//  THIS FILE CONTAINS adsandpages-RELATED FUNCTIONS
//  FUNCTIONS IN THIS CLASS:
//    notification_adsandpages()
//    search_adsandpages()
//    deleteuser_adsandpages()
//    adsandpages_privacy_levels()









// THIS FUNCTION IS RUN ON THE USER HOME PAGE TO GENERATE NOTIFICATIONS
// INPUT: 
// OUTPUT: 
function notification_adsandpages(&$notifications) {
	global $database, $user, $url, $functions_adsandpages;

	// SET VARIABLES AND INITIALIZE adsandpages OBJECT
	$adsandpages = new se_adsandpages($user->user_info[user_id]);
	$where = "(se_adsandpagesmembers.adsandpagesmember_status='0' AND se_adsandpagesmembers.adsandpagesmember_approved='1')";

	// GET TOTAL adsandpages INVITES
	$total_adsandpagess = $adsandpages->adsandpages_total($where);

	// IF adsandpages INVITES, CONTINUE
	if($total_adsandpagess > 0) {

	  // GET PLUGIN ICON
	  $plugin_info = $database->database_fetch_assoc($database->database_query("SELECT plugin_icon FROM se_plugins WHERE plugin_type='adsandpages'"));

	  // SET NOTIFICATION ARRAY
	  $notifications[] = Array('notify_url' => $url->url_base."user_adsandpages_invites.php",
				'notify_icon' => $plugin_info[plugin_icon],
				'notify_text' => $total_adsandpagess.$functions_adsandpages[11]);
	}

} // END notification_adsandpages() FUNCTION









// THIS FUNCTION IS RUN DURING THE SEARCH PROCESS TO SEARCH THROUGH adsandpagesS AND adsandpages MEDIA
// INPUT: $search_text REPRESENTING THE STRING TO SEARCH FOR
//	  $total_only REPRESENTING 1/0 DEPENDING ON WHETHER OR NOT TO RETURN JUST THE TOTAL RESULTS
//	  $search_objects REPRESENTING AN ARRAY CONTAINING INFORMATION ABOUT THE POSSIBLE OBJECTS TO SEARCH
//	  $results REPRESENTING THE ARRAY OF SEARCH RESULTS
//	  $total_results REPRESENTING THE TOTAL SEARCH RESULTS
// OUTPUT: 
function search_adsandpages($search_text, $total_only, &$search_objects, &$results, &$total_results) {
	global $database, $url, $functions_adsandpages, $results_per_page, $p;

	// GET adsandpages FIELDS
	$adsandpagesfields = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_type, adsandpagesfield_options FROM se_adsandpagesfields WHERE adsandpagesfield_type<>'5'");
	$adsandpagesvalue_query = "se_adsandpagess.adsandpages_title LIKE '%$search_text%' OR se_adsandpagess.adsandpages_desc LIKE '%$search_text%'";
    
	// LOOP OVER adsandpages FIELDS
	while($adsandpagesfield_info = $database->database_fetch_assoc($adsandpagesfields)) {
    
	  // TEXT FIELD OR TEXTAREA
	  if($adsandpagesfield_info[adsandpagesfield_type] == 1 | $adsandpagesfield_info[adsandpagesfield_type] == 2) {
	    if($adsandpagesvalue_query != "") { $adsandpagesvalue_query .= " OR "; }
	    $adsandpagesvalue_query .= "se_adsandpagesvalues.adsandpagesvalue_".$adsandpagesfield_info[adsandpagesfield_id]." LIKE '%$search_text%'";

	  // RADIO OR SELECT BOX
	  } elseif($adsandpagesfield_info[adsandpagesfield_type] == 3 | $adsandpagesfield_info[adsandpagesfield_type] == 4) {
	    // LOOP OVER FIELD OPTIONS
	    $options = explode("<~!~>", $adsandpagesfield_info[adsandpagesfield_options]);
	    for($i=0,$max=count($options);$i<$max;$i++) {
	      if(str_replace(" ", "", $options[$i]) != "") {
	        $option = explode("<!>", $options[$i]);
	        $option_id = $option[0];
	        $option_label = $option[1];
	        if(strpos($option_label, $search_text)) {
	          if($adsandpagesvalue_query != "") { $adsandpagesvalue_query .= " OR "; }
	          $adsandpagesvalue_query .= "se_adsandpagesvalues.adsandpagesvalue_".$adsandpagesfield_info[adsandpagesfield_id]."='$option_id'";
	        }
	      }
	    }
	  }
	}

	// CONSTRUCT adsandpages QUERY
	$adsandpagesvalue_query = "SELECT '1' AS sub_type, se_adsandpagess.adsandpages_id AS adsandpages_id, se_adsandpagess.adsandpages_photo AS adsandpages_photo, se_adsandpagess.adsandpages_title AS title, se_adsandpagess.adsandpages_desc AS description, '0' AS adsandpagesmedia_id FROM se_adsandpagess LEFT JOIN se_adsandpagesvalues ON se_adsandpagess.adsandpages_id=se_adsandpagesvalues.adsandpagesvalue_adsandpages_id WHERE se_adsandpagess.adsandpages_search='1' AND ($adsandpagesvalue_query)";

	// CONSTRUCT adsandpages MEDIA QUERY
	$adsandpagesmedia_query = "SELECT '2' AS sub_type, se_adsandpagess.adsandpages_id AS adsandpages_id, '' AS adsandpages_photo, se_adsandpagesmedia.adsandpagesmedia_title AS title, se_adsandpagess.adsandpages_title AS description, se_adsandpagesmedia.adsandpagesmedia_id AS adsandpagesmedia_id FROM se_adsandpagesmedia, se_adsandpagesalbums, se_adsandpagess WHERE se_adsandpagesmedia.adsandpagesmedia_adsandpagesalbum_id=se_adsandpagesalbums.adsandpagesalbum_id AND se_adsandpagesalbums.adsandpagesalbum_id=se_adsandpagess.adsandpages_id AND se_adsandpagess.adsandpages_search='1' AND (se_adsandpagesmedia.adsandpagesmedia_title LIKE '%$search_text%' OR se_adsandpagesmedia.adsandpagesmedia_desc LIKE '%$search_text%')";

	// UNION TWO QUERIES
	$adsandpages_query = "($adsandpagesvalue_query) UNION ALL ($adsandpagesmedia_query)";

	// GET TOTAL QUERIES
	$total_adsandpagess = $database->database_num_rows($database->database_query($adsandpages_query." LIMIT 201"));

	// IF NOT TOTAL ONLY
	if($total_only == 0) {

	  // MAKE adsandpages PAGES
	  $start = ($p - 1) * $results_per_page;
	  $limit = $results_per_page+1;

	  // SEARCH adsandpagesS
	  $adsandpagess = $database->database_query($adsandpages_query." ORDER BY adsandpages_id DESC LIMIT $start, $limit");
	  while($adsandpages_info = $database->database_fetch_assoc($adsandpagess)) {

	    // CREATE AN OBJECT FOR adsandpages
	    $adsandpages = new se_adsandpages();
	    $adsandpages->adsandpages_info[adsandpages_id] = $adsandpages_info[adsandpages_id];

	    // RESULT IS A adsandpages
	    if($adsandpages_info[sub_type] == 1) {

	      // SET adsandpages PHOTO, IF AVAILABLE
	      $adsandpages->adsandpages_info[adsandpages_photo] = $adsandpages_info[adsandpages_photo];
	      $adsandpages_photo = $adsandpages->adsandpages_photo();
	      if($adsandpages_photo != "") { $result_icon = $adsandpages_photo; } else { $result_icon = ""; }

	      // SET RESULT URL
	      $result_url = $url->url_base."adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id];

	      // SET RESULT DESCRIPTION
	      $result_desc = $adsandpages_info[description];

	    // RESULT IS MEDIA
	    } else {
	      
	      // SET THUMBNAIL, IF AVAILABLE
	      $thumb_path = $adsandpages->adsandpages_dir($adsandpages->adsandpages_info[adsandpages_id]).$adsandpages_info[adsandpagesmedia_id]."_thumb.jpg";
	      if(file_exists($thumb_path)) { $result_icon = $thumb_path; } else { $result_icon = ""; }

	      // SET RESULT URL
	      $result_url = $url->url_base."adsandpages_album_file.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagesmedia_id=$adsandpages_info[adsandpagesmedia_id]";
	
	      // SET RESULT DESCRIPTION
	      $result_desc = $functions_adsandpages[10].$adsandpages_info[description];

	    }

	    $results[] = Array('result_url' => $result_url,
				'result_icon' => $result_icon,
				'result_name' => $adsandpages_info[title],
				'result_desc' => $result_desc,
				'result_user' => '');
	  }

	  // SET TOTAL RESULTS
	  $total_results = $total_adsandpagess;

	}

	// SET ARRAY VALUES
	if($total_adsandpagess > 200) { $total_adsandpagess = "200+"; }
	$search_objects[] = Array('search_type' => 'adsandpages',
				'search_item' => $functions_adsandpages[9],
				'search_total' => $total_adsandpagess);
} // END search_adsandpages() FUNCTION









// THIS FUNCTION IS RUN WHEN A USER IS DELETED
// INPUT: $user_id REPRESENTING THE USER ID OF THE USER BEING DELETED
// OUTPUT: 
function deleteuser_adsandpages($user_id) {
	global $database;

	// INITATE adsandpages OBJECT
	$adsandpages = new se_adsandpages($user_id);

	// LOOP OVER adsandpagesS AND DELETE THEM
	$adsandpagess = $database->database_query("SELECT adsandpages_id FROM se_adsandpagess WHERE adsandpages_user_id='$user_id'");
	while($adsandpages_info = $database->database_fetch_assoc($adsandpagess)) {
	  $adsandpages->adsandpages_delete($adsandpages_info[adsandpages_id]);
	}

	// DELETE USER FROM ALL adsandpagesS
	$database->database_query("DELETE FROM se_adsandpagesmembers WHERE adsandpagesmember_user_id='$user_id'");
	
	// DELETE USER'S COMMENTS
	$database->database_query("DELETE FROM se_adsandpagescomments WHERE adsandpagescomment_authoruser_id='$user_id'");
	$database->database_query("DELETE FROM se_adsandpagesmediacomments WHERE adsandpagesmediacomment_authoruser_id='$user_id'");

} // END deleteuser_adsandpages() FUNCTION









// THIS FUNCTION RETURNS TEXT CORRESPONDING TO THE GIVEN adsandpages PRIVACY LEVEL
// INPUT: $privacy_level REPRESENTING THE LEVEL OF adsandpages PRIVACY
// OUTPUT: A STRING EXPLAINING THE GIVEN PRIVACY SETTING
function adsandpages_privacy_levels($privacy_level) {
	global $functions_adsandpages;

	switch($privacy_level) {
	  case 0: $privacy = $functions_adsandpages[1]; break;
	  case 1: $privacy = $functions_adsandpages[2]; break;
	  case 2: $privacy = $functions_adsandpages[3]; break;
	  case 3: $privacy = $functions_adsandpages[4]; break;
	  case 4: $privacy = $functions_adsandpages[5]; break;
	  case 5: $privacy = $functions_adsandpages[6]; break;
	  case 6: $privacy = $functions_adsandpages[7]; break;
	  case 7: $privacy = $functions_adsandpages[8]; break;
	  default: $privacy = ""; break;
	}

	return $privacy;
} // END adsandpages_privacy_levels() FUNCTION

?>