<?

//  THIS CLASS CONTAINS adsandpages-RELATED METHODS 
//  METHODS IN THIS CLASS:
//    se_adsandpages()
//    adsandpages_total()
//    adsandpages_list()
//    adsandpages_create()
//    adsandpages_fields()
//    adsandpages_delete()
//    adsandpages_delete_selected()
//    adsandpages_lastupdate()
//    adsandpages_privacy_max()
//    adsandpages_member_total()
//    adsandpages_member_list()
//    adsandpages_dir()
//    adsandpages_photo()
//    adsandpages_photo_upload()
//    adsandpages_photo_delete()
//    adsandpages_media_upload()
//    adsandpages_media_space()
//    adsandpages_media_total()
//    adsandpages_media_list()
//    adsandpages_media_update()
//    adsandpages_media_delete()
//    adsandpages_topic_list()
//    adsandpages_topic_total()
//    adsandpages_post_list()
//    adsandpages_post_total()





class se_adsandpages {

	// INITIALIZE VARIABLES
	var $is_error;			// DETERMINES WHETHER THERE IS AN ERROR OR NOT
	var $error_message;		// CONTAINS RELEVANT ERROR MESSAGE

	var $user_id;			// CONTAINS THE USER ID OF THE USER WHOSE adsandpagesS WE ARE EDITING
	var $user_rank;			// CONTAINS THE USER'S ASSOCIATION TO THE adsandpages (LEADER - 2, OFFICER - 1, MEMBER - 0, NOT AFFILIATED - -1)

	var $adsandpages_exists;		// DETERMINES WHETHER THE adsandpages HAS BEEN SET AND EXISTS OR NOT

	var $adsandpages_info;		// CONTAINS THE adsandpages INFO OF THE adsandpages WE ARE EDITING
	var $adsandpagesvalue_info;		// CONTAINS THE adsandpagesVALUE INFO OF THE adsandpages WE ARE EDITING
	var $adsandpagesowner_level_info;	// CONTAINS THE adsandpages OWNER'S LEVEL INFO FOR THE adsandpages WE ARE EDITING

	var $adsandpages_fields;		// CONTAINS ARRAY OF adsandpages FIELDS
	var $adsandpages_field_query;		// CONTAINS A PARTIAL DATABASE QUERY TO SAVE/RETRIEVE adsandpages FIELD VALUES








	// THIS METHOD SETS INITIAL VARS
	// INPUT: $user_id (OPTIONAL) REPRESENTING THE USER ID OF THE USER WHOSE adsandpagesS WE ARE CONCERNED WITH
	//	  $adsandpages_id (OPTIONAL) REPRESENTING THE adsandpages ID OF THE adsandpages WE ARE CONCERNED WITH
	// OUTPUT: 
	function se_adsandpages($user_id = 0, $adsandpages_id = 0) {
	  global $database;

	  $this->user_id = $user_id;
	  $this->adsandpages_exists = 0;
	  $this->user_rank = -1;

	  if($adsandpages_id != 0) {
	    $adsandpages = $database->database_query("SELECT * FROM se_adsandpagess WHERE adsandpages_id='$adsandpages_id'");
	    if($database->database_num_rows($adsandpages) == 1) {
	      $this->adsandpages_exists = 1;
	      $this->adsandpages_info = $database->database_fetch_assoc($adsandpages);
	      $this->adsandpagesvalue_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_adsandpagesvalues WHERE adsandpagesvalue_adsandpages_id='$adsandpages_id'"));
	      $this->adsandpagesowner_level_info = $database->database_fetch_assoc($database->database_query("SELECT se_levels.* FROM se_users LEFT JOIN se_levels ON se_users.user_level_id=se_levels.level_id WHERE se_users.user_id='".$this->adsandpages_info[adsandpages_user_id]."'"));

	      if($this->user_id != 0) {
	        $adsandpagesmember = $database->database_query("SELECT adsandpagesmember_id, adsandpagesmember_rank FROM se_adsandpagesmembers WHERE adsandpagesmember_user_id='".$this->user_id."' AND adsandpagesmember_adsandpages_id='$adsandpages_id' AND adsandpagesmember_status='1'");
	        if($database->database_num_rows($adsandpagesmember) == 1) {
	          $adsandpagesmember_info = $database->database_fetch_assoc($adsandpagesmember);
	          $this->user_rank = $adsandpagesmember_info[adsandpagesmember_rank];
	        }
	      }
	    }
	  }

	} // END se_adsandpages() METHOD








	// THIS METHOD RETURNS THE TOTAL NUMBER OF adsandpagesS
	// INPUT: $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	//	  $adsandpages_details (OPTIONAL) REPRESENTING A BOOLEAN THAT DETERMINES WHETHER TO RETRIEVE TOTAL MEMBERS, adsandpages LEADER, ETC
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF adsandpagesS
	function adsandpages_total($where = "", $adsandpages_details = 0) {
	  global $database;

	  // BEGIN QUERY
	  $adsandpages_query = "SELECT se_adsandpagess.adsandpages_id";

	  // SELECT RELEVANT adsandpages DETAILS IF NECESSARY
	  if($adsandpages_details == 1) { $adsandpages_query .= ", count(member_table.adsandpagesmember_id) AS num_members, se_users.user_id, se_users.user_username"; }

	  // IF USER ID NOT EMPTY, GET USER AS MEMBER
	  if($this->user_id != 0) { $adsandpages_query .= ", se_adsandpagesmembers.adsandpagesmember_rank"; }

	  // CONTINUE QUERY
	  $adsandpages_query .= " FROM";

	  // IF USER ID NOT EMPTY, SELECT FROM adsandpagesMEMBER TABLE
	  if($this->user_id != 0) { 
	    $adsandpages_query .= " se_adsandpagesmembers LEFT JOIN se_adsandpagess ON se_adsandpagesmembers.adsandpagesmember_adsandpages_id=se_adsandpagess.adsandpages_id "; 
	  } else {
	    $adsandpages_query .= " se_adsandpagess";
	  }

	  // CONTINUE QUERY IF NECESSARY
	  if($adsandpages_details == 1) { $adsandpages_query .= " LEFT JOIN se_adsandpagesmembers AS member_table ON se_adsandpagess.adsandpages_id=member_table.adsandpagesmember_adsandpages_id AND member_table.adsandpagesmember_status='1' AND member_table.adsandpagesmember_approved='1' LEFT JOIN se_users ON se_adsandpagess.adsandpages_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" | $this->user_id != 0) { $adsandpages_query .= " WHERE"; }

	  // IF USER ID NOT EMPTY, MAKE SURE USER IS A MEMBER
	  if($this->user_id != 0) { $adsandpages_query .= " se_adsandpagesmembers.adsandpagesmember_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 & $where != "") { $adsandpages_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $adsandpages_query .= " $where"; }

	  // ADD adsandpages BY
	  $adsandpages_query .= " adsandpages BY adsandpages_id";

	  // RUN QUERY
	  $adsandpages_total = $database->database_num_rows($database->database_query($adsandpages_query));
	  return $adsandpages_total;

	} // END adsandpages_total() METHOD








	// THIS METHOD RETURNS AN ARRAY OF adsandpagesS
	// INPUT: $start REPRESENTING THE adsandpages TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpagesS TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	//	  $adsandpages_details (OPTIONAL) REPRESENTING A BOOLEAN THAT DETERMINES WHETHER TO RETRIEVE TOTAL MEMBERS, adsandpages LEADER, ETC
	// OUTPUT: AN ARRAY OF adsandpagesS
	function adsandpages_list($start, $limit, $sort_by = "adsandpages_id DESC", $where = "", $adsandpages_details = 0) {
	  global $database, $user;

	  // BEGIN QUERY
	  $adsandpages_query = "SELECT se_adsandpagess.*";

	  // SELECT RELEVANT adsandpages DETAILS IF NECESSARY
	  if($adsandpages_details == 1) { $adsandpages_query .= ", count(member_table.adsandpagesmember_id) AS num_members, se_users.user_id, se_users.user_username, se_users.user_photo"; }

	  // IF USER ID NOT EMPTY, GET USER AS MEMBER
	  if($this->user_id != 0) { $adsandpages_query .= ", se_adsandpagesmembers.adsandpagesmember_rank"; }

	  // CONTINUE QUERY
	  $adsandpages_query .= " FROM";

	  // IF USER ID NOT EMPTY, SELECT FROM adsandpagesMEMBER TABLE
	  if($this->user_id != 0) { 
	    $adsandpages_query .= " se_adsandpagesmembers LEFT JOIN se_adsandpagess ON se_adsandpagesmembers.adsandpagesmember_adsandpages_id=se_adsandpagess.adsandpages_id "; 
	  } else {
	    $adsandpages_query .= " se_adsandpagess";
	  }

	  // CONTINUE QUERY IF NECESSARY
	  if($adsandpages_details == 1) { $adsandpages_query .= " LEFT JOIN se_adsandpagesmembers AS member_table ON se_adsandpagess.adsandpages_id=member_table.adsandpagesmember_adsandpages_id AND member_table.adsandpagesmember_status='1' AND member_table.adsandpagesmember_approved='1' LEFT JOIN se_users ON se_adsandpagess.adsandpages_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" | $this->user_id != 0) { $adsandpages_query .= " WHERE"; }

	  // IF USER ID NOT EMPTY, MAKE SURE USER IS A MEMBER
	  if($this->user_id != 0) { $adsandpages_query .= " se_adsandpagesmembers.adsandpagesmember_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 & $where != "") { $adsandpages_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $adsandpages_query .= " $where"; }

	  // ADD adsandpages BY, ORDER, AND LIMIT CLAUSE
	  $adsandpages_query .= " adsandpages BY adsandpages_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagess = $database->database_query($adsandpages_query);

	  // GET adsandpagesS INTO AN ARRAY
	  $adsandpages_array = Array();
	  while($adsandpages_info = $database->database_fetch_assoc($adsandpagess)) {

	    // CREATE OBJECT FOR LEADER
	    if($user->user_info[user_id] == $adsandpages_info[adsandpages_user_id]) {
	      $leader = $user;
	    } else {
	      $leader = new se_user();
	      $leader->user_exists = 1;
	      $leader->user_info[user_id] = $adsandpages_info[user_id];
	      $leader->user_info[user_username] = $adsandpages_info[user_username];
	      $leader->user_info[user_photo] = $adsandpages_info[user_photo];
	    }

	    // CREATE OBJECT FOR adsandpages
	    $adsandpages = new se_adsandpages($adsandpages_info[user_id]);
	    $adsandpages->adsandpages_exists = 1;
	    $adsandpages->adsandpages_info= $adsandpages_info;


	    // SET adsandpages ARRAY
	    $adsandpages_array[] = Array('adsandpages' => $adsandpages,
				'adsandpages_leader' => $leader,
				'adsandpages_rank' => $adsandpages_info[adsandpagesmember_rank],
				'adsandpages_members' => $adsandpages_info[num_members]);
	  }

	  // RETURN ARRAY
	  return $adsandpages_array;

	} // END adsandpages_list() METHOD








	// THIS METHOD CREATES A NEW adsandpages
	// INPUT: $adsandpages_title REPRESENTING THE adsandpages TITLE
	//	  $adsandpages_desc REPRESENTING THE adsandpages DESCRIPTION
	//	  $adsandpagescat_id REPRESENTING THE adsandpages CATEGORY ID
	//	  $adsandpages_search REPRESENTING WHETHER THE adsandpages SHOULD BE SEARCHABLE
	//	  $adsandpages_privacy REPRESENTING THE PRIVACY OF THE adsandpages
	//	  $adsandpages_comments REPRESENTING WHO CAN POST COMMENTS ON THE adsandpages
	//	  $adsandpages_discussion REPRESENTING WHO CAN CREATE AND POST IN DISCUSSION TOPICS IN THIS adsandpages
	//	  $adsandpages_approval REPRESENTING WHETHER THE LEADER MUST APPROVE MEMBERSHIP REQUESTS
	// OUTPUT: THE NEWLY CREATED adsandpages'S adsandpages ID
	function adsandpages_create($adsandpages_title, $adsandpages_desc, $adsandpagescat_id, $adsandpages_search, $adsandpages_privacy, $adsandpages_comments, $adsandpages_discussion, $adsandpages_approval) {
	  global $database;

	  $datecreated = time();

	  // ADD ROW TO adsandpagesS TABLE
	  $database->database_query("INSERT INTO se_adsandpagess (adsandpages_user_id, adsandpages_adsandpagescat_id, adsandpages_datecreated, adsandpages_title, adsandpages_desc, adsandpages_search, adsandpages_privacy, adsandpages_comments, adsandpages_discussion, adsandpages_approval) VALUES ('".$this->user_id."', '$adsandpagescat_id', '$datecreated', '$adsandpages_title', '$adsandpages_desc', '$adsandpages_search', '$adsandpages_privacy', '$adsandpages_comments', '$adsandpages_discussion', '$adsandpages_approval')");
	  $adsandpages_id = $database->database_insert_id();

	  // ADD adsandpages FIELD VALUES
	  $database->database_query("INSERT INTO se_adsandpagesvalues (adsandpagesvalue_adsandpages_id) VALUES ('$adsandpages_id')");
	  if(count($this->adsandpages_field_query) != "") {
	    $adsandpagesvalue_query = "UPDATE se_adsandpagesvalues SET ".$this->adsandpages_field_query." WHERE adsandpagesvalue_adsandpages_id='$adsandpages_id'";
	    $database->database_query($adsandpagesvalue_query);
	  }

	  // MAKE OWNER A MEMBER
	  $database->database_query("INSERT INTO se_adsandpagesmembers (adsandpagesmember_user_id, adsandpagesmember_adsandpages_id, adsandpagesmember_status, adsandpagesmember_approved, adsandpagesmember_rank) VALUES ('".$this->user_id."', '$adsandpages_id', '1', '1', '2')");

	  // ADD adsandpages STYLES ROW
	  $database->database_query("INSERT INTO se_adsandpagesstyles (adsandpagesstyle_adsandpages_id) VALUES ('$adsandpages_id')");

	  // ADD adsandpages ALBUM
	  $database->database_query("INSERT INTO se_adsandpagesalbums (adsandpagesalbum_adsandpages_id, adsandpagesalbum_datecreated, adsandpagesalbum_dateupdated, adsandpagesalbum_title, adsandpagesalbum_desc, adsandpagesalbum_search, adsandpagesalbum_privacy, adsandpagesalbum_comments) VALUES ('$adsandpages_id', '$datecreated', '$datecreated', '', '', '$adsandpages_search', '$adsandpages_privacy', '$adsandpages_comments')");

	  // ADD adsandpages DIRECTORY
	  $adsandpages_directory = $this->adsandpages_dir($adsandpages_id);
	  $adsandpages_path_array = explode("/", $adsandpages_directory);
	  array_pop($adsandpages_path_array);
	  array_pop($adsandpages_path_array);
	  $subdir = implode("/", $adsandpages_path_array)."/";
	  if(!is_dir($subdir)) { 
	    mkdir($subdir, 0777); 
	    chmod($subdir, 0777); 
	    $handle = fopen($subdir."index.php", 'x+');
	    fclose($handle);
	  }
	  mkdir($adsandpages_directory, 0777);
	  chmod($adsandpages_directory, 0777);
	  $handle = fopen($adsandpages_directory."/index.php", 'x+');
	  fclose($handle);

	  return $adsandpages_id;

	} // END adsandpages_create() METHOD









	// THIS METHOD LOOPS AND/OR VALIDATES adsandpages FIELD INPUT AND CREATES A PARTIAL QUERY TO UPDATE adsandpages TABLE
	// INPUT: $validate (OPTIONAL) REPRESENTING A BOOLEAN THAT DETERMINES WHETHER TO VALIDATE POST VARS OR NOT
	//	  $profile (OPTIONAL) REPRESENTING A BOOLEAN THAT DETERMINES WHETHER TO CREATE FORMATTED PROFILE FIELD VALUES
	// OUTPUT: 
	function adsandpages_fields($validate = 0, $profile = 0) {
	  global $database, $datetime, $setting, $class_adsandpages;

	  // GET NON DEPENDENT FIELDS
	  $field_count = 0;
	  $this->adsandpages_fields = "";
	  $field_query = "SELECT * FROM se_adsandpagesfields WHERE adsandpagesfield_dependency='0' ORDER BY adsandpagesfield_order";
	  $fields = $database->database_query($field_query);
	  while($field_info = $database->database_fetch_assoc($fields)) {

	    // SET FIELD VARS
	    $is_field_error = 0;
	    $field_value = "";
	    $field_value_adsandpages = "";

	    // FIELD TYPE SWITCH
	    switch($field_info[adsandpagesfield_type]) {

	      case 1: // TEXT FIELD
	      case 2: // TEXTAREA

	        // VALIDATE POSTED FIELD VALUE
	        if($validate == 1) {

	          // RETRIEVE POSTED FIELD VALUE
	          $adsandpagesvalue_var = "field_".$field_info[adsandpagesfield_id];
	          $field_value = censor($_POST[$adsandpagesvalue_var]);
	          if($field_info[adsandpagesfield_type] == 2) { $field_value = str_replace("\r\n", "<br>", $field_value); }

	          // CHECK FOR REQUIRED
	          if($field_info[adsandpagesfield_required] != 0 & str_replace(" ", "", $field_value) == "") {
	            $this->is_error = 1;
	            $this->error_message = $class_adsandpages[1];
	            $is_field_error = 1;
	          }

	          // RUN PREG MATCH (ONLY FOR TEXT FIELDS)
	          if($field_info[adsandpagesfield_regex] != "" & str_replace(" ", "", $field_value) != "") {
	            if(!preg_match($field_info[adsandpagesfield_regex], $field_value)) {
	              $this->is_error = 1;
	              $this->error_message = $class_adsandpages[2];
	              $is_field_error = 1;
	            }
	          }

	          // UPDATE SAVE adsandpages QUERY
	          if($this->adsandpages_field_query != "") { $this->adsandpages_field_query .= ", "; }
	          $this->adsandpages_field_query .= "adsandpagesvalue_$field_info[adsandpagesfield_id]='$field_value'";

		// DO NOT VALIDATE FIELD VALUE
	        } else {
	          // RETRIEVE DATABASE FIELD VALUE
	          if($this->adsandpagesvalue_info != "") {
	            $adsandpagesvalue_column = "adsandpagesvalue_".$field_info[adsandpagesfield_id];
	            $field_value = $this->adsandpagesvalue_info[$adsandpagesvalue_column];
	          }
	        }

		// FORMAT VALUE FOR PROFILE
		if($profile == 1) {
		  $field_value_adsandpages = $field_value;

		// FORMAT VALUE FOR FORM
		} else {
		  if($field_info[adsandpagesfield_type] == 2) { $field_value = str_replace("<br>", "\r\n", $field_value); }
		}
	        break;



	      case 3: // SELECT BOX
	      case 4: // RADIO BUTTON

	        // VALIDATE POSTED FIELD
	        if($validate == 1) {

	          // RETRIEVE POSTED FIELD VALUE
	          $adsandpagesvalue_var = "field_".$field_info[adsandpagesfield_id];
	          $field_value = censor($_POST[$adsandpagesvalue_var]);

	          // CHECK FOR REQUIRED
	          if($field_info[adsandpagesfield_required] != 0 & $field_value == "-1") {
	            $this->is_error = 1;
	            $this->error_message = $class_adsandpages[1];
	            $is_field_error = 1;
	          }

	          // UPDATE SAVE adsandpages VALUE QUERY
	          if($this->adsandpages_field_query != "") { $this->adsandpages_field_query .= ", "; }
	          $this->adsandpages_field_query .= "adsandpagesvalue_$field_info[adsandpagesfield_id]='$field_value'";


		// DO NOT VALIDATE FIELD VALUE
	        } else {
	          // RETRIEVE DATABASE FIELD VALUE
	          if($this->adsandpagesvalue_info != "") {
	            $adsandpagesvalue_column = "adsandpagesvalue_".$field_info[adsandpagesfield_id];
	            $field_value = $this->adsandpagesvalue_info[$adsandpagesvalue_column];
	          }
	        }

	        // LOOP OVER FIELD OPTIONS
	        $field_options = Array();
	        $options = explode("<~!~>", $field_info[adsandpagesfield_options]);
	        $num_options = 0;
	        for($i=0,$max=count($options);$i<$max;$i++) {
	          $dep_field_info = "";
	          $option_dependency = 0;
	          $dep_field_value = "";
	          if(str_replace(" ", "", $options[$i]) != "") {
	            $option = explode("<!>", $options[$i]);
	            $option_id = $option[0];
	            $option_label = $option[1];
	            $option_dependency = $option[2];
	            $option_dependent_field_id = $option[3];

	            // OPTION HAS DEPENDENCY
	            if($option_dependency == "1") { 
	              $dep_field = $database->database_query("SELECT adsandpagesfield_id, adsandpagesfield_title, adsandpagesfield_maxlength, adsandpagesfield_style, adsandpagesfield_required, adsandpagesfield_regex FROM se_adsandpagesfields WHERE adsandpagesfield_id='$option_dependent_field_id' AND adsandpagesfield_dependency='$field_info[adsandpagesfield_id]'");
	              if($database->database_num_rows($dep_field) != "1") {
	                $dep_field_info = "";
	                $option_dependency = 0;
	                $dep_field_value = "";
	              } else {
	                $dep_field_info = $database->database_fetch_assoc($dep_field);

	                // VALIDATE POSTED FIELD VALUE
	                if($validate == 1) {
	                  // OPTION SELECTED
	                  if($field_value == $option_id) {
	                    $dep_adsandpagesvalue_var = "field_".$dep_field_info[adsandpagesfield_id];
	                    $dep_field_value = censor($_POST[$dep_adsandpagesvalue_var]);
  
	                    // CHECK FOR REQUIRED
	                    if($dep_field_info[adsandpagesfield_required] != 0 & str_replace(" ", "", $dep_field_value) == "") {
	                      $this->is_error = 1;
	                      $this->error_message = $class_adsandpages[1];
	                      $is_field_error = 1;
	                    }

	                    // RUN PREG MATCH
	                    if($dep_field_info[adsandpagesfield_regex] != "" & str_replace(" ", "", $dep_field_value) != "") {
	                      if(!preg_match($dep_field_info[adsandpagesfield_regex], $dep_field_value)) {
	                        $this->is_error = 1;
	                        $this->error_message = $class_adsandpages[2];
	                        $is_field_error = 1;
	                      }
	                    }

	                  // OPTION NOT SELECTED
	                  } else {
	                    $dep_field_value = "";
	                  }

	    	          // UPDATE SAVE adsandpages VALUE QUERY
	   	          if($this->adsandpages_field_query != "") { $this->adsandpages_field_query .= ", "; }
	    	          $this->adsandpages_field_query .= "adsandpagesvalue_$dep_field_info[adsandpagesfield_id]='$dep_field_value'";


			// DO NOT VALIDATE POSTED FIELD VALUE
	                } else {
	                  // RETRIEVE DATABASE FIELD VALUE
	                  if($this->adsandpagesvalue_info != "") {
	                    $adsandpagesvalue_column = "adsandpagesvalue_".$dep_field_info[adsandpagesfield_id];
	                    $dep_field_value = $this->adsandpagesvalue_info[$adsandpagesvalue_column];
	                  }
	                }
	              }
	            }

		    // FORMAT VALUE FOR PROFILE IF OPTION IS SELECTED
		    if($profile == 1 & $field_value == $option_id) {
		      $field_value_adsandpages = $option_label;

		      // ADD DEPENDENT VALUE TO FIELD VALUE
		      if($dep_field_value != "") { $field_value_adsandpages .= " ".$dep_field_info[adsandpagesfield_title]." ".$dep_field_value; }
		    }
          
	            // SET OPTIONS ARRAY
	            $field_options[$num_options] = Array('option_id' => $option_id,
							'option_label' => $option_label,
							'option_dependency' => $option_dependency,
							'dep_field_id' => $dep_field_info[adsandpagesfield_id],
							'dep_field_title' => $dep_field_info[adsandpagesfield_title],
							'dep_field_required' => $dep_field_info[adsandpagesfield_required],
							'dep_field_maxlength' => $dep_field_info[adsandpagesfield_maxlength],
							'dep_field_style' => $dep_field_info[adsandpagesfield_style],
							'dep_field_value' => $dep_field_value,
							'dep_field_error' => $dep_field_error);
	            $num_options++;
	          }
	        }
	        break;


	      case 5: // DATE FIELD

		// SET MONTH, DAY, AND YEAR FORMAT FROM SETTINGS
		switch($setting[setting_dateformat]) {
		  case "n/j/Y": case "n.j.Y": case "n-j-Y": $month_format = "n"; $day_format = "j"; $year_format = "Y"; $date_order = "mdy"; break;
		  case "Y/n/j": case "Ynj": $month_format = "n"; $day_format = "j"; $year_format = "Y"; $date_order = "ymd"; break;
		  case "Y-n-d": $month_format = "n"; $day_format = "d"; $year_format = "Y"; $date_order = "ymd"; break;
		  case "Y-m-d": $month_format = "m"; $day_format = "d"; $year_format = "Y"; $date_order = "ymd"; break;
		  case "j/n/Y": case "j.n.Y": $month_format = "n"; $day_format = "j"; $year_format = "Y"; $date_order = "dmy"; break;
		  case "M. j, Y": $month_format = "M"; $day_format = "j"; $year_format = "Y"; $date_order = "mdy"; break;
		  case "F j, Y": case "l, F j, Y": $month_format = "F"; $day_format = "j"; $year_format = "Y"; $date_order = "mdy"; break;
		  case "j F Y": case "D j F Y": case "l j F Y": $month_format = "F"; $day_format = "j"; $year_format = "Y"; $date_order = "dmy"; break;
		  case "D-j-M-Y": case "D j M Y": case "j-M-Y": $month_format = "M"; $day_format = "j"; $year_format = "Y"; $date_order = "dmy"; break;
		  case "Y-M-j": $month_format = "M"; $day_format = "j"; $year_format = "Y"; $date_order = "ymd"; break;
		}  
  

	        // VALIDATE POSTED VALUE
	        if($validate == 1) {
	          // RETRIEVE POSTED FIELD VALUE
	          $adsandpagesvalue_var1 = "field_".$field_info[adsandpagesfield_id]."_1";
	          $adsandpagesvalue_var2 = "field_".$field_info[adsandpagesfield_id]."_2";
	          $adsandpagesvalue_var3 = "field_".$field_info[adsandpagesfield_id]."_3";
	          $field_1 = $_POST[$adsandpagesvalue_var1];
	          $field_2 = $_POST[$adsandpagesvalue_var2];
	          $field_3 = $_POST[$adsandpagesvalue_var3];

	          // ORDER DATE VALUES PROPERLY
	          switch($date_order) {
	            case "mdy": $month = $field_1; $day = $field_2; $year = $field_3; break;
	            case "ymd": $year = $field_1; $month = $field_2; $day = $field_3; break;
	            case "dmy": $day = $field_1; $month = $field_2; $year = $field_3; break;
	          }
  
	          // SET ALL TO BLANK IF ONE FIELD BLANK
	          if($month == 0 | $day == 0 | $year == 0) { $month = 0; $day = 0; $year = 0; }

	          // CONSTRUCT TIMESTAMP FROM MONTH, DAY, YEAR
	          $field_value = $datetime->MakeTime("0", "0", "0", "$month", "$day", "$year");
  
	          // CHECK FOR REQUIRED
	          if($field_info[adsandpagesfield_required] != 0 & $field_value == $datetime->MakeTime("0", "0", "0", "0", "0", "0")) {
	            $this->is_error = 1;
	            $this->error_message = $class_adsandpages[1];
	            $is_field_error = 1;
	          }

	          // UPDATE SAVE adsandpages VALUE QUERY
	          if($this->adsandpages_field_query != "") { $this->adsandpages_field_query .= ", "; }
	          $this->adsandpages_field_query .= "adsandpagesvalue_$field_info[adsandpagesfield_id]='$field_value'";

		// DO NOT VALIDATE FIELD VALUE AND DON'T CREATE SEARCH VALUE
	        } else {
	          // RETRIEVE DATABASE FIELD VALUE
	          if($this->adsandpagesvalue_info != "") {
	            $adsandpagesvalue_column = "adsandpagesvalue_".$field_info[adsandpagesfield_id];
	            $field_value = $this->adsandpagesvalue_info[$adsandpagesvalue_column];
	          } else {
	            $field_value = $datetime->MakeTime("0", "0", "0", "0", "0", "0");
	          }
	        }


		// FORMAT VALUE FOR PROFILE
		if($profile == 1) {
	   	  if($field_value != $datetime->MakeTime("0", "0", "0", "0", "0", "0")) { $field_value_adsandpages = $datetime->cdate($setting[setting_dateformat], $field_value); }

		// FORMAT VALUE FOR FORM
	    	} else {

	          // DECONSTRUCT TIMESTAMP INTO DATE MONTH, DAY, AND YEAR
	          if($field_value != $datetime->MakeTime("0", "0", "0", "0", "0", "0")) {
	            $field_date = $datetime->MakeDate($field_value);
	            $field_month = $field_date[0]; $field_day = $field_date[1]; $field_year = $field_date[2];
	          } else {
	            $field_month = 0; $field_day = 0; $field_year = 0;
	          }

	          // CONSTRUCT MONTH ARRAY
	          $month_array = Array();
	          $month_array[0] = Array('name' => "[$class_adsandpages[4]]", 'value' => "0", 'selected' => "");
	          for($m=1;$m<=12;$m++) {
	            if($field_month == $m) { $selected = " SELECTED"; } else { $selected = ""; }
	            $month_array[$m] = Array('name' => $datetime->cdate("$month_format", mktime(0, 0, 0, $m, 1, 1990)),
						'value' => $m,
						'selected' => $selected);
	          }
  
	          // CONSTRUCT DAY ARRAY
	          $day_array = Array();
	          $day_array[0] = Array('name' => "[$class_adsandpages[5]]", 'value' => "0", 'selected' => "");
	          for($d=1;$d<=31;$d++) {
	            if($field_day == $d) { $selected = " SELECTED"; } else { $selected = ""; }
	            $day_array[$d] = Array('name' => $datetime->cdate("$day_format", mktime(0, 0, 0, 1, $d, 1990)),
	    					'value' => $d,
	  					'selected' => $selected);
	          }

	          // CONSTRUCT YEAR ARRAY
	          $year_array = Array();
	          $year_count = 1;
	          $current_year = $datetime->cdate("Y", time());
	          $year_array[0] = Array('name' => "[$class_adsandpages[6]]", 'value' => "0", 'selected' => "");
	          for($y=$current_year;$y>=1920;$y--) {
	            if($field_year == $y) { $selected = " SELECTED"; } else { $selected = ""; }
	            $year_array[$year_count] = Array('name' => $y,
	    						'value' => $y,
	    						'selected' => $selected);
	            $year_count++;
	          }

	          // ORDER DATE ARRAYS PROPERLY
	          switch($date_order) {
	            case "mdy": $date_array1 = $month_array; $date_array2 = $day_array; $date_array3 = $year_array; break;
	            case "ymd": $date_array1 = $year_array; $date_array2 = $month_array; $date_array3 = $day_array; break;
	            case "dmy": $date_array1 = $day_array; $date_array2 = $month_array; $date_array3 = $year_array; break;
	          }
		}

	        break;

	    }

	    // SET FIELD ERROR IF ERROR OCCURRED
	    if($is_field_error == 1) { $field_error = $field_info[adsandpagesfield_error]; } else { $field_error = ""; }

	    // SET FIELD ARRAY AND INCREMENT FIELD COUNT
	    if($profile == 0 | ($profile == 1 & $field_value_adsandpages != "")) {
	      $this->adsandpages_fields[] = Array('field_id' => $field_info[adsandpagesfield_id], 
						'field_title' => $field_info[adsandpagesfield_title], 
						'field_desc' => $field_info[adsandpagesfield_desc],
						'field_type' => $field_info[adsandpagesfield_type],
						'field_required' => $field_info[adsandpagesfield_required],
						'field_style' => $field_info[adsandpagesfield_style],
						'field_maxlength' => $field_info[adsandpagesfield_maxlength],
						'field_options' => $field_options,
						'field_value' => $field_value,
						'field_value_adsandpages' => $field_value_adsandpages,
						'field_error' => $field_error,
						'date_array1' => $date_array1,
						'date_array2' => $date_array2,
						'date_array3' => $date_array3);
	    }

	  } 

	} // END adsandpages_fields() METHOD









	// THIS METHOD DELETES A adsandpages
	// INPUT: $adsandpages_id (OPTIONAL) REPRESENTING THE ID OF THE adsandpages TO DELETE
	// OUTPUT:
	function adsandpages_delete($adsandpages_id = 0) {
	  global $database;

	  if($adsandpages_id == 0) { $adsandpages_id = $this->adsandpages_info[adsandpages_id]; }

	  // DELETE adsandpages ALBUM, MEDIA, MEDIA COMMENTS
	  $database->database_query("DELETE FROM se_adsandpagesalbums, se_adsandpagesmedia, se_adsandpagesmediacomments USING se_adsandpagesalbums LEFT JOIN se_adsandpagesmedia ON se_adsandpagesalbums.adsandpagesalbum_id=se_adsandpagesmedia.adsandpagesmedia_adsandpagesalbum_id LEFT JOIN se_adsandpagesmediacomments ON se_adsandpagesmedia.adsandpagesmedia_id=se_adsandpagesmediacomments.adsandpagesmediacomment_adsandpagesmedia_id WHERE se_adsandpagesalbums.adsandpagesalbum_adsandpages_id='$adsandpages_id'");

	  // DELETE ALL MEMBERS
	  $database->database_query("DELETE FROM se_adsandpagesmembers WHERE se_adsandpagesmembers.adsandpagesmember_adsandpages_id='$adsandpages_id'");

	  // DELETE adsandpages VALUES
	  $database->database_query("DELETE FROM se_adsandpagesvalues WHERE se_adsandpagesvalues.adsandpagesvalue_adsandpages_id='$adsandpages_id'");

	  // DELETE adsandpages STYLE
	  $database->database_query("DELETE FROM se_adsandpagesstyles WHERE se_adsandpagesstyles_adsandpages_id='$adsandpages_id'");

	  // DELETE adsandpages ROW
	  $database->database_query("DELETE FROM se_adsandpagess WHERE se_adsandpagess.adsandpages_id='$adsandpages_id'");

	  // DELETE adsandpages COMMENTS
	  $database->database_query("DELETE FROM se_adsandpagescomments WHERE se_adsandpagescomments.adsandpagescomment_adsandpages_id='$adsandpages_id'");

	  // DELETE adsandpages'S FILES
	  if(is_dir($this->adsandpages_dir($adsandpages_id))) {
	    $dir = $this->adsandpages_dir($adsandpages_id);
	  } else {
	    $dir = ".".$this->adsandpages_dir($adsandpages_id);
	  }
	  if($dh = opendir($dir)) {
	    while(($file = readdir($dh)) !== false) {
	      if($file != "." & $file != "..") {
	        unlink($dir.$file);
	      }
	    }
	    closedir($dh);
	  }
	  rmdir($dir);

	} // END adsandpages_delete() METHOD








	// THIS METHOD DELETES SELECTED adsandpagesS
	// INPUT: $start REPRESENTING THE adsandpages TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpagesS TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	//	  $adsandpages_details (OPTIONAL) REPRESENTING A BOOLEAN THAT DETERMINES WHETHER TO RETRIEVE TOTAL MEMBERS, adsandpages LEADER, ETC
	// OUTPUT: AN ARRAY OF adsandpagesS
	function adsandpages_delete_selected($start, $limit, $sort_by = "adsandpages_id DESC", $where = "", $adsandpages_details = 0) {
	  global $database, $user;

	  // BEGIN QUERY
	  $adsandpages_query = "SELECT se_adsandpagess.adsandpages_id";

	  // SELECT RELEVANT adsandpages DETAILS IF NECESSARY
	  if($adsandpages_details == 1) { $adsandpages_query .= ", count(member_table.adsandpagesmember_id) AS num_members, se_users.user_id, se_users.user_username, se_users.user_photo"; }

	  // IF USER ID NOT EMPTY, GET USER AS MEMBER
	  if($this->user_id != 0) { $adsandpages_query .= ", se_adsandpagesmembers.adsandpagesmember_rank"; }

	  // CONTINUE QUERY
	  $adsandpages_query .= " FROM";

	  // IF USER ID NOT EMPTY, SELECT FROM adsandpagesMEMBER TABLE
	  if($this->user_id != 0) { 
	    $adsandpages_query .= " se_adsandpagesmembers LEFT JOIN se_adsandpagess ON se_adsandpagesmembers.adsandpagesmember_adsandpages_id=se_adsandpagess.adsandpages_id "; 
	  } else {
	    $adsandpages_query .= " se_adsandpagess";
	  }

	  // CONTINUE QUERY IF NECESSARY
	  if($adsandpages_details == 1) { $adsandpages_query .= " LEFT JOIN se_adsandpagesmembers AS member_table ON se_adsandpagess.adsandpages_id=member_table.adsandpagesmember_adsandpages_id AND member_table.adsandpagesmember_status='1' AND member_table.adsandpagesmember_approved='1' LEFT JOIN se_users ON se_adsandpagess.adsandpages_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" | $this->user_id != 0) { $adsandpages_query .= " WHERE"; }

	  // IF USER ID NOT EMPTY, MAKE SURE USER IS A MEMBER
	  if($this->user_id != 0) { $adsandpages_query .= " se_adsandpagesmembers.adsandpagesmember_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 & $where != "") { $adsandpages_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $adsandpages_query .= " $where"; }

	  // ADD adsandpages BY, ORDER, AND LIMIT CLAUSE
	  $adsandpages_query .= " adsandpages BY adsandpages_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagess = $database->database_query($adsandpages_query);

	  // GET adsandpagesS INTO AN ARRAY
	  while($adsandpages_info = $database->database_fetch_assoc($adsandpagess)) {
    	    $var = "delete_adsandpages_".$adsandpages_info[adsandpages_id];
	    if($_POST[$var] == 1) { $this->adsandpages_delete($adsandpages_info[adsandpages_id]); }
	  }

	} // END adsandpages_delete_selected() METHOD








	// THIS METHOD UPDATES THE adsandpages'S LAST UPDATE DATE
	// INPUT: 
	// OUTPUT: 
	function adsandpages_lastupdate() {
	  global $database;

	  $database->database_query("UPDATE se_adsandpagess SET adsandpages_dateupdated='".time()."' WHERE adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'");
	  
	} // END adsandpages_lastupdate() METHOD








	// THIS METHOD RETURNS MAXIMUM PRIVACY LEVEL VIEWABLE BY A USER WITH REGARD TO THE CURRENT adsandpages
	// INPUT: $user REPRESENTING A USER OBJECT
	//	  $allowable_privacy (OPTIONAL) REPRESENTING A STRING OF ALLOWABLE PRIVACY SETTINGS
	// OUTPUT: RETURNS THE INTEGER REPRESENTING THE MAXIMUM PRIVACY LEVEL VIEWABLE BY A USER WITH REGARD TO THE CURRENT adsandpages
	function adsandpages_privacy_max($user, $allowable_privacy = "01234567") {
	  global $database;

	  switch(TRUE) {

	    // NOBODY
	    // NO ONE HAS $privacy_level = 7

	    // adsandpages LEADER
	    case($this->adsandpages_info[adsandpages_user_id] == $user->user_info[user_id]):
	      $privacy_level = 6;
	      break;

	    // adsandpages MEMBER
	    case($database->database_num_rows($database->database_query("SELECT adsandpagesmember_id FROM se_adsandpagesmembers WHERE adsandpagesmember_user_id='".$user->user_info[user_id]."' AND adsandpagesmember_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."' AND adsandpagesmember_status='1'")) != 0):
	      $privacy_level = 5;
	      break;
    
	    // adsandpages LEADER'S FRIEND
	    case($database->database_num_rows($database->database_query("SELECT friend_id FROM se_friends WHERE friend_user_id1='".$this->adsandpages_info[adsandpages_user_id]."' AND friend_user_id2='".$user->user_info[user_id]."'")) != 0):
	      $privacy_level = 4;
	      break;

	    // adsandpages MEMBER'S FRIEND
	    case($database->database_num_rows($database->database_query("SELECT se_friends.friend_id FROM se_adsandpagesmembers LEFT JOIN se_friends ON se_adsandpagesmembers.adsandpagesmember_user_id=se_friends.friend_user_id1 AND se_adsandpagesmembers.adsandpagesmember_status='1' WHERE se_adsandpagesmembers.adsandpagesmember_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."' AND se_friends.friend_user_id2='".$user->user_info[user_id]."'")) != 0):
	      $privacy_level = 3;
	      break;

	    // FRIEND OF adsandpages MEMBER'S FRIENDS
	    case($database->database_num_rows($database->database_query("SELECT t2.friend_user_id2 FROM se_adsandpagesmembers LEFT JOIN se_friends AS t1 ON se_adsandpagesmembers.adsandpagesmember_user_id=t1.friend_user_id1 AND se_adsandpagesmembers.adsandpagesmember_status='1' LEFT JOIN se_friends AS t2 ON t1.friend_user_id2=t2.friend_user_id1 WHERE se_adsandpagesmembers.adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' AND t2.friend_user_id2='".$user->user_info[user_id]."'")) != 0):
	      $privacy_level = 2;
	      break;
    
	    // REGISTERED USER
	    case($user->user_exists != 0):
	      $privacy_level = 1;
	      break;
    
	    // EVERYONE (DEFAULT)
	    default:	
	      $privacy_level = 0;
	      break;

	  }

	  // MAKE SURE PRIVACY LEVEL IS ALLOWED BY ADMIN
	  $allowable_privacy = str_split($allowable_privacy);
	  rsort($allowable_privacy);
	  if($privacy_level >= $allowable_privacy[0]) {
	    $privacy_level = 7;
	  }

	  // RETURN PRIVACY LEVEL
	  return $privacy_level;
	  
	} // END adsandpages_privacy_max() METHOD








	// THIS METHOD RETURNS THE TOTAL NUMBER OF MEMBERS IN A adsandpages
	// INPUT: $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	//	  $member_details (OPTIONAL) REPRESENTING WHETHER TO JOIN TO THE USER TABLE FOR SEARCH PURPOSES
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF adsandpages MEMBERS
	function adsandpages_member_total($where = "", $member_details = 0) {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagesmember_query = "SELECT se_adsandpagesmembers.adsandpagesmember_id FROM se_adsandpagesmembers";

	  // JOIN TO USER TABLE IF NECESSARY
	  if($member_details == 1) { $adsandpagesmember_query .= " LEFT JOIN se_users ON se_adsandpagesmembers.adsandpagesmember_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $where != "") { $adsandpagesmember_query .= " WHERE"; }

	  // IF adsandpages ID IS SET
	  if($this->adsandpages_exists != 0) { $adsandpagesmember_query .= " se_adsandpagesmembers.adsandpagesmember_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $where != "") { $adsandpagesmember_query .= " AND"; }  

	  // ADD REST OF WHERE CLAUSE
	  if($where != "") { $adsandpagesmember_query .= " $where"; }

	  // RUN QUERY
	  $adsandpagesmember_total = $database->database_num_rows($database->database_query($adsandpagesmember_query));
	  return $adsandpagesmember_total;

	} // END adsandpages_member_total() METHOD








	// THIS METHOD RETURNS AN ARRAY OF adsandpages MEMBERS
	// INPUT: $start REPRESENTING THE adsandpages MEMBER TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpages MEMBERS TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY OF adsandpages MEMBERS
	function adsandpages_member_list($start, $limit, $sort_by = "adsandpagesmember_id DESC", $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagesmember_query = "SELECT se_adsandpagesmembers.*, se_users.user_id, se_users.user_username, se_users.user_photo, se_users.user_dateupdated, se_users.user_lastlogindate, se_users.user_signupdate FROM se_adsandpagesmembers LEFT JOIN se_users ON se_adsandpagesmembers.adsandpagesmember_user_id=se_users.user_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $where != "") { $adsandpagesmember_query .= " WHERE"; }

	  // IF adsandpages ID IS SET
	  if($this->adsandpages_exists != 0) { $adsandpagesmember_query .= " se_adsandpagesmembers.adsandpagesmember_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $where != "") { $adsandpagesmember_query .= " AND"; }  

	  // ADD REST OF WHERE CLAUSE
	  if($where != "") { $adsandpagesmember_query .= " $where"; }

	  // ADD ORDER, AND LIMIT CLAUSE
	  $adsandpagesmember_query .= " ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagesmembers = $database->database_query($adsandpagesmember_query);

	  // GET adsandpages MEMBERS INTO AN ARRAY
	  $adsandpagesmember_array = Array();
	  while($adsandpagesmember_info = $database->database_fetch_assoc($adsandpagesmembers)) {

	    // CREATE OBJECT FOR MEMBER
	    $member = new se_user();
	    $member->user_exists = 1;
	    $member->user_info[user_id] = $adsandpagesmember_info[user_id];
	    $member->user_info[user_username] = $adsandpagesmember_info[user_username];
	    $member->user_info[user_photo] = $adsandpagesmember_info[user_photo];
	    $member->user_info[user_dateupdated] = $adsandpagesmember_info[user_dateupdated];
	    $member->user_info[user_lastlogindate] = $adsandpagesmember_info[user_lastlogindate];
	    $member->user_info[user_signupdate] = $adsandpagesmember_info[user_signupdate];

	    // SET adsandpages ARRAY
	    $adsandpagesmember_array[] = Array('adsandpagesmember_id' => $adsandpagesmember_info[adsandpagesmember_id],
					'adsandpagesmember_rank' => $adsandpagesmember_info[adsandpagesmember_rank],
					'adsandpagesmember_title' => $adsandpagesmember_info[adsandpagesmember_title],
					'member' => $member);
	  }

	  // RETURN ARRAY
	  return $adsandpagesmember_array;

	} // END adsandpages_member_list() METHOD








	// THIS METHOD RETURNS THE PATH TO THE GIVEN adsandpages'S DIRECTORY
	// INPUT: $adsandpages_id (OPTIONAL) REPRESENTING A adsandpages'S adsandpages_ID
	// OUTPUT: A STRING REPRESENTING THE RELATIVE PATH TO THE adsandpages'S DIRECTORY
	function adsandpages_dir($adsandpages_id = 0) {

	  if($adsandpages_id == 0 & $this->adsandpages_exists) { $adsandpages_id = $this->adsandpages_info[adsandpages_id]; }

	  $subdir = $adsandpages_id+999-(($adsandpages_id-1)%1000);
	  $adsandpagesdir = "./uploads_adsandpages/$subdir/$adsandpages_id/";
	  return $adsandpagesdir;

	} // END adsandpages_dir() METHOD








	// THIS METHOD OUTPUTS THE PATH TO THE adsandpages'S PHOTO OR THE GIVEN NOPHOTO IMAGE
	// INPUT: $nophoto_image (OPTIONAL) REPRESENTING THE PATH TO AN IMAGE TO OUTPUT IF NO PHOTO EXISTS
	// OUTPUT: A STRING CONTAINING THE PATH TO THE adsandpages'S PHOTO
	function adsandpages_photo($nophoto_image = "") {

	  $adsandpages_photo = $this->adsandpages_dir($this->adsandpages_info[adsandpages_id]).$this->adsandpages_info[adsandpages_photo];
	  if(!file_exists($adsandpages_photo) | $this->adsandpages_info[adsandpages_photo] == "") { $adsandpages_photo = $nophoto_image; }
	  return $adsandpages_photo;
	  
	} // END adsandpages_photo() METHOD








	// THIS METHOD UPLOADS A adsandpages PHOTO ACCORDING TO SPECIFICATIONS AND RETURNS adsandpages PHOTO
	// INPUT: $photo_name REPRESENTING THE NAME OF THE FILE INPUT
	// OUTPUT: 
	function adsandpages_photo_upload($photo_name) {
	  global $database, $url;

	  // SET KEY VARIABLES
	  $file_maxsize = "4194304";
	  $file_exts = explode(",", str_replace(" ", "", strtolower($this->adsandpagesowner_level_info[level_adsandpages_photo_exts])));
	  $file_types = explode(",", str_replace(" ", "", strtolower("image/jpeg, image/jpg, image/jpe, image/pjpeg, image/pjpg, image/x-jpeg, x-jpg, image/gif, image/x-gif, image/png, image/x-png")));
	  $file_maxwidth = $this->adsandpagesowner_level_info[level_adsandpages_photo_width];
	  $file_maxheight = $this->adsandpagesowner_level_info[level_adsandpages_photo_height];
	  $photo_newname = "0_".rand(1000, 9999).".jpg";
	  $file_dest = $this->adsandpages_dir($this->adsandpages_info[adsandpages_id]).$photo_newname;

	  $new_photo = new se_upload();
	  $new_photo->new_upload($photo_name, $file_maxsize, $file_exts, $file_types, $file_maxwidth, $file_maxheight);

	  // UPLOAD AND RESIZE PHOTO IF NO ERROR
	  if($new_photo->is_error == 0) {

	    // DELETE OLD AVATAR IF EXISTS
	    $this->adsandpages_photo_delete();

	    // CHECK IF IMAGE RESIZING IS AVAILABLE, OTHERWISE MOVE UPLOADED IMAGE
	    if($new_photo->is_image == 1) {
	      $new_photo->upload_photo($file_dest);
	    } else {
	      $new_photo->upload_file($file_dest);
	    }

	    // UPDATE adsandpages INFO WITH IMAGE IF STILL NO ERROR
	    if($new_photo->is_error == 0) {
	      $database->database_query("UPDATE se_adsandpagess SET adsandpages_photo='$photo_newname' WHERE adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'");
	      $this->adsandpages_info[adsandpages_photo] = $photo_newname;
	    }
	  }
	
	  $this->is_error = $new_photo->is_error;
	  $this->error_message = $new_photo->error_message;
	  
	} // END adsandpages_photo_upload() METHOD








	// THIS METHOD DELETES A adsandpages PHOTO
	// INPUT: 
	// OUTPUT: 
	function adsandpages_photo_delete() {
	  global $database;
	  $adsandpages_photo = $this->adsandpages_photo();
	  if($adsandpages_photo != "") {
	    unlink($adsandpages_photo);
	    $database->database_query("UPDATE se_adsandpagess SET adsandpages_photo='' WHERE adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'");
	    $this->adsandpages_info[adsandpages_photo] = "";
	  }
	} // END adsandpages_photo_delete() METHOD








	// THIS METHOD UPLOADS MEDIA TO A adsandpages ALBUM
	// INPUT: $file_name REPRESENTING THE NAME OF THE FILE INPUT
	//	  $adsandpagesalbum_id REPRESENTING THE ID OF THE adsandpages ALBUM TO UPLOAD THE MEDIA TO
	//	  $space_left REPRESENTING THE AMOUNT OF SPACE LEFT
	// OUTPUT:
	function adsandpages_media_upload($file_name, $adsandpagesalbum_id, &$space_left) {
	  global $class_adsandpages, $database, $url;

	  // SET KEY VARIABLES
	  $file_maxsize = $this->adsandpagesowner_level_info[level_adsandpages_album_maxsize];
	  $file_exts = explode(",", str_replace(" ", "", strtolower($this->adsandpagesowner_level_info[level_adsandpages_album_exts])));
	  $file_types = explode(",", str_replace(" ", "", strtolower($this->adsandpagesowner_level_info[level_adsandpages_album_mimes])));
	  $file_maxwidth = $this->adsandpagesowner_level_info[level_adsandpages_album_width];
	  $file_maxheight = $this->adsandpagesowner_level_info[level_adsandpages_album_height];

	  $new_media = new se_upload();
	  $new_media->new_upload($file_name, $file_maxsize, $file_exts, $file_types, $file_maxwidth, $file_maxheight);

	  // UPLOAD AND RESIZE PHOTO IF NO ERROR
	  if($new_media->is_error == 0) {

	    // INSERT ROW INTO MEDIA TABLE
	    $database->database_query("INSERT INTO se_adsandpagesmedia (
							adsandpagesmedia_adsandpagesalbum_id,
							adsandpagesmedia_date
							) VALUES (
							'$adsandpagesalbum_id',
							'".time()."'
							)");
	    $adsandpagesmedia_id = $database->database_insert_id();

	    // CHECK IF IMAGE RESIZING IS AVAILABLE, OTHERWISE MOVE UPLOADED IMAGE
	    if($new_media->is_image == 1) {
	      $file_dest = $this->adsandpages_dir($this->adsandpages_info[adsandpages_id]).$adsandpagesmedia_id.".jpg";
	      $thumb_dest = $this->adsandpages_dir($this->adsandpages_info[adsandpages_id]).$adsandpagesmedia_id."_thumb.jpg";
	      $new_media->upload_photo($file_dest);
	      $new_media->upload_photo($thumb_dest, 200, 200);
	      $file_ext = "jpg";
	      $file_filesize = filesize($file_dest);
	    } else {
	      $file_dest = $this->adsandpages_dir($this->adsandpages_info[adsandpages_id]).$adsandpagesmedia_id.".".$new_media->file_ext;
	      $new_media->upload_file($file_dest);
	      $file_ext = $new_media->file_ext;
	      $file_filesize = filesize($file_dest);
	    }

	    // CHECK SPACE LEFT
	    if($file_filesize > $space_left) {
	      $new_media->is_error = 1;
	      $new_media->error_message = $class_adsandpages[3].$_FILES[$file_name]['name'];
	    } else {
	      $space_left = $space_left-$file_filesize;
	    }

	    // DELETE FROM DATABASE IF ERROR
	    if($new_media->is_error != 0) {
	      $database->database_query("DELETE FROM se_adsandpagesmedia WHERE adsandpagesmedia_id='$adsandpagesmedia_id' AND adsandpagesmedia_adsandpagesalbum_id='$adsandpagesalbum_id'");
	      @unlink($file_dest);

	    // UPDATE ROW IF NO ERROR
	    } else {
	      $database->database_query("UPDATE se_adsandpagesmedia SET adsandpagesmedia_ext='$file_ext', adsandpagesmedia_filesize='$file_filesize' WHERE adsandpagesmedia_id='$adsandpagesmedia_id' AND adsandpagesmedia_adsandpagesalbum_id='$adsandpagesalbum_id'");
	    }
	  }
	
	  // RETURN FILE STATS
	  $file = Array('is_error' => $new_media->is_error,
			'error_message' => $new_media->error_message,
			'adsandpagesmedia_id' => $adsandpagesmedia_id,
			'adsandpagesmedia_ext' => $file_ext,
			'adsandpagesmedia_filesize' => $file_filesize);
	  return $file;

	} // END adsandpages_media_upload() METHOD








	// THIS METHOD RETURNS THE SPACE USED
	// INPUT: $adsandpagesalbum_id (OPTIONAL) REPRESENTING THE ID OF THE ALBUM TO CALCULATE
	// OUTPUT: AN INTEGER REPRESENTING THE SPACE USED
	function adsandpages_media_space($adsandpagesalbum_id = 0) {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagesmedia_query = "SELECT sum(se_adsandpagesmedia.adsandpagesmedia_filesize) AS total_space";
	
	  // CONTINUE QUERY
	  $adsandpagesmedia_query .= " FROM se_adsandpagesalbums LEFT JOIN se_adsandpagesmedia ON se_adsandpagesalbums.adsandpagesalbum_id=se_adsandpagesmedia.adsandpagesmedia_adsandpagesalbum_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $adsandpagesalbum_id != 0) { $adsandpagesmedia_query .= " WHERE"; }

	  // IF adsandpages EXISTS, SPECIFY adsandpages ID
	  if($this->adsandpages_exists != 0) { $adsandpagesmedia_query .= " se_adsandpagesalbums.adsandpagesalbum_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $adsandpagesalbum_id != 0) { $adsandpagesmedia_query .= " AND"; }

	  // SPECIFY ALBUM ID IF NECESSARY
	  if($adsandpagesalbum_id != 0) { $adsandpagesmedia_query .= " se_adsandpagesalbums.adsandpagesalbum_id='$adsandpagesalbum_id'"; }

	  // GET AND RETURN TOTAL SPACE USED
	  $space_info = $database->database_fetch_assoc($database->database_query($adsandpagesmedia_query));
	  return $space_info[total_space];

	} // END adsandpages_media_space() METHOD








	// THIS METHOD RETURNS THE NUMBER OF adsandpages MEDIA
	// INPUT: $adsandpagesalbum_id (OPTIONAL) REPRESENTING THE ID OF THE adsandpages ALBUM TO CALCULATE
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF FILES
	function adsandpages_media_total($adsandpagesalbum_id = 0) {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagesmedia_query = "SELECT count(se_adsandpagesmedia.adsandpagesmedia_id) AS total_files";
	
	  // CONTINUE QUERY
	  $adsandpagesmedia_query .= " FROM se_adsandpagesalbums LEFT JOIN se_adsandpagesmedia ON se_adsandpagesalbums.adsandpagesalbum_id=se_adsandpagesmedia.adsandpagesmedia_adsandpagesalbum_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $adsandpagesalbum_id != 0) { $adsandpagesmedia_query .= " WHERE"; }

	  // IF adsandpages EXISTS, SPECIFY adsandpages ID
	  if($this->adsandpages_exists != 0) { $adsandpagesmedia_query .= " se_adsandpagesalbums.adsandpagesalbum_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $adsandpagesalbum_id != 0) { $adsandpagesmedia_query .= " AND"; }

	  // SPECIFY ALBUM ID IF NECESSARY
	  if($adsandpagesalbum_id != 0) { $adsandpagesmedia_query .= " se_adsandpagesalbums.adsandpagesalbum_id='$adsandpagesalbum_id'"; }

	  // GET AND RETURN TOTAL FILES
	  $file_info = $database->database_fetch_assoc($database->database_query($adsandpagesmedia_query));
	  return $file_info[total_files];

	} // END adsandpages_media_total() METHOD








	// THIS METHOD RETURNS AN ARRAY OF adsandpages MEDIA
	// INPUT: $start REPRESENTING THE adsandpages MEDIA TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpages MEDIA TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY OF adsandpages MEDIA
	function adsandpages_media_list($start, $limit, $sort_by = "adsandpagesmedia_id DESC", $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagesmedia_query = "SELECT se_adsandpagesmedia.*, se_adsandpagesalbums.adsandpagesalbum_id, se_adsandpagesalbums.adsandpagesalbum_adsandpages_id, se_adsandpagesalbums.adsandpagesalbum_title, count(se_adsandpagesmediacomments.adsandpagesmediacomment_id) AS total_comments";
	
	  // CONTINUE QUERY
	  $adsandpagesmedia_query .= " FROM se_adsandpagesmedia LEFT JOIN se_adsandpagesmediacomments ON se_adsandpagesmediacomments.adsandpagesmediacomment_adsandpagesmedia_id=se_adsandpagesmedia.adsandpagesmedia_id LEFT JOIN se_adsandpagesalbums ON se_adsandpagesalbums.adsandpagesalbum_id=se_adsandpagesmedia.adsandpagesmedia_adsandpagesalbum_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $where != "") { $adsandpagesmedia_query .= " WHERE"; }

	  // IF adsandpages EXISTS, SPECIFY adsandpages ID
	  if($this->adsandpages_exists != 0) { $adsandpagesmedia_query .= " se_adsandpagesalbums.adsandpagesalbum_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $where != "") { $adsandpagesmedia_query .= " AND"; }

	  // ADD ADDITIONAL WHERE CLAUSE
	  if($where != "") { $adsandpagesmedia_query .= " $where"; }

	  // ADD adsandpages BY, ORDER, AND LIMIT CLAUSE
	  $adsandpagesmedia_query .= " adsandpages BY adsandpagesmedia_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagesmedia = $database->database_query($adsandpagesmedia_query);

	  // GET adsandpages MEDIA INTO AN ARRAY
	  $adsandpagesmedia_array = Array();
	  while($adsandpagesmedia_info = $database->database_fetch_assoc($adsandpagesmedia)) {

	    // CREATE ARRAY OF MEDIA DATA
	    $adsandpagesmedia_array[] = Array('adsandpagesmedia_id' => $adsandpagesmedia_info[adsandpagesmedia_id],
					'adsandpagesmedia_adsandpagesalbum_id' => $adsandpagesmedia_info[adsandpagesmedia_adsandpagesalbum_id],
					'adsandpagesmedia_date' => $adsandpagesmedia_info[adsandpagesmedia_date],
					'adsandpagesmedia_title' => $adsandpagesmedia_info[adsandpagesmedia_title],
					'adsandpagesmedia_desc' => str_replace("<br>", "\r\n", $adsandpagesmedia_info[adsandpagesmedia_desc]),
					'adsandpagesmedia_ext' => $adsandpagesmedia_info[adsandpagesmedia_ext],
					'adsandpagesmedia_filesize' => $adsandpagesmedia_info[adsandpagesmedia_filesize],
					'adsandpagesmedia_comments_total' => $adsandpagesmedia_info[total_comments]);

	  }

	  // RETURN ARRAY
	  return $adsandpagesmedia_array;

	} // END adsandpages_media_list() METHOD








	// THIS METHOD UPDATES adsandpages MEDIA INFORMATION
	// INPUT: $start REPRESENTING THE adsandpages MEDIA TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpages MEDIA TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY CONTAINING ALL THE adsandpages MEDIA ID
	function adsandpages_media_update($start, $limit, $sort_by = "adsandpagesmedia_id DESC", $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagesmedia_query = "SELECT se_adsandpagesmedia.*, se_adsandpagesalbums.adsandpagesalbum_id, se_adsandpagesalbums.adsandpagesalbum_adsandpages_id, se_adsandpagesalbums.adsandpagesalbum_title, count(se_adsandpagesmediacomments.adsandpagesmediacomment_id) AS total_comments";
	
	  // CONTINUE QUERY
	  $adsandpagesmedia_query .= " FROM se_adsandpagesmedia LEFT JOIN se_adsandpagesmediacomments ON se_adsandpagesmediacomments.adsandpagesmediacomment_adsandpagesmedia_id=se_adsandpagesmedia.adsandpagesmedia_id LEFT JOIN se_adsandpagesalbums ON se_adsandpagesalbums.adsandpagesalbum_id=se_adsandpagesmedia.adsandpagesmedia_adsandpagesalbum_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $where != "") { $adsandpagesmedia_query .= " WHERE"; }

	  // IF adsandpages EXISTS, SPECIFY adsandpages ID
	  if($this->adsandpages_exists != 0) { $adsandpagesmedia_query .= " se_adsandpagesalbums.adsandpagesalbum_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $where != "") { $adsandpagesmedia_query .= " AND"; }

	  // ADD ADDITIONAL WHERE CLAUSE
	  if($where != "") { $adsandpagesmedia_query .= " $where"; }

	  // ADD adsandpages BY, ORDER, AND LIMIT CLAUSE
	  $adsandpagesmedia_query .= " adsandpages BY adsandpagesmedia_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagesmedia = $database->database_query($adsandpagesmedia_query);

	  // GET adsandpages MEDIA INTO AN ARRAY
	  $adsandpagesmedia_array = Array();
	  while($adsandpagesmedia_info = $database->database_fetch_assoc($adsandpagesmedia)) {
	    $var1 = "adsandpagesmedia_title_".$adsandpagesmedia_info[adsandpagesmedia_id];
	    $var2 = "adsandpagesmedia_desc_".$adsandpagesmedia_info[adsandpagesmedia_id];
	    $adsandpagesmedia_title = censor($_POST[$var1]);
	    $adsandpagesmedia_desc = censor(str_replace("\r\n", "<br>", $_POST[$var2]));
	    if($adsandpagesmedia_title != $adsandpagesmedia_info[adsandpagesmedia_title] OR $adsandpagesmedia_desc != $adsandpagesmedia_info[adsandpagesmedia_desc]) {
	      $database->database_query("UPDATE se_adsandpagesmedia SET adsandpagesmedia_title='$adsandpagesmedia_title', adsandpagesmedia_desc='$adsandpagesmedia_desc' WHERE adsandpagesmedia_id='$adsandpagesmedia_info[adsandpagesmedia_id]'");
	    }
	    $adsandpagesmedia_array[] = $adsandpagesmedia_info[adsandpagesmedia_id];
	  }

	  return $adsandpagesmedia_array;

	} // END adsandpages_media_update() METHOD








	// THIS METHOD DELETES SELECTED adsandpages MEDIA
	// INPUT: $start REPRESENTING THE adsandpages MEDIA TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpages MEDIA TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT:
	function adsandpages_media_delete($start, $limit, $sort_by = "adsandpagesmedia_id DESC", $where = "") {
	  global $database, $url;

	  // BEGIN QUERY
	  $adsandpagesmedia_query = "SELECT se_adsandpagesmedia.*, se_adsandpagesalbums.adsandpagesalbum_id, se_adsandpagesalbums.adsandpagesalbum_adsandpages_id, se_adsandpagesalbums.adsandpagesalbum_title, count(se_adsandpagesmediacomments.adsandpagesmediacomment_id) AS total_comments";
	
	  // CONTINUE QUERY
	  $adsandpagesmedia_query .= " FROM se_adsandpagesmedia LEFT JOIN se_adsandpagesmediacomments ON se_adsandpagesmediacomments.adsandpagesmediacomment_adsandpagesmedia_id=se_adsandpagesmedia.adsandpagesmedia_id LEFT JOIN se_adsandpagesalbums ON se_adsandpagesalbums.adsandpagesalbum_id=se_adsandpagesmedia.adsandpagesmedia_adsandpagesalbum_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $where != "") { $adsandpagesmedia_query .= " WHERE"; }

	  // IF adsandpages EXISTS, SPECIFY adsandpages ID
	  if($this->adsandpages_exists != 0) { $adsandpagesmedia_query .= " se_adsandpagesalbums.adsandpagesalbum_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $where != "") { $adsandpagesmedia_query .= " AND"; }

	  // ADD ADDITIONAL WHERE CLAUSE
	  if($where != "") { $adsandpagesmedia_query .= " $where"; }

	  // ADD adsandpages BY, ORDER, AND LIMIT CLAUSE
	  $adsandpagesmedia_query .= " adsandpages BY adsandpagesmedia_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagesmedia = $database->database_query($adsandpagesmedia_query);

	  // LOOP OVER adsandpages MEDIA
	  $adsandpagesmedia_delete = "";
	  while($adsandpagesmedia_info = $database->database_fetch_assoc($adsandpagesmedia)) {
	    $var = "delete_adsandpagesmedia_".$adsandpagesmedia_info[adsandpagesmedia_id];
	    if($_POST[$var] == 1) { 
	      if($adsandpagesmedia_delete != "") { $adsandpagesmedia_delete .= " OR "; }
	      $adsandpagesmedia_delete .= "adsandpagesmedia_id='$adsandpagesmedia_info[adsandpagesmedia_id]'";
	      $adsandpagesmedia_path = $this->adsandpages_dir($this->adsandpages_info[adsandpages_id]).$adsandpagesmedia_info[adsandpagesmedia_id].".".$adsandpagesmedia_info[adsandpagesmedia_ext];
	      if(file_exists($adsandpagesmedia_path)) { unlink($adsandpagesmedia_path); }
	      $thumb_path = $this->adsandpages_dir($this->adsandpages_info[adsandpages_id]).$adsandpagesmedia_info[adsandpagesmedia_id]."_thumb.".$adsandpagesmedia_info[adsandpagesmedia_ext];
	      if(file_exists($thumb_path)) { unlink($thumb_path); }
	    }
	  }

	  // IF DELETE CLAUSE IS NOT EMPTY, DELETE adsandpages MEDIA
	  if($adsandpagesmedia_delete != "") { $database->database_query("DELETE FROM se_adsandpagesmedia, se_adsandpagesmediacomments USING se_adsandpagesmedia LEFT JOIN se_adsandpagesmediacomments ON se_adsandpagesmedia.adsandpagesmedia_id=se_adsandpagesmediacomments.adsandpagesmediacomment_adsandpagesmedia_id WHERE ($adsandpagesmedia_delete)"); }

	} // END adsandpages_media_delete() METHOD








	// THIS METHOD RETURNS AN ARRAY OF adsandpages TOPICS
	// INPUT: $start REPRESENTING THE adsandpages TOPIC TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpages TOPICS TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY OF adsandpages TOPICS
	function adsandpages_topic_list($start, $limit, $sort_by = "adsandpagestopic_date DESC", $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagestopic_query = "SELECT se_adsandpagestopics.*, count(se_adsandpagesposts.adsandpagespost_id) AS total_posts";
	
	  // CONTINUE QUERY
	  $adsandpagestopic_query .= " FROM se_adsandpagestopics LEFT JOIN se_adsandpagesposts ON se_adsandpagesposts.adsandpagespost_adsandpagestopic_id=se_adsandpagestopics.adsandpagestopic_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $where != "") { $adsandpagestopic_query .= " WHERE"; }

	  // IF adsandpages EXISTS, SPECIFY adsandpages ID
	  if($this->adsandpages_exists != 0) { $adsandpagestopic_query .= " se_adsandpagestopics.adsandpagestopic_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $where != "") { $adsandpagestopic_query .= " AND"; }

	  // ADD ADDITIONAL WHERE CLAUSE
	  if($where != "") { $adsandpagestopic_query .= " $where"; }

	  // ADD adsandpages BY, ORDER, AND LIMIT CLAUSE
	  $adsandpagestopic_query .= " adsandpages BY adsandpagestopic_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagestopics = $database->database_query($adsandpagestopic_query);

	  // GET adsandpages TOPICS INTO AN ARRAY
	  $adsandpagestopic_array = Array();
	  while($adsandpagestopic_info = $database->database_fetch_assoc($adsandpagestopics)) {

	    // CREATE ARRAY OF TOPIC DATA
	    $adsandpagestopic_array[] = Array('adsandpagestopic_id' => $adsandpagestopic_info[adsandpagestopic_id],
					'adsandpagestopic_adsandpages_id' => $adsandpagestopic_info[adsandpagestopic_adsandpages_id],
					'adsandpagestopic_date' => $adsandpagestopic_info[adsandpagestopic_date],
					'adsandpagestopic_subject' => $adsandpagestopic_info[adsandpagestopic_subject],
					'adsandpagestopic_views' => $adsandpagestopic_info[adsandpagestopic_views],
					'adsandpagesposts_total' => $adsandpagestopic_info[total_posts]);

	  }

	  // RETURN ARRAY
	  return $adsandpagestopic_array;

	} // END adsandpages_topic_list() METHOD








	// THIS METHOD RETURNS THE NUMBER OF adsandpages TOPICS
	// INPUT: $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF TOPICS
	function adsandpages_topic_total($where = "") {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagestopic_query = "SELECT se_adsandpagestopics.*, count(se_adsandpagesposts.adsandpagespost_id) AS total_posts";
	
	  // CONTINUE QUERY
	  $adsandpagestopic_query .= " FROM se_adsandpagestopics LEFT JOIN se_adsandpagesposts ON se_adsandpagesposts.adsandpagespost_adsandpagestopic_id=se_adsandpagestopics.adsandpagestopic_id";

	  // ADD WHERE IF NECESSARY
	  if($this->adsandpages_exists != 0 | $where != "") { $adsandpagestopic_query .= " WHERE"; }

	  // IF adsandpages EXISTS, SPECIFY adsandpages ID
	  if($this->adsandpages_exists != 0) { $adsandpagestopic_query .= " se_adsandpagestopics.adsandpagestopic_adsandpages_id='".$this->adsandpages_info[adsandpages_id]."'"; }

	  // ADD AND IF NECESSARY
	  if($this->adsandpages_exists != 0 & $where != "") { $adsandpagestopic_query .= " AND"; }

	  // ADD ADDITIONAL WHERE CLAUSE
	  if($where != "") { $adsandpagestopic_query .= " $where"; }

	  // ADD adsandpages BY, ORDER, AND LIMIT CLAUSE
	  $adsandpagestopic_query .= " adsandpages BY adsandpagestopic_id";

	  // RUN QUERY
	  $total_topics = $database->database_num_rows($database->database_query($adsandpagestopic_query));

	  // RETURN TOTAL TOPICS
	  return $total_topics;

	} // END adsandpages_topic_total() METHOD








	// THIS METHOD RETURNS AN ARRAY OF adsandpages POSTS
	// INPUT: $start REPRESENTING THE adsandpages POST TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF adsandpages POSTS TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY OF adsandpages POSTS
	function adsandpages_post_list($start, $limit, $sort_by = "adsandpagespost_date DESC", $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagespost_query = "SELECT se_adsandpagesposts.*, se_users.user_id, se_users.user_username, se_users.user_photo";
	
	  // CONTINUE QUERY
	  $adsandpagespost_query .= " FROM se_adsandpagesposts LEFT JOIN se_users ON se_adsandpagesposts.adsandpagespost_authoruser_id=se_users.user_id";

	  // ADD WHERE IF NECESSARY
	  if($where != "") { $adsandpagespost_query .= " WHERE $where"; }

	  // ADD ORDER, AND LIMIT CLAUSE
	  $adsandpagespost_query .= " ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $adsandpagesposts = $database->database_query($adsandpagespost_query);

	  // GET adsandpages POSTS INTO AN ARRAY
	  $adsandpagespost_array = Array();
	  while($adsandpagespost_info = $database->database_fetch_assoc($adsandpagesposts)) {

	    // CREATE AN OBJECT FOR AUTHOR
	    $author = new se_user();
	    $author->user_info[user_id] = $adsandpagespost_info[user_id];
	    $author->user_info[user_username] = $adsandpagespost_info[user_username];
	    $author->user_info[user_photo] = $adsandpagespost_info[user_photo];

	    // CREATE ARRAY OF POST DATA
	    $adsandpagespost_array[] = Array('adsandpagespost_id' => $adsandpagespost_info[adsandpagespost_id],
					'adsandpagespost_date' => $adsandpagespost_info[adsandpagespost_date],
					'adsandpagespost_body' => $adsandpagespost_info[adsandpagespost_body],
					'adsandpagespost_author' => $author);

	  }

	  // RETURN ARRAY
	  return $adsandpagespost_array;

	} // END adsandpages_post_list() METHOD








	// THIS METHOD RETURNS THE NUMBER OF adsandpages POSTS
	// INPUT: $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF POSTS
	function adsandpages_post_total($where = "") {
	  global $database;

	  // BEGIN QUERY
	  $adsandpagespost_query = "SELECT se_adsandpagesposts.adsandpagespost_id, se_users.user_id";
	
	  // CONTINUE QUERY
	  $adsandpagespost_query .= " FROM se_adsandpagesposts LEFT JOIN se_users ON se_adsandpagesposts.adsandpagespost_authoruser_id=se_users.user_id";

	  // ADD WHERE IF NECESSARY
	  if($where != "") { $adsandpagespost_query .= " WHERE $where"; }

	  // RUN QUERY
	  $total_posts = $database->database_num_rows($database->database_query($adsandpagespost_query));

	  // RETURN TOTAL POSTS
	  return $total_posts;

	} // END adsandpages_post_total() METHOD

}
?>