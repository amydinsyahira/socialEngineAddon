<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE adsandpages LANGUAGE FILE
include "./lang/lang_".$global_lang."_adsandpages.php";

// INCLUDE adsandpages CLASS FILE
include "./include/class_adsandpages.php";

// INCLUDE adsandpages FUNCTION FILE
include "./include/functions_adsandpages.php";

?>