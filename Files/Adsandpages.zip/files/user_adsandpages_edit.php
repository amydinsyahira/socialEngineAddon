<?
$page = "user_adsandpages_edit";
include "header.php";

if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['justadded'])) { $justadded = $_POST['justadded']; } elseif(isset($_GET['justadded'])) { $justadded = $_GET['justadded']; } else { $justadded = ""; }


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == 0 | $adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }


// SET ERROR VARIABLES
$is_error = 0;
$result = 0;
$error_message = "";


// CHECK FOR ADMIN ALLOWANCE OF PHOTO
if($adsandpages->adsandpagesowner_level_info[level_adsandpages_photo] == 0 & ($task == "remove" | $task == "upload")) { $task = "main"; }


// DELETE PHOTO
if($task == "remove") { $adsandpages->adsandpages_photo_delete(); $adsandpages->adsandpages_lastupdate(); }

// UPLOAD PHOTO
if($task == "upload") {
  $adsandpages->adsandpages_photo_upload("photo");
  $is_error = $adsandpages->is_error;
  $error_message = $adsandpages->error_message;
  if($is_error == 0) { $adsandpages->adsandpages_lastupdate(); }
}



// RETRIEVE AND/OR VALIDATE adsandpages FIELDS
if($task == "dosave") { $validate = 1; } else { $validate = 0; }
$adsandpages->adsandpages_fields($validate, 0);
if($validate == 1) { $is_error = $adsandpages->is_error; $error_message = $adsandpages->error_message; }






if($task == "dosave") {
  // GET BASIC adsandpages INFO
  $adsandpages_title = censor($_POST['adsandpages_title']);
  $adsandpages_desc = censor(str_replace("\r\n", "<br>", $_POST['adsandpages_desc']));
  $adsandpagescat_id = $_POST['adsandpagescat_id'];
  $subadsandpagescat_id = $_POST['subadsandpagescat_id'];
  $adsandpages_search = $_POST['adsandpages_search'];
  $adsandpages_privacy = $_POST['adsandpages_privacy'];
  $adsandpages_comments = $_POST['adsandpages_comments'];
  $adsandpages_discussion = $_POST['adsandpages_discussion'];
  $adsandpages_approval = $_POST['adsandpages_approval'];

  // CHECK TO MAKE SURE TITLE HAS BEEN ENTERED
  if(str_replace(" ", "", $adsandpages_title) == "") {
    $is_error = 1;
    $error_message = $user_adsandpages_edit[8];
  }

  // CHECK THAT PRIVACY IS NOT BLANK
  if($adsandpages_privacy == "") { $adsandpages_privacy = true_privacy(0, $adsandpages->adsandpagesowner_level_info[level_adsandpages_privacy]); }
  if($adsandpages_comments == "") { $adsandpages_comments = true_privacy(0, $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]); }
  if($adsandpages_discussion == "") { $adsandpages_discussion = true_privacy(0, $adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion]); }

  // CHECK THAT SEARCH IS NOT BLANK
  if($adsandpages->adsandpagesowner_level_info[level_adsandpages_search] == 0) { $adsandpages_search = 1; }

  // CHECK THAT APPROVAL IS NOT BLANK
  if($adsandpages->adsandpagesowner_level_info[level_adsandpages_approval] == 0) { $adsandpages_approval = 0; }

  // IF NO ERROR, SAVE adsandpages
  if($is_error == 0) {
    if($subadsandpagescat_id != 0) { $new_adsandpagescat_id = $subadsandpagescat_id; } else { $new_adsandpagescat_id = $adsandpagescat_id; }

    // UPDATE adsandpages VALUES
    $adsandpagesvalue_query = "UPDATE se_adsandpagesvalues SET ".$adsandpages->adsandpages_field_query." WHERE adsandpagesvalue_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'";
    $database->database_query($adsandpagesvalue_query);

    // IF NEW MEMBER APPROVAL SETTING IS CHANGED TO 0, APPROVE ALL WAITING MEMBERS
    if($adsandpages_approval == 0) {
      $database->database_query("UPDATE se_adsandpagesmembers SET adsandpagesmember_status='1', adsandpagesmember_approved='1' WHERE adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' AND adsandpagesmember_approved='0'");
    }

    // UPDATE adsandpages
    $database->database_query("UPDATE se_adsandpagess SET adsandpages_title='$adsandpages_title', adsandpages_adsandpagescat_id='$new_adsandpagescat_id', adsandpages_desc='$adsandpages_desc', adsandpages_search='$adsandpages_search', adsandpages_privacy='$adsandpages_privacy', adsandpages_comments='$adsandpages_comments', adsandpages_discussion='$adsandpages_discussion', adsandpages_approval='$adsandpages_approval' WHERE adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
    $database->database_query("UPDATE se_adsandpagesalbums SET adsandpagesalbum_privacy='$adsandpages_privacy', adsandpagesalbum_comments='$adsandpages_comments', adsandpagesalbum_search='$adsandpages_search' WHERE adsandpagesalbum_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");

    // RESET RESULTS
    $adsandpages->adsandpages_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_adsandpagess WHERE adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'"));
    $adsandpages->adsandpagesvalue_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_adsandpagesvalues WHERE adsandpagesvalue_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'"));

    // SET RESULT MESSAGE
    $result = 1;

    $adsandpages->adsandpages_lastupdate();
  }




} else {
  $adsandpages_title = $adsandpages->adsandpages_info[adsandpages_title];
  $adsandpages_desc = str_replace("<br>", "\r\n", $adsandpages->adsandpages_info[adsandpages_desc]);
  $adsandpages_approval = $adsandpages->adsandpages_info[adsandpages_approval];
  $adsandpages_search = $adsandpages->adsandpages_info[adsandpages_search];
  $adsandpages_privacy = $adsandpages->adsandpages_info[adsandpages_privacy];
  $adsandpages_comments = $adsandpages->adsandpages_info[adsandpages_comments];
  $adsandpages_discussion = $adsandpages->adsandpages_info[adsandpages_discussion];
  if($adsandpages->adsandpages_info[adsandpages_adsandpagescat_id] == 0) {
    $adsandpagescat_id = 0;
    $subadsandpagescat_id = 0;
  } else {
    $adsandpagescat = $database->database_fetch_assoc($database->database_query("SELECT adsandpagescat_id, adsandpagescat_dependency FROM se_adsandpagescats WHERE adsandpagescat_id='".$adsandpages->adsandpages_info[adsandpages_adsandpagescat_id]."'"));
    if($adsandpagescat[adsandpagescat_dependency] == 0) {
      $adsandpagescat_id = $adsandpagescat[adsandpagescat_id];
      $subadsandpagescat_id = "0";
    } else {
      $parentadsandpagescat = $database->database_fetch_assoc($database->database_query("SELECT adsandpagescat_id FROM se_adsandpagescats WHERE adsandpagescat_id='$adsandpagescat[adsandpagescat_dependency]'"));
      $adsandpagescat_id = $parentadsandpagescat[adsandpagescat_id];
      $subadsandpagescat_id = $adsandpagescat[adsandpagescat_id];
    }
  }
}





// GET adsandpages CATEGORIES
$categories_array = Array();
$categories_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_dependency='0' ORDER BY adsandpagescat_id");
while($category = $database->database_fetch_assoc($categories_query)) {
  // GET DEPENDENT adsandpages CATS
  $dep_categories_query = $database->database_query("SELECT * FROM se_adsandpagescats WHERE adsandpagescat_dependency='$category[adsandpagescat_id]' ORDER BY adsandpagescat_id");
  $dep_adsandpagescat_array = Array();
  while($dep_category = $database->database_fetch_assoc($dep_categories_query)) {
    $dep_adsandpagescat_array[] = Array('subadsandpagescat_id' => $dep_category[adsandpagescat_id],
					'subadsandpagescat_title' => $dep_category[adsandpagescat_title]);
  }

  $categories_array[] = Array('adsandpagescat_id' => $category[adsandpagescat_id],
			       'adsandpagescat_title' => $category[adsandpagescat_title],
			       'subcats' => $dep_adsandpagescat_array);
}




// GET AVAILABLE adsandpages PRIVACY OPTIONS
$privacy_options = Array();
for($p=0;$p<strlen($adsandpages->adsandpagesowner_level_info[level_adsandpages_privacy]);$p++) {
  $privacy_level = substr($adsandpages->adsandpagesowner_level_info[level_adsandpages_privacy], $p, 1);
  if(adsandpages_privacy_levels($privacy_level) != "") {
    $privacy_options[] = Array('privacy_id' => "adsandpages_privacy".$privacy_level,
				'privacy_value' => $privacy_level,
				'privacy_option' => adsandpages_privacy_levels($privacy_level));
  }
}

// GET AVAILABLE adsandpages COMMENT OPTIONS
$comment_options = Array();
for($p=0;$p<strlen($adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]);$p++) {
  $comment_level = substr($adsandpages->adsandpagesowner_level_info[level_adsandpages_comments], $p, 1);
  if(adsandpages_privacy_levels($comment_level) != "") {
    $comment_options[] = Array('comment_id' => "adsandpages_comment".$comment_level,
				'comment_value' => $comment_level,
				'comment_option' => adsandpages_privacy_levels($comment_level));
  }
}



// GET AVAILABLE adsandpages DISCUSSION OPTIONS
$discussion_options = Array();
for($p=0;$p<strlen($adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion]);$p++) {
  $discussion_level = substr($adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion], $p, 1);
  if(adsandpages_privacy_levels($discussion_level) != "") {
    $discussion_options[] = Array('discussion_id' => "adsandpages_discussion".$discussion_level,
				'discussion_value' => $discussion_level,
				'discussion_option' => adsandpages_privacy_levels($discussion_level));
  }
}



// ASSIGN VARIABLES AND SHOW USER EDIT adsandpages PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('justadded', $justadded);
$smarty->assign('error_message', $error_message);
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
$smarty->assign('discussion_options', $discussion_options);
$smarty->assign('fields', $adsandpages->adsandpages_fields);
$smarty->assign('cats', $categories_array);
$smarty->assign('adsandpages_title', $adsandpages_title);
$smarty->assign('adsandpages_desc', $adsandpages_desc);
$smarty->assign('adsandpagescat_id', $adsandpagescat_id);
$smarty->assign('subadsandpagescat_id', $subadsandpagescat_id);
$smarty->assign('adsandpages_approval', $adsandpages_approval);
$smarty->assign('adsandpages_search', $adsandpages_search);
$smarty->assign('adsandpages_privacy', true_privacy($adsandpages_privacy, $adsandpages->adsandpagesowner_level_info[level_adsandpages_privacy]));
$smarty->assign('adsandpages_comments', true_privacy($adsandpages_comments, $adsandpages->adsandpagesowner_level_info[level_adsandpages_comments]));
$smarty->assign('adsandpages_discussion', true_privacy($adsandpages_discussion, $adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion]));
include "footer.php";
?>