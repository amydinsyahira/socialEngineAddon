<?
$page = "user_adsandpages_invites";
include "header.php";

if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// SET INITIAL VARIABLES
$result_accepted = "";
$result_rejected = "";
$adsandpages_title = "";



// ACCEPT INVITATION
if($task == "accept") {
  $adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
  if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages_invites.php"); exit(); }
  $database->database_query("UPDATE se_adsandpagesmembers SET adsandpagesmember_status='1' WHERE adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' AND adsandpagesmember_user_id='".$user->user_info[user_id]."' AND adsandpagesmember_status='0' LIMIT 1");
  $adsandpages_title = $adsandpages->adsandpages_info[adsandpages_title];
  $result_accepted = $user_adsandpages_invites[1];

  // INSERT ACTION
  $adsandpages_title_short = $adsandpages->adsandpages_info[adsandpages_title];
  if(strlen($adsandpages_title_short) > 100) { $adsandpages_title_short = substr($adsandpages_title_short, 0, 97); $adsandpages_title_short .= "..."; }
  $actions->actions_add($user, "joinadsandpages", Array('[username]', '[id]', '[title]'), Array($user->user_info[user_username], $adsandpages->adsandpages_info[adsandpages_id], $adsandpages_title_short));
}


// REJECT INVITATION
if($task == "reject") {
  $adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
  if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages_invites.php"); exit(); }
  $database->database_query("DELETE FROM se_adsandpagesmembers WHERE adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' AND adsandpagesmember_user_id='".$user->user_info[user_id]."' AND adsandpagesmember_status='0' LIMIT 1");
  $adsandpages_title = $adsandpages->adsandpages_info[adsandpages_title];
  $result_rejected = $user_adsandpages_invites[2];
}









// SET VARIABLES AND INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id]);
$sort_by = "se_adsandpagess.adsandpages_id";
$where = "(se_adsandpagesmembers.adsandpagesmember_status='0' AND se_adsandpagesmembers.adsandpagesmember_approved='1')";

// GET TOTAL adsandpagesS
$total_adsandpagess = $adsandpages->adsandpages_total($where);

// GET adsandpagesS ARRAY
$adsandpages_array = $adsandpages->adsandpages_list(0, $total_adsandpagess, $sort_by, $where, 1);


// ASSIGN SMARTY VARIABLES AND DISPLAY adsandpages INVITES PAGE
$smarty->assign('adsandpages_id', $adsandpages_id);
$smarty->assign('adsandpages_title', $adsandpages_title);
$smarty->assign('result_accepted', $result_accepted);
$smarty->assign('result_rejected', $result_rejected);
$smarty->assign('adsandpagess', $adsandpages_array);
$smarty->assign('total_adsandpagess', $total_adsandpagess);
include "footer.php";
?>