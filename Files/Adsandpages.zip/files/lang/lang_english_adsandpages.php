<?
// SET GENERAL VARIABLES, AVAILABLE ON EVERY PAGE
$header_adsandpages[1] = "adsandpagess";
$header_adsandpages[2] = "adsandpagess";

// ASSIGN ALL SMARTY GENERAL adsandpages VARIABLES
reset($header_adsandpages);
while(list($key, $val) = each($header_adsandpages)) {
  $smarty->assign("header_adsandpages".$key, $val);
}



// ASSIGN ALL CLASS/FUNCTION FILE VARIABLES
$functions_adsandpages[1] = "Everyone";
$functions_adsandpages[2] = "All Registered Users";
$functions_adsandpages[3] = "Only Ads and Pages Members, Their Friends, and Their Friends' Friends";
$functions_adsandpages[4] = "Only Ads and Pages Members and Their Friends";
$functions_adsandpages[5] = "Only Ads and Pages Members and adsandpages Leader's Friends";
$functions_adsandpages[6] = "Only Ads and Pages Members";
$functions_adsandpages[7] = "Only Ads and Pages Leader";
$functions_adsandpages[8] = "Nobody";
$functions_adsandpages[9] = "Ads and Pages/Ads and Pages photos";
$functions_adsandpages[10] = "Photo in Ads and Pages: ";
$functions_adsandpages[11] = " new Ads and Pages invite(s)";

$class_adsandpages[1] = "Please ensure you have completed all the required fields.";
$class_adsandpages[2] = "Please ensure you have filled out the fields in the proper format.";
$class_adsandpages[3] = "You do not have enough free space to upload ";
$class_adsandpages[4] = "MONTH";
$class_adsandpages[5] = "DAY";
$class_adsandpages[6] = "YEAR";



// SET LANGUAGE PAGE VARIABLES
switch ($page) {

  case "admin_adsandpages":
	$admin_adsandpages[1] = "General Ads and Pages Settings";
	$admin_adsandpages[2] = "This page contains general Ads and Pages settings that affect your entire social network.";
	$admin_adsandpages[3] = "Your changes have been saved.";
	$admin_adsandpages[4] = "Subject";
	$admin_adsandpages[5] = "Message";
	$admin_adsandpages[6] = "Ads and Pages Invitation Email";
	$admin_adsandpages[7] = "This is the email that gets sent to a user when they are invited to join a adsandpages. For more system emails, please visit the <a href='admin_emails.php'>System Emails</a> page.";
	$admin_adsandpages[8] = "[username] - replaced with the username of the recepient.<br>[adsandpagesname] - replaced with the name of the adsandpages.<br>[link] - replaced with the link to login.";
	$admin_adsandpages[9] = "Save Changes";
	$admin_adsandpages[10] = "Public Permission Defaults";
	$admin_adsandpages[11] = "Select whether or not you want to let the public (visitors that are not logged-in) to view the following sections of your social network. In some cases (such as Profiles, Blogs, and Albums), if you have given them the option, your users will be able to make their pages private even though you have made them publically viewable here. For more permissions settings, please visit the <a href='admin_general.php'>General Settings</a> page.";
	$admin_adsandpages[12] = "Ads and Pages";
	$admin_adsandpages[13] = "Yes, the public can view adsandpagess unless they are made private.";
	$admin_adsandpages[14] = "No, the public cannot view adsandpagess.";
	$admin_adsandpages[15] = "New Ads and Pages Comment Email";
	$admin_adsandpages[16] = "This is the email that gets sent to a user when a new comment is posted about a adsandpages they lead. For more system emails, please visit the <a href='admin_emails.php'>System Emails</a> page.";
	$admin_adsandpages[17] = "[username] - replaced with the username of the recepient.<br>[commenter] - replaced with the name of the user who posted the comment.<br>[adsandpagesname] - replaced with the name of the adsandpages.<br>[link] - replaced with the link to the adsandpages.";
	$admin_adsandpages[18] = "New Ads and Pages Media Comment Email";
	$admin_adsandpages[19] = "This is the email that gets sent to a user when a new comment is posted on one of the photos/files in a adsandpages they lead. For more system emails, please visit the <a href='admin_emails.php'>System Emails</a> page.";
	$admin_adsandpages[20] = "[username] - replaced with the username of the recepient.<br>[commenter] - replaced with the name of the user who posted the comment.<br>[adsandpagesname] - replaced with the name of the adsandpages.<br>[link] - replaced with the link to the photo.";
	$admin_adsandpages[21] = "New Ads and Pages Membership Request Email";
	$admin_adsandpages[22] = "This is the email that gets sent to a user when someone requests membership to a adsandpages they lead. For more system emails, please visit the <a href='admin_emails.php'>System Emails</a> page.";
	$admin_adsandpages[23] = "[username] - replaced with the username of the recepient.<br>[requester] - replaced with the name of the user who is requesting membership.<br>[adsandpagesname] - replaced with the name of the adsandpages.<br>[link] - replaced with the link to login.";
	$admin_adsandpages[24] = "adsandpages Fields";
	$admin_adsandpages[25] = "When a adsandpages is created, the adsandpages creator (owner) will describe the adsandpages by filling in some fields with information about the adsandpages. Add the fields you want to include below. Some examples of adsandpages fields are \"Location\", \"adsandpages Email\", \"Website URL\", etc. Remember that a \"adsandpages Name\" field will always be available and required. Click an arrow next to a field to change the field order.";
	$admin_adsandpages[26] = "There are currently no adsandpages fields.";
	$admin_adsandpages[27] = "Add New adsandpages Field";
	$admin_adsandpages[28] = "adsandpages Categories";
	$admin_adsandpages[29] = "You may want to allow your users to categorize their adsandpagess by subject, location, etc. Categorized adsandpagess make it easier for users to find and join adsandpagess that interest them. If you want to allow adsandpages categories, you can create them (along with subcategories) below.";
	$admin_adsandpages[30] = "Add Category";
	$admin_adsandpages[31] = "Add Subcategory";
	$admin_adsandpages[32] = "Require users to enter validation code when starting or posting in a discussion topic?";
	$admin_adsandpages[33] = "If you have selected Yes, an image containing a random sequence of 6 numbers will be shown to users on the \"start a topic\" and \"post topic reply\" page. Users will be required to enter these numbers into the Verification Code field in order to post their topic/reply. This feature helps prevent users from trying to create discussion topic spam. For this feature to work properly, your server must have the GD Libraries (2.0 or higher) installed and configured to work with PHP. If you are seeing errors, try turning this off. ";
	$admin_adsandpages[34] = "Yes, enable validation code for discussion topics.";
	$admin_adsandpages[35] = "No, disable validation code for discussion topics.";
	break;

case "admin_levels_adsandpagessettings":
	$admin_levels_adsandpagessettings[1] = "User adsandpages Settings";
	$admin_levels_adsandpagessettings[2] = "If you have enabled user adsandpagess, your users will have the option of creating adsandpagess and inviting members. This is an excellent way to encourage user interaction. Use this page to configure your user adsandpages settings.";
	$admin_levels_adsandpagessettings[3] = "Allow User adsandpagess?";
	$admin_levels_adsandpagessettings[4] = "If you have selected YES, your users will have the option of creating and joining adsandpagess. Note that if you switch this from YES to NO, users will lose any current adsandpages memberships they have.";
	$admin_levels_adsandpagessettings[5] = "Yes, users can create adsandpagess.";
	$admin_levels_adsandpagessettings[6] = "No, users cannot create adsandpagess.";
	$admin_levels_adsandpagessettings[7] = "Save Changes";
	$admin_levels_adsandpagessettings[8] = "Your changes have been saved.";
	$admin_levels_adsandpagessettings[9] = "Allow adsandpages Photos?";
	$admin_levels_adsandpagessettings[10] = "If you enable this feature, users will be able to upload a small photo icon when creating or editing a adsandpages. This can be displayed next to the adsandpages name on users' profiles, in search/browse results, etc.";
	$admin_levels_adsandpagessettings[11] = "Yes, users can upload a photo icon when they create/edit a adsandpages.";
	$admin_levels_adsandpagessettings[12] = "No, users can not upload a photo icon when they create/edit a adsandpages.";
	$admin_levels_adsandpagessettings[13] = "If you have selected YES above, please input the maximum dimensions for the adsandpages photos. If your users upload a photo that is larger than these dimensions, the server will attempt to scale them down automatically. This feature requires that your PHP server is compiled with support for the GD Libraries.";
	$admin_levels_adsandpagessettings[14] = "Maximum Width:";
	$admin_levels_adsandpagessettings[15] = "(in pixels, between 1 and 999)";
	$admin_levels_adsandpagessettings[16] = "Maximum Height:";
	$admin_levels_adsandpagessettings[17] = "What file types do you want to allow for adsandpages photos (gif, jpg, jpeg, or png)? Separate file types with commas, i.e. jpg, jpeg, gif, png";
	$admin_levels_adsandpagessettings[18] = "Allowed File Types:";
	$admin_levels_adsandpagessettings[19] = "Allow Member Titles?";
	$admin_levels_adsandpagessettings[20] = "If set to YES, adsandpages owners/officers will be able to give adsandpages members special titles. (e.g. \"President\", \"Vice President\", \"Treasurer\", etc.)";
	$admin_levels_adsandpagessettings[21] = "Yes, allow member titles.";
	$admin_levels_adsandpagessettings[22] = "No, do not allow member titles.";
	$admin_levels_adsandpagessettings[23] = "Allow adsandpages Officers?";
	$admin_levels_adsandpagessettings[24] = "If set to YES, adsandpages owners will be able to promote adsandpages members to \"officers\". Officers have all of the abilities of adsandpages owners, except that they cannot remove the adsandpages owner. Note: If this feature was previously set to YES and you change it to NO, any officers that already exist within adsandpagess will be automatically demoted to members.";
	$admin_levels_adsandpagessettings[25] = "Yes, allow adsandpages officers.";
	$admin_levels_adsandpagessettings[26] = "No, do not allow adsandpages officers.";
	$admin_levels_adsandpagessettings[27] = "Allow Member Approval?";
	$admin_levels_adsandpagessettings[28] = "Do you want to give owners and officers the ability to approve new members? If set to YES, adsandpages owners and officers will be able to turn on the \"members can join by approval only\" feature. This forces prospective members to wait for approval before they can become a adsandpages member.";
	$admin_levels_adsandpagessettings[29] = "Yes, optionally allow the member approval feature.";
	$admin_levels_adsandpagessettings[30] = "No, do not allow the member approval feature.";
	$admin_levels_adsandpagessettings[31] = "Allow custom CSS styles?";
	$admin_levels_adsandpagessettings[32] = "If you enable this feature, your users will be able to customize the colors and fonts of their adsandpagess by altering their CSS styles. ";
	$admin_levels_adsandpagessettings[33] = "Yes, allow custom css.";
	$admin_levels_adsandpagessettings[34] = "No, do not allow custom css.";
	$admin_levels_adsandpagessettings[35] = "adsandpages File Settings";
	$admin_levels_adsandpagessettings[36] = "List the following file extensions that users are allowed to upload. Separate file extensions with commas, for example: jpg, gif, jpeg, png, bmp";
	$admin_levels_adsandpagessettings[37] = "To successfully upload a file, the file must have an allowed filetype extension as well as an allowed MIME type. This prevents users from disguising malicious files with a fake extension. Separate MIME types with commas, for example: image/jpeg, image/gif, image/png, image/bmp";
	$admin_levels_adsandpagessettings[38] = "How much storage space should each adsandpages have to store its files?";
	$admin_levels_adsandpagessettings[39] = "Unlimited";
	$admin_levels_adsandpagessettings[40] = "Enter the maximum filesize for uploaded files in KB. This must be a number between 1 and 204800.";
	$admin_levels_adsandpagessettings[41] = "Enter the maximum width and height (in pixels) for images uploaded to adsandpagess. Images with dimensions outside this range will be sized down accordingly if your server has the GD Libraries installed. Note that unusual image types like BMP, TIFF, RAW, and others may not be resized.";
	$admin_levels_adsandpagessettings[42] = "Maximum Width:";
	$admin_levels_adsandpagessettings[43] = "Maximum Height:";
	$admin_levels_adsandpagessettings[44] = "(in pixels, between 1 and 9999)";
	$admin_levels_adsandpagessettings[45] = "Maximum Allowed adsandpagess";
	$admin_levels_adsandpagessettings[46] = "Enter the maximum number of adsandpagess each user can own. This must be an integer between 1 and 999.";
	$admin_levels_adsandpagessettings[47] = "allowed adsandpagess";
	$admin_levels_adsandpagessettings[48] = "Photo width and height must be integers between 1 and 999.";
	$admin_levels_adsandpagessettings[49] = "Your maximum filesize field must contain an integer between 1 and 204800.";
	$admin_levels_adsandpagessettings[50] = "Your maximum width and height fields must contain integers between 1 and 9999.";
	$admin_levels_adsandpagessettings[51] = "Your maximum allowed albums field must contain an integer between 1 and 999.";
	$admin_levels_adsandpagessettings[52] = "<b>adsandpages Discussion Options</b><br>adsandpages leaders can choose from any of the options checked below when they decide who can create and post in discussion topics in their adsandpagess. If you do not check any options, everyone will be allowed to post discussion topics in adsandpagess.";
	





	$admin_levels_adsandpagessettings[59] = "<b>Search Privacy Options</b><br>If you enable this feature, adsandpages leaders will be able to exclude their adsandpages from search results. Otherwise, all adsandpagess will be included in search results.";
	$admin_levels_adsandpagessettings[60] = "Yes, allow adsandpages leaders to exclude their adsandpagess from search results.";
	$admin_levels_adsandpagessettings[61] = "No, force all adsandpagess to be included in search results.";
	$admin_levels_adsandpagessettings[62] = "adsandpages Privacy Options";
	$admin_levels_adsandpagessettings[63] = "Editing User Level:";
	$admin_levels_adsandpagessettings[64] = "You are currently editing this user level's settings. Remember, these settings only apply to the users that belong to this user level. When you're finished, you can edit the <a href='admin_levels.php'>other levels here</a>.";
	$admin_levels_adsandpagessettings[65] = "<b>Overall adsandpages Privacy</b><br>adsandpages leaders can choose from any of the options checked below when they decide who can view their adsandpagess. If you do not check any options, everyone will be allowed to view adsandpagess.";
	$admin_levels_adsandpagessettings[66] = "<b>adsandpages Comment Options</b><br>adsandpages leaders can choose from any of the options checked below when they decide who can post comments on their adsandpagess. If you do not check any options, everyone will be allowed to post comments on adsandpagess.";
	break;

case "admin_adsandpages_addfield":
	$admin_adsandpages_addfield[1] = "Add adsandpages Information Field";
	$admin_adsandpages_addfield[2] = "Use this page to create a new adsandpages information field. adsandpages information fields are used to collect information about new adsandpagess when users create them.";
	$admin_adsandpages_addfield[3] = "No dependent field";
	$admin_adsandpages_addfield[4] = "Yes, has dependent field";
	$admin_adsandpages_addfield[5] = "Field Title:";
	$admin_adsandpages_addfield[6] = "Custom Error Message:";
	$admin_adsandpages_addfield[7] = "Field Type:";
	$admin_adsandpages_addfield[8] = "Text Field";
	$admin_adsandpages_addfield[9] = "Multi-line Text Area";
	$admin_adsandpages_addfield[10] = "Pull-down Select Box";
	$admin_adsandpages_addfield[11] = "Radio Buttons";
	$admin_adsandpages_addfield[12] = "Inline CSS Style:";
	$admin_adsandpages_addfield[13] = "Field Maxlength:";
	$admin_adsandpages_addfield[14] = "Regex Validation:";
	$admin_adsandpages_addfield[15] = "If you want to force the user to enter data in a certain format,<br>enter the corresponding regular expression above. A preg_match()<br>will be applied when the user enters data. This is optional - if you<br>don't understand or need regular expressions, leave this blank.";

	$admin_adsandpages_addfield[17] = "Options:";
	$admin_adsandpages_addfield[18] = "You must specify at least one option.";
	$admin_adsandpages_addfield[19] = "Label";
	$admin_adsandpages_addfield[20] = "Dependency?";
	$admin_adsandpages_addfield[21] = "Dependent Field Label";
	$admin_adsandpages_addfield[22] = "Add New Option";
	$admin_adsandpages_addfield[23] = "Add Field";
	$admin_adsandpages_addfield[24] = "Cancel";

	$admin_adsandpages_addfield[26] = "You must specify a field type.";
	$admin_adsandpages_addfield[27] = "Please enter both a value and a label for each option.";
	$admin_adsandpages_addfield[28] = "You must enter a title for this field.";
	$admin_adsandpages_addfield[29] = "Field Description:";




	$admin_adsandpages_addfield[34] = "Required:";
	$admin_adsandpages_addfield[35] = "Required";
	$admin_adsandpages_addfield[36] = "Not Required";
	$admin_adsandpages_addfield[37] = "Date Field";
	break;

case "admin_adsandpages_editdepfield":
	$admin_adsandpages_editdepfield[1] = "Edit Dependent adsandpages Information Field";
	$admin_adsandpages_editdepfield[2] = "Complete this form to edit this dependent field.";
	$admin_adsandpages_editdepfield[3] = "Field Label:";
	$admin_adsandpages_editdepfield[4] = "Inline CSS Style:";




	$admin_adsandpages_editdepfield[9] = "Regex Validation:";
	$admin_adsandpages_editdepfield[10] = "If you want to force the user to enter data in a certain format,<br>enter the corresponding regular expression above. A preg_match()<br>will be applied when the user enters data. This is optional - if you<br>don't understand or need regular expressions, leave this blank.";


	$admin_adsandpages_editdepfield[13] = "Save Changes";
	$admin_adsandpages_editdepfield[14] = "Cancel";
	$admin_adsandpages_editdepfield[15] = "Parent Field:";
	$admin_adsandpages_editdepfield[16] = "Field Maxlength:";
	$admin_adsandpages_editdepfield[17] = "Required:";
	$admin_adsandpages_editdepfield[18] = "Required";
	$admin_adsandpages_editdepfield[19] = "Not Required";
	break;

case "admin_adsandpages_editfield":
	$admin_adsandpages_editfield[1] = "Edit adsandpages Information Field";
	$admin_adsandpages_editfield[2] = "Use this page to edit this adsandpages information field. adsandpages information fields are used to collect information about new adsandpagess when users create them.";
	$admin_adsandpages_editfield[3] = "No dependent field";
	$admin_adsandpages_editfield[4] = "Yes, has dependent field";
	$admin_adsandpages_editfield[5] = "Field Title:";
	$admin_adsandpages_editfield[6] = "Custom Error Message:";
	$admin_adsandpages_editfield[7] = "Field Type:";
	$admin_adsandpages_editfield[8] = "Text Field";
	$admin_adsandpages_editfield[9] = "Multi-line Text Area";
	$admin_adsandpages_editfield[10] = "Pull-down Select Box";
	$admin_adsandpages_editfield[11] = "Radio Buttons";
	$admin_adsandpages_editfield[12] = "Inline CSS Style:";
	$admin_adsandpages_editfield[13] = "Field Maxlength:";
	$admin_adsandpages_editfield[14] = "Regex Validation:";
	$admin_adsandpages_editfield[15] = "If you want to force the user to enter data in a certain format,<br>enter the corresponding regular expression above. A preg_match()<br>will be applied when the user enters data. This is optional - if you<br>don't understand or need regular expressions, leave this blank.";

	$admin_adsandpages_editfield[17] = "Options:";
	$admin_adsandpages_editfield[18] = "You must specify at least one option.";
	$admin_adsandpages_editfield[19] = "Label";
	$admin_adsandpages_editfield[20] = "Dependency?";
	$admin_adsandpages_editfield[21] = "Dependent Field Label";
	$admin_adsandpages_editfield[22] = "Add New Option";
	$admin_adsandpages_editfield[23] = "Edit Field";
	$admin_adsandpages_editfield[24] = "Cancel";

	$admin_adsandpages_editfield[26] = "You must specify a field type.";
	$admin_adsandpages_editfield[27] = "Please enter both a value and a label for each option.";
	$admin_adsandpages_editfield[28] = "You must enter a title for this field.";
	$admin_adsandpages_editfield[29] = "Field Description:";




	$admin_adsandpages_editfield[34] = "Delete Field";
	$admin_adsandpages_editfield[35] = "Confirm Field Deletion";
	$admin_adsandpages_editfield[36] = "Are you sure you want to delete this field and any dependent fields it may have?";
	$admin_adsandpages_editfield[37] = "Required:";
	$admin_adsandpages_editfield[38] = "Required";
	$admin_adsandpages_editfield[39] = "Not Required";
	$admin_adsandpages_editfield[40] = "Date Field";
	break;

case "admin_viewadsandpagess":
	$admin_viewadsandpagess[1] = "View User-created adsandpagess";
	$admin_viewadsandpagess[2] = "This page lists all of the adsandpagess that users have created on your social network. You can use this page to monitor these adsandpagess and delete offensive or unwanted material if necessary. Entering criteria into the filter fields will help you find specific adsandpagess. Leaving the filter fields blank will show all the adsandpagess on your social network.";
	$admin_viewadsandpagess[3] = "Title";
	$admin_viewadsandpagess[4] = "Creator";
	$admin_viewadsandpagess[5] = "Filter";
	$admin_viewadsandpagess[6] = "ID";
	$admin_viewadsandpagess[7] = "Title";
	$admin_viewadsandpagess[8] = "Owner";
	$admin_viewadsandpagess[9] = "Members";
	$admin_viewadsandpagess[10] = "Date Created";
	$admin_viewadsandpagess[11] = "Options";
	$admin_viewadsandpagess[12] = "view";
	$admin_viewadsandpagess[13] = "delete";
	$admin_viewadsandpagess[14] = "adsandpagess Found";
	$admin_viewadsandpagess[15] = "Page:";
	$admin_viewadsandpagess[16] = "Delete adsandpages";
	$admin_viewadsandpagess[17] = "Are you sure you want to delete this adsandpages?";
	$admin_viewadsandpagess[18] = "Cancel";
	$admin_viewadsandpagess[19] = "No adsandpagess were found.";
	$admin_viewadsandpagess[20] = "Delete Selected";
	break;

  case "adsandpages":
	$adsandpages[1] = "You do not have permission to view this adsandpages.";
	$adsandpages[2] = "Browse Members";
	$adsandpages[3] = "Be a Fan";
	$adsandpages[4] = "Leave this Fan";
	$adsandpages[5] = "adsandpages Statistics";
	$adsandpages[6] = "Leader:";
	$adsandpages[7] = "Views:";
	$adsandpages[8] = "views";
	$adsandpages[9] = "Members:";
	$adsandpages[10] = "members";
	$adsandpages[11] = "Photos:";
	$adsandpages[12] = "photos";
	$adsandpages[13] = "Last Update:";
	$adsandpages[14] = "adsandpages Information";
	$adsandpages[15] = "adsandpages Name:";
	$adsandpages[16] = "Description:";
	$adsandpages[17] = "Category:";
	$adsandpages[18] = "Members";
	$adsandpages[19] = "view all";
	$adsandpages[20] = "members";
	$adsandpages[21] = "Photos";
	$adsandpages[22] = "view all photos";
	$adsandpages[23] = "Comments";
	$adsandpages[24] = "Post Comment";
	$adsandpages[25] = "view all comments";
	$adsandpages[26] = "Anonymous";
	$adsandpages[27] = "message";
	$adsandpages[28] = "An Error Has Occurred";
	$adsandpages[29] = "Browse Photos";
	$adsandpages[30] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages[31] = "Write Something...";
	$adsandpages[32] = "Posting...";
	$adsandpages[33] = "Please enter a message.";
	$adsandpages[34] = "You have entered the wrong security code.";
	$adsandpages[35] = "\o\\n";	  //THESE CHARACTERS ARE BEING ESCAPED BECAUSE THEY ARE BEING USED IN A DATE FUNCTION
	$adsandpages[36] = "Enter the numbers you see in this image into the field to its right. This helps keep our site free of spam.";
	$adsandpages[37] = "Private adsandpages";
	$adsandpages[38] = "Report this adsandpages";
	$adsandpages[39] = "Return";
	$adsandpages[40] = "reply";
	$adsandpages[41] = "The adsandpages you are looking for has been deleted or does not exist.";
	$adsandpages[42] = "Discussion Topics";
	$adsandpages[43] = "view all topics";
	$adsandpages[44] = "There are no discussion topics.";
	$adsandpages[45] = "start topic";
	$adsandpages[46] = "post(s), updated";
	$adsandpages[47] = "discussion topics";
	$adsandpages[48] = "Topics:";
	break;

  case "adsandpages_album":
	$adsandpages_album[1] = "You do not have permission to view this album.";
	$adsandpages_album[2] = "'s Photos";
	$adsandpages_album[3] = "An Error Has Occurred";
	$adsandpages_album[4] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_album[5] = "Last Page";
	$adsandpages_album[6] = "viewing image";
	$adsandpages_album[7] = "of";
	$adsandpages_album[8] = "viewing images";
	$adsandpages_album[9] = "Next Page";
	$adsandpages_album[10] = "Return";
	break;

  case "adsandpages_album_file":
	$adsandpages_album_file[1] = "You do not have permission to view this file.";
	$adsandpages_album_file[2] = "'s Photo";
	$adsandpages_album_file[3] = "Untitled";
	$adsandpages_album_file[4] = "photos";
	$adsandpages_album_file[5] = "download audio";
	$adsandpages_album_file[6] = "download video";
	$adsandpages_album_file[7] = "download this file";
	$adsandpages_album_file[8] = "Return to";
	$adsandpages_album_file[9] = "'s Album";
	$adsandpages_album_file[10] = "Post Comment";
	$adsandpages_album_file[11] = "Report Inappropriate Content";
	$adsandpages_album_file[12] = "Comments";
	$adsandpages_album_file[13] = "on";
	$adsandpages_album_file[14] = "Anonymous";
	$adsandpages_album_file[15] = "An Error Has Occurred";
	$adsandpages_album_file[16] = "By";
	$adsandpages_album_file[17] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_album_file[18] = "Write Something...";
	$adsandpages_album_file[19] = "Posting...";
	$adsandpages_album_file[20] = "Please enter a message.";
	$adsandpages_album_file[21] = "You have entered the wrong security code.";
	$adsandpages_album_file[22] = "\o\\n";  //THESE CHARACTERS ARE BEING ESCAPED BECAUSE THEY ARE BEING USED IN A DATE FUNCTION
	$adsandpages_album_file[23] = "message";
	$adsandpages_album_file[24] = "Enter the numbers you see in this image into the field to its right. This helps keep our site free of spam.";
	$adsandpages_album_file[25] = "Return";
	break;

  case "adsandpages_comments":
	$adsandpages_comments[1] = "message";
	$adsandpages_comments[2] = "\o\\n";	  //THESE CHARACTERS ARE BEING ESCAPED BECAUSE THEY ARE BEING USED IN A DATE FUNCTION
	$adsandpages_comments[3] = "Comments About";

	$adsandpages_comments[5] = "Back to";

	$adsandpages_comments[7] = "Last Page";
	$adsandpages_comments[8] = "showing comment";
	$adsandpages_comments[9] = "of";
	$adsandpages_comments[10] = "showing comments";
	$adsandpages_comments[11] = "Next Page";
	$adsandpages_comments[12] = "Anonymous";

	$adsandpages_comments[14] = "Write Something...";
	$adsandpages_comments[15] = "Posting...";
	$adsandpages_comments[16] = "Please enter a message.";
	$adsandpages_comments[17] = "You have entered the wrong security code.";
	$adsandpages_comments[18] = "Post Comment";
	$adsandpages_comments[19] = "Enter the numbers you see in this image into the field to its right. This helps keep our site free of spam.";
	$adsandpages_comments[20] = "An Error Has Occurred";

	$adsandpages_comments[22] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_comments[23] = "Return";
	break;

  case "adsandpages_discussion":
	$adsandpages_discussion[1] = "An Error Has Occurred";
	$adsandpages_discussion[2] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_discussion[3] = "Return";
	$adsandpages_discussion[4] = "Discussion Board";
	$adsandpages_discussion[5] = "Start Topic";
	$adsandpages_discussion[6] = "Back to";
	$adsandpages_discussion[7] = "Last Page";
	$adsandpages_discussion[8] = "showing topic";
	$adsandpages_discussion[9] = "of";
	$adsandpages_discussion[10] = "showing topics";
	$adsandpages_discussion[11] = "Next Page";
	$adsandpages_discussion[12] = "post(s), updated";
	$adsandpages_discussion[13] = "delete";
	$adsandpages_discussion[14] = "Topic";
	$adsandpages_discussion[15] = "Last Updated";
	$adsandpages_discussion[16] = "Replies";
	$adsandpages_discussion[17] = "Views";
	$adsandpages_discussion[18] = "replies";
	$adsandpages_discussion[19] = "views";
	break;

  case "adsandpages_discussion_delete":
	$adsandpages_discussion_delete[1] = "An Error Has Occurred";
	$adsandpages_discussion_delete[2] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_discussion_delete[3] = "Return";
	$adsandpages_discussion_delete[4] = "Delete Topic";
	$adsandpages_discussion_delete[5] = "Delete Post";
	$adsandpages_discussion_delete[6] = "Are you sure you want to delete this topic?";
	$adsandpages_discussion_delete[7] = "Are you sure you want to delete this post?";
	$adsandpages_discussion_delete[8] = "Delete Topic";
	$adsandpages_discussion_delete[9] = "Delete Post";
	$adsandpages_discussion_delete[10] = "Cancel";
	$adsandpages_discussion_delete[11] = "Discussion Board";
	break;

  case "adsandpages_discussion_post":
	$adsandpages_discussion_post[1] = "An Error Has Occurred";
	$adsandpages_discussion_post[2] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_discussion_post[3] = "Return";
	$adsandpages_discussion_post[4] = "Discussion Board";
	$adsandpages_discussion_post[5] = "Start Topic";
	$adsandpages_discussion_post[6] = "Post Topic";
	$adsandpages_discussion_post[7] = "Topic Subject";
	$adsandpages_discussion_post[8] = "Your Message";
	$adsandpages_discussion_post[9] = "Please enter a subject.";
	$adsandpages_discussion_post[10] = "Please enter a message to post.";
	$adsandpages_discussion_post[11] = "Cancel";
	$adsandpages_discussion_post[12] = "Post Reply";
	$adsandpages_discussion_post[13] = "Enter the numbers you see in this image into the field to its right. This helps keep our site free of spam.";
	$adsandpages_discussion_post[14] = "You have entered the wrong security code.";
	break;

  case "adsandpages_discussion_view":
	$adsandpages_discussion_view[1] = "An Error Has Occurred";
	$adsandpages_discussion_view[2] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_discussion_view[3] = "Return";
	$adsandpages_discussion_view[4] = "Discussion Board";
	$adsandpages_discussion_view[5] = "Reply to Topic";
	$adsandpages_discussion_view[6] = "Back to Discussion Board";
	$adsandpages_discussion_view[7] = "Last Page";
	$adsandpages_discussion_view[8] = "showing post";
	$adsandpages_discussion_view[9] = "of";
	$adsandpages_discussion_view[10] = "showing posts";
	$adsandpages_discussion_view[11] = "Next Page";
	$adsandpages_discussion_view[12] = "Anonymous";
	$adsandpages_discussion_view[13] = "\o\\n";	  //THESE CHARACTERS ARE BEING ESCAPED BECAUSE THEY ARE BEING USED IN A DATE FUNCTION
	$adsandpages_discussion_view[14] = "message";
	$adsandpages_discussion_view[15] = "delete";
	break;

  case "adsandpages_members":
	$adsandpages_members[1] = "Members of";
	$adsandpages_members[2] = "The following people are members of";
	$adsandpages_members[3] = "Last Page";
	$adsandpages_members[4] = "viewing members";
	$adsandpages_members[5] = "of";
	$adsandpages_members[6] = "viewing members";
	$adsandpages_members[7] = "Next Page";
	$adsandpages_members[8] = "Username:";
	$adsandpages_members[9] = "Last Update:";
	$adsandpages_members[10] = "Last Login:";
	$adsandpages_members[11] = "View Profile";
	$adsandpages_members[12] = "Add to Friends";
	$adsandpages_members[13] = "Send Message";
	$adsandpages_members[14] = "An Error Has Occurred";
	$adsandpages_members[15] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$adsandpages_members[16] = "Return";
	break;

  case "user_adsandpages":
	$user_adsandpages[1] = "My adsandpagess";
	$user_adsandpages[2] = "adsandpages Invitations";
	$user_adsandpages[3] = "Browse adsandpagess";
	$user_adsandpages[4] = "My adsandpagess";
	$user_adsandpages[5] = "Below are all of the adsandpagess that you belong to.<br>To search for new adsandpagess to join, visit the ";
	$user_adsandpages[6] = "Browse adsandpagess page";
	$user_adsandpages[7] = "Create New adsandpages";
	$user_adsandpages[8] = "You are not a member of any adsandpagess.";
	$user_adsandpages[9] = "Size:";
	$user_adsandpages[10] = "members";
	$user_adsandpages[11] = "Leader:";
	$user_adsandpages[12] = "View adsandpages";
	$user_adsandpages[13] = "Edit adsandpages";
	$user_adsandpages[14] = "Leave adsandpages";
	$user_adsandpages[15] = "adsandpages Settings";
	break;

  case "user_adsandpages_add":
	$user_adsandpages_add[1] = "Please enter a name for your adsandpages.";
	$user_adsandpages_add[2] = "You have already created the maximum number of adsandpagess allowed. To create this new adsandpages, you must leave one of the adsandpagess you currently own.";
	$user_adsandpages_add[3] = "Please complete all required fields.";
	$user_adsandpages_add[4] = "Please ensure you have filled out the fields in the proper formats.";
	$user_adsandpages_add[5] = "My adsandpagess";
	$user_adsandpages_add[6] = "adsandpages Invitations";
	$user_adsandpages_add[7] = "Browse adsandpagess";
	$user_adsandpages_add[8] = "Create New adsandpages";
	$user_adsandpages_add[9] = "Please give us some information about your new adsandpages. After you have created your adsandpages, you can begin inviting other users to become members.";
	$user_adsandpages_add[10] = "adsandpages Name*";
	$user_adsandpages_add[11] = "adsandpages Description";
	$user_adsandpages_add[12] = "adsandpages Category";
	$user_adsandpages_add[13] = "adsandpages Settings";
	$user_adsandpages_add[14] = "Member Approval";
	$user_adsandpages_add[15] = "New members can join without approval.";
	$user_adsandpages_add[16] = "New members must be approved before joining.";
	$user_adsandpages_add[17] = "When people try to join this adsandpages, should they be allowed to join immediately, or should they be forced to wait for approval?";
	$user_adsandpages_add[18] = "Include this adsandpages in search/browse results?";
	$user_adsandpages_add[19] = "Yes, include this adsandpages in search/browse results.";
	$user_adsandpages_add[20] = "No, exclude this adsandpages from search/browse results.";
	$user_adsandpages_add[21] = "Who can see this adsandpages?";
	$user_adsandpages_add[22] = "You can decide who gets to see this adsandpages.";
	$user_adsandpages_add[23] = "Allow Comments?";
	$user_adsandpages_add[24] = "You can decide who can post comments in this adsandpages.";
	$user_adsandpages_add[25] = "Add adsandpages";
	$user_adsandpages_add[26] = "Cancel";
	$user_adsandpages_add[27] = "adsandpages Settings";
	$user_adsandpages_add[28] = "adsandpages Details";
	$user_adsandpages_add[29] = "Allow Discussion Board?";
	$user_adsandpages_add[30] = "You can decide who can create and post in discussion topics in this adsandpages.";
	break;

  case "user_adsandpages_browse":
	$user_adsandpages_browse[1] = "My adsandpagess";
	$user_adsandpages_browse[2] = "adsandpages Invitations";
	$user_adsandpages_browse[3] = "Browse adsandpagess";
	$user_adsandpages_browse[4] = "Browse adsandpagess";
	$user_adsandpages_browse[5] = "Finding a adsandpages that interests you is easy! Just select a category below, or search for a adsandpages with your own keywords on the <a href='search.php'>search page</a>.";
	$user_adsandpages_browse[6] = "adsandpages Categories";
	$user_adsandpages_browse[7] = "adsandpagess";
	$user_adsandpages_browse[8] = "adsandpages";
	$user_adsandpages_browse[9] = "Other";
	$user_adsandpages_browse[10] = "adsandpages(s) found in";
	$user_adsandpages_browse[11] = "Size:";
	$user_adsandpages_browse[12] = "member(s)";
	$user_adsandpages_browse[13] = "Leader:";
	$user_adsandpages_browse[14] = "View adsandpages";
	$user_adsandpages_browse[15] = "Join adsandpages";
	$user_adsandpages_browse[16] = "Last Page";
	$user_adsandpages_browse[17] = "viewing adsandpages";
	$user_adsandpages_browse[18] = "of";
	$user_adsandpages_browse[19] = "viewing adsandpagess";
	$user_adsandpages_browse[20] = "Next Page";
	$user_adsandpages_browse[21] = "adsandpages Settings";
	break;

  case "user_adsandpages_edit":
	$user_adsandpages_edit[1] = "Photos must be less than 4MB in size";
	$user_adsandpages_edit[2] = "Photos must have one of the following extensions:";
	$user_adsandpages_edit[3] = "Photos must be less than or equal to the following dimensions:";
	$user_adsandpages_edit[4] = "pixels";
	$user_adsandpages_edit[5] = "Your photo failed to upload. Please try again. If this error persists, please contact support.";
	$user_adsandpages_edit[6] = "Please complete all required fields.";
	$user_adsandpages_edit[7] = "Please ensure you have filled out the fields in the proper formats.";
	$user_adsandpages_edit[8] = "Please enter a name for your adsandpages.";
	$user_adsandpages_edit[9] = "Your changes have been saved.";
	$user_adsandpages_edit[10] = "adsandpages Details";
	$user_adsandpages_edit[11] = "Members";
	$user_adsandpages_edit[12] = "Invitations";
	$user_adsandpages_edit[13] = "Photos";
	$user_adsandpages_edit[14] = "Comments";
	$user_adsandpages_edit[15] = "adsandpages Style";
	$user_adsandpages_edit[16] = "Delete adsandpages";
	$user_adsandpages_edit[17] = "Edit adsandpages:";
	$user_adsandpages_edit[18] = "All of this adsandpages's details are displayed and can be changed below.";
	$user_adsandpages_edit[19] = "Your adsandpages was successfully created! You can add a photo and edit the adsandpages details below.";
	$user_adsandpages_edit[20] = "adsandpages Photo";
	$user_adsandpages_edit[21] = "Current Photo";
	$user_adsandpages_edit[22] = "remove photo";
	$user_adsandpages_edit[23] = "Upload Photo";
	$user_adsandpages_edit[24] = "Upload";
	$user_adsandpages_edit[25] = "Images must be less than 4 MB in size with one of the following extensions:";
	$user_adsandpages_edit[26] = "adsandpages Details";
	$user_adsandpages_edit[27] = "adsandpages Name*";
	$user_adsandpages_edit[28] = "adsandpages Description";
	$user_adsandpages_edit[29] = "adsandpages Category";
	$user_adsandpages_edit[30] = "adsandpages Settings";
	$user_adsandpages_edit[31] = "Member Approval";
	$user_adsandpages_edit[32] = "New members can join without approval.";
	$user_adsandpages_edit[33] = "New members must be approved before joining.";
	$user_adsandpages_edit[34] = "When people try to join this adsandpages, should they be allowed to join immediately, or should they be forced to wait for approval? Approving/denying members can be managed from the";
	$user_adsandpages_edit[35] = "Note: If you turn member approval off, any new members awaiting approval will be automatically approved.";
	$user_adsandpages_edit[36] = "Include this adsandpages in search/browse results?";
	$user_adsandpages_edit[37] = "Yes, include this adsandpages in search/browse results.";
	$user_adsandpages_edit[38] = "No, exclude this adsandpages from search/browse results.";
	$user_adsandpages_edit[39] = "Who can see this adsandpages?";
	$user_adsandpages_edit[40] = "You can decide who gets to see this adsandpages.";
	$user_adsandpages_edit[41] = "Allow Comments?";
	$user_adsandpages_edit[42] = "You can decide who can post comments in this adsandpages.";
	$user_adsandpages_edit[43] = "Save Changes";
	$user_adsandpages_edit[44] = "invitations page";
	$user_adsandpages_edit[45] = "Cancel";
	$user_adsandpages_edit[46] = "&#171; Back to My adsandpagess";
	$user_adsandpages_edit[47] = "Allow Discussion Board?";
	$user_adsandpages_edit[48] = "You can decide who can create and post in discussion topics in this adsandpages.";
	break;

  case "user_adsandpages_edit_comments":
	$user_adsandpages_edit_comments[1] = "adsandpages Details";
	$user_adsandpages_edit_comments[2] = "Members";
	$user_adsandpages_edit_comments[3] = "Invitations";
	$user_adsandpages_edit_comments[4] = "Photos";
	$user_adsandpages_edit_comments[5] = "Comments";
	$user_adsandpages_edit_comments[6] = "adsandpages Style";
	$user_adsandpages_edit_comments[7] = "Delete adsandpages";
	$user_adsandpages_edit_comments[8] = "Back to My adsandpagess";
	$user_adsandpages_edit_comments[9] = "adsandpages Comments:";
	$user_adsandpages_edit_comments[10] = "The comments below have been written about this adsandpages by other people. To delete comments, click their checkboxes and then click the \"Delete Selected\" button below the comment list.";
	$user_adsandpages_edit_comments[11] = "Last Page";
	$user_adsandpages_edit_comments[12] = "comment";
	$user_adsandpages_edit_comments[13] = "of";
	$user_adsandpages_edit_comments[14] = "comments";
	$user_adsandpages_edit_comments[15] = "Next Page";
	$user_adsandpages_edit_comments[16] = "No comments have been posted about this adsandpages.";
	$user_adsandpages_edit_comments[17] = "Anonymous";
	$user_adsandpages_edit_comments[18] = "Delete Selected";
	$user_adsandpages_edit_comments[19] = "\o\\n";  //THESE CHARACTERS ARE BEING ESCAPED BECAUSE THEY ARE BEING USED IN A DATE FUNCTION
	$user_adsandpages_edit_comments[20] = "select all comments";
	break;

  case "user_adsandpages_edit_delete":
	$user_adsandpages_edit_delete[1] = "adsandpages Details";
	$user_adsandpages_edit_delete[2] = "Members";
	$user_adsandpages_edit_delete[3] = "Invitations";
	$user_adsandpages_edit_delete[4] = "Photos";
	$user_adsandpages_edit_delete[5] = "Comments";
	$user_adsandpages_edit_delete[6] = "adsandpages Style";
	$user_adsandpages_edit_delete[7] = "Delete adsandpages";
	$user_adsandpages_edit_delete[8] = "Back to My adsandpagess";
	$user_adsandpages_edit_delete[9] = "Delete adsandpages:";
	$user_adsandpages_edit_delete[10] = "Are you sure you want to delete this adsandpages? All of its content will be permanently deleted, and all members will be removed.";
	$user_adsandpages_edit_delete[11] = "Delete adsandpages";
	$user_adsandpages_edit_delete[12] = "Cancel";
	break;

  case "user_adsandpages_edit_files":
	$user_adsandpages_edit_files[1] = "Your changes have been saved.";
	$user_adsandpages_edit_files[2] = "adsandpages Details";
	$user_adsandpages_edit_files[3] = "Members";
	$user_adsandpages_edit_files[4] = "Invitations";
	$user_adsandpages_edit_files[5] = "Photos";
	$user_adsandpages_edit_files[6] = "Comments";
	$user_adsandpages_edit_files[7] = "adsandpages Style";
	$user_adsandpages_edit_files[8] = "Delete adsandpages";
	$user_adsandpages_edit_files[9] = "Back to My adsandpagess";
	$user_adsandpages_edit_files[10] = "adsandpages Photos:";
	$user_adsandpages_edit_files[11] = "Manage this adsandpages's photos and files from this page.<br>Total files in this album: ";
	$user_adsandpages_edit_files[12] = "Add New Photos";
	$user_adsandpages_edit_files[13] = "Title";
	$user_adsandpages_edit_files[14] = "comments";
	$user_adsandpages_edit_files[15] = "Caption";
	$user_adsandpages_edit_files[16] = "Delete Photo";
	$user_adsandpages_edit_files[17] = "Save Changes";
	break;

  case "user_adsandpages_edit_files_comments":
	$user_adsandpages_edit_files_comments[1] = "adsandpages Details";
	$user_adsandpages_edit_files_comments[2] = "Members";
	$user_adsandpages_edit_files_comments[3] = "Invitations";
	$user_adsandpages_edit_files_comments[4] = "Photos";
	$user_adsandpages_edit_files_comments[5] = "Comments";
	$user_adsandpages_edit_files_comments[6] = "adsandpages Style";
	$user_adsandpages_edit_files_comments[7] = "Delete adsandpages";
	$user_adsandpages_edit_files_comments[8] = "Back to My adsandpagess";
	$user_adsandpages_edit_files_comments[9] = "Photo Comments";
	$user_adsandpages_edit_files_comments[10] = "To delete comments, click their checkboxes and then click the \"Delete Selected\" button below the comment list.";
	$user_adsandpages_edit_files_comments[11] = "Last Page";
	$user_adsandpages_edit_files_comments[12] = "comment";
	$user_adsandpages_edit_files_comments[13] = "of";
	$user_adsandpages_edit_files_comments[14] = "comments";
	$user_adsandpages_edit_files_comments[15] = "Next Page";
	$user_adsandpages_edit_files_comments[16] = "No comments have been posted about this photo.";
	$user_adsandpages_edit_files_comments[17] = "Anonymous";
	$user_adsandpages_edit_files_comments[18] = "Delete Selected";
	$user_adsandpages_edit_files_comments[19] = "\o\\n";  //THESE CHARACTERS ARE BEING ESCAPED BECAUSE THEY ARE BEING USED IN A DATE FUNCTION
	$user_adsandpages_edit_files_comments[20] = "select all comments";
	$user_adsandpages_edit_files_comments[21] = "Back to Photos";
	break;

  case "user_adsandpages_edit_files_upload":
	$user_adsandpages_edit_files_upload[1] = "adsandpages Details";
	$user_adsandpages_edit_files_upload[2] = "Members";
	$user_adsandpages_edit_files_upload[3] = "Invitations";
	$user_adsandpages_edit_files_upload[4] = "Photos";
	$user_adsandpages_edit_files_upload[5] = "Comments";
	$user_adsandpages_edit_files_upload[6] = "adsandpages Style";
	$user_adsandpages_edit_files_upload[7] = "Delete adsandpages";
	$user_adsandpages_edit_files_upload[8] = "Back to My adsandpagess";
	$user_adsandpages_edit_files_upload[9] = "Upload Photos:";
	$user_adsandpages_edit_files_upload[10] = "To upload photos from your computer, click the \"Browse\" button, locate them on your computer, then click the \"Upload Photos\" button.";
	$user_adsandpages_edit_files_upload[11] = "Back to Photos";
	$user_adsandpages_edit_files_upload[12] = "You have";
	$user_adsandpages_edit_files_upload[13] = "of free space remaining.";
	$user_adsandpages_edit_files_upload[14] = "You may upload files of the following types:";
	$user_adsandpages_edit_files_upload[15] = "You may upload files with sizes up to";
	$user_adsandpages_edit_files_upload[16] = "File 1:";
	$user_adsandpages_edit_files_upload[17] = "File 2:";
	$user_adsandpages_edit_files_upload[18] = "File 3:";
	$user_adsandpages_edit_files_upload[19] = "File 4:";
	$user_adsandpages_edit_files_upload[20] = "File 5:";
	$user_adsandpages_edit_files_upload[21] = "Upload Photos";
	$user_adsandpages_edit_files_upload[22] = "UPLOADING"; // USED IN JAVASCRIPT, NO QUOTES OR SPECIAL CHARACTERS ALLOWED
	$user_adsandpages_edit_files_upload[23] = "was uploaded successfully.";
	break;

  case "user_adsandpages_edit_invite":
	$user_adsandpages_edit_invite[1] = "user(s) were successfully invited to join this adsandpages.";
	$user_adsandpages_edit_invite[2] = "1 person was uninvited from this adsandpages.";
	$user_adsandpages_edit_invite[3] = "1 person was approved and has joined this adsandpages.";
	$user_adsandpages_edit_invite[4] = "1 person was rejected from joining this adsandpages.";
	$user_adsandpages_edit_invite[5] = "adsandpages Details";
	$user_adsandpages_edit_invite[6] = "Members";
	$user_adsandpages_edit_invite[7] = "Invitations";
	$user_adsandpages_edit_invite[8] = "Photos";
	$user_adsandpages_edit_invite[9] = "Comments";
	$user_adsandpages_edit_invite[10] = "adsandpages Style";
	$user_adsandpages_edit_invite[11] = "Delete adsandpages";
	$user_adsandpages_edit_invite[12] = "Back to My adsandpagess";
	$user_adsandpages_edit_invite[13] = "adsandpages Invitations:";
	$user_adsandpages_edit_invite[14] = "Use this page to invite new members and approve or deny membership requests.";
	$user_adsandpages_edit_invite[15] = "Send Invitations";
	$user_adsandpages_edit_invite[16] = "To invite someone to join this adsandpages, enter the person's username in the field below. Remember that even if this adsandpages is set to be viewable by \"members only,\" people that you invite will be able to view the adsandpages as though they are members.";
	$user_adsandpages_edit_invite[17] = "Username:"; // USED IN JAVASCRIPT, NO QUOTES OR SPECIAL CHARACTERS ALLOWED
	$user_adsandpages_edit_invite[18] = "Invite";
	$user_adsandpages_edit_invite[19] = "Add Another Person";
	$user_adsandpages_edit_invite[20] = "Members Awaiting Approval";
	$user_adsandpages_edit_invite[21] = "The following people want to join our adsandpages and are waiting for approval.";
	$user_adsandpages_edit_invite[22] = "There are no new members waiting for approval.";
	$user_adsandpages_edit_invite[23] = "approve";
	$user_adsandpages_edit_invite[24] = "reject";
	$user_adsandpages_edit_invite[25] = "Invited Members";
	$user_adsandpages_edit_invite[26] = "The following people have already been invited to join our adsandpages.";
	$user_adsandpages_edit_invite[27] = "We are not waiting for confirmation from any invited members.";
	$user_adsandpages_edit_invite[28] = "uninvite";
	break;

  case "user_adsandpages_edit_member":
	$user_adsandpages_edit_member[1] = "adsandpages Details";
	$user_adsandpages_edit_member[2] = "Members";
	$user_adsandpages_edit_member[3] = "Invitations";
	$user_adsandpages_edit_member[4] = "Photos";
	$user_adsandpages_edit_member[5] = "Comments";
	$user_adsandpages_edit_member[6] = "adsandpages Style";
	$user_adsandpages_edit_member[7] = "Delete adsandpages";
	$user_adsandpages_edit_member[8] = "Back to My adsandpagess";
	$user_adsandpages_edit_member[9] = "Edit adsandpages Member";
	$user_adsandpages_edit_member[10] = "Use this page to change this adsandpages member's details.";
	$user_adsandpages_edit_member[11] = "Member Username:";
	$user_adsandpages_edit_member[12] = "Member Title:";
	$user_adsandpages_edit_member[13] = "Member Rank:";
	$user_adsandpages_edit_member[14] = "Owner";
	$user_adsandpages_edit_member[15] = "Member";
	$user_adsandpages_edit_member[16] = "Officer";
	$user_adsandpages_edit_member[17] = "<b>Warning:</b> You are about to transfer your ownership of this adsandpages to this person. Are you sure you want to make this person the new adsandpages owner? You will be demoted to member and logged out of the edit adsandpages area!";
	$user_adsandpages_edit_member[18] = "You are currently the adsandpages owner. If you want to give your ownership to another member, find them on the";
	$user_adsandpages_edit_member[19] = "Save Changes";
	$user_adsandpages_edit_member[20] = "Cancel";
	$user_adsandpages_edit_member[21] = "View Members";
	$user_adsandpages_edit_member[22] = "page and edit their membership. When you make them the adsandpages owner, you will be demoted to the rank of adsandpages member.";
	break;

  case "user_adsandpages_edit_members":
	$user_adsandpages_edit_members[1] = "adsandpages Details";
	$user_adsandpages_edit_members[2] = "Members";
	$user_adsandpages_edit_members[3] = "Invitations";
	$user_adsandpages_edit_members[4] = "Photos";
	$user_adsandpages_edit_members[5] = "Comments";
	$user_adsandpages_edit_members[6] = "adsandpages Style";
	$user_adsandpages_edit_members[7] = "Delete adsandpages";
	$user_adsandpages_edit_members[8] = "Back to My adsandpagess";
	$user_adsandpages_edit_members[9] = "Browse Members:";
	$user_adsandpages_edit_members[10] = "Use this page to list or search for adsandpages members.";
	$user_adsandpages_edit_members[11] = "All adsandpages Members";
	$user_adsandpages_edit_members[12] = "Only Officers";
	$user_adsandpages_edit_members[13] = "Search";
	$user_adsandpages_edit_members[14] = "Sort by:";
	$user_adsandpages_edit_members[15] = "Recently Updated";
	$user_adsandpages_edit_members[16] = "Recently Logged In";
	$user_adsandpages_edit_members[17] = "Member Title";
	$user_adsandpages_edit_members[18] = "Member Rank";
	$user_adsandpages_edit_members[19] = "Last Page";
	$user_adsandpages_edit_members[20] = "viewing entry";
	$user_adsandpages_edit_members[21] = "of";
	$user_adsandpages_edit_members[22] = "viewing entries";
	$user_adsandpages_edit_members[23] = "Next Page";
	$user_adsandpages_edit_members[24] = "Last Update:";
	$user_adsandpages_edit_members[25] = "Last Login:";
	$user_adsandpages_edit_members[26] = "Member Rank:";
	$user_adsandpages_edit_members[27] = "Owner";
	$user_adsandpages_edit_members[28] = "Officer";
	$user_adsandpages_edit_members[29] = "Member";
	$user_adsandpages_edit_members[30] = "Member Title:";
	$user_adsandpages_edit_members[31] = "Edit Member Details";
	$user_adsandpages_edit_members[32] = "Remove Member";
	$user_adsandpages_edit_members[33] = "Send Message";
	$user_adsandpages_edit_members[34] = "Search:";
	break;

  case "user_adsandpages_edit_members_remove":
	$user_adsandpages_edit_members_remove[1] = "adsandpages Details";
	$user_adsandpages_edit_members_remove[2] = "Members";
	$user_adsandpages_edit_members_remove[3] = "Invitations";
	$user_adsandpages_edit_members_remove[4] = "Photos";
	$user_adsandpages_edit_members_remove[5] = "Comments";
	$user_adsandpages_edit_members_remove[6] = "adsandpages Style";
	$user_adsandpages_edit_members_remove[7] = "Delete adsandpages";
	$user_adsandpages_edit_members_remove[8] = "Back to My adsandpagess";
	$user_adsandpages_edit_members_remove[9] = "Remove Member";
	$user_adsandpages_edit_members_remove[10] = "Are you sure you want to remove this member from your adsandpages?";
	$user_adsandpages_edit_members_remove[11] = "Remove Member";
	$user_adsandpages_edit_members_remove[12] = "Cancel";
	break;

  case "user_adsandpages_edit_style":
	$user_adsandpages_edit_style[1] = "Your changes have been saved.";
	$user_adsandpages_edit_style[2] = "adsandpages Details";
	$user_adsandpages_edit_style[3] = "Members";
	$user_adsandpages_edit_style[4] = "Invitations";
	$user_adsandpages_edit_style[5] = "Photos";
	$user_adsandpages_edit_style[6] = "Comments";
	$user_adsandpages_edit_style[7] = "adsandpages Style";
	$user_adsandpages_edit_style[8] = "Delete adsandpages";
	$user_adsandpages_edit_style[9] = "Back to My adsandpagess";
	$user_adsandpages_edit_style[10] = "Customize adsandpages:";
	$user_adsandpages_edit_style[11] = "You can change the colors, fonts, and styles of your adsandpages page by adding CSS code below. The contents of the text area below will be output between &lt;style&gt; tags on your adsandpages page.";
	$user_adsandpages_edit_style[12] = "Save Changes";
	break;

  case "user_adsandpages_invites":
	$user_adsandpages_invites[1] = "You have joined the adsandpages";
	$user_adsandpages_invites[2] = "You have declined to join the adsandpages";
	$user_adsandpages_invites[3] = "My adsandpagess";
	$user_adsandpages_invites[4] = "adsandpages Invitations";
	$user_adsandpages_invites[5] = "Browse adsandpagess";
	$user_adsandpages_invites[6] = "adsandpages Invitations";
	$user_adsandpages_invites[7] = "When you receive an invitation to join a adsandpages, it will appear on this page until you have either accepted or rejected it.";
	$user_adsandpages_invites[8] = "Name:";
	$user_adsandpages_invites[9] = "Size:";
	$user_adsandpages_invites[10] = "members";
	$user_adsandpages_invites[11] = "Leader:";
	$user_adsandpages_invites[12] = "View adsandpages";
	$user_adsandpages_invites[13] = "Accept Invitation";
	$user_adsandpages_invites[14] = "Reject Invitation";
	$user_adsandpages_invites[15] = "You have no pending adsandpages invitations.";
	$user_adsandpages_invites[16] = "adsandpages Settings";
	break;

  case "user_adsandpages_join":
	$user_adsandpages_join[1] = "You have already joined this adsandpages.";
	$user_adsandpages_join[2] = "You have already requested to join this adsandpages.";
	$user_adsandpages_join[3] = "You have successfully joined this adsandpages!";
	$user_adsandpages_join[4] = "My adsandpagess";
	$user_adsandpages_join[5] = "adsandpages Invitations";
	$user_adsandpages_join[6] = "Browse adsandpagess";
	$user_adsandpages_join[7] = "Join";
	$user_adsandpages_join[8] = "Are you sure you want to join this adsandpages?";
	$user_adsandpages_join[9] = "Join adsandpages";
	$user_adsandpages_join[10] = "Cancel";
	$user_adsandpages_join[11] = "Return";
	$user_adsandpages_join[12] = "You have requested to join this adsandpages. A adsandpages officer will confirm or reject your request soon.";
	$user_adsandpages_join[13] = "adsandpages Settings";
	break;

  case "user_adsandpages_leave":
	$user_adsandpages_leave[1] = "My adsandpagess";
	$user_adsandpages_leave[2] = "adsandpages Invitations";
	$user_adsandpages_leave[3] = "Browse adsandpagess";
	$user_adsandpages_leave[4] = "Leave";
	$user_adsandpages_leave[5] = "Are you sure you want to leave this adsandpages?";
	$user_adsandpages_leave[6] = "<b>You are currently the owner of this adsandpages. If you leave this adsandpages now, the entire adsandpages will be deleted.</b> If you want to leave this adsandpages without deleting it, you must first transfer your ownership to another person.";
	$user_adsandpages_leave[7] = "Find another adsandpages member";
	$user_adsandpages_leave[8] = ", upgrade their rank to owner, and then you can leave this adsandpages without it being deleted.";
	$user_adsandpages_leave[9] = "Leave adsandpages";
	$user_adsandpages_leave[10] = "Cancel";
	$user_adsandpages_leave[11] = "adsandpages Settings";
	break;

  case "user_adsandpages_settings":
	$user_adsandpages_settings[1] = "My adsandpagess";
	$user_adsandpages_settings[2] = "adsandpages Invitations";
	$user_adsandpages_settings[3] = "Browse adsandpagess";
	$user_adsandpages_settings[4] = "adsandpages Settings";
	$user_adsandpages_settings[5] = "adsandpages Settings";
	$user_adsandpages_settings[6] = "Edit your adsandpages settings such as email notifications on this page.";
	$user_adsandpages_settings[7] = "Your changes have been saved.";
	$user_adsandpages_settings[8] = "Save Changes";
	$user_adsandpages_settings[9] = "adsandpages Notifications";
	$user_adsandpages_settings[10] = "Check the boxes next to the email notifications you would like to receive.";
	$user_adsandpages_settings[11] = "Notify me when someone invites me to join a adsandpages.";
	$user_adsandpages_settings[12] = "Notify me when someone writes a comment on a adsandpages I lead.";
	$user_adsandpages_settings[13] = "Notify me when someone writes a comment on one of the photos in a adsandpages I lead.";
	$user_adsandpages_settings[14] = "Notify me when someone requests membership in a adsandpages I lead.";
	break;

}

// ASSIGN ALL SMARTY VARIABLES
if(is_array(${"$page"})) {
  reset(${"$page"});
  while(list($key, $val) = each(${"$page"})) {
    $smarty->assign($page.$key, $val);
  }
}
?>