<?
$page = "adsandpages_discussion_post";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['adsandpagestopic_id'])) { $adsandpagestopic_id = $_POST['adsandpagestopic_id']; } elseif(isset($_GET['adsandpagestopic_id'])) { $adsandpagestopic_id = $_GET['adsandpagestopic_id']; } else { $adsandpagestopic_id = 0; }

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_adsandpages] == 0) {
  $page = "error";
  $smarty->assign('error_header', $adsandpages_discussion_post[1]);
  $smarty->assign('error_message', $adsandpages_discussion_post[2]);
  $smarty->assign('error_submit', $adsandpages_discussion_post[3]);
  include "footer.php";
}


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
if($adsandpages->adsandpages_exists == 0) { header("Location: home.php"); exit(); }

// GET PRIVACY LEVEL
$privacy_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$allowed_privacy = true_privacy($adsandpages->adsandpages_info[adsandpages_privacy], $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$is_adsandpages_private = 0;
if($privacy_level < $allowed_privacy) { header("Location: adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }


// CHECK IF USER IS ALLOWED TO DISCUSS
$discussion_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion]);
$allowed_discussion = true_privacy($adsandpages->adsandpages_info[adsandpages_discussion], $adsandpages->adsandpagesowner_level_info[level_adsandpages_discussion]);
if($discussion_level < $allowed_discussion) { header("Location: adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }


// SET VARS
$is_error = 0;
$error_message = "";
$topic_id = 0;
$topic_subject = "";
$topic_body = "";


// VALIDATE TOPIC ID
$adsandpagestopic = $database->database_query("SELECT * FROM se_adsandpagestopics WHERE adsandpagestopic_id='$adsandpagestopic_id'");
if($database->database_num_rows($adsandpagestopic) == 1) {
  $adsandpagestopic_info = $database->database_fetch_assoc($adsandpagestopic);
  $topic_id = $adsandpagestopic_info[adsandpagestopic_id];
  $topic_subject = $adsandpagestopic_info[adsandpagestopic_subject];
}




// IF TASK IS CANCEL
if($task == "cancel") {
  if($topic_id != 0) {
    header("Location: adsandpages_discussion_view.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagestopic_id=$adsandpagestopic_id");
    exit();
  } else {
    header("Location: adsandpages_discussion.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]);
    exit();
  }
}


// IF A TOPIC IS BEING POSTED
if($task == "dopost") {
  $topic_date = time();
  $topic_body = censor(str_replace("\r\n", "<br>", $_POST['topic_body']));

  // RETRIEVE AND CHECK SECURITY CODE IF NECESSARY
  if($setting[setting_adsandpages_discussion_code] != 0) {
    session_start();
    $code = $_SESSION['code'];
    if($code == "") { $code = randomcode(); }
    $comment_secure = $_POST['comment_secure'];

    if($comment_secure != $code) { $is_error = 1; $error_message = $adsandpages_discussion_post[14]; }
  }

  // MAKE SURE TOPIC BODY IS NOT EMPTY
  if(str_replace(" ", "", $topic_body) == "") { $is_error = 1; $error_message = $adsandpages_discussion_post[10]; }

  // IF STARTING TOPIC, CHECK THAT SUBJECT IS NOT EMPTY
  if($topic_id == 0) {
    $topic_subject = censor($_POST['topic_subject']);
    if(str_replace(" ", "", $topic_subject) == "") { $is_error = 1; $error_message = $adsandpages_discussion_post[9]; }
  }

  // ADD TOPIC IF NO ERROR
  if($is_error == 0) {
    if($topic_id == 0) {
      $database->database_query("INSERT INTO se_adsandpagestopics (adsandpagestopic_adsandpages_id, adsandpagestopic_date, adsandpagestopic_subject) VALUES ('".$adsandpages->adsandpages_info[adsandpages_id]."', '$topic_date', '$topic_subject')");
      $topic_id = $database->database_insert_id();
    }
    $database->database_query("INSERT INTO se_adsandpagesposts (adsandpagespost_adsandpagestopic_id, adsandpagespost_authoruser_id, adsandpagespost_date, adsandpagespost_body) VALUES ('$topic_id', '".$user->user_info[user_id]."', '$topic_date', '$topic_body')");
    header("Location: adsandpages_discussion_view.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagestopic_id=".$topic_id);
    exit();
  }
}

// GET CUSTOM adsandpages STYLE IF ALLOWED
if($adsandpages->adsandpagesowner_level_info[level_adsandpages_style] != 0) { 
  $adsandpagesstyle_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesstyle_css FROM se_adsandpagesstyles WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1")); 
  $global_css = $adsandpagesstyle_info[adsandpagesstyle_css];
}


// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('is_error', $is_error);
$smarty->assign('error_message', $error_message);
$smarty->assign('topic_id', $topic_id);
$smarty->assign('topic_subject', $topic_subject);
$smarty->assign('topic_body', str_replace("<br>", "\r\n", $topic_body));
include "footer.php";
?>