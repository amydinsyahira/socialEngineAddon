<?
$page = "adsandpages_discussion_delete";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = ""; }
if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['adsandpagestopic_id'])) { $adsandpagestopic_id = $_POST['adsandpagestopic_id']; } elseif(isset($_GET['adsandpagestopic_id'])) { $adsandpagestopic_id = $_GET['adsandpagestopic_id']; } else { $adsandpagestopic_id = 0; }
if(isset($_POST['adsandpagespost_id'])) { $adsandpagespost_id = $_POST['adsandpagespost_id']; } elseif(isset($_GET['adsandpagespost_id'])) { $adsandpagespost_id = $_GET['adsandpagespost_id']; } else { $adsandpagespost_id = 0; }

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_adsandpages] == 0) {
  $page = "error";
  $smarty->assign('error_header', $adsandpages_discussion_delete[1]);
  $smarty->assign('error_message', $adsandpages_discussion_delete[2]);
  $smarty->assign('error_submit', $adsandpages_discussion_delete[3]);
  include "footer.php";
}

// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
if($adsandpages->adsandpages_exists == 0) { header("Location: home.php"); exit(); }


// CHECK THAT TOPIC EXISTS AND GET TOPIC INFO
$topic = $database->database_query("SELECT * FROM se_adsandpagestopics WHERE adsandpagestopic_id='$adsandpagestopic_id' AND adsandpagestopic_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
if($database->database_num_rows($topic) != 1) { header("Location: adsandpages_discussion.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }
$topic_info = $database->database_fetch_assoc($topic);


// CHECK THAT POST EXISTS AND GET POST INFO
if($adsandpagespost_id != 0) {
  $post = $database->database_query("SELECT * FROM se_adsandpagesposts WHERE adsandpagespost_id='$adsandpagespost_id' AND adsandpagespost_adsandpagestopic_id='$adsandpagestopic_id'");
  if($database->database_num_rows($post) != 1) { header("Location: adsandpages_discussion.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }
  $post_info = $database->database_fetch_assoc($post);

  // MAKE SURE USER IS ALLOWED TO DELETE OBJECT
  if(!(($post_info[adsandpagespost_authoruser_id] != 0 || $user->user_info[user_id] == $post_info[adsandpagespost_authoruser_id]) || $adsandpages->user_rank == 2 || $adsandpages->user_rank == 1)) {
    header("Location: adsandpages_discussion.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]);
    exit();
  }

  // ENSURE WE ARE DELETING THE POST
  if($task == "delete") { $task = "postdelete"; }


// adsandpages TOPIC DELETION
} else {

  // MAKE SURE USER IS ALLOWED TO DELETE OBJECT
  if($adsandpages->user_rank != 2 && $adsandpages->user_rank != 1) {
    header("Location: adsandpages_discussion.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]);
    exit();
  }

  // ENSURE WE ARE DELETING THE TOPIC
  if($task == "delete") { $task = "topicdelete"; }

}




// DELETE TOPIC
if($task == "topicdelete") {
  $database->database_query("DELETE FROM se_adsandpagestopics WHERE adsandpagestopic_id='$adsandpagestopic_id' AND adsandpagestopic_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
  $database->database_query("DELETE FROM se_adsandpagesposts WHERE adsandpagespost_adsandpagestopic_id='$adsandpagestopic_id'");
  header("Location: adsandpages_discussion_view.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagestopic_id=$adsandpagestopic_id");
  exit();

// DELETE POST
} elseif($task == "postdelete") {
  $database->database_query("DELETE FROM se_adsandpagesposts WHERE adsandpagespost_id='$adsandpagespost_id' AND adsandpagespost_adsandpagestopic_id='$adsandpagestopic_id'");
  if($database->database_num_rows($database->database_query("SELECT adsandpagespost_id FROM se_adsandpagesposts WHERE adsandpagespost_adsandpagestopic_id='$adsandpagestopic_id'")) == 0) {
    $database->database_query("DELETE FROM se_adsandpagestopics WHERE adsandpagestopic_id='$adsandpagestopic_id' AND adsandpagestopic_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
  }
  header("Location: adsandpages_discussion_view.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]."&adsandpagestopic_id=$adsandpagestopic_id");
  exit();

}




// GET CUSTOM adsandpages STYLE IF ALLOWED
if($adsandpages->adsandpagesowner_level_info[level_adsandpages_style] != 0) { 
  $adsandpagesstyle_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesstyle_css FROM se_adsandpagesstyles WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1")); 
  $global_css = $adsandpagesstyle_info[adsandpagesstyle_css];
}

// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('adsandpagestopic_id', $adsandpagestopic_id);
$smarty->assign('adsandpagespost_id', $adsandpagespost_id);
include "footer.php";
?>