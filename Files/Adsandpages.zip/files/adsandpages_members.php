<?
$page = "adsandpages_members";
include "header.php";

// GET PAGE VARIABLE
if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }
if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_adsandpages] == 0) {
  $page = "error";
  $smarty->assign('error_header', $adsandpages_members[14]);
  $smarty->assign('error_message', $adsandpages_members[15]);
  $smarty->assign('error_submit', $adsandpages_members[16]);
  include "footer.php";
}


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);
if($adsandpages->adsandpages_exists == 0) { header("Location: home.php"); exit(); }

// GET PRIVACY LEVEL
$privacy_level = $adsandpages->adsandpages_privacy_max($user, $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$allowed_privacy = true_privacy($adsandpages->adsandpages_info[adsandpages_privacy], $adsandpages->adsandpagesowner_level_info[level_profile_privacy]);
$is_adsandpages_private = 0;
if($privacy_level < $allowed_privacy) { header("Location: adsandpages.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }



// SET WHERE/SORT
$sort = "se_users.user_username";
$where = "(se_adsandpagesmembers.adsandpagesmember_status='1')";

// GET TOTAL MEMBERS
$total_members = $adsandpages->adsandpages_member_total($where);

// MAKE MEMBER PAGES
$members_per_page = 10;
$page_vars = make_page($total_members, $members_per_page, $p);

// GET MEMBER ARRAY
$members = $adsandpages->adsandpages_member_list($page_vars[0], $members_per_page, $sort, $where);

// ASSIGN VARIABLES AND DISPLAY BROWSE PAGE
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('members', $members);
$smarty->assign('total_members', $total_members);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($members));
include "footer.php";
?>