<?
$page = "user_adsandpages_edit_style";
include "header.php";

if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == 0 | $adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }

// SET EMPTY VARS
$result = 0;

// CHECK IF CUSTOM CSS IS DISABLED BY ADMIN
if($adsandpages->adsandpagesowner_level_info[level_adsandpages_style] != 1) { header("Location: user_adsandpages_edit.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit(); }


// SAVE NEW CSS
if($task == "dosave") {
  $style_adsandpages = addslashes(strip_tags(htmlspecialchars_decode($_POST['style_adsandpages'], ENT_QUOTES)));
  $database->database_query("UPDATE se_adsandpagesstyles SET adsandpagesstyle_css='$style_adsandpages' WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
  $result = 1;
}


// GET THIS USER'S adsandpages CSS
$style_query = $database->database_query("SELECT adsandpagesstyle_css FROM se_adsandpagesstyles WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1");
if($database->database_num_rows($style_query) == 1) { 
  $style_info = $database->database_fetch_assoc($style_query); 
} else {
  $database->database_query("INSERT INTO se_adsandpagesstyles (adsandpagesstyle_adsandpages_id, adsandpagesstyle_css) VALUES ('".$adsandpages->adsandpages_info[adsandpages_id]."', '')");
  $style_info = $database->database_fetch_assoc($database->database_query("SELECT adsandpagesstyle_css FROM se_adsandpagesstyles WHERE adsandpagesstyle_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1")); 
}

// ASSIGN SMARTY VARIABLES AND DISPLAY EDIT STYLE PAGE
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('result', $result);
$smarty->assign('style_adsandpages', htmlspecialchars($style_info[adsandpagesstyle_css]));
include "footer.php";
?>