<?
$page = "user_adsandpages_edit_member";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['member_id'])) { $member_id = $_POST['member_id']; } elseif(isset($_GET['member_id'])) { $member_id = $_GET['member_id']; } else { $member_id = 0; }


// VALIDATE MEMBER
$member_query = $database->database_query("SELECT se_adsandpagesmembers.*, se_users.user_username FROM se_adsandpagesmembers LEFT JOIN se_users ON se_adsandpagesmembers.adsandpagesmember_user_id=se_users.user_id WHERE se_adsandpagesmembers.adsandpagesmember_id='$member_id' LIMIT 1");
if($database->database_num_rows($member_query) != 1) { header("Location: user_adsandpages_edit_members.php"); exit; }
$member_info = $database->database_fetch_assoc($member_query);


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == 0 | $adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank < $member_info[adsandpagesmember_rank]) { header("Location: user_adsandpages_edit_members.php"); exit(); }







// SAVE CHANGES TO MEMBER
if($task == "dosave") {
  $member_rank = $_POST['member_rank'];
  $member_title = $_POST['member_title'];

  // DO NOT CHANGE TITLE IF ADMIN HAS TURNED OFF MEMBER TITLES
  if($adsandpages->adsandpagesowner_level_info[level_adsandpages_titles] != 1) { $member_title = $member_info[adsandpagesmember_title]; }

  // DO NOT CHANGE RANK IF ADMIN HAS TURNED OFF OFFICERS BUT MEMBER WAS SOMEHOW SET TO OFFICER
  if($adsandpages->adsandpagesowner_level_info[level_adsandpages_officers] != 1 AND $member_rank == 1) { $member_rank = $member_info[adsandpagesmember_rank]; }

  // IF EDITOR IS AN OFFICER, DONT ALLOW RANK CHANGE
  if($adsandpages->user_rank != 2) { $member_rank = $member_info[adsandpagesmember_rank]; }

  // SAVE CHANGES
  $database->database_query("UPDATE se_adsandpagesmembers SET adsandpagesmember_title='$member_title', adsandpagesmember_rank='$member_rank' WHERE adsandpagesmember_id='$member_info[adsandpagesmember_id]' AND adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1");

  // IF THIS MEMBER WAS SET TO OWNER, DEMOTE OLD OWNER TO MEMBER
  if($member_info[adsandpagesmember_rank] < 2 AND $member_rank == 2) {
    $database->database_query("UPDATE se_adsandpagesmembers SET adsandpagesmember_rank='0' WHERE adsandpagesmember_id<>'$member_info[adsandpagesmember_id]' AND adsandpagesmember_rank='2' AND adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
    $database->database_query("UPDATE se_adsandpagess SET adsandpages_user_id='$member_info[adsandpagesmember_user_id]' WHERE adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."'");
  }

  // SEND BACK TO VIEW MEMBERS PAGE
  header("Location: user_adsandpages_edit_members.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit;
}



// ASSIGN SMARTY VARIABLES AND DISPLAY EDIT MEMBER PAGE
$smarty->assign('member_info', $member_info);
$smarty->assign('adsandpages', $adsandpages);
include "footer.php";
?>