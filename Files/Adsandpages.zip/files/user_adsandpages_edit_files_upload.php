<?
$page = "user_adsandpages_edit_files_upload";
include "header.php";

if(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } elseif(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == 0 | $adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }


// GET adsandpages ALBUM INFO
$adsandpagesalbum_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_adsandpagesalbums WHERE adsandpagesalbum_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1"));


// GET TOTAL SPACE USED
$space_used = $adsandpages->adsandpages_media_space();
$space_left = $adsandpages->adsandpagesowner_level_info[level_adsandpages_album_storage] - $space_used;



// UPLOAD FILES
if($task == "doupload") {
  $file_result = Array();

  // RUN FILE UPLOAD FUNCTION FOR EACH SUBMITTED FILE
  $update_adsandpagesalbum = 0;
  $new_adsandpagesalbum_cover = "";
  for($f=1;$f<6;$f++) {
    $fileid = "file".$f;
    if($_FILES[$fileid]['name'] != "") {
      $file_result[$fileid] = $adsandpages->adsandpages_media_upload($fileid, $adsandpagesalbum_info[adsandpagesalbum_id], $space_left);
      if($file_result[$fileid]['is_error'] == 0) {
  	$file_result[$fileid]['message'] = stripslashes($_FILES[$fileid]['name'])." $user_adsandpages_edit_files_upload[23]";
	$new_adsandpagesalbum_cover = $file_result[$fileid]['media_id'];
        $update_adsandpagesalbum = 1;
      }
    }
  }

  // UPDATE adsandpages ALBUM UPDATED DATE AND adsandpages ALBUM COVER IF FILE UPLOADED
  if($update_adsandpagesalbum == 1) {
    $newdate = time();
    if($adsandpagesalbum_info[adsandpagesalbum_cover] != 0) { $new_adsandpagesalbum_cover = $adsandpagesalbum_info[adsandpagesalbum_cover]; }
    $database->database_query("UPDATE se_adsandpagesalbums SET adsandpagesalbum_cover='$new_adsandpagesalbum_cover', adsandpagesalbum_dateupdated='$newdate' WHERE adsandpagesalbum_id='$adsandpagesalbum_info[adsandpagesalbum_id]'");

    // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
    $adsandpages->adsandpages_lastupdate();
  }

} // END TASK



// GET MAX FILESIZE ALLOWED
$max_filesize_kb = ($adsandpages->adsandpagesowner_level_info[level_adsandpages_album_maxsize]) / 1024;
$max_filesize_kb = round($max_filesize_kb, 0);

// CONVERT UPDATED SPACE LEFT TO MB
$space_left_mb = ($space_left / 1024) / 1024;
$space_left_mb = round($space_left_mb, 2);


// ASSIGN VARIABLES AND SHOW USER EDIT adsandpages PAGE
$smarty->assign('file1_result', $file_result[file1][message]);
$smarty->assign('file2_result', $file_result[file2][message]);
$smarty->assign('file3_result', $file_result[file3][message]);
$smarty->assign('file4_result', $file_result[file4][message]);
$smarty->assign('file5_result', $file_result[file5][message]);
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('space_left', $space_left_mb);
$smarty->assign('allowed_exts', str_replace(",", ", ", $adsandpages->adsandpagesowner_level_info[level_adsandpages_album_exts]));
$smarty->assign('max_filesize', $max_filesize_kb);
include "footer.php";
?>