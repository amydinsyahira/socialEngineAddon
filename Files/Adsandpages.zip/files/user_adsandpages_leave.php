<?
$page = "user_adsandpages_leave";
include "header.php";

if(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } elseif(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }

// REMOVE USER FROM THIS adsandpages
if($task == "doleave") {
  $database->database_query("DELETE FROM se_adsandpagesmembers WHERE adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' AND adsandpagesmember_user_id='".$user->user_info[user_id]."' LIMIT 1");

  // IF USER IS OWNER OF adsandpages, DELETE THE adsandpages
  if($adsandpages->user_rank == 2) { $adsandpages->adsandpages_delete(); }

  // INSERT ACTION
  $adsandpages_title_short = $adsandpages->adsandpages_info[adsandpages_title];
  if(strlen($adsandpages_title_short) > 100) { $adsandpages_title_short = substr($adsandpages_title_short, 0, 97); $adsandpages_title_short .= "..."; }
  $actions->actions_add($user, "leaveadsandpages", Array('[username]', '[id]', '[title]'), Array($user->user_info[user_username], $adsandpages->adsandpages_info[adsandpages_id], $adsandpages_title_short));

  // RETURN TO adsandpages PAGE
  header("Location: user_adsandpages.php"); 
  exit();
}


// ASSIGN SMARTY VARIABLES AND DISPLAY LEAVE adsandpagesS PAGE
$smarty->assign('adsandpages', $adsandpages);
include "footer.php";
?>