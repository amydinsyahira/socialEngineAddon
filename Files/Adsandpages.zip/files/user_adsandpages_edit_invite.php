<?
$page = "user_adsandpages_edit_invite";
include "header.php";

if(isset($_GET['adsandpages_id'])) { $adsandpages_id = $_GET['adsandpages_id']; } elseif(isset($_POST['adsandpages_id'])) { $adsandpages_id = $_POST['adsandpages_id']; } else { $adsandpages_id = 0; }
if(isset($_GET['task'])) { $task = $_GET['task']; } elseif(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }


// INITIALIZE adsandpages OBJECT
$adsandpages = new se_adsandpages($user->user_info[user_id], $adsandpages_id);

if($adsandpages->adsandpages_exists == 0) { header("Location: user_adsandpages.php"); exit(); }
if($adsandpages->user_rank == 0 | $adsandpages->user_rank == -1) { header("Location: user_adsandpages.php"); exit(); }




// SET EMPTY VARS
$result = "";
$result2 = "";





// INVITE USERS
if($task == "doinvites") {
  $num_invited = $_POST['num_invited'];

  // LOOP THROUGH INVITED USERS
  $invited_count_success = 0;
  for($i=1;$i<=$num_invited;$i++) {
    $var = "invited_username".$i;
    $invited_username = $_POST[$var];
    // IF FIELD IS NOT BLANK, CHECK IF USER WITH THIS USERNAME EXISTS AND IS NOT ALREADY A MEMBER OF THE adsandpages
    if(str_replace(" ", "", $invited_username) != "") {
      $invited_query = $database->database_query("SELECT se_users.user_id, se_users.user_username, se_users.user_email, se_usersettings.usersetting_notify_adsandpagesinvite FROM se_users LEFT JOIN se_usersettings ON se_users.user_id=se_usersettings.usersetting_user_id LEFT JOIN se_adsandpagesmembers ON se_users.user_id=se_adsandpagesmembers.adsandpagesmember_user_id AND se_adsandpagesmembers.adsandpagesmember_adsandpages_id='$adsandpages_id' WHERE se_users.user_username='$invited_username' AND se_adsandpagesmembers.adsandpagesmember_id IS NULL LIMIT 1");
      if($database->database_num_rows($invited_query) == 1) {
	$invited_info = $database->database_fetch_assoc($invited_query);
	$database->database_query("INSERT INTO se_adsandpagesmembers (adsandpagesmember_user_id, 
								adsandpagesmember_adsandpages_id, 
								adsandpagesmember_status,
								adsandpagesmember_approved) VALUES (
								'$invited_info[user_id]',
								'$adsandpages_id',
								'0',
								'1')");
	// SEND INVITE EMAIL
        if($invited_info[usersetting_notify_adsandpagesinvite] == 1) { send_generic($invited_info[user_email], "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>", $setting[setting_email_adsandpagesinvite_subject], $setting[setting_email_adsandpagesinvite_message], Array('[username]', '[adsandpagesname]', '[link]'), Array($invited_info[user_username], $adsandpages->adsandpages_info[adsandpages_title], "<a href=\"".$url->url_base."login.php\">".$url->url_base."login.php</a>")); }
	$invited_count_success++;
      }
    }
  }

  $result = "$invited_count_success $user_adsandpages_edit_invite[1]";
}






// RUN VALIDATION FOR UNINVITE, APPROVE, OR REJECT MEMBER TASKS
if($task == "uninvite" OR $task == "approve" OR $task == "reject") {
  // MAKE SURE adsandpages MEMBER ID EXISTS IN TABLE
  $adsandpagesmember_id = $_GET['adsandpagesmember_id'];
  $adsandpagesmember_query = $database->database_query("SELECT adsandpagesmember_id, adsandpagesmember_adsandpages_id, adsandpagesmember_user_id, adsandpagesmember_status, adsandpagesmember_approved FROM se_adsandpagesmembers WHERE adsandpagesmember_id='$adsandpagesmember_id' AND adsandpagesmember_adsandpages_id='".$adsandpages->adsandpages_info[adsandpages_id]."' LIMIT 1");
  if($database->database_num_rows($adsandpagesmember_query) != 1) { header("Location: user_adsandpages_edit_invite.php?adsandpages_id=".$adsandpages->adsandpages_info[adsandpages_id]); exit; }
  $adsandpagesmember_info = $database->database_fetch_assoc($adsandpagesmember_query);
}

// UNINVITE MEMBER
if($task == "uninvite") {
  // MAKE SURE adsandpages MEMBER BELONGS TO THIS adsandpages AND HAS STATUS=0, APPROVED=1
  if($adsandpagesmember_info[adsandpagesmember_status] == 0 OR $adsandpagesmember_info[adsandpagesmember_approved] == 1) { 
    $database->database_query("DELETE FROM se_adsandpagesmembers WHERE adsandpagesmember_id='$adsandpagesmember_info[adsandpagesmember_id]' LIMIT 1");
    $result2 = $user_adsandpages_edit_invite[2];
  }
}

// APPROVE MEMBER
if($task == "approve") {
  // MAKE SURE adsandpages MEMBER BELONGS TO THIS adsandpages AND HAS STATUS=0, APPROVED=0
  if($adsandpagesmember_info[adsandpagesmember_status] == 0 OR $adsandpagesmember_info[adsandpagesmember_approved] == 0) { 
    $database->database_query("UPDATE se_adsandpagesmembers SET adsandpagesmember_status='1', adsandpagesmember_approved='1' WHERE adsandpagesmember_id='$adsandpagesmember_info[adsandpagesmember_id]' LIMIT 1");
    $result = $user_adsandpages_edit_invite[3];

    // INSERT ACTION
    $new_member = new se_user(Array($adsandpagesmember_info[adsandpagesmember_user_id]));
    $adsandpages_title_short = $adsandpages->adsandpages_info[adsandpages_title];
    if(strlen($adsandpages_title_short) > 100) { $adsandpages_title_short = substr($adsandpages_title_short, 0, 97); $adsandpages_title_short .= "..."; }
    $actions->actions_add($new_member, "joinadsandpages", Array('[username]', '[id]', '[title]'), Array($new_member->user_info[user_username], $adsandpages->adsandpages_info[adsandpages_id], $adsandpages_title_short));
  }
}

// REJECT MEMBER
if($task == "reject") {
  // MAKE SURE adsandpages MEMBER BELONGS TO THIS adsandpages AND HAS STATUS=0, APPROVED=0
  if($adsandpagesmember_info[adsandpagesmember_status] == 0 OR $adsandpagesmember_info[adsandpagesmember_approved] == 0) { 
    $database->database_query("DELETE FROM se_adsandpagesmembers WHERE adsandpagesmember_id='$adsandpagesmember_info[adsandpagesmember_id]' AND adsandpagesmember_adsandpages_id='$adsandpagesmember_info[adsandpagesmember_adsandpages_id]' LIMIT 1");
    $result2 = $user_adsandpages_edit_invite[4];
  }
}

// GET MEMBERS AWAITING APPROVAL
$where = "(se_adsandpagesmembers.adsandpagesmember_status='0' AND se_adsandpagesmembers.adsandpagesmember_approved='0')";
$unapproved_users_total = $adsandpages->adsandpages_member_total($where);
$unapproved_array = $adsandpages->adsandpages_member_list(0, $unapproved_users_total, "adsandpagesmember_id DESC", $where);

// GET INVITED USERS
$where = "(se_adsandpagesmembers.adsandpagesmember_status='0' AND se_adsandpagesmembers.adsandpagesmember_approved='1')";
$invited_users_total = $adsandpages->adsandpages_member_total($where);
$invited_array = $adsandpages->adsandpages_member_list(0, $invited_users_total, "adsandpagesmember_id DESC", $where);

// GET LIST OF FRIENDS FOR SUGGEST BOX
$total_friends = $user->user_friend_total(0);
$friends = $user->user_friend_list(0, $total_friends, 0);

// ASSIGN SMARTY VARIABLES AND DISPLAY EDIT INVITE PAGE
$smarty->assign('result', $result);
$smarty->assign('result2', $result2);
$smarty->assign('adsandpages', $adsandpages);
$smarty->assign('invited', $invited_array);
$smarty->assign('unapproved', $unapproved_array);
$smarty->assign('friends', $friends);
include "footer.php";
?>