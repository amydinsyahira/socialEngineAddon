window.addEvent('domready',function(){

		//SAMPLE 8
		var hs8 = new noobSlide({
			box: $('box8'),
			startItem: 1,
			items: $ES('table','box8'),
			size: 500,
			//handles: $ES('span','handles8'),
			buttons: {previous: $('prev8'), next: $('next8') },
			onWalk: function(currentItem,currentHandle){
				//style for handles
				//this.handles.extend(handles8_more).removeClass('active');
				//$$(currentHandle,handles8_more[this.currentIndex]).addClass('active');
				//text for "previous" and "next" default buttons
				//$('prev8').setHTML('&lt;&lt; '+this.items[this.previousIndex].innerHTML);
				//$('next8').setHTML(this.items[this.nextIndex].innerHTML+' &gt;&gt;');
			}
		});
		//more "previous" and "next" buttons
		hs8.addActionButtons('previous',$ES('.prev','box8'));
		hs8.addActionButtons('next',$ES('.next','box8'));
		//more handle buttons
		//var handles8_more = $ES('span','handles8_more');
		//hs8.addHandleButtons(handles8_more);
		//
		hs8.walk(0)

	});