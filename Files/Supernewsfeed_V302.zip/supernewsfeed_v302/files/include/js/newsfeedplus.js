


/*** LIKES ***/

// TODO: cange like/unlike
function newsfeedplus_like(elem_id) {
  if((newsfeedplus_points == 1) && (newsfeedplus_points_rememberchoice == 0)) {
	mooFaceboxExShow("", "user_newsfeedplus_points.php?task=points&action_id="+elem_id, 370);
	return;
  }
  new SEMods.NewsfeedPlusPoster(elem_id).post_like(1);
}


function newsfeedplus_like_and_give(action_id) {
  var points = SEMods.B.ge('newsfeedplus_givepoints').value;
  // "other"
  if(points == "") {
	points = SEMods.B.ge('newsfeedplus_pointsother').value;
  }
  var remember_choice = SEMods.B.ge('newsfeedplus_remember').checked ? 1 : 0;
  parent.newsfeedplus_like_withpoints(action_id, points, remember_choice);
}


function newsfeedplus_like_withpoints(action_id, points, remember_choice) {
  newsfeedplus_points_rememberchoice = remember_choice;
  new SEMods.NewsfeedPlusPoster(action_id).post_like(1,points,remember_choice);
}


function newsfeedplus_givepoints_onChange() {
  var points = SEMods.B.ge('newsfeedplus_givepoints').value;
  if(points == "") {
	SEMods.B.hide("newsfeedplus_givepoints");
	SEMods.B.show("newsfeedplus_pointsother_holder");
	SEMods.B.ge("newsfeedplus_pointsother").focus();
  }
}

function newsfeedplus_unlike(elem_id) {
  new SEMods.NewsfeedPlusPoster(elem_id).post_unlike();
}


function newsfeedplus_load_likes(elem_id) {
  new SEMods.NewsfeedPlusPoster(elem_id).load_likes(elem_id);
}

function newsfeedplus_load_comments(elem_id) {
  new SEMods.NewsfeedPlusPoster(elem_id).load_comments(elem_id);
}

function newsfeedplus_comment_onFocus(elem_id) {
  var input_elem = SEMods.B.ge("newsfeedplus_comment_" + elem_id);
  if(input_elem.value == newsfeedplus_lang_writecomment) {
	SEMods.B.ge("newsfeedplus_comment_" + elem_id).value = "";;
	SEMods.B.ge("newsfeedplus_comment_" + elem_id).className = "textarea newsfeedplus_comment_active";
  }
  
  controller = newsfeedplus_autogrow('newsfeedplus_comment_' + elem_id);
  SEMods.B.show('newsfeedplus_commentpost_' + elem_id);
  if(controller) {
	controller.onFocus();
  }
}


function newsfeedplus_comment_onBlur(elem_id) {
  var input_elem = SEMods.B.ge("newsfeedplus_comment_" + elem_id);
  if(input_elem.value == "") {
	SEMods.B.hide('newsfeedplus_commentpost_' + elem_id);
	input_elem.value = newsfeedplus_lang_writecomment;
	SEMods.B.ge("newsfeedplus_comment_" + elem_id).className = "textarea newsfeedplus_comment";
  }
}


function newsfeedplus_cancelcomment(elem_id) {
  SEMods.B.hide('newsfeedplus_commentpost_' + elem_id);
  SEMods.B.hide('newsfeedplus_commentpost_' + elem_id);
  SEMods.B.ge("newsfeedplus_comment_" + elem_id).value = newsfeedplus_lang_writecomment;
  SEMods.B.ge("newsfeedplus_comment_" + elem_id).className = "textarea newsfeedplus_comment";
}

function newsfeedplus_comment(elem_id) {
  //var input_elem = SEMods.B.ge("newsfeedplus_comment_" + elem_id);
  SEMods.B.show("newsfeedplus_comment_" + elem_id);
  SEMods.B.ge("newsfeedplus_comment_" + elem_id).focus();
}



function newsfeedplus_editcomment(elem_id, comment_id) {
  this.edit_obj = null;
  
  if(this.edit_obj == null) {
	this.edit_obj = SEMods.B.ge("newsfeedplus_editcomment_wrapper");
	this.textarea_obj = SEMods.B.ge("newsfeedplus_editcomment");
	this.textarea_obj.className = "newsfeedplus_textarea newsfeedplus_comment";
	controller = newsfeedplus_autogrow(this.textarea_obj);
  }
  
  SEMods.B.hide("newsfeedplus_comment_body_"+elem_id+"_"+comment_id);

  var comment_elem = SEMods.B.ge("newsfeedplus_comment_body_"+elem_id+"_"+comment_id);
  var wrapper = SEMods.B.ge("newsfeedplus_comment_body_wrapper_"+elem_id+"_"+comment_id);

  this.textarea_obj.value = comment_elem.innerHTML;
  this.textarea_obj.className = "newsfeedplus_textarea newsfeedplus_comment_active";
  wrapper.appendChild(this.edit_obj);
  this.edit_obj.style.display = "";
  this.textarea_obj.focus();
}



function newsfeedplus_deletecomment(elem_id,comment_id) {
  elem = SEMods.B.ge("newsfeedplus_commentitem_" + elem_id + "_" + comment_id);
  if(elem) {
	elem.parentNode.removeChild(elem);
  }
  new SEMods.NewsfeedPlusPoster(elem_id).remove_comment(comment_id);
}


function newsfeedplus_submitcomment(elem_id) {
  var input_elem = SEMods.B.ge("newsfeedplus_comment_" + elem_id);
  var comment = encodeURIComponent(input_elem.value);
  input_elem.value = newsfeedplus_lang_writecomment;
  input_elem.className = "textarea newsfeedplus_comment";
  new SEMods.NewsfeedPlusPoster(elem_id).post_comment(comment);
}


SEMods.NewsfeedPlusEditor = function() {
};


// Singleton
SEMods.NewsfeedPlusEditor = {
  elem_id : '',
  instance_id : '',
  action_id : 0,
  comment_id : 0,
  edit_obj : null,
  textarea_obj : null,
  editing : false,
  updating : false,

  edit_comment : function (elem_id, comment_id) {
	
	if(this.updating) {
	  return;
	}
	
	this.cancel_comment();
	
	this.elem_id = elem_id;
	//this.action_id = newsfeedplus_get_action_id(elem_id);
	if (elem_id.indexOf('_') != -1) {
	  this.action_id = elem_id.split('_')[0];
	  this.instance_id = elem_id.split('_')[1];
	} else {
	this.action_id = elem_id;
	}

	this.comment_id = comment_id;
	this.editing = true;
	
	edit_obj = SEMods.NewsfeedPlusEditor.edit_obj;
	
	if(edit_obj == null) {
	  edit_obj = SEMods.B.ge("newsfeedplus_editcomment_wrapper");
	  textarea_obj = SEMods.B.ge("newsfeedplus_editcomment");
	  textarea_obj.className = "newsfeedplus_textarea newsfeedplus_comment";
	  controller = newsfeedplus_autogrow(textarea_obj);
	  SEMods.NewsfeedPlusEditor.textarea_obj = textarea_obj;
	  SEMods.NewsfeedPlusEditor.edit_obj = edit_obj;
	}
	
	textarea_obj = SEMods.NewsfeedPlusEditor.textarea_obj;
	
	SEMods.B.hide("newsfeedplus_comment_body_"+elem_id+"_"+comment_id);
  
	SEMods.NewsfeedPlusEditor.comment_elem = SEMods.B.ge("newsfeedplus_comment_body_"+elem_id+"_"+comment_id);
	SEMods.NewsfeedPlusEditor.wrapper = SEMods.B.ge("newsfeedplus_comment_body_wrapper_"+elem_id+"_"+comment_id);
  
	textarea_obj.disabled = false;
	textarea_obj.value = SEMods.NewsfeedPlusEditor.comment_elem.innerHTML;
	textarea_obj.className = "newsfeedplus_textarea newsfeedplus_comment_active";
	SEMods.NewsfeedPlusEditor.wrapper.appendChild(edit_obj);
	SEMods.B.show("newsfeedplus_editcomment_post");
	edit_obj.style.display = "";
	textarea_obj.focus();
  },

  cancel_comment : function () {
	if(SEMods.NewsfeedPlusEditor.editing) {
	  SEMods.NewsfeedPlusEditor.wrapper.removeChild(SEMods.NewsfeedPlusEditor.edit_obj);
	  SEMods.B.show(SEMods.NewsfeedPlusEditor.comment_elem);
	  SEMods.NewsfeedPlusEditor.editing = false;
	}
  },
  
  update_comment : function () {
	SEMods.NewsfeedPlusEditor.updating = true;
	
	var comment = encodeURIComponent(SEMods.NewsfeedPlusEditor.textarea_obj.value);
	SEMods.NewsfeedPlusEditor.textarea_obj.disabled = true;

	SEMods.B.hide('newsfeedplus_editcomment_post');

	var ajax = new SEMods.Ajax(SEMods.NewsfeedPlusEditor.onUpdateSuccess, SEMods.NewsfeedPlusEditor.onUpdateFail);
	var params = "task=updatecomment&comment="+comment+"&action_id="+SEMods.NewsfeedPlusEditor.action_id+"&comment_id="+SEMods.NewsfeedPlusEditor.comment_id;
	ajax.post(newsfeedplus_actionurl,params);
  },
  
  onUpdateSuccess : function( obj, responseText ) {

    var r = [];
    try {
      r = eval('(' + responseText + ')')
    } catch(e) {
      r.status = 1;
    };
    if (r.status == 0) {
	  SEMods.NewsfeedPlusEditor.comment_elem.innerHTML = SEMods.NewsfeedPlusEditor.textarea_obj.value;
    } else {
      //error
	  // apps_show_error_message(r.err_msg ? r.err_msg: '')
    }

	SEMods.NewsfeedPlusEditor.updating = false;
	SEMods.NewsfeedPlusEditor.cancel_comment();
	
  },

  onUpdateFail : function( obj, responseText ) {
	SEMods.NewsfeedPlusEditor.updating = false;
	SEMods.NewsfeedPlusEditor.cancel_comment();
  }
  
}

function newsfeedplus_get_action_id(elem_id) {
  if (elem_id.indexOf('_') != -1) {
    return elem_id.split('_')[0];
  }
  return elem_id;
}


SEMods.NewsfeedPlusPoster = function(elem_id) {
  this.elem_id = elem_id;
  //this.action_id = newsfeedplus_get_action_id(elem_id);
  if (elem_id.indexOf('_') != -1) {
    this.action_id = elem_id.split('_')[0];
    this.instance_id = elem_id.split('_')[1];
  } else {
    this.action_id = elem_id;
  }

};


SEMods.NewsfeedPlusPoster.prototype = {
  elem_id : '',
  instance_id : '',
  action_id : 0,
  
  post_comment : function(comment) {
	SEMods.B.hide('newsfeedplus_commentpost_' + this.elem_id);
	SEMods.B.hide('newsfeedplus_comment_' + this.elem_id);
	SEMods.B.show('newsfeedplus_commentpost_progress_' + this.elem_id);

	var ajax = new SEMods.Ajax(this.onPostSuccess.bind(this), this.onPostFail.bind(this));
	var params = "task=postcomment&comment="+comment+"&action_id="+this.action_id+"&instance_id="+this.instance_id;
	ajax.post(newsfeedplus_actionurl,params);
  },
  
  remove_comment : function(comment_id) {
	//var ajax = new SEMods.Ajax(this.onPostSuccess.bind(this), this.onPostFail.bind(this));
	var ajax = new SEMods.Ajax();
	var params = "task=deletecomment&comment_id="+comment_id+"&action_id="+this.action_id+"&instance_id="+this.instance_id;
	ajax.post(newsfeedplus_actionurl,params);
  },
  
  onPostSuccess : function( obj, responseText ) {
	SEMods.B.hide('newsfeedplus_commentpost_progress_' + this.elem_id);
	SEMods.B.show('newsfeedplus_comment_' + this.elem_id);
	
    var r = [];
    try {
      r = eval('(' + responseText + ')')
    } catch(e) {
      r.status = 1;
    };
    if (r.status == 0) {
	  var elem = document.createElement("DIV");
	  elem.innerHTML = r.html;
	  SEMods.B.ge('newsfeedplus_comments_'+this.elem_id).appendChild(elem);

	  // try all other instances - not good - incorrect instance
	//  if(this.instance_id != '') {
	//	for(var i=0;i<=10;i++) {
	//	  if(SEMods.B.ge('newsfeedplus_comments_'+this.action_id + '_' + i)) {
	//		elem = document.createElement("DIV");
	//		elem.innerHTML = r.html;
	//		SEMods.B.ge('newsfeedplus_comments_'+this.action_id + '_' + i).appendChild(elem);
	//	  }
	//	}
	//  }
	  
    } else {
      //error
	  // apps_show_error_message(r.err_msg ? r.err_msg: '')
    }
	
  },
  
  onPostFail : function( obj, responseText ) {
	SEMods.B.hide('newsfeedplus_commentpost_progress_' + this.elem_id);
	SEMods.B.show('newsfeedplus_comment_' + this.elem_id);
  },
  
  
  

  post_like : function(like, points, remember_choice) {
	var ajax = new SEMods.Ajax(this.onPostLikeSuccess.bind(this), this.onPostLikeFail.bind(this));
	var params = "task=like&like="+like+"&action_id="+this.action_id+"&instance_id="+this.instance_id;
	if(typeof points != "undefined") {
	  params += '&points='+points+'&remember='+remember_choice;
	}
	ajax.post(newsfeedplus_actionurl,params);
  },


  
  onPostLikeSuccess : function( obj, responseText ) {
	
    var r = [];
    try {
      r = eval('(' + responseText + ')')
    } catch(e) {
      r.status = 1;
    };
    if (r.status == 0) {
	  var elem = document.createElement("DIV");
	  elem.innerHTML = r.html;
	  SEMods.B.ge('newsfeedplus_likes_'+this.elem_id).appendChild(elem);

	  elem = SEMods.B.ge('newsfeedplus_unlike_'+this.elem_id);
	  if(elem) {
		elem.style.display = "";
	  }
	  SEMods.B.hide('newsfeedplus_ilike_'+this.elem_id);

	  // try all other instances - not good - incorrect instance
	  if(this.instance_id != '') {
		for(var i=0;i<=10;i++) {
		  if($('newsfeedplus_unlike_'+this.action_id + '_' + i)) {
			$('newsfeedplus_unlike_'+this.action_id + '_' + i).style.display = "";
			SEMods.B.hide('newsfeedplus_ilike_'+this.action_id + '_' + i);
		  }
		}
	  }
	  
    } else {
      //error
	  // apps_show_error_message(r.err_msg ? r.err_msg: '')
    }
	
  },
  
  onPostLikeFail : function( obj, responseText ) {
  },




  post_unlike : function(like) {

	var ajax = new SEMods.Ajax(this.onPostUnLikeSuccess.bind(this), this.onPostUnLikeFail.bind(this));
	var params = "task=unlike"+"&action_id="+this.action_id+"&instance_id="+this.instance_id;
	ajax.post(newsfeedplus_actionurl,params);
  },
  
  onPostUnLikeSuccess : function( obj, responseText ) {
	
    var r = [];
    try {
      r = eval('(' + responseText + ')')
    } catch(e) {
      r.status = 1;
    };
    if (r.status == 0) {
	  
	  elem = SEMods.B.ge('newsfeedplus_likeitem_'+this.elem_id+'_'+r.user_id);
	  if(elem) {
		elem.parentNode.removeChild(elem);
	  }
	  SEMods.B.hide('newsfeedplus_unlike_'+this.elem_id);
	  elem = SEMods.B.ge('newsfeedplus_ilike_'+this.elem_id);
	  if(elem) {
		elem.style.display = "";
	  }

	  if(this.instance_id != '') {
		for(var i=0;i<=10;i++) {
		  if($('newsfeedplus_ilike_'+this.action_id + '_' + i)) {
			$('newsfeedplus_ilike_'+this.action_id + '_' + i).style.display = "";
			SEMods.B.hide('newsfeedplus_unlike_'+this.action_id + '_' + i);
		  }
		}
	  }
	  
    } else {
      //error
	  // apps_show_error_message(r.err_msg ? r.err_msg: '')
    }
	
  },
  
  onPostUnLikeFail : function( obj, responseText ) {
  },




  load_likes : function(action_id) {

	var ajax = new SEMods.Ajax(this.onLoadLikesSuccess.bind(this), this.onLoadLikesFail.bind(this));
	var params = "task=loadlikes"+"&action_id="+this.action_id+"&instance_id="+this.instance_id;
	ajax.post(newsfeedplus_actionurl,params);
  },
  
  onLoadLikesSuccess : function( obj, responseText ) {
	
    var r = [];
    try {
      r = eval('(' + responseText + ')')
    } catch(e) {
      r.status = 1;
    };
    if (r.status == 0) {
	  SEMods.B.ge('newsfeedplus_likes_'+this.elem_id).innerHTML = r.html;
    } else {
      //error
	  // apps_show_error_message(r.err_msg ? r.err_msg: '')
    }
	
  },
  
  onLoadLikesFail : function( obj, responseText ) {
  },
  

  load_comments : function(action_id) {

	var ajax = new SEMods.Ajax(this.onLoadCommentsSuccess.bind(this), this.onLoadCommentsFail.bind(this));
	var params = "task=loadcomments"+"&action_id="+this.action_id+"&instance_id="+this.instance_id;
	ajax.post(newsfeedplus_actionurl,params);
  },
  
  onLoadCommentsSuccess : function( obj, responseText ) {
	
    var r = [];
    try {
      r = eval('(' + responseText + ')')
    } catch(e) {
      r.status = 1;
    };

    if (r.status == 0) {

	  SEMods.B.ge('newsfeedplus_comments_'+this.elem_id).innerHTML = r.html;

    } else {
      //error
	  // apps_show_error_message(r.err_msg ? r.err_msg: '')
    }
	
  },
  
  onLoadCommentsFail : function( obj, responseText ) {
  }
  
  
  
}


function newsfeedplus_autogrow(elementid) {
  var el = SEMods.Browser.ge(elementid);
  if(!el) SEMods.Utils.debug("textarea_autogrow(): element not found");
  if(el && !el._controlled) {
	el._controlled = true;
	el._controller = new SEMods.TextAreaControl(el);
	el._controller.setAutoGrow(true);
	return el._controller;
  }
  return false;
};
