<?php


// MAX COMMENTS BEFORE COLLAPSING
//define('NEWSFEEDPLUS_MAX_COMMENTS',3);

// MAX LIKES BEFORE COLLAPSING
//define('NEWSFEEDPLUS_MAX_LIKES',4);



/*
 * Purpose - delete user data when user is deleted
 *
 */
function deleteuser_newsfeedplus($user_id) {

  // delete comments
  semods::db_query("DELETE FROM se_semods_newsfeedplus WHERE newsfeedplus_user_id = $user_id");

  // delete likes
  semods::db_query("DELETE FROM se_semods_newsfeedpluslikes WHERE newsfeedpluslike_user_id = $user_id");

}



function newsfeedplus_hook_header() {
  global $user, $page, $task, $setting;
  
  
  if($task == "action_delete") {
    
    $action_id = semods::getpost('action_id');

    // MUST BE LOGGED IN TO USE THIS TASK, MAKE SURE USERS ARE ALLOWED TO DELETE ACTIONS
    if( !$user->user_exists || !$action_id || !$setting['setting_actions_selfdelete'] ) {
      return;
    }
    
    newsfeedplus_deleteaction($action_id);
    
  }
  
}


// admin - no caching
function  newsfeedplus_load_all_comments($p, $max_items, $filter_actiontype, $filter_user, $filter_withcomments, $filter_comment) {
  global $smarty;
  global $database;
  global $setting;

  $filters = array();
  $filter_actiontype != "" ? $filters[] = "action_actiontype_id = $filter_actiontype" : 0;
  $filter_comment != "" ? $filters[] = "newsfeedplus_comment LIKE '%$filter_comment%'" : 0;
  
  if($filter_user != "" && $setting['setting_username']) {
    $filters[] = "(U.user_username LIKE '%$filter_user%' OR U1.user_username LIKE '%$filter_user%')";
  } elseif($filter_user != "" && !$setting['setting_username']) {
    $filters[] = "((U.user_fname LIKE '%$filter_user%' OR U.user_lname LIKE '%$filter_user%') OR (U1.user_fname LIKE '%$filter_user%' OR U1.user_lname LIKE '%$filter_user%'))";
  }

  $filter_withcomments == 1 ? $filters[] = "newsfeedplus_id IS NOT NULL" : 0;
  
  $newsfeedplus_comments = array();
  

  $sql_count = "SELECT COUNT(*)";

  $sql_head = "SELECT U.*, P.*, se_actions.*, se_actiontypes.actiontype_icon, se_actiontypes.actiontype_text, se_actiontypes.actiontype_media ";

  $sql_body = "
          FROM se_actions 
          LEFT JOIN se_semods_newsfeedplus P
            ON se_actions.action_id = P.newsfeedplus_action_id
          LEFT JOIN se_actiontypes
            ON se_actions.action_actiontype_id=se_actiontypes.actiontype_id
          LEFT JOIN se_users U
            ON U.user_id = P.newsfeedplus_user_id
          ";

  if($filter_user != "") {
    $sql_body .= "LEFT JOIN se_users U1
            ON U1.user_id = se_actions.action_user_id AND se_actions.action_object_owner = 'user' 
          ";
  }
  
  if(!empty($filters)) {
  
    $filters = implode(' AND ',$filters);
    $sql_body .= ' WHERE ' . $filters;
          
  }

  $sql = $sql_count . $sql_body;


  $actions_per_page = $max_items;
  
  $total_actions = semods::db_query_count($sql);
  
  $page_vars = make_page($total_actions, $actions_per_page, $p);

  $page_array = Array();
  for($x=0;$x<=$page_vars[2]-1;$x++) {
    if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
    $page_array[$x] = Array('page' => $x+1,
                            'link' => $link);
  }

  $sql_footer = "  ORDER BY action_date DESC LIMIT {$page_vars[0]}, $actions_per_page";
  
  $sql = $sql_head . $sql_body . $sql_footer;


  //echo $sql;exit;
  $previous_action_id = 0;                 
  $rows = new semods_db_iterator_assoc($sql);
  while($action = $rows->next()) {

    // since the query pulls all in a big chunk, only process first action
    if($previous_action_id != $action['action_id']) {
       
      // action
      if( ($action_vars = unserialize($action['action_text']))===FALSE )
        $action_vars = mb_unserialize($action['action_text']);
  
      // REGISTER PRELOADED TEXT
      SE_Language::_preload($action['actiontype_text']);
  
      // RETRIEVE MEDIA IF NECESSARY
      $action_media = false;
      if($action['actiontype_media'] == 1)
      {
        $action_media = Array();
        $media = $database->database_query("SELECT * FROM se_actionmedia WHERE actionmedia_action_id={$action['action_id']}");
        while( $media_info = $database->database_fetch_assoc($media) )
        {
          $action_media[] = $media_info;
        }
      }
      
      $previous_action_id = $action['action_id'];

    } else {
      
      // flag for template to not display it
      $action['newsfeedplus_skip_action'] = 1;
      
    }
    
  
    semods_utils::create_user_photo($action,'../images/nophoto.gif',true);
    semods_utils::create_user_displayname_ex($action);

    $newsfeedplus_comments[] = array( 'comment'            => $action['newsfeedplus_comment'],
                                      'comment_id'         => $action['newsfeedplus_id'],
                                      'date'               => $action['newsfeedplus_date'],
                                      'is_owner'           => false,
                                      'user_photo'         => $action['user_photo'],
                                      'user_id'            => $action['user_id'],
                                      'user_username'      => $action['user_username'],
                                      'user_displayname'   => $action['user_displayname'],
                                      
                                      'skip_action'         => $action['newsfeedplus_skip_action'],

                                      'action_id'           => $action['action_id'],
                                      'action_date'         => $action['action_date'],
                                      'action_text'         => $action['actiontype_text'],
                                      'action_vars'         => $action_vars,
                                      'action_user_id'      => $action['action_user_id'],
                                      'action_username'     => $action_username_info['user_username'],    // WTF is this?
                                      'action_icon'         => $action['actiontype_icon'],
                                      'action_media'        => $action_media
                                      
                                      );
  }

  //return $newsfeedplus_comments;
  return array( 'actions'     => $newsfeedplus_comments,
                'page_vars'   => $page_vars,
                'page_array'  => $page_array,
                'total_actions'  => $total_actions
              );
}





function newsfeedplus_submitcomment($action_id, $comment) {
  global $user, $database, $setting;

  // MAKE SURE COMMENT BODY IS NOT EMPTY - ADD BREAKS AND CENSOR
  $comment = str_replace("\r\n", "<br>", cleanHTML(censor($comment), $setting['setting_comment_html'], Array("style")));
  $comment = preg_replace('/(<br>){3,}/is', '<br><br>', $comment);
  $comment = str_replace("'", "\'", $comment);
  if(trim($comment) == "") {
    return false;
  }

  $now = time();

  semods::db_query("INSERT INTO se_semods_newsfeedplus (
                   newsfeedplus_action_id,
                   newsfeedplus_user_id,
                   newsfeedplus_comment,
                   newsfeedplus_date
                   ) VALUES (
                   $action_id,
                   {$user->user_info['user_id']},
                   '$comment',
                   '$now'           
                   )
                   ");
  
  $comment_id = $database->database_insert_id();

  // caching - destroy cache key
  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');

    if( is_object($cache_object) ) {
      $cache_key = "newsfeedplus_".$action_id;
      $cache_object->remove($cache_key);
    }
  }
  
  // email to action "owner"  - TBD: "userxx" commented on your status
  $action_owner_user_id = semods::db_query_count("SELECT action_user_id FROM se_actions WHERE action_id = $action_id");
  if($action_owner_user_id) {
    newsfeedplus_email_commented($action_owner_user_id, $user);
  }
  
  $comment_item = array('comment'            => $comment,
                        'comment_id'         => $comment_id,
                        'date'               => $now,
                        'is_owner'           => true,
                        'user_photo'         => $user->user_photo('./images/nophoto.gif',TRUE),
                        'user_id'            => $user->user_info['user_id'],
                        'user_username'      => $user->user_info['user_username'],
                        'user_displayname'   => $user->user_displayname
                        );

  return $comment_item;  
}




function newsfeedplus_updatecomment($action_id, $comment_id, $comment) {
  global $user, $database, $setting, $admin;

  // MAKE SURE COMMENT BODY IS NOT EMPTY - ADD BREAKS AND CENSOR
  $comment = str_replace("\r\n", "<br>", cleanHTML(censor($comment), $setting['setting_comment_html'], Array("style")));
  $comment = preg_replace('/(<br>){3,}/is', '<br><br>', $comment);
  $comment = str_replace("'", "\'", $comment);
  if(trim($comment) == "") {
    return false;
  }

  $now = time();

  // super moderator
  if($admin->admin_exists) {
    semods::db_query("UPDATE se_semods_newsfeedplus SET newsfeedplus_comment = '$comment' WHERE newsfeedplus_id = $comment_id");
  } else {
    semods::db_query("UPDATE se_semods_newsfeedplus SET newsfeedplus_comment = '$comment' WHERE newsfeedplus_id = $comment_id AND newsfeedplus_user_id = {$user->user_info['user_id']}");
  }
  
  // caching - destroy cache key
  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');

    if( is_object($cache_object) ) {
      $cache_key = "newsfeedplus_".$action_id;
      $cache_object->remove($cache_key);
    }
  }
  
  return true;  
}


function newsfeedplus_deleteaction($action_id) {
  global $user;
  global $admin;

  // supermoderator 
  if($admin->admin_exists) {

    // comments and likes
    semods::db_query("DELETE FROM se_semods_newsfeedplus, se_semods_newsfeedpluslikes
                      USING se_actions
                      LEFT JOIN se_semods_newsfeedplus
                        ON se_actions.action_id = se_semods_newsfeedplus.newsfeedplus_action_id
                      LEFT JOIN se_semods_newsfeedpluslikes
                        ON se_actions.action_id = se_semods_newsfeedpluslikes.newsfeedpluslike_action_id
                      WHERE action_id='{$action_id}'
                      ");
  
  } else {

    // comments and likes
    semods::db_query("DELETE FROM se_semods_newsfeedplus, se_semods_newsfeedpluslikes
                      USING se_actions
                      LEFT JOIN se_semods_newsfeedplus
                        ON se_actions.action_id = se_semods_newsfeedplus.newsfeedplus_action_id
                      LEFT JOIN se_semods_newsfeedpluslikes
                        ON se_actions.action_id = se_semods_newsfeedpluslikes.newsfeedpluslike_action_id
                      WHERE action_id='{$action_id}' AND action_user_id='{$user->user_info['user_id']}'
                      ");
    
    
  }

  // caching - destroy cache key
  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');

    if( is_object($cache_object) ) {
      $cache_key = "newsfeedplus_".$action_id;
      $cache_object->remove($cache_key);

      $cache_key = "newsfeedpluslikes_".$action_id;
      $cache_object->remove($cache_key);
    }
  }

}

function newsfeedplus_deletecomment($action_id, $comment_id) {
  global $user;
  global $admin;

  // supermoderator 
  if($admin->admin_exists) {
    semods::db_query("DELETE FROM se_semods_newsfeedplus WHERE newsfeedplus_id = {$comment_id}");
  } else {
    semods::db_query("DELETE FROM se_semods_newsfeedplus
                      USING se_actions
                      LEFT JOIN se_semods_newsfeedplus
                        ON se_actions.action_id = se_semods_newsfeedplus.newsfeedplus_action_id
                      WHERE action_id = $action_id
                        AND (newsfeedplus_user_id = {$user->user_info['user_id']} OR action_user_id = {$user->user_info['user_id']} )
                        ");
  }

  // caching - destroy cache key
  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');

    if( is_object($cache_object) ) {
      $cache_key = "newsfeedplus_".$action_id;
      $cache_object->remove($cache_key);
    }
  }
  
}


function newsfeedplus_award_points($sender, $receiver_user_id, $points_amount) {
  global $url;
  global $global_plugins;
  global $newsfeedplus_points;
  
  if(!$newsfeedplus_points) {
    return false;
  }

  // check receiver exists
  $receiver_user = new se_user( array($receiver_user_id) );
  if($receiver_user->user_exists == 0) {
    return false;
  }

  // TBD: check receiver has points?
  // receiver user has points enabled
  //if( (($receiver_user->level_info['level_userpoints_allow'] == 0) || ($receiver_user->user_info['user_userpoints_allowed'] == 0)) {
  //  return false;
  //}

  // check points left
  if(!userpoints_deduct( $sender->user_info['user_id'], $points_amount ) ) {
    return false;
  }
  
  // if sending to yourself, don't count toward "total earned"
  $update_total_earned = $receiver_user_id != $sender->user_info['user_id'];
  
  // TBD: gaming
  //$update_total_earned = false;
  
  userpoints_add( $receiver_user_id,
                  $points_amount,
                  $update_total_earned // update or not "total points earned"
                );

  // LANGER
  
  // Transaction - Sender
  $transaction_id = userpoints_new_transaction( $sender->user_info['user_id'],
                                                0,
                                                2,
                                                0,
                                                //semods::get_language_text(100016064) . " <a href=\"". $url->url_create("profile", $ruser->user_info['user_username']) ."\">{$ruser->user_displayname}</a>",
                                                "Like and Give points to" . " <a href=\"". $url->url_create("profile", $receiver_user->user_info['user_username']) ."\">{$receiver_user->user_displayname}</a>",
                                                -$points_amount
                                               );

  // Transaction - Receiver
  $transaction_id = userpoints_new_transaction( $receiver_user_id,
                                                0,
                                                1,
                                                0,
                                                //semods::get_language_text(100016065) . "  <a href=\"". $url->url_create("profile", $sender->user_info['user_username']) ."\">{$sender->user_displayname}</a>",
                                                "<a href=\"". $url->url_create("profile", $sender->user_info['user_username']) ."\">{$sender->user_displayname}</a> " . "liked your action and sent you points",
                                                $points_amount
                                               );

  return true;
}


function newsfeedplus_submitlike($action_id, $like = 1, $points_amount = 0, $remember = 0) {
  global $user;

  // load from user settings
  if($remember == 777) {
    $points_amount = $user->usersetting_info['usersetting_newsfeedplus_likepoints'];
  }

  // save to user settings
  if($remember == 1) {
    semods::db_query("UPDATE se_usersettings SET usersetting_newsfeedplus_likepoints='$points_amount',usersetting_newsfeedplus_rememberchoice='1'  WHERE usersetting_user_id='{$user->user_info['user_id']}' LIMIT 1");
    
    $cache_object = SECache::getInstance();
    if( is_object($cache_object) )
    {
      $cache_object->remove('site_user_settings_'.$user->user_info['user_id']);
    }
  }
  
  // TBD: if duplicate "like" comes in, points will be awarded again, but "like" entry not
  if($points_amount > 0) {
    $action_owner_user_id = semods::db_query_count("SELECT action_user_id FROM se_actions WHERE action_id = $action_id");
    $points_awarded = newsfeedplus_award_points( $user, $action_owner_user_id, $points_amount );
  }
  
  if(!$points_awarded) {
    $points_amount = 0;
  }

  $now = time();

  $affected_rows = semods::db_query_affected_rows("INSERT IGNORE INTO se_semods_newsfeedpluslikes (
                                                    newsfeedpluslike_action_id,
                                                    newsfeedpluslike_user_id,
                                                    newsfeedpluslike_like,
                                                    newsfeedpluslike_date,
                                                    newsfeedpluslike_awardedpoints
                                                    ) VALUES (
                                                    $action_id,
                                                    {$user->user_info['user_id']},
                                                    $like,
                                                    '$now',
                                                    $points_amount
                                                    )
                                                    ");

  // already liked
  if($affected_rows == 0) {
    return false;
  }
  
  // caching - destroy cache key
  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');

    if( is_object($cache_object) ) {
      $cache_key = "newsfeedpluslikes_".$action_id;
      $cache_object->remove($cache_key);
    }
  }
  
  // email to action "owner"
  //if($action_owner_user_id) {
  //  newsfeedplus_email_liked($action_owner_user_id, $user);
  //}
  
  $like_item = array('user_displayname'   => $user->user_displayname,
                     'user_username'      => $user->user_info['user_username'],
                     'user_photo'         => $user->user_photo('./images/nophoto.gif',TRUE),
                     'user_id'            => $user->user_info['user_id'],
                     'like'               => $like,
                     'like_points'        => $points_amount,
                     'date'               => $now
                        );
  
  return $like_item;
  
}


function newsfeedplus_submitunlike($action_id) {
  global $user;
  
  semods::db_query("DELETE FROM se_semods_newsfeedpluslikes WHERE newsfeedpluslike_action_id AND newsfeedpluslike_user_id = {$user->user_info['user_id']}");
  
  // caching - destroy cache key
  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');

    if( is_object($cache_object) ) {
      $cache_key = "newsfeedpluslikes_".$action_id;
      $cache_object->remove($cache_key);
    }
  }
  
}


function  newsfeedplus_load_comments($action_id) {
  global $smarty;

  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');
  }

  if( is_object($cache_object) ) {
    $cache_key = "newsfeedplus_".$action_id;
    $cached_action = $cache_object->get($cache_key);

    if( is_array($cached_action) ) {
      return $cached_action;
    }
  }
  
  $newsfeedplus_comments = array();
  
  $sql = "SELECT *
          FROM se_semods_newsfeedplus P
          LEFT JOIN se_users U
            ON U.user_id = P.newsfeedplus_user_id
          WHERE
            newsfeedplus_action_id = $action_id
          ";
                   
  $rows = new semods_db_iterator_assoc($sql);
  while($row = $rows->next()) {
    semods_utils::create_user_photo($row,'./images/nophoto.gif',true);
    semods_utils::create_user_displayname_ex($row);
    $newsfeedplus_comments[] = array('comment'            => $row['newsfeedplus_comment'],
                                      'comment_id'         => $row['newsfeedplus_id'],
                                      'date'               => $row['newsfeedplus_date'],
                                      'is_owner'           => false,
                                      'user_photo'         => $row['user_photo'],
                                      'user_id'            => $row['user_id'],
                                      'user_username'      => $row['user_username'],
                                      'user_displayname'   => $row['user_displayname']
                                      );
  }


  // CACHE
  if( !empty($newsfeedplus_comments) && is_object($cache_object) ) {
    $cache_key = "newsfeedplus_".$action_id;
    $cache_object->store($newsfeedplus_comments, $cache_key);
  }

  return $newsfeedplus_comments;
}



function  newsfeedplus_load_likes($action_id) {
  global $smarty;

  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');
  }

  if( is_object($cache_object) ) {
    $cache_key = "newsfeedpluslikes_".$action_id;
    $cached_action = $cache_object->get($cache_key);

    if( is_array($cached_action) ) {
      return $cached_action;
    }
  }
  

  $newsfeedplus_likes = array();
  
  $sql = "SELECT *
          FROM se_semods_newsfeedpluslikes P
          LEFT JOIN se_users U
            ON U.user_id = P.newsfeedpluslike_user_id
          WHERE
            newsfeedpluslike_action_id = $action_id
          ";

  $rows = new semods_db_iterator_assoc($sql);
  while($row = $rows->next()) {
    semods_utils::create_user_photo($row,'./images/nophoto.gif',true);
    semods_utils::create_user_displayname_ex($row);
    $newsfeedplus_likes[] = array('like'               => $row['newsfeedpluslike_like'],
                                  'like_points'        => $row['newsfeedpluslike_awardedpoints'],
                                  'like_id'            => $row['newsfeedpluslike_id'],
                                  'date'               => $row['newsfeedpluslike_date'],
                                  'is_owner'           => false,
                                  'user_photo'         => $row['user_photo'],
                                  'user_id'            => $row['user_id'],
                                  'user_username'      => $row['user_username'],
                                  'user_displayname'   => $row['user_displayname']
                                  );
  }


  // CACHE
  if( !empty($newsfeedplus_likes) && is_object($cache_object) ) {
    $cache_key = "newsfeedpluslikes_".$action_id;
    $cache_object->store($newsfeedplus_likes, $cache_key);
  }

  return $newsfeedplus_likes;   
}




/*** LOAD HOOK ***/
function newsfeedplus_hook_load_newsfeedplus($actions_array = array(), $want_result = false) {
  global $smarty, $user;
  //global $actions_array, $smarty, $user;
  
  $actions_array = $smarty->_tpl_vars['actions'];
  
  $result = newsfeedplus_load_newsfeedplus($actions_array, $user);

  $smarty->assign('newsfeedplus_comments',$result['newsfeedplus_comments']);
  $smarty->assign('newsfeedplus_likes',$result['newsfeedplus_likes']);
  $smarty->assign('newsfeedplus_iliked',$result['newsfeedplus_iliked']);
}





function newsfeedplus_load_newsfeedplus($actions_array = array(), $user) {

  global $smarty;
  
  if(class_exists("SECache") ) {
    $cache_object = SECache::getInstance('serial');
  }

  /*** COMMENTS ***/
  
  $newsfeedplus_comments = array();
  $actions_list = array();
  foreach($actions_array as $action) {
    
    if( is_object($cache_object) ) {
      $cache_key = "newsfeedplus_".$action['action_id'];
      $cached_action = $cache_object->get($cache_key);

      if( is_array($cached_action) ) {
        $newsfeedplus_comments[$action['action_id']] = $cached_action;
        continue;
      }
      
    }

    $actions_list[] = $action['action_id'];  
  }
  
  if(!empty($actions_list)) {
  
    $actions_list_for_query = implode(',',$actions_list);
    $sql = "SELECT *
            FROM se_semods_newsfeedplus P
            LEFT JOIN se_users U
              ON U.user_id = P.newsfeedplus_user_id
            WHERE
              newsfeedplus_action_id IN ($actions_list_for_query)
            ";
                     
    $rows = new semods_db_iterator_assoc($sql);
    while($row = $rows->next()) {
      semods_utils::create_user_photo($row,'./images/nophoto.gif',true);
      semods_utils::create_user_displayname_ex($row);
      $newsfeedplus_comments[$row['newsfeedplus_action_id']][] = array('comment'            => $row['newsfeedplus_comment'],
                                                                       'comment_id'         => $row['newsfeedplus_id'],
                                                                       'date'               => $row['newsfeedplus_date'],
                                                                       'is_owner'           => false,
                                                                       'user_photo'         => $row['user_photo'],
                                                                       'user_id'            => $row['user_id'],
                                                                       'user_username'      => $row['user_username'],
                                                                       'user_displayname'   => $row['user_displayname']
                                                                       );
    }


    // CACHE
    if( is_object($cache_object) ) {
      foreach($actions_list as $action_id) {
        $cache_key = "newsfeedplus_".$action_id;
        if(isset($newsfeedplus_comments[$action_id])) {
          $cache_object->store($newsfeedplus_comments[$action_id], $cache_key);
        }
      }
    }
   
  }
  
  
  
  /*** LIKES ***/

  $newsfeedplus_likes = array();
  $actions_list = array();
  foreach($actions_array as $action) {
    
    if( is_object($cache_object) ) {
      $cache_key = "newsfeedpluslikes_".$action['action_id'];
      $cached_action = $cache_object->get($cache_key);

      if( is_array($cached_action) ) {
        $newsfeedplus_likes[$action['action_id']] = $cached_action;
        continue;
      }
      
    }

    $actions_list[] = $action['action_id'];  
  }
  
  if(!empty($actions_list)) {
  
    $actions_list_for_query = implode(',',$actions_list);
    $sql = "SELECT *
            FROM se_semods_newsfeedpluslikes P
            LEFT JOIN se_users U
              ON U.user_id = P.newsfeedpluslike_user_id
            WHERE
              newsfeedpluslike_action_id IN ($actions_list_for_query)
            ";

    $rows = new semods_db_iterator_assoc($sql);
    while($row = $rows->next()) {
      semods_utils::create_user_photo($row,'./images/nophoto.gif',true);
      semods_utils::create_user_displayname_ex($row);
      $newsfeedplus_likes[$row['newsfeedpluslike_action_id']][] = array('like'              => $row['newsfeedpluslike_like'],
                                                                       'like_points'        => $row['newsfeedpluslike_awardedpoints'],
                                                                       'like_id'            => $row['newsfeedpluslike_id'],
                                                                       'date'               => $row['newsfeedpluslike_date'],
                                                                       'is_owner'           => false,
                                                                       'user_photo'         => $row['user_photo'],
                                                                       'user_id'            => $row['user_id'],
                                                                       'user_username'      => $row['user_username'],
                                                                       'user_displayname'   => $row['user_displayname']
                                                                       );
    }


    // CACHE
    if( is_object($cache_object) ) {
      foreach($actions_list as $action_id) {
        $cache_key = "newsfeedpluslikes_".$action_id;
        if(isset($newsfeedplus_likes[$action_id])) {
          $cache_object->store($newsfeedplus_likes[$action_id], $cache_key);
        }
      }
    }
   
  }
  
  // TODO: make this dumbless
  // FIND IF CURRENT USER LIKED ACTIONS.
  $newsfeedplus_iliked = array();
  if($user->user_exists) {
    foreach($newsfeedplus_likes as $action_liked_id => $action_liked) {
      foreach($action_liked as $user_liked) {
        if($user_liked['user_id'] == $user->user_info['user_id']) {
          $newsfeedplus_iliked[$action_liked_id] = 1;
          break;
        }
      }
    }
  }
  
  
  // COLLAPSING LIMITS
  //$smarty->assign('newsfeedplus_limit_likes',NEWSFEEDPLUS_MAX_LIKES);
  //$smarty->assign('newsfeedplus_limit_comments',NEWSFEEDPLUS_MAX_COMMENTS);
  $smarty->assign('newsfeedplus_limit_likes',semods::get_setting('newsfeedplus_foldlikes'));
  $smarty->assign('newsfeedplus_limit_comments',semods::get_setting('newsfeedplus_foldcomments'));
  
  //var_dump($newsfeedplus_iliked);exit;
  //$smarty->assign('newsfeedplus_comments',$newsfeedplus_comments);
  //$smarty->assign('newsfeedplus_likes',$newsfeedplus_likes);
  //$smarty->assign('newsfeedplus_iliked',$newsfeedplus_iliked);
  
  return array( 'newsfeedplus_comments' => $newsfeedplus_comments,
                'newsfeedplus_likes'    => $newsfeedplus_likes,
                'newsfeedplus_iliked'   => $newsfeedplus_iliked
               );
}





/********************* EMAIL FUNCTIONS *********************/


function newsfeedplus_send_email( $email_name, $to_email, $replace = array() ) {
  global $setting;

  $email = semods::db_query_assoc( "SELECT * FROM se_semods_systememails WHERE systememail_name='$email_name'" );

  SE_Language::_preload_multi($email['systememail_subject'], $email['systememail_body']);
  SE_Language::load();

  $subject = htmlspecialchars_decode(SE_Language::_get($email['systememail_subject']), ENT_QUOTES);
  $message = htmlspecialchars_decode(SE_Language::_get($email['systememail_body']), ENT_QUOTES);

    list( $message, $subject ) = str_replace(
                        array_keys($replace),
                        array_values($replace),
                          array( $message,
                                 $subject ) );

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

  if(semods::get_setting('emailer_enabled') && function_exists("semods_send_mail_queued")) {
      semods_send_mail_queued( $setting['setting_email_fromname'],
                               $setting['setting_email_fromemail'],
                             $to_email,
                               $subject,
                               $message );
    } else {

      // ENCODE SUBJECT FOR UTF8
      $subject="=?UTF-8?B?".base64_encode($subject)."?=";

      // SET HEADERS
      $from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
      $headers = "MIME-Version: 1.0"."\n";
      $headers .= "Content-type: text/html; charset=utf-8"."\n";
      $headers .= "Content-Transfer-Encoding: 8bit"."\n";
      $headers .= "From: $from_email"."\n";
      $headers .= "Return-Path: $from_email"."\n";
      $headers .= "Reply-To: $from_email";

    @mail($to_email, $subject, $message, $headers);
    }

}


/*
 * Notify user about comment
 *
 */
function newsfeedplus_email_commented($action_owner_user_id, $commenter) {
  global $setting, $url;

  $user = new se_user( array( $action_owner_user_id ));
  if($user->user_exists == 0)
    return;

  $time = time();

  // GET SERVER INFO
  $prefix = $url->url_base;

  $replace = array( '[username]'              => $user->user_info['user_username'],
                    '[displayname]'           => $user->user_displayname,
                    '[email]'                 => $user->user_info['user_email'],
                    '[link]'                  => "<a href=\"$prefix"."user_newsfeedplus.php\">$prefix"."user_newsfeedplus.php</a>",
                    '[commenter_username]'    => $commenter->user_info['user_username'],
                    '[commenter_displayname]' => $commenter->user_displayname
                    );

  newsfeedplus_send_email( "newsfeedplus_commented", $user->user_info['user_email'], $replace );

  return true;
}

?>