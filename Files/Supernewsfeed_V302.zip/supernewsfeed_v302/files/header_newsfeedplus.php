<?php

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE SE VERSION
include_once "include/version.php";

// INCLUDE CLASS FILE
include_once "./include/class_semods.php";
include_once "./include/class_semods_utils.php";
include_once "./include/class_newsfeedplus.php";

// INCLUDE FUNCTION FILE
include_once "./include/functions_newsfeedplus.php";



switch($page) {

  case "home":
  case "user_home":
  case "profile":
  case "group":
  case "network":
    SE_Hook::register("se_footer", 'newsfeedplus_hook_load_newsfeedplus');
    break;

  case "misc_js":
    SE_Hook::register("se_header", 'newsfeedplus_hook_header');
    break;



    //SE_Hook::register("se_user_home", 'newsfeedplus_hook_load_newsfeedplus');


}

// SHALL WE USE POINTS
$newsfeedplus_points = (array_key_exists("userpoints", $global_plugins)  &&        // points plugin installed & enabled
                       ( ($user->level_info['level_userpoints_allow'] != 0) &&     // user has points enabled per level
                        ($user->user_info['user_userpoints_allowed'] != 0)) &&     // user has points enabled
                       $user->level_info['level_newsfeedplus_pointsforlikes']);     // allow points for likes

$smarty->assign('newsfeedplus_points',intval($newsfeedplus_points));  


// SET USER DELETION HOOK
SE_Hook::register("se_user_delete", 'deleteuser_newsfeed');

?>