<?php
$page = "user_newsfeedplus";


//$smarty->assign('', $);
include "footer.php";
?>