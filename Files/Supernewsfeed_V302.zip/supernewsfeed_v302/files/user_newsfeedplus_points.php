<?php
$page = "user_newsfeedplus_points";
include 'header.php';

$action_id = semods::getpost('action_id',0);

// find owner
$action_owner_user_id = semods::db_query_count("SELECT action_user_id FROM se_actions WHERE action_id = $action_id");
$action_owner_user = new se_user( array( $action_owner_user_id ));


$smarty->assign('points_balance', userpoints_get_points( $user->user_info['user_id'] ));
$smarty->assign('action_id', $action_id);
$smarty->assign('action_owner_user', $action_owner_user);
include "footer.php";
?>