<?php
$page = "admin_newsfeedplus";
include "admin_header.php";

$task = semods::post('task', 'main');

// SET RESULT VARIABLE
$result = 0;



// SAVE CHANGES
if($task == "dosave") {

  $setting_newsfeedplus_foldcomments = semods::getpost('setting_newsfeedplus_foldcomments',3);
  $setting_newsfeedplus_foldlikes = semods::getpost('setting_newsfeedplus_foldlikes',4);


  //$is_error = 1;
  //for(;;) {
    //if() {
    //  $error_message = ;
    //}

    $is_error = 0;
  //  break;
  //}


  if($is_error != 1) {

    $database->database_query("UPDATE se_semods_settings SET
              setting_newsfeedplus_foldcomments = '$setting_newsfeedplus_foldcomments',
              setting_newsfeedplus_foldlikes = '$setting_newsfeedplus_foldlikes'
             ");

  }

  // SAVE EMAILS
  $emails = $_POST['emails'];//semods::post('emails', array());
  
  $email_query = $database->database_query("SELECT * FROM se_semods_systememails WHERE systememail_type='newsfeedplus' ORDER BY systememail_id");
  while($email = $database->database_fetch_assoc($email_query)) {
    SE_Language::edit($email['systememail_subject'], $emails[$email['systememail_id']]['subject']);
    SE_Language::edit($email['systememail_body'], str_replace("\r\n", "<br>", $emails[$email['systememail_id']]['body']));
  }

  $result = 1;

}

// EMAILS
$email_query = $database->database_query("SELECT * FROM se_semods_systememails WHERE systememail_type='newsfeedplus' ORDER BY systememail_id");
while($email = $database->database_fetch_assoc($email_query)) {
  SE_Language::_preload_multi($email['systememail_title'], $email['systememail_desc'], $email['systememail_subject'], $email['systememail_body'], $email['systememail_hint']);
  $email_array[] = $email;
}


// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
$smarty->assign('setting_newsfeedplus_foldcomments', semods::get_setting('newsfeedplus_foldcomments'));
$smarty->assign('setting_newsfeedplus_foldlikes', semods::get_setting('newsfeedplus_foldlikes'));
$smarty->assign('emails', $email_array);
include "admin_footer.php";
?>