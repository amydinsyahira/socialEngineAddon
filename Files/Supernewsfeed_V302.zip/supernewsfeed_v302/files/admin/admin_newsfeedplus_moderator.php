<?php
$page = "admin_newsfeedplus_moderator";
include "admin_header.php";

$task = semods::getpost('task', 'main');
$p = semods::getpost('p',1);

$f_actiontype = semods::getpost('f_actiontype', '');
$f_user = semods::getpost('f_user', '');
$f_withcomments = (int)semods::getpost('f_withcomments', '0');
$f_comment = semods::getpost('f_comment', '');


// SET RESULT VARIABLE
$result = 0;



// DELETE ACTION
if($task == "deleteaction") {
  $action_id = semods::getpost('action_id',0);

  newsfeedplus_deleteaction($action_id);
  
  $response = array();
  $response['status'] = 0;
  
  echo json_encode($response);
  exit;
}



$newsfeedplus_comments = newsfeedplus_load_all_comments($p,100, $f_actiontype, $f_user, $f_withcomments,$f_comment);
$actiontypes = semods::db_query_assoc_all("SELECT * FROM se_actiontypes ORDER BY actiontype_name ASC");


// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
$smarty->assign('actions', $newsfeedplus_comments['actions']);
$smarty->assign('pages', $newsfeedplus_comments['page_array']);
$smarty->assign('actiontypes', $actiontypes);

$smarty->assign('p', $newsfeedplus_comments['page_vars'][1]);
$smarty->assign('total_actions', $newsfeedplus_comments['total_actions']);

$smarty->assign('f_user', $f_user);
$smarty->assign('f_actiontype', $f_actiontype);
$smarty->assign('f_withcomments', $f_withcomments);
$smarty->assign('f_comment', $f_comment);

include "admin_footer.php";
?>