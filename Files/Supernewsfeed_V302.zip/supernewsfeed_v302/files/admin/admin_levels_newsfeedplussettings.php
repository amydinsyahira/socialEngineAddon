<?php
$page = "admin_levels_newsfeedplussettings";
include "admin_header.php";

$task = semods::getpost('task', 'main');
$level_id = semods::getpost('level_id', 0);

// VALIDATE LEVEL ID
$level_info = semods::db_query_assoc( "SELECT * FROM se_levels WHERE level_id = $level_id" );
if(!$level_info) {
  header("Location: admin_levels.php");
  exit();
}

// SET RESULT VARIABLE
$result = 0;
$is_error = 0;
$error_message = "";


// SAVE CHANGES
if($task == "dosave") {

  $level_newsfeedplus_allow_comments = semods::post('level_newsfeedplus_allow_comments', 0);
  $level_newsfeedplus_allow_likes = semods::post('level_newsfeedplus_allow_likes', 0);
  $level_newsfeedplus_pointsforlikes = semods::post('level_newsfeedplus_pointsforlikes', 0);
  $level_newsfeedplus_maxlikepoints = semods::post('level_newsfeedplus_maxlikepoints', 0);

  
  $database->database_query("UPDATE se_levels SET 
		  level_newsfeedplus_allow_comments=$level_newsfeedplus_allow_comments,
		  level_newsfeedplus_allow_likes=$level_newsfeedplus_allow_likes,
		  level_newsfeedplus_pointsforlikes=$level_newsfeedplus_pointsforlikes,
		  level_newsfeedplus_maxlikepoints=$level_newsfeedplus_maxlikepoints
		  WHERE level_id = $level_id"
		  );

  // flush cache
  $cache = SECache::getInstance('serial');
  
  // Get from cache
  if( is_object($cache) ) {
    $cache->remove('site_level_settings_'.$level_id);
  }

  // refresh	
  $level_info = semods::db_query_assoc( "SELECT * FROM se_levels WHERE level_id = $level_id" );

  $result = 1;
  
} // END DOSAVE TASK

$newsfeedplus_has_userpoints = function_exists('userpoints_deduct');

// ASSIGN VARIABLES AND SHOW ALBUM SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('newsfeedplus_has_userpoints', $newsfeedplus_has_userpoints);
$smarty->assign('error_message', $error_message);
$smarty->assign('level_info', $level_info);
$smarty->assign('level_id', $level_info['level_id']);
$smarty->assign('level_name', $level_info['level_name']);
include "admin_footer.php";
?>