<?php
$plugin_name = "Super Newsfeed";
$plugin_version = "3.02";
$plugin_type = "newsfeedplus";
$plugin_desc = "This plugin introduces advanced interactive Newsfeed.";
$plugin_icon = "newsfeedplus16.png";
$plugin_menu_title = "100052000";
$plugin_pages_main = "100052001<!>newsfeedplus16.png<!>admin_newsfeedplus.php<~!~>100052004<!>newsfeedplus16.png<!>admin_newsfeedplus_moderator.php<~!~>";
$plugin_pages_level = "100052005<!>admin_levels_newsfeedplussettings.php<~!~>";
$plugin_url_htaccess = "";

if($install == "newsfeedplus") {

  //######### INSERT ROW INTO se_plugins
  $database->database_query("INSERT INTO se_plugins (

                  plugin_name,
                  plugin_version,
                  plugin_type,
                  plugin_desc,
                  plugin_icon,
                  plugin_menu_title,
                  plugin_pages_main,
                  plugin_pages_level,
                  plugin_url_htaccess
                  ) VALUES (
                  '$plugin_name',
                  '$plugin_version',
                  '$plugin_type',
                  '".str_replace("'", "\'", $plugin_desc)."',
                  '$plugin_icon',
                  '$plugin_menu_title',
                  '$plugin_pages_main',
                  '$plugin_pages_level',
                  '$plugin_url_htaccess')

                  ON DUPLICATE KEY UPDATE

                  plugin_version='$plugin_version',
                  plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
                  plugin_icon='$plugin_icon',
                  plugin_menu_title='$plugin_menu_title',
                  plugin_pages_main='$plugin_pages_main',
                  plugin_pages_level='$plugin_pages_level',
                  plugin_url_htaccess='$plugin_url_htaccess'

  ");


  //######### INSERT LANGUAGE VARS
  $database->database_query("INSERT IGNORE INTO se_languagevars (languagevar_id, languagevar_language_id, languagevar_value, languagevar_default) VALUES
                            (100052000, 1, 'Super Newsfeed', ''),
                            (100052001, 1, 'Super Newsfeed Settings', ''),
                            (100052002, 1, 'Super Newsfeed Settings', ''),
                            (100052003, 1, 'You can modify more settings (enable/disable commenting, liking and awarding points for liking) for each', ''),
                            (100052004, 1, 'Super Newsfeed Moderator', ''),
                            (100052005, 1, 'SuperNewsfeed Settings', ''),
                            (100052006, 1, 'Posting...', ''),
                            (100052007, 1, 'I like it', ''),
                            (100052008, 1, 'Unlike It', ''),
                            (100052009, 1, 'I Don\'t Like It', ''),
                            (100052010, 1, 'Comment', ''),
                            (100052011, 1, 'Write a comment...', ''),
                            (100052012, 1, 'Post', ''),
                            (100052013, 1, 'Cancel', ''),
                            (100052014, 1, 'likes this', ''),
                            (100052015, 1, 'points', ''),
                            (100052016, 1, 'people like this', ''),
                            (100052017, 1, 'View all comments', ''),
                            (100052018, 1, 'Like and Give Points?', ''),
                            (100052019, 1, 'You can reward %1\$s with points ! How many points would you like to give? (You have <strong>%2\$s</strong> point(s) available.)', ''),
                            (100052020, 1, 'Don\'t give points, I just like it!', ''),
                            (100052021, 1, 'Other', ''),
                            (100052022, 1, 'Remember my choice next time I \"Like\" something and don\'t show this dialog.', ''),
                            (100052023, 1, 'Like it', ''),
                            (100052024, 1, 'Cancel', ''),
                            (100052025, 1, 'or', ''),
                            (100052026, 1, 'SuperNewsfeed - Moderator', ''),
                            (100052027, 1, 'On this page you can easily moderate the Activity Feed available on your network, including feed comments.', ''),
                            (100052028, 1, 'Action Type', ''),
                            (100052029, 1, 'Show only actions with comments?', ''),
                            (100052030, 1, 'Newsfeed Comment', ''),
                            (100052031, 1, 'No newsfeed actions found.', ''),
                            (100052032, 1, '%1\$s Actions Found', ''),
                            (100052033, 1, 'SuperNewsfeed Settings', ''),
                            (100052034, 1, 'SuperNewsfeed Settings', ''),
                            (100052035, 1, 'Changes Successfully Saved.', ''),
                            (100052036, 1, 'Allow Newsfeed commenting?', ''),
                            (100052037, 1, 'Do you want to let users comment on each other\'s newsfeed actions?', ''),
                            (100052038, 1, 'Yes, Allow newsfeed commenting.', ''),
                            (100052039, 1, 'No, Do not allow newsfeed commenting.', ''),
                            (100052040, 1, 'Allow Newsfeed liking?', ''),
                            (100052041, 1, 'Do you want to let users like each other\'s newsfeed actions?', ''),
                            (100052042, 1, 'Yes, Allow newsfeed liking.', ''),
                            (100052043, 1, 'No, Do not allow newsfeed liking.', ''),
                            (100052044, 1, 'Allow users to award points for \"liking\"? This will let a user decide whether he wants to donate some amount of the points when liking a newsfeed action item.', ''),
                            (100052045, 1, 'This feature requires \"Activity Points\" plugin installed and enabled.', ''),
                            (100052046, 1, 'Yes, Allow users to award points for liking.', ''),
                            (100052047, 1, 'No, Do not allow users to award points for liking.', ''),
                            (100052048, 1, 'Maximum points user can reward for \"liking\"', ''),
                            (100052049, 1, 'Maximum', ''),
                            (100052050, 1, 'Save Changes', ''),
                            (100052051, 1, 'General Settings', ''),
                            (100052052, 1, 'Maximum comments to show before folding.', ''),
                            (100052053, 1, 'comments', ''),
                            (100052054, 1, 'Maximum \"likes\" to show before folding.', ''),
                            (100052055, 1, 'likes', ''),
                            (100052056, 1, 'New Comment Email', ''),
                            (100052057, 1, 'This is the email that gets sent to user after somebody comments on his newsfeed action.', ''),
                            (100052058, 1, 'New Comment on your action', ''),
                            (100052059, 1, 'Hello [displayname],\r\n\r\n[commenter_displayname] has just commented on your newsfeed action.\r\n\r\nBest Regards,\r\nSocial Network Administration', ''),
                            (100052060, 1, '[displayname] - replaced with the display name of the recepient (Full Name with fallback to username).<br>[email] - replaced with the email address of the recepient.<br>[commenter_displayname] - replaced with the display name of the commenter', ''),
                            (100052061, 1, 'Subject', ''),
                            (100052062, 1, 'Message', '')
                            ");


  //######### INSERT EMAILS

  $database->database_query("CREATE TABLE IF NOT EXISTS `se_semods_systememails` (
      `systememail_id` int(9) NOT NULL auto_increment,
      `systememail_name` varchar(100) collate utf8_unicode_ci NOT NULL,
      `systememail_title` int(9) NOT NULL,
      `systememail_desc` int(9) NOT NULL,
      `systememail_subject` int(9) NOT NULL,
      `systememail_body` int(9) NOT NULL,
      `systememail_vars` varchar(250) collate utf8_unicode_ci NOT NULL,
      `systememail_type` varchar(30) collate utf8_unicode_ci NOT NULL,
      `systememail_hint` int(11) NOT NULL,
      PRIMARY KEY  (`systememail_id`),
      UNIQUE KEY `systememail_name` (`systememail_name`)
    ) CHARACTER  SET=utf8 COLLATE=utf8_unicode_ci
  ");

  $database->database_query("REPLACE INTO `se_semods_systememails` (`systememail_name`, `systememail_title`, `systememail_desc`, `systememail_subject`, `systememail_body`, `systememail_vars`, `systememail_type`, `systememail_hint`) VALUES ('newsfeedplus_commented', '100052056', '100052057', '100052058', '100052059', '', 'newsfeedplus', '100052060' )");


  //######### CREATE DATABASE STRUCTURE

  if(!function_exists('chain_sql')) {
    function chain_sql( $sql ) {
      global $database;

      $rows = explode( ';;;', $sql);
      foreach($rows as $row) {
        $row = trim($row);
        if(empty($row))
          continue;
        $database->database_query( $row );
      }

    }
  }

  chain_sql(
<<<EOC


CREATE TABLE IF NOT EXISTS `se_semods_newsfeedplus` (
  `newsfeedplus_id` int(10) unsigned NOT NULL auto_increment,
  `newsfeedplus_user_id` int(11) NOT NULL,
  `newsfeedplus_action_id` int(11) NOT NULL,
  `newsfeedplus_comment` text collate utf8_unicode_ci NOT NULL,
  `newsfeedplus_date` int(11) NOT NULL,
  PRIMARY KEY  (`newsfeedplus_id`)
) CHARSET=utf8 COLLATE=utf8_unicode_ci;;;


CREATE TABLE IF NOT EXISTS `se_semods_newsfeedpluslikes` (
  `newsfeedpluslike_id` int(10) unsigned NOT NULL auto_increment,
  `newsfeedpluslike_user_id` int(11) NOT NULL,
  `newsfeedpluslike_action_id` int(11) NOT NULL,
  `newsfeedpluslike_like` tinyint(4) NOT NULL default '1',
  `newsfeedpluslike_date` int(11) NOT NULL,
  `newsfeedpluslike_awardedpoints` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`newsfeedpluslike_id`),
  UNIQUE KEY `newsfeedpluslike_user_id` (`newsfeedpluslike_user_id`,`newsfeedpluslike_action_id`)
) CHARSET=utf8 COLLATE=utf8_unicode_ci;;;


ALTER TABLE `se_usersettings` ADD `usersetting_newsfeedplus_likepoints` TINYINT( 0 ) NOT NULL;;;
ALTER TABLE `se_usersettings` ADD `usersetting_newsfeedplus_rememberchoice` TINYINT( 0 ) NOT NULL;;;

ALTER TABLE `se_levels` ADD `level_newsfeedplus_allow_comments` TINYINT NOT NULL DEFAULT '1';;;
ALTER TABLE `se_levels` ADD `level_newsfeedplus_allow_likes` TINYINT NOT NULL DEFAULT '1';;;
ALTER TABLE `se_levels` ADD `level_newsfeedplus_pointsforlikes` TINYINT UNSIGNED NOT NULL DEFAULT '1';;;
ALTER TABLE `se_levels` ADD `level_newsfeedplus_maxlikepoints` INT UNSIGNED NOT NULL DEFAULT '0';;;



EOC
);




  /*** SHARED ELEMENTS ***/


  //######### CREATE se_semods_settings
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_semods_settings'")) == 0) {

    $database->database_query("CREATE TABLE `se_semods_settings` (
	  `setting_newsfeedplus_foldcomments` INT UNSIGNED NOT NULL DEFAULT '3',
      `setting_newsfeedplus_foldlikes` INT UNSIGNED NOT NULL DEFAULT '4'
      )");

    $database->database_query("INSERT INTO `se_semods_settings` (`setting_newsfeedplus_foldcomments`) VALUES ('3')");

  } else {

  chain_sql(
<<<EOC

ALTER TABLE `se_semods_settings` ADD `setting_newsfeedplus_foldcomments` INT UNSIGNED NOT NULL DEFAULT '3';;;
ALTER TABLE `se_semods_settings` ADD `setting_newsfeedplus_foldlikes` INT UNSIGNED NOT NULL DEFAULT '4';;;

EOC
);

  }



}


?>