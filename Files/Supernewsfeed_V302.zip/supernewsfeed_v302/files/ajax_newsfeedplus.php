<?php

define('SE_PAGE_AJAX', TRUE);

$page = "ajax_newsfeedplus";
include "header.php";

$task = semods::getpost('task','main');




/*** TASKS REQUIRING LOGGED IN USER/ADMIN ***/



if($task == "postcomment" && $user->user_exists) {
  $action_id = (int)semods::getpost('action_id',0);
  $instance_id = semods::getpost('instance_id','');
  $comment = semods::getpost('comment','');
  
  $comment_item = newsfeedplus_submitcomment($action_id,$comment);
  
  $response = array();

  if($comment_item !== false) {

    $smarty->assign('newsfeedplus_comment_item',$comment_item);
    $smarty->assign('newsfeedplus_action_id',$action_id);
    $smarty->assign('newsfeedplus_instance',$instance_id);
    $smarty->assign_by_ref('datetime', $datetime);
    $smarty->assign_by_ref('url', $url);
    $smarty->assign_by_ref('user', $user);
  
    $response['status'] = 0;
    $response['html'] = $smarty->fetch('newsfeedplus_comment_item.tpl');

  } else {

    $response['status'] = 1;
    $response['err_msg'] = '';
    
  }
    
  echo json_encode($response);
  exit;
}





if(($task == "updatecomment") && ($user->user_exists || $admin->admin_exists)) {
  $action_id = (int)semods::getpost('action_id',0);
  $instance_id = semods::getpost('instance_id','');
  $comment_id = (int)semods::getpost('comment_id',0);
  $comment = semods::getpost('comment','');
  
  $comment_item = newsfeedplus_updatecomment($action_id,$comment_id,$comment);
  
  $response = array();

  if($comment_item !== false) {
  
    $response['status'] = 0;

  } else {

    $response['status'] = 1;
    $response['err_msg'] = '';
    
  }
    
  echo json_encode($response);
  exit;
}





if(($task == "deletecomment") && ($user->user_exists || $admin->admin_exists)) {
  $action_id = (int)semods::getpost('action_id',0);
  $instance_id = semods::getpost('instance_id','');
  $comment_id = (int)semods::getpost('comment_id',0);
  
  newsfeedplus_deletecomment($action_id,$comment_id);
  
  $response = array();
  $response['status'] = 0;
  
  echo json_encode($response);
  exit;
}





if($task == "like" && $user->user_exists) {
  $action_id = (int)semods::getpost('action_id',0);
  $instance_id = semods::getpost('instance_id','');
  $points = (int)semods::getpost('points',0);
  $remember = semods::getpost('remember',777);
  
  $like_item = newsfeedplus_submitlike($action_id, 1, $points, $remember);

  $response = array();

  if($like_item !== false) {

    $smarty->assign('newsfeedplus_like_item',$like_item);
    $smarty->assign('newsfeedplus_action_id',$action_id);
    $smarty->assign('newsfeedplus_instance',$instance_id);
    $smarty->assign_by_ref('datetime', $datetime);
    $smarty->assign_by_ref('url', $url);
    $smarty->assign_by_ref('user', $user);

    $response['status'] = 0;
    $response['html'] = $smarty->fetch('newsfeedplus_like_item.tpl');
    
  } else {

    $response['status'] = 1;
    $response['err_msg'] = '';
    
  }


  echo json_encode($response);
  exit;
}





if($task == "unlike" && $user->user_exists) {
  $action_id = (int)semods::getpost('action_id',0);
  $instance_id = semods::getpost('instance_id','');
  
  newsfeedplus_submitunlike($action_id);

  $response = array();

  $response['status'] = 0;
  $response['user_id'] = $user->user_info['user_id'];

  echo json_encode($response);
  exit;
}





/*** TASKS NOT REQUIRING LOGGED IN USER ***/



if($task == "loadlikes") {
  $action_id = (int)semods::getpost('action_id',0);
  $instance_id = semods::getpost('instance_id','');
  
  $newsfeedplus_likes[$action_id] = newsfeedplus_load_likes($action_id);
  
  $smarty->assign('newsfeedplus_limit_likes',999);
  $smarty->assign('newsfeedplus_likes',$newsfeedplus_likes);
  $smarty->assign('newsfeedplus_action_id',$action_id);
  $smarty->assign('newsfeedplus_instance',$instance_id);
  
  $smarty->assign_by_ref('datetime', $datetime);
  $smarty->assign_by_ref('url', $url);
  $smarty->assign_by_ref('user', $user);

  $response = array();
  $response['status'] = 0;
  $response['html'] = $smarty->fetch('newsfeedplus_likes.tpl');

  echo json_encode($response);
  exit;
}





if($task == "loadcomments") {
  $action_id = (int)semods::getpost('action_id',0);
  $instance_id = semods::getpost('instance_id','');
  $action_user_id = semods::db_query_count("SELECT action_user_id FROM se_actions WHERE action_id = $action_id");
  
  $newsfeedplus_comments[$action_id] = newsfeedplus_load_comments($action_id);
  
  $smarty->assign('newsfeedplus_limit_comments',999);
  $smarty->assign('newsfeedplus_comments',$newsfeedplus_comments);
  $smarty->assign('newsfeedplus_action_id',$action_id);
  $smarty->assign('newsfeedplus_action_user_id',$action_user_id);
  $smarty->assign('newsfeedplus_instance',$instance_id);
  
  $smarty->assign_by_ref('datetime', $datetime);
  $smarty->assign_by_ref('url', $url);
  $smarty->assign_by_ref('user', $user);

  $response = array();
  $response['status'] = 0;
  $response['html'] = $smarty->fetch('newsfeedplus_comments.tpl');

  echo json_encode($response);
  exit;
}

?>