<?php
/**
 * Database layer for SocialEngine
 * @author Hire-Experts
 * @version 1.02
 */
class he_database
{
	function query($query)
	{
		global $database;
		return $database->database_query($query);
	}
	
	function num_rows($resource)
	{
		global $database;
		return $database->database_num_rows($resource);
	}
	
	function fetch_array($query)
	{
		global $database;
		
		$rows = array();
		$res = he_database::query($query);
		while($row = $database->database_fetch_assoc($res))
		  $rows[] = $row;
		
		return $rows;
	}
	
	function fetch_row($query)
	{
		global $database;
		return $database->database_fetch_assoc(he_database::query($query));
	}
	
	function fetch_row_from_resource($resource)
	{
		global $database;
		return $database->database_fetch_assoc($resource);
	}
	
	function fetch_field($query)
	{
		global $database;
		$row = $database->database_fetch_array(he_database::query($query));
		return $row ? $row[0] : null;
	}
	
	function real_escape($unescaped_string)
	{
		global $database;
		return $database->database_real_escape_string($unescaped_string);
	}
	
	function insert_id()
	{
		global $database;
		return $database->database_insert_id();
	}
	
	function affected_rows()
	{
		global $database;
		return $database->database_affected_rows();
	}
}
?>