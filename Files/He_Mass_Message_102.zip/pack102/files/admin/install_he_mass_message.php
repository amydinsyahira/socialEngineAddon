<?

$plugin_name = "Mass Message Pro Plugin";
$plugin_version = "1.00";
$plugin_type = "he_mass_message";
$plugin_desc = "This plugin allows you to easily send message announcements to selected users. You can restrict recipients by user level, subnetwork and profile categories. Also you can use placeholders(like recipient display name and email) in an announcement's subject and message body. The plugin allows queueing mass messages, emails and sending them in a much more controlled way in order to prevent server overload and marking host as spammer. It is very useful feature if you have a large user base. Please go to <a href=\"http://www.hire-experts.com/\">Hire-Experts.com</a> to get this plugin latest version.";
$plugin_icon = "he_mass_message16.gif";
$plugin_menu_title = "";
$plugin_pages_main = "690690029<!>he_mass_message16.gif<!>admin_mass_message_tool.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";
$plugin_db_charset = 'utf8';
$plugin_db_collation = 'utf8_unicode_ci';


if($install == "he_mass_message") {
	
	//check if plugin was already installed
	$sql = "SELECT * FROM se_plugins WHERE plugin_type='$plugin_type' LIMIT 1";
	$resource = $database->database_query($sql) or die($database->database_error()." <b>SQL was: </b>$sql");
	
	$plugin_info = array();
	if( $database->database_num_rows($resource) )
		$plugin_info = $database->database_fetch_assoc($resource);
	
	
	//install plugin
	if( !$plugin_info ) {
		$database->database_query("INSERT INTO se_plugins (plugin_name,
			plugin_version,
			plugin_type,
			plugin_desc,
			plugin_icon,
			plugin_menu_title,
			plugin_pages_main,
			plugin_pages_level,
			plugin_url_htaccess
			) VALUES (
			'$plugin_name',
			'$plugin_version',
			'$plugin_type',
			'".str_replace("'", "\'", $plugin_desc)."',
			'$plugin_icon',
			'',
			'$plugin_pages_main',
			'',
			'$plugin_url_htaccess')");
	
	
	//update plugin
	} else {
		$database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
			plugin_version='$plugin_version',
			plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
			plugin_icon='$plugin_icon',
			plugin_menu_title='',
			plugin_pages_main='$plugin_pages_main',
			plugin_pages_level='',
			plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
	}
	
	$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_message_from_user` varchar(255) NOT NULL;");
	$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_message_per_minute` int(10) NOT NULL;");
	$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_email_per_minute` int(10) NOT NULL;");
	$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_message_last_execute` int(10) unsigned NOT NULL;");
	$database->database_query("ALTER TABLE `se_settings` ADD `setting_mass_email_last_execute` int(10) unsigned NOT NULL;");
	$database->database_query("CREATE TABLE IF NOT EXISTS `se_mass_message_campaign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `sender` varchar(255) NOT NULL,
  `recipient_count` int(10) NOT NULL,
  `sent_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;");
	$database->database_query("CREATE TABLE IF NOT EXISTS `se_mass_message_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;");
	
	if( !$setting['setting_mass_message_per_minute'] )
		$database->database_query("UPDATE `se_settings` SET `setting_mass_message_per_minute`='30' WHERE `setting_id`=1");
	if( !$setting['setting_mass_email_per_minute'] )
		$database->database_query("UPDATE `se_settings` SET `setting_mass_email_per_minute`='20' WHERE `setting_id`=1");
	

	//insert langs
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690001 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690001', '1', 'Mass Message Pro Tools', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690002 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690002', '1', 'This plugin allows you to easily send message announcements to selected users. You can restrict recipients by user level, subnetwork and profile categories. Also you can use placeholders(like recipient display name and email) in an announcement\'s subject and message body. The plugin allows queueing mass messages, emails and sending them in a much more controlled way in order to prevent server overload and marking host as spammer. It is very useful feature if you have a large user base.', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690003 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690003', '1', 'Settings', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690004 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690004', '1', 'Send Mass Message', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690005 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690005', '1', 'Send Mass Email', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690006 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690006', '1', 'From User(Mass Message)', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690007 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690007', '1', 'Local messages count sending per minute', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690008 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690008', '1', 'Emails count sending per minute', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690009 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690009', '1', 'Save changes', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690010 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690010', '1', 'Changes have been saved.', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690011 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690011', '1', 'Failed. Please check carefully and try again', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690012 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690012', '1', 'Subject', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690013 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690013', '1', 'Message', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690014 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690014', '1', 'Recipients', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690015 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690015', '1', 'Select which users will receive this message announcement. By default, all user levels, subnetworks and profile categories are selected - this means that every user on your social network will receive this announcement. Use CTRL-click to select or deselect multiple user levels, subnetworks or profile categories. If a user matches any user level OR subnetwork OR profile category you have selected here, they will receive this announcement.', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690016 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690016', '1', 'Available Variables: [displayname],[email]', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690017 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690017', '1', 'Send Message', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690018 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690018', '1', 'User Levels', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690019 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690019', '1', 'Subnetworks', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690020 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690020', '1', 'Profile Categories', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690021 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690021', '1', '(signup default)', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690022 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690022', '1', 'Default Subnetwork', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690023 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690023', '1', 'Sent.', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690024 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690024', '1', 'This feature is available in Mass Message Pro Paid version. The paid version has many enhancements of existing features(it supports fields restrictions - only for female recipients, etc) and also it allows you to send email announcements. You can purchase this plugin from <a href=\"http://www.hire-experts.com/plugin.php?plugin_name=he_mass_message\">Hire-Experts.com</a>. ', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690025 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690025', '1', 'Mass Message Campaigns', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690026 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690026', '1', 'From User', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690027 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690027', '1', 'Recipients', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690028 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690028', '1', 'Sent Date', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690029 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690029', '1', 'Mass Message Pro', 'mass_message')");
	if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=690690030 LIMIT 1")) == 0) $database->database_query("INSERT INTO `se_languagevars` VALUES('690690030', '1', 'Here you can change the plugin settings. Please <b>choose From User - the plugin use this user as sender in mass message</b>.', 'mass_message')");
}

?>