<?

defined('SE_PAGE') or exit();

include("./include/class_he_database.php");
include("./include/class_he_mass_message.php");

he_mass_message::cron();
?>