<?
$page = "user_invite_statistics";
include "header.php";

// SET EMPTY VARS
$is_error = "";
$result = "";

// CHECK IF INVITE CODES SET TO ADMINS ONLY
if($setting[setting_signup_invite] == 1) {
  header("Location: user_home.php");
  exit();
}

$invites_stats = semods::db_query_assoc( 'SELECT invites_sent, invites_converted FROM se_invites_stats_user WHERE user_id=' . $user->user_info['user_id'] );

$invites_sent = isset($invites_stats['invites_sent']) ? $invites_stats['invites_sent'] : 0;
$invites_converted = isset($invites_stats['invites_converted']) ? $invites_stats['invites_converted'] : 0;

// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('invites_sent', $invites_sent);
$smarty->assign('invites_converted', $invites_converted);

$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
include "footer.php";
?>