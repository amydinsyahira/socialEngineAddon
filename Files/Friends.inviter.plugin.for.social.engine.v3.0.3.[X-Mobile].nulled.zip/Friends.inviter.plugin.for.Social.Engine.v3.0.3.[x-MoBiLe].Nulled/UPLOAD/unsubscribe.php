<?
$page = "unsubscribe";
include "header.php";


$task = semods::getpost('task', 'main');
$email = semods::getpost('email', '');


// UNSUBSCRIBE
if($task == "unsubscribe") {

  if(!is_email_address( $email ) ) {
    $error_message = 100010272;
  } else {
  
    $rows = $database->database_query("SELECT COUNT(*) FROM se_semods_unsubscribe WHERE unsubscribe_user_email = '$email'");
    $row = $database->database_fetch_array( $rows );
    if($row[0] == 0) {
      $database->database_query("INSERT INTO se_semods_unsubscribe (unsubscribe_user_email) VALUES ('$email')");
      
      // Cleanup possibly queued emails ?
    }
    
    $email = '';
    $result = 100010273;
    $hide_unsubscribe_form = true;
  }
  
}


// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('email', $email);
$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
$smarty->assign('hide_unsubscribe_form', $hide_unsubscribe_form);
include "footer.php";
?>