<?
$page = "user_invite_reflink";
include "header.php";

// CHECK IF INVITE CODES SET TO ADMINS ONLY
if($setting[setting_signup_invite] == 1) {
  header("Location: user_home.php");
  exit();
}

$reflink = $url->url_base . 'signup.php?signup_referer=' . $user->user_info['user_username'];

// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('reflink', $reflink);
include "footer.php";
?>