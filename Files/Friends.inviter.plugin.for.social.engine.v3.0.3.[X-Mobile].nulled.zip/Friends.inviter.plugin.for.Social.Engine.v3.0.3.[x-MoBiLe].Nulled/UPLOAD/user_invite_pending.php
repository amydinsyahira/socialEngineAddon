<?
$page = "user_invite_pending";
include "header.php";

// SET EMPTY VARS
$is_error = "";
$result = "";

$p = semods::getpost('p', 1);

// CHECK IF INVITE CODES SET TO ADMINS ONLY
if($setting['setting_signup_invite'] == 1) {
  header("Location: user_home.php");
  exit();
}

$invites_total = semods::db_query_count( 'SELECT COUNT(*) FROM se_invites WHERE invite_user_id=' . $user->user_info['user_id'] );
$invites_per_page = 50;
$page_vars = make_page($invites_total, $invites_per_page, $p);

$invites = semods::db_query_assoc_all("SELECT invite_id, invite_user_id, invite_date, invite_email
                                       FROM se_invites
                                       WHERE invite_user_id={$user->user_info['user_id']}
                                       ORDER BY invite_date DESC LIMIT {$page_vars[0]}, $invites_per_page");

// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('invites', $invites);
$smarty->assign('invites_total', $invites_total);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($invites));

$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
include "footer.php";
?>