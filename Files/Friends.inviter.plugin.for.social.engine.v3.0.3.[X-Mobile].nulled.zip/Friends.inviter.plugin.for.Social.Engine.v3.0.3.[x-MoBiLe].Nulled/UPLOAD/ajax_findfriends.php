<?php
$page = "ajax_findfriends";
include "header.php";


// CREATE USER OBJECT AND ATTEMPT TO LOG USER IN
$user = new se_user();
$user->user_checkCookies();

// USER IS NOT LOGGED IN, Check it its during signup
if($user->user_exists == 0) { 

  if(isset($_COOKIE['signup_id']) & isset($_COOKIE['signup_email']) & isset($_COOKIE['signup_password'])) {

    // GET USER ROW IF AVAILABLE
    $user_id = $_COOKIE['signup_id'];
    $new_user = new se_user(Array($user_id));

    // VERIFY USER LOGIN COOKIE VALUES AND RESET USER LOGIN VARIABLE
    if($_COOKIE['signup_email'] == crypt($new_user->user_info['user_email'], "$1$".$new_user->user_info['user_code']."$") & $_COOKIE['signup_password'] == $new_user->user_info['user_password']) {
      $signup_logged_in = 1;
    }
  }

  if($signup_logged_in != 1) {
    exit;
  }
  
  $user = $new_user;
  $new_user = null;
}




//// STILL USER NOT LOGGED IN?
//if($user->user_exists == 0)
//    exit;



$task = semods::getpost('task', 'befriend');




if($task == "befriend") {
    $befriend_arr = explode( ',', semods::getpost('befriend') );
    
    $friendships_count = 0;
    foreach($befriend_arr as $befriend) {
          
          $friend = new se_user(Array($befriend));
          if($friend->user_exists == 1) {
            
            //echo "1: " . $user->user_friended($friend->user_info['user_id']);
            //echo "\r\n";
            //echo "2: " . $user->user_friended($friend->user_info['user_id'], 0);
            //echo "\r\n";
            //echo "3: " . $friend->user_friended($user->user_info['user_id'], 0);
            //echo "\r\n";

            if($user->user_friended($friend->user_info['user_id']) ||   // CHECK IF USER IS ALREADY FRIENDED
               $user->user_friended($friend->user_info['user_id'], 0) ||  // CHECK IF USER IS ALREADY FRIENDED, WAITING FOR CONFIRMATION
               $friend->user_friended($user->user_info['user_id'], 0) )    // CHECK IF USER FRIENDED YOU ALREADY
            continue;

            //echo "blah";
            
            // TODO:
            // CHECK IF USER FRIENDED YOU ALREADY AND IF YES, CONFIRM HIM
            //if($owner->user_friended($user->user_info['user_id'], 0) )    
            
            if($setting['setting_connection_allow'] == 3 | $setting['setting_connection_allow'] == 1 | ($setting['setting_connection_allow'] == 2 & $user->user_info['user_subnet_id'] == $friend->user_info['user_subnet_id'])) {
              // SET RESULT, DIRECTION, STATUS
              switch($setting['setting_connection_framework']) {
                case "0":
                  $direction = 2;
                  $friend_status = 0;
                  break;
                case "1":
                  $direction = 1;
                  $friend_status = 0;
                  break;
                case "2": 
                  $direction = 2;
                  $friend_status = 1;
                  break;
                case "3":
                  $direction = 1;
                  $friend_status = 1;
                  break;      
              } 
    
              // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE	          
              $user->user_friend_add($friend->user_info['user_id'], $friend_status, '', '');
              
              // INSERT ACTION
              if($friend_status == 1) { 
                $actions->actions_add($user, "addfriend", array($user->user_info[user_username], $user->user_displayname, $friend->user_info[user_username], $friend->user_displayname)); 
              } else {
                $notify->notify_add($friend->user_info[user_id], 'friendrequest', $user->user_info[user_id]);
              }
              
                  
              // IF TWO-WAY CONNECTION AND NON-CONFIRMED, INSERT OTHER DIRECTION
              if($direction == 2 & $friend_status == 1) {
                $friend->user_friend_add($user->user_info['user_id'], $friend_status, '', '');
                $actions->actions_add($friend, "addfriend", array($friend->user_info[user_username], $friend->user_displayname, $user->user_info[user_username], $user->user_displayname));
              }
            }
            $friendships_count++;
    
            // SEND FRIENDSHIP EMAIL
//            send_friendrequest($friend, $user->user_info['user_username']);
              send_systememail( 'friendrequest',
                                $user->user_info['user_email'],
                                array( $user->user_displayname,
                                      $friend->user_displayname,
                                      "<a href=\"".$url->url_base."login.php\">".$url->url_base."login.php</a>"
                                      )
                                );
          }
          
    }
    
    // UPDATE STATS
    update_stats("friends", $friendships_count);
    
    echo $friendships_count;
    exit;
}




if($task == "inviteresend") {
    
    $inviteid = intval(semods::getpost('id'));
    
    $invite_data = semods::db_query_array("SELECT invite_email, invite_code FROM se_invites WHERE invite_id = $inviteid AND invite_user_id = {$user->user_info['user_id']}");
    if(!$invite_data) {
        exit;
    }
    
    if($setting['setting_signup_invite'] == 0) {
      fi_send_invitation( $user, $invite_data[0], '', true );
    } else {
      fi_send_invitecode( $user, $invite_data[0], '', true );
    }

}



if($task == "invitedelete") {
    $inviteid = semods::getpost('id');
    $database->database_query("DELETE FROM se_invites WHERE invite_id = $inviteid AND invite_user_id = {$user->user_info['user_id']}");
}



?>