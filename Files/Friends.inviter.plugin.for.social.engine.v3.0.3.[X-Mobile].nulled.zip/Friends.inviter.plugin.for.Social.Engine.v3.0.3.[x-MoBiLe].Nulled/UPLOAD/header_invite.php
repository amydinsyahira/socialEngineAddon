<?

// INCLUDE SEMODS CLASS
include_once "./include/class_semods.php";


// INCLUDE INVITE FUNCTION FILE
include_once "./include/functions_invite.php";


// PRELOAD LANGUAGE
SE_Language::_preload(100010022);


if($user->user_exists) {

  // SET MAIN MENU VARS
  $plugin_vars['menu_main'] = array( 'file'  => 'invite.php?findfriends=1',
                                     'title' => 100010022
                                     );
}


switch($page) {

  case "signup":

    SE_Hook::register("se_signup", "fi_hook_signup");
    SE_Hook::register("se_footer", "fi_hook_signup_footer");
    SE_Hook::register("se_signup_success", "fi_hook_signup_success");

    SE_Hook::register("se_signup_decide", "fi_hook_signup_decide");


    $fi_task = semods::getpost('task', 'step1');

    break;

}

?>