<?
$page = "invite";
include "header.php";

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if(($user->user_exists == 0) && ($setting['setting_permission_invite'] == 0)) {
  $page = "error";
  $smarty->assign('error_header', 100010200);
  $smarty->assign('error_message', 100010199);
  $smarty->assign('error_submit', 100010201);
  include "footer.php";
}



$task = semods::getpost('task', 'main');

// not logged in users can't "find friends", though it's an interesting idea
$find_friends = ($user->user_exists == 0) ? 0 : semods::getpost('findfriends', 0);


// SET EMPTY VARS
$is_error = "";
$result = "";

// CHECK IF INVITE CODES SET TO ADMINS ONLY
if($setting['setting_signup_invite'] == 1) {
  header("Location: user_home.php");
  exit();
}



// RETRIEVE AND CHECK SECURITY CODE IF NECESSARY
if(($task != "main") && ($setting['setting_invite_code'] != 0)) {
  session_start();
  $code = $_SESSION['code'];
  if($code == "") { $code = randomcode(); }
  $invite_secure = semods::post('invite_secure');
  if($invite_secure != $code) {
    $is_error = 1;
    $error_message = 100010152;
 }
}



// SEND INVITATIONS
if(($task == "doinvite") && ($is_error != 1)) {

  $fi_result = fi_invite_contacts( $user );
  if($fi_result['err']) {
    $is_error = 1;
    $error_message  = $fi_result['err_msg'];
  } else {
    $result = 100010137;
    $invite_emails = '';
    $smarty->assign('invite_emails', $invite_emails);
  }

}



// TOP/AVAILABLE DOMAINS, SERVICES
list($domains, $services) = fi_get_top_services();

// Default to show webcontacts screen
$screen = semods::post('screen', 'webcontacts');

// Default to show webmail box
$provider = semods::post('provider', 'auto');

$login = $post_login = semods::getpost('user');
$domain = semods::getpost('domain');
$typed_domain = semods::getpost('domain_type');

if($task == "doinvitefriends" && $is_error != 1) {

  $fi_result = fi_fetch_contacts( $user, $find_friends );
  if($fi_result['err'] && !$fi_result['captcha_required']) {
    $is_error = 1;
    $error_message  = $fi_result['err_msg'];
  }

}


$smarty->assign('login', $login);
$smarty->assign('domain', $domain);
$smarty->assign('typed_domain', $typed_domain);
$smarty->assign('provider', $provider);
$smarty->assign('screen', $screen);
$smarty->assign('find_friends', $find_friends);
$smarty->assign('domains', $domains);
$smarty->assign('services', $services);
$smarty->assign('invite_secure', $invite_secure);
$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
include "footer.php";
?>