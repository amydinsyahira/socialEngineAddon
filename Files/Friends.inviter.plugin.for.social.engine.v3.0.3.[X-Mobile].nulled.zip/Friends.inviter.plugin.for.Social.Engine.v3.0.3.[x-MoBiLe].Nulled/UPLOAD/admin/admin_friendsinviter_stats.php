<?
$page = "admin_friendsinviter_stats";
include "admin_header.php";

$task = semods::getpost('task', 'main');
$graph = semods::getpost('graph', 'summary');
$period = semods::getpost('period', 'week');
$start = semods::getpost('start', 1);

// CLEAR USER STATS IF REQUESTED
if($task == "clearuserinvitestats") {
  $database->database_query("TRUNCATE se_invites_stats_user");
  header("Location: admin_friendsinviter_stats.php?graph=$graph");
  exit;
}


// GENERATE CHART DATA
if($task == "getdata") {

  // INCLUDE FLASH CHART FUNCTIONS
  include_once "../include/charts/charts.php";

  // SET CHART TYPE
  $chart['chart_type'] = "line";

  // SET STYLES
  $chart['chart_border'] = array('top_thickness' => 1, 
                                 'bottom_thickness' => 1, 
                                 'left_thickness' => 1, 
                                 'right_thickness' => 1,
				 'color' => "666666");
  $chart['axis_category'] = array ('size' => 10, 
                                   'color' => "333333"); 
  $chart['axis_value'] = array('size' => 10, 
                               'color' =>  "333333"); 
  $chart['legend_label'] = array('size' => 12, 
                                 'color' => "000000"); 
  $chart['chart_pref'] = array('line_thickness' => 2, 
			       'point_shape' => "none",
			       'fill_shape' => true);
  $chart['chart_value'] = array('prefix' => "", 
				'suffix' => "", 
				'decimals' => 0, 
				'separator' => "", 
				'position' => "cursor", 
				'hide_zero' => true, 
				'as_percentage' => false, 
				'font' => "arial", 
				'bold' => true, 
				'size' => 12, 
				'color' => "000000", 
				'alpha' => 75 );
  $chart['chart_grid_h'] = array('alpha' => 5,
				 'color' => "000000", 
				 'thickness' => 1, 
				 'type' => "solid");
  $chart['chart_grid_v'] = array('alpha' => 5,
				 'color' => "000000",
				 'thickness' => 1,
				 'type' => "solid");


  // SET LEGEND LABEL AND QUERY VARIABLE
  $chart['chart_data'][0][0] = "";
  switch($graph) {
    case "imported_vs_invited":
      $var1 = "stat_imported_contacts";
      $var2 = "stat_invited_contacts";
      $chart['chart_data'][1][0] = $admin_friendsinviter_stats[24];
      $chart['chart_data'][2][0] = $admin_friendsinviter_stats[25];
      break;
    case "invites_vs_converted":
      $var1 = "stat_invites";
      $var2 = "stat_converted_invites";
      $chart['chart_data'][1][0] = $admin_friendsinviter_stats[26];
      $chart['chart_data'][2][0] = $admin_friendsinviter_stats[27];
      break;
    }

  // SET PERIOD
  switch($period) {
    case "week":
      $interval = "86400";
      $stat_date_format = "D";
      $date_compare = "j";
      $num_points = 8;
      if(date('w', time()) == 0) { $day_num = 7; } else { $day_num = date('w', time()); }
      $old_stat_date = mktime(0, 0, 0, date('n', time()), date('j', time())-$day_num+1-7*($start-1), date('Y', time()));
      $last_stat_date = mktime(0, 0, 0, date('n', time()), date('j', time())-$day_num+1-7*($start-1)+7, date('Y', time()));
      $chart['chart_data'][1][0] .= $admin_friendsinviter_stats[8].$admin_friendsinviter_stats[7]." ".$datetime->cdate("M jS", $old_stat_date).$admin_friendsinviter_stats[9];
      break;
    case "month":
      $interval = "86400";
      $stat_date_format = "j";
      $date_compare = "j";
      $num_points = date("t", time())+1;
      $old_stat_date = mktime(0, 0, 0, date('n', time())-($start-1), 1, date('Y', time()));
      $last_stat_date = mktime(0, 0, 0, date('n', time())-($start-1)+1, 1, date('Y', time()));
      $chart['chart_data'][1][0] .= $admin_friendsinviter_stats[8].$datetime->cdate("F", $old_stat_date).$admin_friendsinviter_stats[9];
      break;
    case "year":
      $interval = "2678400";
      $stat_date_format = "M.";
      $date_compare = "n";
      $num_points = 13;
      $old_stat_date = mktime(0, 0, 0, 1, 1, date('Y', time())-($start-1));
      $last_stat_date = mktime(0, 0, 0, 1, 1, date('Y', time())-($start-1)+1);
      $chart['chart_data'][1][0] .= $admin_friendsinviter_stats[8].$datetime->cdate("Y", $old_stat_date).$admin_friendsinviter_stats[9];
      break;
  }

  // RUN QUERY
  $stats = $database->database_query("SELECT stat_date, $var1 AS stat_var, $var2 AS stat_var2  FROM se_stats WHERE stat_date<=$last_stat_date AND stat_date>=$old_stat_date ORDER BY stat_date ASC");

  // SET VARS
  $count = 0;
  $old_stat_date = $old_stat_date-$interval;

  // PUT STATS INTO ARRAY FOR GRAPH
  while($stat = $database->database_fetch_assoc($stats)) {
    while($stat['stat_date']-$old_stat_date>$interval) {
      $new_stat_date = $old_stat_date + $interval;
      $count++;
      $chart['chart_data'][0][$count] = date($stat_date_format, $new_stat_date);
      $chart['chart_data'][1][$count] = 0;
      $chart['chart_data'][2][$count] = 0;
      $old_stat_date = $new_stat_date;
    }
    if(date($date_compare, $old_stat_date) == date($date_compare, $stat['stat_date'])) {
      $chart['chart_data'][1][$count] += $stat['stat_var'];
      $chart['chart_data'][2][$count] += $stat['stat_var2'];
    } else {
      $count++;
      $chart['chart_data'][0][$count] = date($stat_date_format, $stat['stat_date']);
      $chart['chart_data'][1][$count] = $stat['stat_var'];
      $chart['chart_data'][2][$count] = $stat['stat_var2'];
      $old_stat_date = $stat['stat_date'];
    }
  }

  while(count($chart['chart_data'][0])<$num_points) {
      $new_stat_date = $old_stat_date + $interval;
      $count++;
      $chart['chart_data'][0][$count] = date($stat_date_format, $new_stat_date);
      $chart['chart_data'][1][$count] = 0;
      $chart['chart_data'][2][$count] = 0;
      $old_stat_date = $new_stat_date;
  }


  // OUTPUT CHART
  SendChartData($chart);
  exit();
}








// INCLUDE FLASH CHART FUNCTIONS FOR GRAPHS
include_once "../include/charts/charts.php";
$chart = InsertChart("../include/charts/charts.swf", "../include/charts/charts_library", "admin_friendsinviter_stats.php?task=getdata&graph=$graph&period=$period&start=$start&uniqueID=".uniqid(rand(),true), 550, 400, "FFFFFF");





if($graph == "topinviters") {

  // CLEAR CHART
  $chart = "";

  $leaderboarddbr = $database->database_query("SELECT A.invites_sent, A.invites_converted, B.user_id, B.user_username FROM se_invites_stats_user A LEFT JOIN se_users B ON A.user_id = B.user_id WHERE B.user_id != 0 ORDER BY A.invites_sent DESC, A.invites_converted DESC LIMIT 100");
  $leaderboard = Array();
  while($row = $database->database_fetch_array($leaderboarddbr)) {
    $leaderboard[] = $row;
  }
  
  $leaderboard_title = $admin_friendsinviter_stats[30];
  $leaderboard_desc = $admin_friendsinviter_stats[31];

}

if($graph == "topsignups") {

  // CLEAR CHART
  $chart = "";

  $leaderboarddbr = $database->database_query("SELECT A.invites_sent, A.invites_converted, B.user_id, B.user_username FROM se_invites_stats_user A LEFT JOIN se_users B ON A.user_id = B.user_id WHERE B.user_id != 0 ORDER BY A.invites_converted DESC, A.invites_sent DESC LIMIT 100");
  $leaderboard = Array();
  while($row = $database->database_fetch_array($leaderboarddbr)) {
    $leaderboard[] = $row;
  }

  $leaderboard_title = $admin_friendsinviter_stats[32];
  $leaderboard_desc = $admin_friendsinviter_stats[33];

}







if($graph == "summary") {

  // CLEAR CHART
  $chart = "";

  // GET SUMMARY
  $stats = $database->database_fetch_array($database->database_query("SELECT SUM(stat_invites), SUM(stat_converted_invites ), SUM(stat_imported_contacts ), SUM(stat_invited_contacts) FROM se_stats"));

  $total_invites = $stats[0];
  $total_converted_invites = $stats[1];
  $contacts_invited_vs_signups = $total_invites ? $total_converted_invites / $total_invites * 100 : 0;

  $total_contacts_imported = $stats[2];
  $total_contacts_invited = $stats[3];
  $contacts_imported_vs_invited = $total_contacts_imported ? $total_contacts_invited / $total_contacts_imported * 100 : 0;
  
  $average_contacts_per_user = 0;

}




// ASSIGN VARIABLES AND SHOW STATS PAGE
$smarty->assign('chart', $chart);

$smarty->assign('total_invites', $total_invites);
$smarty->assign('total_converted_invites', $total_converted_invites);
$smarty->assign('contacts_invited_vs_signups', $contacts_invited_vs_signups);
$smarty->assign('total_contacts_imported', $total_contacts_imported);
$smarty->assign('total_contacts_invited', $total_contacts_invited);
$smarty->assign('contacts_imported_vs_invited', $contacts_imported_vs_invited);
$smarty->assign('average_contacts_per_user', $average_contacts_per_user);

$smarty->assign('leaderboard', $leaderboard);
$smarty->assign('leaderboard_total', count($leaderboard));
$smarty->assign('leaderboard_title', $leaderboard_title);
$smarty->assign('leaderboard_desc ', $leaderboard_desc);

$smarty->assign('topsignups', $topsignups);
$smarty->assign('topsignups_total', count($topsignups));

$smarty->assign('graph', $graph);
$smarty->assign('period', $period);
$smarty->assign('start', $start);

include "admin_footer.php";
?>