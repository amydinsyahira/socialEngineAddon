<?

// INCLUDE INVITE FUNCTION FILE
include_once "../include/functions_invite.php";

// INCLUDE SHARED CLASS FILE
include_once "../include/class_semods.php";

?>