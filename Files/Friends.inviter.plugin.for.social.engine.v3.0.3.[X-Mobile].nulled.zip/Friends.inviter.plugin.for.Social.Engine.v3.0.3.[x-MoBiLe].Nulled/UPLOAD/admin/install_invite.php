<?php
$plugin_name = "Friends Inviter Advanced";
$plugin_version = "3.1";
$plugin_type = "invite";
$plugin_desc = "This plugin allows your users easily invite their friends from address book like gmail, yahoo, hotmail, aol, mail.com, Messenger, etc.";
$plugin_icon = "invite16.gif";
$plugin_menu_title = "100010000";
$plugin_pages_main = "100010001<!>invite16.gif<!>admin_friendsinviter_stats.php<~!~>100010002<!>invite16.gif<!>admin_friendsinviter_tracker.php<~!~>100010003<!>invite16.gif<!>admin_friendsinviter.php<~!~>100010004<!>invite16.gif<!>admin_semods_support.php";
$plugin_pages_level = "";
$plugin_url_htaccess = "";

if($install == "invite") {

  //######### INSERT ROW INTO se_plugins
  $database->database_query("INSERT INTO se_plugins (

                  plugin_name,
                  plugin_version,
                  plugin_type,
                  plugin_desc,
                  plugin_icon,
                  plugin_menu_title,
                  plugin_pages_main,
                  plugin_pages_level,
                  plugin_url_htaccess
                  ) VALUES (
                  '$plugin_name',
                  '$plugin_version',
                  '$plugin_type',
                  '".str_replace("'", "\'", $plugin_desc)."',
                  '$plugin_icon',
                  '$plugin_menu_title',
                  '$plugin_pages_main',
                  '$plugin_pages_level',
                  '$plugin_url_htaccess')
  
                  ON DUPLICATE KEY UPDATE

                  plugin_version='$plugin_version',
                  plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
                  plugin_icon='$plugin_icon',
                  plugin_menu_title='$plugin_menu_title',
                  plugin_pages_main='$plugin_pages_main',
                  plugin_pages_level='$plugin_pages_level',
                  plugin_url_htaccess='$plugin_url_htaccess'
                  
  ");


  //######### INSERT LANGUAGE VARS
  $database->database_query("REPLACE INTO se_languagevars (languagevar_id, languagevar_language_id, languagevar_value, languagevar_default) VALUES (100010000, 1, 'Friends Inviter', ''),(100010001, 1, 'View Statistics', ''),(100010002, 1, 'Invitations Tracker', ''),(100010003, 1, 'Friends Inviter Settings', ''),(100010004, 1, 'Support', ''),(100010005, 1, 'Admininstrator, please configure your api_key and secret!', ''),(100010006, 1, 'Your Address Book is empty', ''),(100010007, 1, 'Please enter your login information.', ''),(100010008, 1, 'All your contacts are already here! Have you tried another address book?', ''),(100010009, 1, 'Background email - Notification of ERRORS', ''),(100010010, 1, 'Background email - Notification of success', ''),(100010011, 1, 'Unknown error occurred', ''),(100010012, 1, 'Service temporarily unavailable', ''),(100010013, 1, 'Not subscribed for this service', ''),(100010014, 1, 'Authentication failed', ''),(100010015, 1, 'Empty User or Password fields', ''),(100010016, 1, 'Unable to decide which service to use', ''),(100010017, 1, 'Unsupported service', ''),(100010018, 1, 'Service is unreachable at this moment', ''),(100010019, 1, 'Error during communication to service', ''),(100010020, 1, 'Capcha required', ''),(100010021, 1, 'HTTP Error', ''),(100010022, 1, 'Find Friends', ''),(100010023, 1, 'General Friends Inviter Settings', ''),(100010024, 1, 'This page contains general Friends Inviter settings.', ''),(100010025, 1, 'Your changes have been saved.', ''),(100010026, 1, 'Service keys', ''),(100010027, 1, 'API Key', ''),(100010028, 1, 'Secret', ''),(100010029, 1, 'Specify Api Key and Secret that you have recieved. Should be string 32 characters long consisting of letters and numbers.', ''),(100010030, 1, 'Spam prevention / Mail sending load', ''),(100010031, 1, '(This parameter is ignored if using background email sending.) <br> How many invitations each user can send per batch ( prevent server overload ) <b>Note:</b> Limiting this can seriously harm your network growth - extra emails are dropped. Please enter number, 0 for unlimited invitations per batch. ', ''),(100010032, 1, 'invitations per batch.', ''),(100010033, 1, 'How many invitations each user can send per day ( prevent spam ). <b>Note:</b> Limiting this can seriously harm your network growth - extra emails are dropped. Please enter number, 0 for unlimited invitations per day.', ''),(100010034, 1, 'invitations per day.', ''),(100010035, 1, 'Save Changes', ''),(100010036, 1, 'Require users to enter validation code when inviting others?', ''),(100010037, 1, 'If you have selected Yes, an image containing a random sequence of 6 numbers will be shown to users on the \\\"invite\\\" page. Users will be required to enter these numbers into the Verification Code field in order to send their invitation. This feature helps prevent users from trying to create comment spam. For this feature to work properly, your server must have the GD Libraries (2.0 or higher) installed and configured to work with PHP. If you are seeing errors, try turning this off.', ''),(100010038, 1, 'Yes, enable validation code for inviting.', ''),(100010039, 1, 'No, disable validation code for inviting.', ''),(100010040, 1, 'Befriending behaviour', ''),(100010041, 1, 'Please select friendship relation between new user and inviting / referring user, based on <strong><u>new user email address</u></strong>. This happens when one or more users send invitation to the same email address.', ''),(100010042, 1, 'Default network behaviour', ''),(100010043, 1, 'Only befriend if the network is invitation-only', ''),(100010044, 1, 'One-way friend request from inviter', ''),(100010045, 1, 'New user receives incoming friend request from the inviter(s) (Default)', ''),(100010046, 1, 'Confirmed friendship', ''),(100010047, 1, 'New user and inviter(s) become confirmed friends', ''),(100010048, 1, 'One-way friend request from new user', ''),(100010049, 1, 'Inviter(s) receive incoming friend request from the new user.', ''),(100010050, 1, 'Please select friendship relation between new user and inviting / referring user, based on <strong><u>referring user</u></strong>. This happens when invitation is sent or posted somewhere with \\\"signup_referer\\\" link, e.g. http://www.yoursite.com/signup.php?signup_referer=ReferringUser - default behavior when using website invitation system.', ''),(100010051, 1, 'No Friendship is established', ''),(100010052, 1, 'Good if you allow your users post links anywhere on the internet to market the site, so the new users have no social friendships relation with the inviter / promoter. (Default)', ''),(100010053, 1, 'One-way friend request from referring user (inviter/promoter)', ''),(100010054, 1, 'New user receives incoming friend request from the referring user (inviter/promoter) (Default)', ''),(100010055, 1, 'Confirmed friendship', ''),(100010056, 1, 'New user and referring user (inviter/promoter) become confirmed friends ', ''),(100010057, 1, 'One-way friend request from new user', ''),(100010058, 1, 'Referring user (inviter/promoter) receives incoming friend request from the new user.', ''),(100010059, 1, 'Background emaling Settings', ''),(100010060, 1, 'This page contains Background emaling settings.', ''),(100010061, 1, 'Your changes have been saved.', ''),(100010062, 1, 'Save Changes', ''),(100010063, 1, 'Background email sending', ''),(100010064, 1, 'Currently queued emails:', ''),(100010065, 1, 'Background email sending allows queueing invitation emails and sending them in a much more controlled way in order to prevent server overload and marking host as spammer. Invitation process is much faster - user doesn\'t wait for emails to finish being sent but is instantly presented with next page. <b> Note: </b> Currently works for unix/linux based servers only.', ''),(100010066, 1, 'Enable background email sending', ''),(100010067, 1, 'Maximum retries for sending mail - sometimes sending can fail - instead of silently dropping them, retry upto this amount.', ''),(100010068, 1, 'maximum retries', ''),(100010069, 1, 'Maximum emails to send each run / batch of processing. The background processing script will send this much emails each time it is run. Enter 0 to send all queued emails at once.', ''),(100010070, 1, 'max emails per batch', ''),(100010071, 1, 'SMTP host', ''),(100010072, 1, 'Crontab line - path to php5 binary and processing script. Please note - this should be php version 5. The background processing script is located in your installation: <i>admin/process_email_queue.php</i>, the path should be absolute.', ''),(100010073, 1, 'Reset crontab line to default', ''),(100010074, 1, 'Crontab period - period to run background email process script. Note: Some hosting companies limit crontab jobs period to minimum of 15 minutes.', ''),(100010075, 1, 'min', ''),(100010076, 1, 'hour', ''),(100010077, 1, 'Estimated time to send these emails:', ''),(100010078, 1, 'days', ''),(100010079, 1, 'hours', ''),(100010080, 1, 'minutes', ''),(100010081, 1, 'Notifications from background processing script, will be sent to administrator email', ''),(100010082, 1, 'Notify on error', ''),(100010083, 1, 'Notify on success', ''),(100010084, 1, 'There was an error running crontab( %s ). Please make sure your hoster allows executing crontab or add the \'crontab line\' manually from your cpanel crontab editor.', ''),(100010085, 1, 'Could not find php binary. Please enter manually.', ''),(100010086, 1, 'SMTP Server Settings', ''),(100010087, 1, 'Configure STMP Server for sending email. <strong><u>Note</u></strong>: SMTP server is only used when background emailing is enabled.', ''),(100010088, 1, 'SMTP host', ''),(100010089, 1, 'SMTP port', ''),(100010090, 1, 'SMTP user', ''),(100010091, 1, 'SMTP password', ''),(100010092, 1, 'The following settings are optional and should be changed only if instructed by your hoster.', ''),(100010093, 1, 'Invitation Statistics', ''),(100010094, 1, 'Use this page to monitor your network growth.', ''),(100010095, 1, 'Quick Summary', ''),(100010096, 1, 'Invitations Sent vs Signups', ''),(100010097, 1, 'Imported Contacts vs Invited', ''),(100010098, 1, 'Network Growth', ''),(100010099, 1, 'Week of', ''),(100010100, 1, ' (', ''),(100010101, 1, ')', ''),(100010102, 1, 'Quick Network Invitation Statistics', ''),(100010103, 1, 'The following data is a quick snapshot of your social network.<br>The data does not include any items that have been deleted.', ''),(100010104, 1, 'Average contacts per user:', ''),(100010105, 1, 'Total Invitations sent:', ''),(100010106, 1, 'Total Signups by Invitations:', ''),(100010107, 1, 'Invites/Signups Ratio:', ''),(100010108, 1, 'Total Contacts Imported', ''),(100010109, 1, 'Total Invited From Imported Contacts:', ''),(100010110, 1, 'Imported/Invited Ratio:', ''),(100010111, 1, 'Period:', ''),(100010112, 1, 'This Week (Daily)', ''),(100010113, 1, 'This Month (Daily)', ''),(100010114, 1, 'This Year (Monthly)', ''),(100010115, 1, 'Refresh', ''),(100010116, 1, 'Imported contacts', ''),(100010117, 1, 'Invited contacts', ''),(100010118, 1, 'Invites Sent', ''),(100010119, 1, 'Referred Users', ''),(100010120, 1, 'Leaderboard', ''),(100010121, 1, 'Top Inviters', ''),(100010122, 1, 'clear all user statistics', ''),(100010123, 1, 'Top Inviter', ''),(100010124, 1, '', ''),(100010125, 1, 'Top Signups', ''),(100010126, 1, '', ''),(100010127, 1, 'User', ''),(100010128, 1, 'No data.', ''),(100010129, 1, 'Last Period', ''),(100010130, 1, 'Next Period', ''),(100010131, 1, 'Invite Users', ''),(100010132, 1, 'Use this page to invite new users to your social network. If you have specified that users may signup by invitation only, this page will email an invitation code to the email addresses you specify. Otherwise, a simple invitation email will be sent. Both these emails can be modified on your <a href=\'admin_emails.php\'>System Emails</a> page.', ''),(100010133, 1, 'Email Addresses', ''),(100010134, 1, 'Enter email addresses, separated by commas, in the field below.', ''),(100010135, 1, 'Invite Users', ''),(100010136, 1, 'Invitations have been sent!', ''),(100010137, 1, 'Your invitations have been sent.', ''),(100010138, 1, 'Invite Your Friends', ''),(100010139, 1, 'It\'s more fun with friends! Invite your friends to join.', ''),(100010140, 1, 'You have', ''),(100010141, 1, 'invite(s) remaining.', ''),(100010142, 1, 'When they signup, they will be instantly added to your friends list.', ''),(100010143, 1, 'Email:', ''),(100010144, 1, 'Separate multiple email addresses (up to 5) with commas.', ''),(100010145, 1, 'Message:', ''),(100010146, 1, 'Type your message here. (optional)', ''),(100010147, 1, 'Send Invitation', ''),(100010148, 1, 'You must be logged in to view this page. <a href=\'login.php\'>Click here</a> to login.', ''),(100010149, 1, 'An Error Has Occurred.', ''),(100010150, 1, 'Return', ''),(100010151, 1, 'Enter the numbers you see in this image into the field to its left. This helps keep our site free of spam.', ''),(100010152, 1, 'Please make sure you have correctly entered the verification code.', ''),(100010153, 1, 'Please enter at least one recipient email address for your invitation.', ''),(100010154, 1, 'Invite friends from your address book.', ''),(100010155, 1, 'Email:', ''),(100010156, 1, '(for example mymail@gmail.com)', ''),(100010157, 1, 'Password:', ''),(100010158, 1, 'We don\'t store your login information.', ''),(100010159, 1, 'Network:', ''),(100010160, 1, 'Invite friends', ''),(100010161, 1, 'Messenger, LinkedIn, Plaxo, ...', ''),(100010162, 1, 'Auto', ''),(100010163, 1, 'Invite your friends', ''),(100010164, 1, 'Your contacts', ''),(100010165, 1, 'Please select which of your contacts would you like to invite.', ''),(100010166, 1, 'Select all/nothing', ''),(100010167, 1, 'Invite Friends', ''),(100010168, 1, 'Cancel', ''),(100010169, 1, 'We don\'t store your login information.', ''),(100010170, 1, 'Web Email ', ''),(100010171, 1, 'Start typing domain...', ''),(100010172, 1, 'This domain may be supported.', ''),(100010173, 1, 'Type domain here', ''),(100010174, 1, '(Gmail, Hotmail, Yahoo, ...)', ''),(100010175, 1, 'Loading... (this may take up to one minute)', ''),(100010176, 1, 'Or invite from your address book', ''),(100010177, 1, 'Or invite by manually typing emails', ''),(100010178, 1, '(Click to Open)', ''),(100010179, 1, 'other...', ''),(100010180, 1, '+ Add more', ''),(100010181, 1, 'friends', ''),(100010182, 1, 'that are still not here!', ''),(100010183, 1, 'Current Friends', ''),(100010184, 1, 'Friend Requests', ''),(100010185, 1, 'Friend Settings', ''),(100010186, 1, 'Outgoing Friend Requests', ''),(100010187, 1, 'It\'s more fun with friends! Check which of your address book buddies is already here.', ''),(100010188, 1, 'Find Your Friends', ''),(100010189, 1, 'Select all your friends', ''),(100010190, 1, 'You have ', ''),(100010191, 1, ' contacts already here that you can add as friends', ''),(100010192, 1, 'Add to friends', ''),(100010193, 1, 'Select which users would you like to add as friends.', ''),(100010194, 1, 'Login to your address book to find your friends.', ''),(100010195, 1, 'or', ''),(100010196, 1, 'Invite Friends', ''),(100010197, 1, 'Pending Invites', ''),(100010198, 1, 'Statistics', ''),(100010199, 1, 'You must be logged in to view this page. <a href=\'login.php\'>Click here</a> to login.', ''),(100010200, 1, 'An Error Has Occurred.', ''),(100010201, 1, 'Return', ''),(100010202, 1, 'Pending Invites', ''),(100010203, 1, 'Here you can see status of your invitations.', ''),(100010204, 1, 'You do not have any pending invites at this time.', ''),(100010205, 1, 'Previous Page', ''),(100010206, 1, 'viewing invite', ''),(100010207, 1, 'viewing invites', ''),(100010208, 1, 'of', ''),(100010209, 1, 'Next Page', ''),(100010210, 1, 'Invite Friends', ''),(100010211, 1, 'Pending Invites', ''),(100010212, 1, 'Statistics', ''),(100010213, 1, 'Statistics', ''),(100010214, 1, 'Here you can view statistics of your invitations.', ''),(100010215, 1, 'Invites Sent:', ''),(100010216, 1, 'Referred Users:', ''),(100010217, 1, 'Invite Friends', ''),(100010218, 1, 'Pending Invites', ''),(100010219, 1, 'Statistics', ''),(100010220, 1, 'Invite friends from your address book.', ''),(100010221, 1, 'Email:', ''),(100010222, 1, '(for example mymail@gmail.com)', ''),(100010223, 1, 'Password:', ''),(100010224, 1, 'Find friends!', ''),(100010225, 1, 'Messenger, LinkedIn, Plaxo, ...', ''),(100010226, 1, 'Invite your friends', ''),(100010227, 1, 'Your contacts', ''),(100010228, 1, 'Please choose contacts you would like to invite from the list', ''),(100010229, 1, 'Choose all/nothing', ''),(100010230, 1, 'Invite friends', ''),(100010231, 1, 'Cancel', ''),(100010232, 1, 'We don\'t store your login information.', ''),(100010233, 1, 'Web mail', ''),(100010234, 1, 'Please enter at least one email address.', ''),(100010235, 1, 'Your invites were sent.', ''),(100010236, 1, 'Select all your friends', ''),(100010237, 1, 'You have ', ''),(100010238, 1, ' contacts already here', ''),(100010239, 1, '', ''),(100010240, 1, ' that you can add as friends.', ''),(100010241, 1, 'Select which users would you like to add as friends.', ''),(100010242, 1, 'Choose another email account', ''),(100010243, 1, ' to find more friends', ''),(100010244, 1, 'Add to friends', ''),(100010245, 1, 'Skip', ''),(100010246, 1, ' contacts ', ''),(100010247, 1, 'that are still not here!', ''),(100010248, 1, 'that are not on ', ''),(100010249, 1, 'Select which of your contacts would you like to invite.', ''),(100010250, 1, 'Please correct your login details.', ''),(100010251, 1, 'No contacts.', ''),(100010252, 1, 'Start typing domain...', ''),(100010253, 1, 'This domain may be supported.', ''),(100010254, 1, 'Type domain here', ''),(100010255, 1, 'Web Email ', ''),(100010256, 1, '(Click to Open)', ''),(100010257, 1, '(other...)', ''),(100010258, 1, 'Network', ''),(100010259, 1, 'Loading... (this may take up to one minute)', ''),(100010260, 1, 'Or invite from your address book', ''),(100010261, 1, 'Or invite by manually typing emails', ''),(100010262, 1, '+ Add more', ''),(100010263, 1, 'Your Message', ''),(100010264, 1, 'If you want to include a personal message in your invitations, enter it here. (optional)', ''),(100010265, 1, 'Find Your Friends', ''),(100010266, 1, 'It\'s more fun with friends! Check which of your address book buddies is already here.', ''),(100010267, 1, 'or', ''),(100010268, 1, 'Unsubscribe', ''),(100010269, 1, 'Here you can unsubscribe from receiving any future emails from our website.', ''),(100010270, 1, 'Your Email:', ''),(100010271, 1, 'Unsubscribe', ''),(100010272, 1, 'Please verify you have entered valid email address.', ''),(100010273, 1, 'You have been unsubscribed. Please allow 1-2 business days for processing.', ''),(100010274, 1, 'Top Webmail services', ''),(100010275, 1, 'Edit pre-selected webmail services that will appear in the drop down box of the web mails on the invitation page. ( gmail.com, yahoo.com ... ) ', ''),(100010276, 1, '+ Add more', ''),(100010277, 1, 'Top Networks', ''),(100010278, 1, 'Edit list of services that will appear on the network selection drop-down box on the invitation page. Networks include - Messenger, Facebook, Hi5, Myspace, LinkedIn, etc <br> To remove a service, clear \"Display Name\" field.<br> <strong><u>NOTE</u></strong>: Service Name must be matched exactly to the provided list - no spaces, only english.', ''),(100010279, 1, 'Enabled?', ''),(100010280, 1, 'Display Name', ''),(100010281, 1, 'Service Name', ''),(100010282, 1, 'Logo file', ''),(100010283, 1, '+ Add more', ''),(100010284, 1, 'Filter emails', ''),(100010285, 1, 'Edit list of emails that should never receive invitation messages, like support@, info@ ... <br> Note: Regular expression match.', ''),(100010286, 1, '+ Add more', ''),(100010287, 1, 'Referrals / Invitation Tracker', ''),(100010288, 1, 'Here you can see referrals information and statistics', ''),(100010289, 1, 'Username:', ''),(100010290, 1, 'Referring User:', ''),(100010291, 1, 'Filter', ''),(100010292, 1, 'No users were found.', ''),(100010293, 1, 'Users Found', ''),(100010294, 1, 'Page:', ''),(100010295, 1, 'ID', ''),(100010296, 1, 'Username', ''),(100010297, 1, 'Invites Sent', ''),(100010298, 1, 'Referred Users', ''),(100010299, 1, 'Referred By User', ''),(100010300, 1, 'Users Found', ''),(100010301, 1, 'Page:', ''),(100010302, 1, 'SocialEngineMods Quick Support', ''),(100010303, 1, 'Having a problem? Send us an email from here, or <a target=\"blank\" href=\"http://www.socialenginemods.net\">visit our website</a>', ''),(100010304, 1, 'You support request have been sent.', ''),(100010305, 1, 'Name', ''),(100010306, 1, 'Email', ''),(100010307, 1, 'Subject', ''),(100010308, 1, 'Submit support request', ''),(100010309, 1, 'My Referral Link', ''),(100010310, 1, 'Please enter captcha', ''),(100010311, 1, 'Please enter the captcha:', ''),(100010312, 1, 'Continue', ''),(100010313, 1, 'Please select which of your friends would you like to invite', ''),(100010314, 1, 'Select all/nothing', ''),(100010315, 1, 'Please enter captcha', ''),(100010316, 1, 'Please enter the captcha:', ''),(100010317, 1, 'Continue', ''),(100010318, 1, 'Cancel', ''),(100010319, 1, 'You have', ''),(100010320, 1, 'friends', ''),(100010321, 1, 'that are still not here!', ''),(100010322, 1, 'Please select which of your friends would you like to invite', ''),(100010323, 1, 'Select all/nothing', ''),(100010324, 1, 'My Referral Link', ''),(100010325, 1, 'delete', ''),(100010326, 1, 'send new invite', ''),(100010327, 1, 'sending...', ''),(100010328, 1, 'My Referral Link', ''),(100010329, 1, 'My Referral Link', ''),(100010330, 1, 'You can either send an invitation from our site or you can copy and paste your Personal Referral Link and send it in an email or instant message to friends, family members or co-workers.', ''),(100010331, 1, 'My Referral Link:', ''),(100010332, 1, 'My Referral Link', '')");

  

  
  




  if(!function_exists('chain_sql')) {
    function chain_sql( $sql ) {
      global $database;
  
      $rows = explode( ';', $sql);
      foreach($rows as $row) {
        $row = trim($row);
        if(empty($row))
          continue;
        $database->database_query( $row );
      }
  
    }
  }

  //######### CREATE DATABASE STRUCTURE

    chain_sql(
<<<EOC

CREATE TABLE IF NOT EXISTS `se_invites_stats_user` (
  `user_id` int(9) NOT NULL default '0',
  `invites_sent` int(11) NOT NULL default '0',
  `invites_converted` int(11) NOT NULL default '0',
  `invites_sent_counter` int(11) NOT NULL default '0',
  `invites_sent_last` datetime NOT NULL default '0000-00-00',
  PRIMARY KEY  (`user_id`)
);

CREATE TABLE `se_semods_unsubscribe` (
  `unsubscribe_id` int(11) NOT NULL auto_increment,
  `unsubscribe_user_id` int(11) NOT NULL default '0',
  `unsubscribe_user_email` varchar(255) NOT NULL,
  `unsubscribe_type` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`unsubscribe_id`),
  KEY `unsubscribe_user_email` (`unsubscribe_user_email`)
);

EOC
);
  
  
  
  /*** SHARED ELEMENTS ***/



  //######### CREATE se_semods_settings
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_semods_settings'")) == 0) {
    $database->database_query("CREATE TABLE `se_semods_settings` (
      `setting_invite_api_key` varchar(32) NOT NULL default '',
      `setting_invite_secret` varchar(32) NOT NULL default '',
      `setting_invite_max_invites_per_batch` int(11) NOT NULL default '0',
      `setting_invite_max_invites_per_day` int(11) NOT NULL default '0',
	  `setting_invite_date_format` varchar(255) NOT NULL default 'j F Y',
	  `setting_invite_befriend_by_email` tinyint(1) NOT NULL default '1',
	  `setting_invite_befriend_by_referer` tinyint(1) NOT NULL default '0',
      `setting_invite_topdomains` TEXT NOT NULL,
      `setting_invite_topnetworks` TEXT NOT NULL,
      `setting_invite_filteremails` TEXT NOT NULL
    )");

    $database->database_query("INSERT INTO `se_semods_settings` (`setting_invite_topdomains`, `setting_invite_topnetworks`, `setting_invite_filteremails`) VALUES ('gmail.com,hotmail.com,live.com,yahoo.com,aol.com,mail.com,mac.com,fastmail.fm,inbox.com', 'a:8:{i:0;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:9:\"messenger\";s:1:\"d\";s:13:\"MSN Messenger\";s:1:\"l\";s:0:\"\";}i:1;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:5:\"plaxo\";s:1:\"d\";s:5:\"Plaxo\";s:1:\"l\";s:0:\"\";}i:2;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:7:\"myspace\";s:1:\"d\";s:7:\"MySpace\";s:1:\"l\";s:0:\"\";}i:3;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:8:\"Facebook\";s:1:\"d\";s:8:\"Facebook\";s:1:\"l\";s:17:\"logo_facebook.gif\";}i:4;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:3:\"hi5\";s:1:\"d\";s:3:\"Hi5\";s:1:\"l\";s:12:\"logo_hi5.gif\";}i:5;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:5:\"orkut\";s:1:\"d\";s:5:\"Orkut\";s:1:\"l\";s:14:\"logo_orkut.png\";}i:6;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:8:\"linkedin\";s:1:\"d\";s:8:\"LinkedIn\";s:1:\"l\";s:17:\"logo_linkedin.gif\";}i:7;a:4:{s:1:\"e\";s:1:\"0\";s:1:\"n\";s:16:\"friendconnectapi\";s:1:\"d\";s:4:\"Test\";s:1:\"l\";s:0:\"\";}}', '^support@.*,^info@.*,adsense-support@google.com')");
  }

  // UPGRADE / MODIFY
  //######### ADD COLUMNS/VALUES TO se_semods_settings TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_semods_settings LIKE 'setting_invite_api_key'")) == 0) {
    $database->database_query("ALTER TABLE se_semods_settings
      ADD COLUMN `setting_invite_api_key` varchar(32) NOT NULL default '',
      ADD COLUMN `setting_invite_secret` varchar(32) NOT NULL default '',
      ADD COLUMN `setting_invite_max_invites_per_batch` int(11) NOT NULL default '0',
      ADD COLUMN `setting_invite_max_invites_per_day` int(11) NOT NULL default '0',
	  ADD COLUMN `setting_invite_date_format` varchar(255) NOT NULL default 'j F Y',
	  ADD COLUMN `setting_invite_befriend_by_email` tinyint(1) NOT NULL default '1',
	  ADD COLUMN `setting_invite_befriend_by_referer` tinyint(1) NOT NULL default '0',
      ADD COLUMN `setting_invite_topdomains` TEXT NOT NULL,
      ADD COLUMN `setting_invite_topnetworks` TEXT NOT NULL,
      ADD COLUMN `setting_invite_filteremails` TEXT NOT NULL
	");

    $database->database_query("UPDATE `se_semods_settings` SET
    			`setting_invite_topdomains` = 'gmail.com,hotmail.com,live.com,yahoo.com,aol.com,mail.com,mac.com,fastmail.fm,inbox.com',
    			`setting_invite_topnetworks` = 'a:8:{i:0;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:9:\"messenger\";s:1:\"d\";s:13:\"MSN Messenger\";s:1:\"l\";s:0:\"\";}i:1;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:5:\"plaxo\";s:1:\"d\";s:5:\"Plaxo\";s:1:\"l\";s:0:\"\";}i:2;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:7:\"myspace\";s:1:\"d\";s:7:\"MySpace\";s:1:\"l\";s:0:\"\";}i:3;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:8:\"Facebook\";s:1:\"d\";s:8:\"Facebook\";s:1:\"l\";s:17:\"logo_facebook.gif\";}i:4;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:3:\"hi5\";s:1:\"d\";s:3:\"Hi5\";s:1:\"l\";s:12:\"logo_hi5.gif\";}i:5;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:5:\"orkut\";s:1:\"d\";s:5:\"Orkut\";s:1:\"l\";s:14:\"logo_orkut.png\";}i:6;a:4:{s:1:\"e\";s:1:\"1\";s:1:\"n\";s:8:\"linkedin\";s:1:\"d\";s:8:\"LinkedIn\";s:1:\"l\";s:17:\"logo_linkedin.gif\";}i:7;a:4:{s:1:\"e\";s:1:\"0\";s:1:\"n\";s:16:\"friendconnectapi\";s:1:\"d\";s:4:\"Test\";s:1:\"l\";s:0:\"\";}}',
    			`setting_invite_filteremails` = '^support@.*,^info@.*,adsense-support@google.com'
    			");

  }



  //######### ADD COLUMNS/VALUES TO se_stats TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_stats LIKE 'stat_invites'")) == 0) {
    $database->database_query("ALTER TABLE se_stats
					ADD COLUMN `stat_invites` INT( 9 ) NOT NULL DEFAULT '0',
					ADD COLUMN `stat_converted_invites` INT( 9 ) NOT NULL DEFAULT '0',
					ADD COLUMN `stat_imported_contacts` INT( 9 ) NOT NULL DEFAULT '0',
					ADD COLUMN `stat_invited_contacts` INT( 9 ) NOT NULL DEFAULT '0'");

  }

  //######### ADD COLUMNS/VALUES TO se_users TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_users LIKE 'user_referer'")) == 0) {
    $database->database_query("ALTER TABLE se_users
					ADD COLUMN `user_referer` INT( 9 ) NOT NULL DEFAULT '0'
	");

  }

  //######### MODIFY se_stats ADD UNIQUE INDEX
  // SE Team implemented my patch from v2.71, so check if it's uniq already
  $semods_dbr = $database->database_query("SHOW COLUMNS FROM ".$database_name.".se_stats LIKE 'stat_date'");
  $field_info = $semods_dbr ? $database->database_fetch_assoc($semods_dbr) : false;
  if($field_info && ($field_info['Key'] != "UNI")) {
	$database->database_query("ALTER TABLE `se_stats` ADD UNIQUE (`stat_date`)");
  }

  //######### MODIFY se_invites
  $semods_dbr = $database->database_query("SHOW COLUMNS FROM ".$database_name.".se_invites LIKE 'invite_user_id'");
  $field_info = $semods_dbr ? $database->database_fetch_assoc($semods_dbr) : false;
  if($field_info && ($field_info['Key'] != "MUL")) {
    $database->database_query("ALTER TABLE `se_invites` ADD UNIQUE `invite_set` ( `invite_user_id` , `invite_email` )");
  }


}


?>