<?
$page = "admin_friendsinviter_invite";
include "admin_header.php";

error_reporting( E_ALL ^ E_NOTICE ^ E_WARNING );

$task = semods::post('task', 'main');

// SET RESULT VARIABLE
$result = 0;


// SEND INVITATIONS
if($task == 'doinvite') {

  $fi_result = fi_invite_contacts();
  if($fi_result['err'] == 0) {
    $result = 1;
  }

}

// ASSIGN VARIABLES AND SHOW BANNING PAGE
$smarty->assign('result', $result);
include "admin_footer.php";
?>