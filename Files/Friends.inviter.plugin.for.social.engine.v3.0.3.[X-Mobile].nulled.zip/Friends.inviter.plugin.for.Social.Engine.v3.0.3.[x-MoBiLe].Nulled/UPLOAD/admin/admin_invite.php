<?php
header('Location: admin_friendsinviter_invite.php');
?>
