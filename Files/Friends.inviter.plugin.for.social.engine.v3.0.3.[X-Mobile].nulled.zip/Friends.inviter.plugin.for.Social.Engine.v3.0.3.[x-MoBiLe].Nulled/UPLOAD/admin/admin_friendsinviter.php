<?
$page = "admin_friendsinviter";
include "admin_header.php";

$task = semods::getpost('task', 'main');


// SET RESULT VARIABLE
$result = 0;


// SAVE CHANGES
if($task == "dosave") {
  $setting_invite_api_key = semods::post('setting_invite_api_key');
  $setting_invite_secret = semods::post('setting_invite_secret');
  $setting_invite_max_invites_per_batch = intval($_POST['setting_invite_max_invites_per_batch']);
  $setting_invite_max_invites_per_day = intval($_POST['setting_invite_max_invites_per_day']);

  $setting_invite_befriend_by_referer = intval($_POST['setting_invite_befriend_by_referer']);
  $setting_invite_befriend_by_email = intval($_POST['setting_invite_befriend_by_email']);

  $setting_invite_topdomains = implode(',', semods::remove_array_empty_values( semods::post('top_domains', array()) ) );
  
  $topnetworks = semods::post('top_networks', array());
  $setting_invite_topnetworks = array();
  for($i=0; $i<count($topnetworks['d']);$i++) {
    if(trim($topnetworks['d'][$i]) == "")
      continue;
    $setting_invite_topnetworks[] = array( 'e' => semods::g($topnetworks['e'],$i,0),
                                           'n' => $topnetworks['n'][$i],
                                           'd' => $topnetworks['d'][$i],
                                           'l' => $topnetworks['l'][$i],
                                           );
  }
  
  $setting_invite_topnetworks = serialize($setting_invite_topnetworks);
  
  $setting_invite_filteremails = implode(',', semods::remove_array_empty_values( semods::post('filter_emails', array()) ) );

  $database->database_query("UPDATE se_semods_settings SET 
			setting_invite_api_key='$setting_invite_api_key',
			setting_invite_secret='$setting_invite_secret',
			setting_invite_max_invites_per_batch=$setting_invite_max_invites_per_batch,
			setting_invite_max_invites_per_day=$setting_invite_max_invites_per_day,
            setting_invite_befriend_by_referer = $setting_invite_befriend_by_referer,
            setting_invite_befriend_by_email = $setting_invite_befriend_by_email,
            setting_invite_topdomains = '$setting_invite_topdomains',
            setting_invite_topnetworks = '$setting_invite_topnetworks',
            setting_invite_filteremails = '$setting_invite_filteremails'
			");

  $result = 1;

  // GLOBAL SETTINGS  
  $setting_invite_code = $_POST['setting_invite_code'];
  $database->database_query("UPDATE se_settings SET setting_invite_code='$setting_invite_code'");
}


$global_settings = semods::db_query_assoc( "SELECT setting_invite_code FROM se_settings LIMIT 1" );


// Settings
$semods_settings = semods::get_settings();
foreach($semods_settings as $setting => $value)
  if(strncmp("setting_invite_", $setting, 15) == 0)
  $smarty->assign($setting, $value);

// TOP/AVAILABLE DOMAINS, SERVICES
list($top_domains, $top_networks) = fi_get_top_services();

$filter_emails = explode( ',', semods::get_setting('invite_filteremails') );

// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('top_domains', $top_domains);
$smarty->assign('top_networks', $top_networks);
$smarty->assign('filter_emails', $filter_emails);
$smarty->assign('result', $result);
$smarty->assign('error', $error);
$smarty->assign('setting_invite_code', $global_settings['setting_invite_code']);
include "admin_footer.php";
?>