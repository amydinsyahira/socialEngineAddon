<?
$page = "admin_friendsinviter_tracker";
include "admin_header.php";


$s = semods::getpost('s', "vd");   // sort default by invite count desc
$p = semods::getpost('p', 1);
$f_user = semods::getpost('f_user', "");
$f_refuser = semods::getpost('f_refuser', "");

$task = semods::getpost('task', "main");
$user_id = semods::getpost('user_id', 0);

// GET USER IF ONE IS SPECIFIED
$user = new se_user(Array($user_id));

// SET USER SORT-BY VARIABLES FOR HEADING LINKS
$i = "id";   // USER_ID
$u = "u";    // USER_USERNAME
$v = "v";    // INVITES COUNT
$r = "r";    // REFS COUNT

// SET SORT VARIABLE FOR DATABASE QUERY
if($s == "i") {
  $sort = "user_id";
  $i = "id";
} elseif($s == "id") {
  $sort = "user_id DESC";
  $i = "i";
} elseif($s == "u") {
  $sort = "user_username";
  $u = "ud";
} elseif($s == "ud") {
  $sort = "user_username DESC";
  $u = "u";
} elseif($s == "v") {
  $sort = "invites_sent";
  $v = "vd";
} elseif($v == "vd") {
  $sort = "invites_sent DESC";
  $v = "v";
} elseif($s == "r") {
  $sort = "invites_converted ";
  $r = "rd";
} elseif($s == "rd") {
  $sort = "invites_converted DESC";
  $r = "r";
} else {
  $sort = "user_id DESC";
  $i = "i";
}


$sql_head = "SELECT U.user_id, U.user_username, IFNULL(U1.user_username,'') as referer,
			   IFNULL(S.invites_sent, 0) AS invites_sent,
			   IFNULL(S.invites_converted, 0) AS invites_converted";

$sql_body = "FROM se_users U
		LEFT JOIN se_invites_stats_user S ON U.user_id = S.user_id
		LEFT JOIN se_users U1 ON U.user_referer = U1.user_id
        ";

$filters = array();
$f_user != ""    ? $filters[] = "U.user_username LIKE '%$f_user%'" :0;
$f_refuser != ""   ? $filters[] = "U1.user_username = '$f_refuser'" :0;

!empty($filters)  ? $sql_body .= " WHERE " . implode( " AND ", $filters):0;

$sql_count = 'SELECT COUNT(*)' . ' ' . $sql_body;

$sql_users = $sql_head  . ' ' . $sql_body;
		

// GET TOTAL USERS
$total_users = semods::db_query_count( $sql_count );

// MAKE USER PAGES
$users_per_page = 100;
$page_vars = make_page($total_users, $users_per_page, $p);

$page_array = Array();
for($x=0;$x<=$page_vars[2]-1;$x++) {
  if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
  $page_array[$x] = Array('page' => $x+1,
                          'link' => $link);
}

$sql_users .= " ORDER BY $sort LIMIT $page_vars[0], $users_per_page";




// PULL USERS INTO AN ARRAY
$users = semods::db_query_assoc_all( $sql_users );

//var_dump($users);exit;

// ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('total_users', $total_users);
$smarty->assign('pages', $page_array);
$smarty->assign('users', $users);
$smarty->assign('i', $i);
$smarty->assign('u', $u);
$smarty->assign('v', $v);
$smarty->assign('r', $r);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('s', $s);
$smarty->assign('f_user', $f_user);
$smarty->assign('f_refuser', $f_refuser);
include "admin_footer.php"
?>