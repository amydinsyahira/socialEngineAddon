<?
$page = "admin_semods_support";
include "admin_header.php";

$task = semods::getpost('task', 'main');

// SET RESULT VARIABLE
$result = 0;

$from_name = $setting['setting_email_fromname'];
$from_email = $setting['setting_email_fromemail'];
$subject = "Support Request - ";

// SAVE CHANGES
if($task == "dosend") {
  $from_name = semods::post('from_name');
  $from_email = semods::post('from_email');
  $subject = semods::post('subject');
  $message = semods::post('message');

  $sender = "$from_name <$from_email>";
  
  send_generic( 'support@socialenginemods.net', $sender, $subject, $message, array(), array() );

  $subject = "";

  $result = 1;
}


// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('from_name', $from_name);
$smarty->assign('from_email', $from_email);
$smarty->assign('subject', $subject);
$smarty->assign('result', $result);
$smarty->assign('error', $error);
include "admin_footer.php";
?>