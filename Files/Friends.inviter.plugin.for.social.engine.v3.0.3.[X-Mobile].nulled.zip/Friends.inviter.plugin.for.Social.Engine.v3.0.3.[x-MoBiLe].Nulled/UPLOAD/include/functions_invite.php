<?php

//  THIS FILE CONTAINS INVITATION FUNCTIONS
//  FUNCTIONS IN THIS CLASS:
//
// filter_registered_emails
//
// Settings
// fi_get_api_params
//
// helper functions
// fi_preprocess_invitation
// fi_import_contacts
//
// Email
// fi_send_invitation
// fi_send_invitecode
//
// Stats
// fi_update_stats



$contacts_importer_errors[1] = 100010011;
$contacts_importer_errors[8] = 100010012;
$contacts_importer_errors[9] = 100010013;
$contacts_importer_errors[100] = 100010014;
$contacts_importer_errors[101] = 100010015;
$contacts_importer_errors[102] = 100010016;
$contacts_importer_errors[103] = 100010017;
$contacts_importer_errors[104] = 100010018;
$contacts_importer_errors[105] = 100010019;
$contacts_importer_errors[107] = 100010020;
$contacts_importer_errors[1000] = 100010021;






/*********************** Friends Inviter Core Functions *********************/

function fi_check_patterns( $email, $patterns ) {
  foreach($patterns as $pattern) {
    if(preg_match('/'.$pattern.'/i', $email)) {
      return true;
    }
  }
  return false;
}


// Dissects supplied emails for already registered users($friends) and new emails
// also check for valid emails
// in: array of emails / csv email list / array of contacts
//
function filter_registered_emails(&$emails, $emails_are_contacts = false, &$friends, $friends_with ) {
	global $database, $url;

    $excluded_emails = explode(',', semods::get_setting('invite_filteremails'));
    
	$emails_for_query = array();
	$friends_splice = array();

	if(!is_array($emails))
		$emails = explode(',', $emails);

	if($emails_are_contacts) {
      $contacts_new = array();
		foreach($emails as $contact) {
          $contact['email'] = trim($contact['email']);
        if((is_email_address($contact['email'])) && !fi_check_patterns($contact['email'], $excluded_emails)) {
			$emails_for_query[] = "'" . $contact['email'] . "'";
          $contacts_new[] = $contact;
		}
      }
      $emails = $contacts_new;
	} else {
		foreach($emails as $key => $email) {
          $email = trim($email);
          $emails[$key] = $email;
        if((is_email_address($email)) && !fi_check_patterns($email, $excluded_emails)) {
			$emails_for_query[] = "'" . $email . "'";
			$clean_emails[] = $email;
		  }
		}
	}

	if(count($emails_for_query) == 0) {
		$emails = array();
		return 0;
	}

    

	$emails_for_query_string = implode(",", $emails_for_query);

    // CHECK FOR UNSUBSCRIBED EMAILS
    $rows = $database->database_query("SELECT unsubscribe_user_email FROM se_semods_unsubscribe WHERE unsubscribe_user_email IN ($emails_for_query_string)");
    if($database->database_num_rows($rows) > 0) {
      while($row = $database->database_fetch_assoc($rows)) {
			$filtered_emails[] = "'" . $row['unsubscribe_user_email'] . "'";
            $clean_emails_filter[] = $row['unsubscribe_user_email'];
      }
      
      // FILTER EMAILS
      if($emails_are_contacts) {
          // dilute contacts
          // would be better to use array_diff, but structure is incompatible
          $contacts_diluted = array();
          foreach($emails as $contact) {
            if(!in_array($contact['email'], $clean_emails_filter) && is_email_address($contact['email']))
              $contacts_diluted[] = $contact;
          }
          $emails = $contacts_diluted;
      } else {
          $emails = array_diff($clean_emails, $clean_emails_filter);
      }

      
      $emails_for_query = array_diff( $emails_for_query, $filtered_emails );
      $emails_for_query_string = implode(",", $emails_for_query);
    }
    

	if(!is_null($friends)) {
        if($friends_with)
            $dbr_friends = $database->database_query("SELECT user_id, user_username, user_photo, user_email FROM se_users WHERE user_id NOT IN (SELECT se_friends.friend_user_id2 FROM se_friends WHERE friend_user_id1 = $friends_with) AND user_email IN ($emails_for_query_string) AND user_id != $friends_with");
        else
            $dbr_friends = $database->database_query("SELECT user_id, user_username, user_photo, user_email FROM se_users WHERE user_email IN ($emails_for_query_string) ");

        $found_friends = $database->database_num_rows($dbr_friends);

        if($found_friends > 0 ) {
            $friends = array();
            while($row = $database->database_fetch_assoc($dbr_friends)) {
              $nophoto_image = './images/nophoto.gif';
              if(empty($row['user_photo'])) {
                $user_photo = $nophoto_image;
              } else {
                $user_photo = $url->url_userdir($row['user_id']) . $row['user_photo'];
                if(!file_exists($user_photo) ) {
                  $user_photo = $nophoto_image;
                }
              }
              $row['user_photo'] = $user_photo;
              $friends[] = $row;
              $friends_splice[] = $row['user_email'];
            }
        }

	} else {
		$dbr_friends = semods::db_query_array("SELECT GROUP_CONCAT(user_email) FROM se_users WHERE user_email IN ($emails_for_query_string) ");
        if(!empty($dbr_friends[0]))
            $friends_splice = explode(',', $dbr_friends[0]);
	}

    // this is duplicate code block, but it's better to duplicate code then run unnecessary query
	if(!is_null($friends) && $friends_with) {
        $friends_splice = array();
		$dbr_friends = semods::db_query_array("SELECT GROUP_CONCAT(user_email) FROM se_users WHERE user_email IN ($emails_for_query_string) ");
        if(!empty($dbr_friends[0]))
            $friends_splice = explode(',', $dbr_friends[0]);
    }

	if($emails_are_contacts) {
		// dilute contacts
		// would be better to use array_diff, but structure is incompatible
		$contacts_diluted = array();
		foreach($emails as $contact) {
		  if(!in_array($contact['email'], $friends_splice))
			$contacts_diluted[] = $contact;
		}
		$emails = $contacts_diluted;
	} else {
		$emails = array_diff($clean_emails, $friends_splice);
	}

	return count($emails);
}








// Settings, Parameters


function fi_get_api_params() {
    $api_key = semods::get_setting('invite_api_key');
    $secret = semods::get_setting('invite_secret'); 
	return ( !empty($api_key) && !empty($secret) ) ? array( 'api_key' => $api_key, 'secret' => $secret ) : null;
}




// Invitation handling, called from send_invite / send_invitecode
function fi_preprocess_invitation($user_info, &$invite_emails, $invites_left = null, $resend = false) {
	global $database;

	$invite_emails = is_array($invite_emails) ? $invite_emails : explode(",", $invite_emails);

	// MAKE SURE THERE ARE NO MORE THAN 'setting_max_invites_per_batch' EMAILS
	$invites_count = semods::get_setting('invite_max_invites_per_batch') == 0 ? count($invite_emails) : min( semods::get_setting('invite_max_invites_per_batch'), count($invite_emails) );

	// MAKE SURE THERE ARE NO MORE THAN $invites_left EMAILS
	if(!is_null($invites_left) && !$resend)
		$invites_count = min( $invites_left , $invites_count );

	// MAKE SURE THERE ARE NO MORE THAN 'setting_max_invites_per_day' EMAILS
	$invites_sent_counter = 0;
	$invites_sent_last = 0;
	if(semods::get_setting('invite_max_invites_per_day') && ($user_info['user_id'] != 0)) {
		$time = time();
		$today = mktime(0, 0, 0, date('n', $time), date('j', $time), date('Y', $time));
		$invites_sent_last = $today;
		$row = semods::db_query_assoc( "SELECT invites_sent_counter, UNIX_TIMESTAMP( invites_sent_last ) AS invites_sent_last FROM se_invites_stats_user WHERE user_id = {$user_info['user_id']}" );
		if($row) {
			if($row['invites_sent_last'] == $today) {
				$invites_sent_counter = $row['invites_sent_counter'];
				$invites_sent_last = $row['invites_sent_last'];
			}
		}

		$invites_count = min( semods::get_setting('setting_max_invites_per_day') - $invites_sent_counter, $invites_count );

		// Update counter
		$invites_sent_counter += $invites_count;
	}

	// STOP HERE IF NO INVITES LEFT
	if($invites_count == 0)
		return 0;

	$invite_emails = array_slice($invite_emails, 0, $invites_count);

    if(!$resend) {
      
	// USER STATS
	$database->database_query("INSERT INTO se_invites_stats_user (user_id, invites_sent, invites_sent_counter, invites_sent_last) VALUES ( " . $user_info['user_id'] . ", " . $invites_count . ", $invites_sent_counter, FROM_UNIXTIME($invites_sent_last) ) ON DUPLICATE KEY UPDATE invites_sent = invites_sent + " . $invites_count . ", invites_sent_counter = $invites_sent_counter, invites_sent_last = FROM_UNIXTIME($invites_sent_last)" );

	// GLOBAL STATS
	fi_update_stats("invites", $invites_count);

	// USER POINTS, IF NOT ADMIN
	if(($user_info['user_id'] != 0) && function_exists("userpoints_update_points"))
        userpoints_update_points( $user_info['user_id'], "invite", $invites_count );  

    }

	return $invites_count;
}




function fi_import_contacts($login, $password, $domain, $typed_domain, $provider, $findfriends = false, $friends_with = 0, $session = null, $captcha_response = null) {
  global $friendsinviter, $contacts_importer_errors;

  $result = array();
  $contacts = array();
  $friends = array();

  for(;;) {

    $api_params = fi_get_api_params();
    if(!$api_params || empty($api_params['api_key']) || empty($api_params['secret']) ) {
        $error_message = 100010005;
        break;
    }

    if(is_null($captcha_response)) {
    $actual_domain = empty($typed_domain) ? $domain : $typed_domain;

    if(empty($login) || empty($password) || (($provider == 'auto') && empty($actual_domain)) ) {
        $error_message = 100010007;
        break;

    }

    if(!empty($actual_domain))
        $login = $login . '@' . $actual_domain;
    }

    include "./include/contactsImporter.php";

    $importer = new ContactsImporter($api_params['api_key'], $api_params['secret']);
    $contacts = $importer->getContacts($login, $password, $provider, 1, $session, $captcha_response);
    $session = $importer->session;

    if($contacts === false) {
		$error_code = $importer->getErrorCode();
		$error_message = isset($contacts_importer_errors[$error_code]) ? $contacts_importer_errors[$error_code] : $contacts_importer_errors[1];
        
        // captcha
        if( $error_code == $importer->API_E_CAPTCHA_REQUIRED ) {
          $result['captcha_url'] = $importer->captcha_url;
        }
        
        break;
    }

    if(count($contacts) == 0) {
        $error_message = 100010006;
        break;
    }

    
    // SocialContacts don't have email
    if(semods::g($contacts[0], 'email', '') != '') {

      $social_contacts = false;
      
    // filter folks already registered, by email
	if(!$findfriends) {
		$unfound_friends = filter_registered_emails($contacts, true);
		if($unfound_friends == 0) {
		  $error_message = 100010008;
		  break;
		}
	} else {
		$unfound_friends = filter_registered_emails($contacts, true, $friends, $friends_with);
	}

    } else {
      $social_contacts = true;
      $unfound_friends = count($contacts);
    }

    // UPDATE STATISTICS LESS 'FOUND FRIENDS'
    fi_update_stats( "imported_contacts", $unfound_friends );

    break;
  }

  isset($error_message) ? $result['error_message'] = $error_message : 0;
  isset($error_code) ? $result['error_code'] = $error_code : 0;
  !empty($contacts) ? $result['contacts'] = $contacts : 0;
  !empty($friends) ? $result['friends'] = $friends : 0;
  !empty($social_contacts) ? $result['social_contacts'] = $social_contacts : 0;

  $result['session'] = $session;

  return $result;
}





/********************* SOCIAL INVITATION FUNCTIONS *********************/


function fi_send_social_invitecode($user, $invite_ids, $invite_message = "", $session) {
  fi_send_social_invitation($user, $invite_ids, $invite_message, $session );
}


function fi_send_social_invitation($user, $invite_ids, $invite_message = "", $session) {
	global $setting, $url;
	global $database;

    $user_info = $user->user_info;

    $systememail = "invite";
    
	// RETRIEVE EMAIL INFO
    $email = semods::db_query_assoc( "SELECT * FROM se_systememails WHERE systememail_name='$systememail'" );

	SE_Language::_preload_multi($email['systememail_subject'], $email['systememail_body']);
	SE_Language::load();


	$time = time();

	// GET SERVER INFO
	$prefix = $url->url_base;

  	$invites_count = fi_preprocess_invitation($user_info, $invite_ids);
    
    if($invites_count == 0)
      return;
    
    $invite_ids = implode(',', $invite_ids);

	// DECODE SUBJECT AND EMAIL FOR SENDING
    $subject = htmlspecialchars_decode(SE_Language::_get($email['systememail_subject']), ENT_QUOTES);
    $message = htmlspecialchars_decode(SE_Language::_get($email['systememail_body']), ENT_QUOTES);

    // convert back from built-in bullshit technique
    $systememail_vars = explode(',', $email['systememail_vars']);

    $subject = vsprintf($subject, $systememail_vars);
    $message = vsprintf($message, $systememail_vars);


    /*
    [realname] User profile name 
    [city] User city
    [date] date of the invitation sent
    [picture] User profile picture
    */
    
    $extraFields = array( 'realname'        => $user_info['user_username'],      // full name, fallback to username if empty
                          'city'            => '',      // city
                          'picture'         => '<img border="0" src="' . $prefix . 'images/nophoto.gif' . '">',     // picture / profile photo
                          'picture_link'    => $prefix . 'images/nophoto.gif',     // raw picture link
                          'profile_link'    => '',      // profile link
                          'date'            => date( semods::get_setting('invite_date_format') )   // date of invitation
                          );    
    
    // get profile fields
    if($user_info['user_id'] != 0 ) {
        $new_user = new se_user( array($user_info['user_id']), array( '*', '*', '') );
        
        // first name
        if(!empty( $new_user->profile_info['profilevalue_2']))
            $extraFields['realname'] = $new_user->profile_info['profilevalue_2'];

        // last name
        if(!empty( $new_user->profile_info['profilevalue_3']))
            $extraFields['realname'] .= ' ' . $new_user->profile_info['profilevalue_3'];
        
        $extraFields['realname'] = trim($extraFields['realname']);

        // TBD: not a standard field in V3
        //$extraFields['city'] = $new_user->profile_info['profile_5'];
        $extraFields['picture_link'] = $prefix . $new_user->user_photo('images/nophoto.gif');
        $extraFields['picture'] = '<img border="0" src="' . $extraFields['picture_link'] . '">';
        $extraFields['profile_link'] = $url->url_create('profile', $user_info['user_username'] );
    }

    $link = $user_info['user_id']  ? "<a href=\"$prefix"."signup.php?signup_referer={$user_info[user_username]}\">$prefix"."signup.php?signup_referer={$user_info[user_username]}</a>"
                                   : "<a href=\"$prefix"."signup.php\">$prefix"."signup.php</a>";
                                   
    $signup_link = $prefix . "signup.php?signup_referer=".$user_info['user_username'];

    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[message]',
                                 '[link]',
                                 '[signup_link]',
                                 '[realname]',
                                 '[city]',
                                 '[picture]',
                                 '[picture_link]',
                                 '[profile_link]',
                                 '[date]',
                                 '[displayname]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 $invite_message,
                                 $link,
                                 $signup_link,
                                 $extraFields['realname'],
                                 $extraFields['city'],
                                 $extraFields['picture'],
                                 $extraFields['picture_link'],
                                 $extraFields['profile_link'],
                                 $extraFields['date'],
                                 $user->user_displayname
                                ),
                          
                          array( $message,
                                 $subject ) );


	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

    $api_params = fi_get_api_params();

    include "./include/contactsImporter.php";

    $importer = new ContactsImporter($api_params['api_key'], $api_params['secret']);
    
    // invitation type - 0: message, 1: wall
    $importer->inviteContacts($session, $invite_ids, $subject, $message, 0);
  
	return true;
}




/********************* EMAIL FUNCTIONS *********************/





// THIS FUNCTION SENDS GENERIC INVITATION EMAIL TO SPECIFIED EMAILS
// INPUT: $user_info REPRESENTING THE SENDER'S USER INFO
//	  $invite_emails REPRESENTING COMMA-SEPARATED EMAIL ADDRESSES
//	  $invite_message (OPTIONAL) REPRESENTING A CUSTOM USER MESSAGE
// OUTPUT:
function fi_send_invitation($user, $invite_emails, $invite_message = "", $resend = false) {
	global $setting, $url;
	global $database;

    $user_info = $user->user_info;

    $systememail = "invite";
    
	// RETRIEVE EMAIL INFO
    $email = semods::db_query_assoc( "SELECT * FROM se_systememails WHERE systememail_name='$systememail'" );

	SE_Language::_preload_multi($email['systememail_subject'], $email['systememail_body']);
	SE_Language::load();


	$time = time();

	// GET SERVER INFO
	$prefix = $url->url_base;

	$invites_count = fi_preprocess_invitation($user_info, $invite_emails, null, $resend);

	// DECODE SUBJECT AND EMAIL FOR SENDING
    $subject = htmlspecialchars_decode(SE_Language::_get($email['systememail_subject']), ENT_QUOTES);
    $message = htmlspecialchars_decode(SE_Language::_get($email['systememail_body']), ENT_QUOTES);

    // convert back from built-in bullshit technique
    $systememail_vars = explode(',', $email['systememail_vars']);

    $subject = vsprintf($subject, $systememail_vars);
    $message = vsprintf($message, $systememail_vars);


    /*
    [realname] User profile name 
    [city] User city
    [date] date of the invitation sent
    [picture] User profile picture
    */
    
    $extraFields = array( 'realname'        => $user_info['user_username'],      // full name, fallback to username if empty
                          'city'            => '',      // city
                          'picture'         => '<img border="0" src="' . $prefix . 'images/nophoto.gif' . '">',     // picture / profile photo
                          'picture_link'    => $prefix . 'images/nophoto.gif',     // raw picture link
                          'profile_link'    => '',      // profile link
                          'date'            => date( semods::get_setting('invite_date_format') )   // date of invitation
                          );    
    
    // get profile fields
    if($user_info['user_id'] != 0 ) {
        $new_user = new se_user( array($user_info['user_id']), array( '*', '*', '') );
        
        // first name
        if(!empty( $new_user->profile_info['profilevalue_2']))
            $extraFields['realname'] = $new_user->profile_info['profilevalue_2'];

        // last name
        if(!empty( $new_user->profile_info['profilevalue_3']))
            $extraFields['realname'] .= ' ' . $new_user->profile_info['profilevalue_3'];
        
        $extraFields['realname'] = trim($extraFields['realname']);

        // TBD: not a standard field in V3
        //$extraFields['city'] = $new_user->profile_info['profile_5'];
        $extraFields['picture_link'] = $prefix . $new_user->user_photo('images/nophoto.gif');
        $extraFields['picture'] = '<img border="0" src="' . $extraFields['picture_link'] . '">';
        $extraFields['profile_link'] = $url->url_create('profile', $user_info['user_username'] );
    }

    $link = $user_info['user_id']  ? "<a href=\"$prefix"."signup.php?signup_referer={$user_info[user_username]}\">$prefix"."signup.php?signup_referer={$user_info[user_username]}</a>"
                                   : "<a href=\"$prefix"."signup.php\">$prefix"."signup.php</a>";
                                   
    $signup_link = $prefix . "signup.php?signup_referer=".$user_info['user_username'];

    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[message]',
                                 '[link]',
                                 '[signup_link]',
                                 '[realname]',
                                 '[city]',
                                 '[picture]',
                                 '[picture_link]',
                                 '[profile_link]',
                                 '[date]',
                                 '[displayname]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 $invite_message,
                                 $link,
                                 $signup_link,
                                 $extraFields['realname'],
                                 $extraFields['city'],
                                 $extraFields['picture'],
                                 $extraFields['picture_link'],
                                 $extraFields['profile_link'],
                                 $extraFields['date'],
                                 $user->user_displayname
                                ),
                          
                          array( $message,
                                 $subject ) );


	// ENCODE SUBJECT FOR UTF8
	$subject_encoded="=?UTF-8?B?".base64_encode($subject)."?=";

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

	// SET HEADERS
	$from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
	$headers = "MIME-Version: 1.0"."\n";
	$headers .= "Content-type: text/html; charset=utf-8"."\n";
	$headers .= "Content-Transfer-Encoding: 8bit"."\n";
	$headers .= "From: $from_email"."\n";
	$headers .= "Return-Path: $from_email"."\n";
	$headers .= "Reply-To: $from_email";

	// SEND MAIL TO EACH EMAIL, STORE TO DB ONLY IF NOT ADMIN / ANONYMOUS
    if($user_info['user_id'] != 0 ) {
        for($e=0;$e<$invites_count;$e++) {
          $invite_email = str_replace(" ", "", $invite_emails[$e]);
    
          // personal unsubscribe link
          $message_i = str_replace( '[unsubscribe]',
                                  "<a href=\"$prefix"."unsubscribe.php?email={$invite_email}\">$prefix"."unsubscribe.php?email={$invite_email}</a>",
                                      $message);
          
          // INSERT FOR FUTURE FRIENDSHIP CONNECTIONS
          // TABLE HAS UNIQ INDEX ON (invite_user_id,invite_email)
          // invite_code is set to '-'
          $database->database_query("INSERT INTO se_invites (invite_user_id, invite_date, invite_email, invite_code) VALUES ('$user_info[user_id]', '$time', '$invite_email', '-') ON DUPLICATE KEY UPDATE invite_date = $time, invite_code = '-' ");

          if(semods::get_setting('emailer_enabled')) {
			semods_send_mail_queued( $setting['setting_email_fromname'],
									 $setting['setting_email_fromemail'],
									 $invite_email,
									 $subject,
									 $message_i,
                                     1 );
          } else {
          @mail($invite_email, $subject_encoded, $message_i, $headers);
        }

        }
    } else {
        for($e=0;$e<$invites_count;$e++) {
          $invite_email = str_replace(" ", "", $invite_emails[$e]);
          
          // personal unsubscribe link
          $message_i = str_replace( '[unsubscribe]',
                                  "<a href=\"$prefix"."unsubscribe.php?email={$invite_email}\">$prefix"."unsubscribe.php?email={$invite_email}</a>",
                                      $message);
          
          if(semods::get_setting('emailer_enabled')) {
			semods_send_mail_queued( $setting['setting_email_fromname'],
									 $setting['setting_email_fromemail'],
									 $invite_email,
									 $subject,
									 $message_i,
                                     1 );
          } else {
          @mail($invite_email, $subject_encoded, $message_i, $headers);
        }
    }
    }

	return true;
} // END send_invitation() FUNCTION





// THIS FUNCTION SENDS INVITATION CODE EMAIL TO SPECIFIED EMAILS
// INPUT: $user_info REPRESENTING THE SENDER'S USER INFO
//	  $invite_emails REPRESENTING COMMA-SEPARATED EMAIL ADDRESSES
//	  $invite_message (OPTIONAL) REPRESENTING A CUSTOM USER MESSAGE
// OUTPUT:
function fi_send_invitecode($user, $invite_emails, $invite_message="", $resend = false) {
	global $database, $setting, $url;

    $user_info = $user->user_info;

    $systememail = "invitecode";
    
	// RETRIEVE EMAIL INFO
	//$email = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_systememails WHERE systememail_name='$systememail'"));
    $email = semods::db_query_assoc( "SELECT * FROM se_systememails WHERE systememail_name='$systememail'" );

	SE_Language::_preload_multi($email['systememail_subject'], $email['systememail_body']);
	SE_Language::load();

	// SET VARIABLES
	$time = time();
	$invites_left = $user_info['user_invitesleft'];
	if($invites_left <= 0)
		return;

	// GET SERVER INFO
	$prefix = $url->url_base;

	$invites_count = fi_preprocess_invitation($user_info, $invite_emails, $invites_left, $resend);

	    // DECODE SUBJECT AND EMAIL FOR SENDING
    $subject = htmlspecialchars_decode(SE_Language::_get($email['systememail_subject']), ENT_QUOTES);
    $message = htmlspecialchars_decode(SE_Language::_get($email['systememail_body']), ENT_QUOTES);

    // convert back from built-in bullshit technique
    $systememail_vars = explode(',', $email['systememail_vars']);

    $subject = vsprintf($subject, $systememail_vars);
    $message = vsprintf($message, $systememail_vars);


    /*
    [realname] User profile name 
    [city] User city
    [date] date of the invitation sent
    [picture] User profile picture
    */
    
    $extraFields = array( 'realname'        => $user_info['user_username'],      // full name, fallback to username if empty
                          'city'            => '',      // city
                          'picture'         => '<img border="0" src="' . $prefix . 'images/nophoto.gif' . '">',     // picture / profile photo
                          'picture_link'    => $prefix . 'images/nophoto.gif',     // raw picture link
                          'profile_link'    => '',      // profile link
                          'date'            => date( semods::get_setting('setting_date_format') )   // date of invitation
                          );    
    
    // get profile fields
    if($user_info['user_id'] != 0 ) {
        $new_user = new se_user( array($user_info['user_id']), array( '*', '*', '') );
        
        // first name
        if(!empty( $new_user->profile_info['profilevalue_2']))
            $extraFields['realname'] = $new_user->profile_info['profilevalue_2'];

        // last name
        if(!empty( $new_user->profile_info['profilevalue_3']))
            $extraFields['realname'] .= ' ' . $new_user->profile_info['profilevalue_3'];
        
        $extraFields['realname'] = trim($extraFields['realname']);

        // TBD: not a standard field in V3
        //$extraFields['city'] = $new_user->profile_info['profile_5'];
        $extraFields['picture_link'] = $prefix . $new_user->user_photo('images/nophoto.gif');
        $extraFields['picture'] = '<img border="0" src="' . $extraFields['picture_link'] . '">';
        $extraFields['profile_link'] = $url->url_create('profile', $user_info['user_username'] );
    }

    $link = $user_info['user_id']  ? "<a href=\"$prefix"."signup.php?signup_referer={$user_info[user_username]}\">$prefix"."signup.php?signup_referer={$user_info[user_username]}</a>"
                                   : "<a href=\"$prefix"."signup.php\">$prefix"."signup.php</a>";
                                   
    $signup_link = $prefix . "signup.php?signup_referer=".$user_info['user_username'];

    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[message]',
                                 '[link]',
                                 '[signup_link]',
                                 '[realname]',
                                 '[city]',
                                 '[picture]',
                                 '[picture_link]',
                                 '[profile_link]',
                                 '[date]',
                                 '[displayname]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 $invite_message,
                                 $link,
                                 $signup_link,
                                 $extraFields['realname'],
                                 $extraFields['city'],
                                 $extraFields['picture'],
                                 $extraFields['picture_link'],
                                 $extraFields['profile_link'],
                                 $extraFields['date'],
                                 $user->user_displayname
                                ),
                          
                          array( $message,
                                 $subject ) );


	    // REPLACE CARRIAGE RETURNS WITH BREAKS
	    $message = str_replace("\n", "<br>", $message);

	    // SET HEADERS
	    $from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
	    $headers = "MIME-Version: 1.0"."\n";
	    $headers .= "Content-type: text/html; charset=utf-8"."\n";
	    $headers .= "Content-Transfer-Encoding: 8bit"."\n";
	    $headers .= "From: $from_email"."\n";
	    $headers .= "Return-Path: $from_email"."\n";
	    $headers .= "Reply-To: $from_email";

	for($e=0;$e<$invites_count;$e++) {
	  $email = $invite_emails[$e];

	    // CREATE CODE AND INSERT INTO DATABASE
	    $invite_code = randomcode();
	    $database->database_query("INSERT INTO se_invites (invite_user_id, invite_date, invite_email, invite_code) VALUES ('$user_info[user_id]', '$time', '$email', '$invite_code') ON DUPLICATE KEY UPDATE invite_date = '$time', invite_code = '$invite_code' ");

        // also include personal unsubscribe link
        list( $message_i, $subject_i ) = str_replace( array( '[code]',
                                                             '[unsubscribe]'),
                                                      array( $invite_code,
                                                             "<a href=\"$prefix"."unsubscribe.php?email={$email}\">$prefix"."unsubscribe.php?email={$email}</a>" ),
                                                            array( $message, $subject ) );

	    // SEND MAIL
        if(semods::get_setting('emailer_enabled')) {
            semods_send_mail_queued( $setting['setting_email_fromname'],
                                     $setting['setting_email_fromemail'],
                                     $email,
                                     $subject_i,
                                     $message_i );
        } else {

          // ENCODE SUBJECT FOR UTF8
          $subject_i = "=?UTF-8?B?" . base64_encode($subject_i) . "?=";
          
	    @mail($email, $subject_i, $message_i, $headers);
        }

	}

    $invites_left -= $invites_count;

	// UPDATE NEW INVITES LEFT IF NOT ADMIN
	if(($user_info['user_id'] != 0) && !$resend) {
	  $database->database_query("UPDATE se_users SET user_invitesleft='$invites_left' WHERE user_id='$user_info[user_id]'");
	}

	return true;
} // END send_invitecode() FUNCTION












/*********************** STATISTICS *********************/





// THIS FUNCTION UPDATES ROW IN THE STATS TABLE FOR CURRENT DATE
// SE Team updated update_stats() with my patch from v2.71
function fi_update_stats($type, $amount = 1) {
	global $database;

	// INCREASE REQUESTED STAT VALUE
	$database->database_query( "INSERT INTO se_stats ( stat_date, stat_$type ) VALUES( UNIX_TIMESTAMP(CURDATE()), $amount ) ON DUPLICATE KEY UPDATE stat_$type = stat_$type + $amount" );

} // END fi_update_stats() FUNCTION








/*********************** HOOKS *********************/




function fi_hook_signup( $arguments = array() ) {
  //global $fi_task;
  
  // On first page landing, set a session cookie for referer
  if(isset($_GET['signup_referer'])) {
    setcookie("signup_referer", $_GET['signup_referer'], 0, "/");
  } else {
    
  // If landed here, try to see if we have referer
    if(isset($_COOKIE['signup_referer'])) {
      $signup_referer = $_COOKIE['signup_referer'];
    }
  }

}






function fi_hook_signup_footer( $arguments = array() ) {
  global $step, $page;
  
  // invite steps
  //if(($step == "4") || ($step == "4a")) {
  if($step == "4") {
    $page = "signup_invite";
  }

}



function fi_get_top_services() {

  $domains = explode(',', semods::get_setting('invite_topdomains'));
  $services = unserialize( semods::get_setting('invite_topnetworks') );

  return array( $domains, $services );
}


function fi_fetch_contacts( $user, $find_friends = true ) {
  global $smarty;
  
    $login = $post_login = semods::getpost('user');
    $password = semods::getpost('pass');
    $domain = semods::getpost('domain');
    $typed_domain = semods::getpost('domain_type');
  $provider = semods::getpost('provider', 'auto');

  $captcha_response = semods::getpost('captcha_response');
  $session = semods::getpost('session');

  $import_result = fi_import_contacts($post_login, $password, $domain, $typed_domain, $provider, $find_friends, $user->user_info['user_id'], $session, $captcha_response);

  $is_error = 0;
  $error_message = '';
  $captcha_required = false;
  
  if(isset($import_result['error_code']) || isset($import_result['error_message'])) {

    if(isset($import_result['captcha_url'])) {
      $smarty->assign('captcha_url', $import_result['captcha_url']);
      $captcha_required = true;
      $session = $import_result['session'];
    }

      $is_error = 1;
      $error_message = $import_result['error_message'];

    } else {

      $importing = true;
      $contacts = $import_result['contacts'];
    $unfound_friends = count($contacts);
      $friends = $import_result['friends'];
      $found_friends = count($friends);
    $social_contacts = $import_result['social_contacts'];
    $session = $import_result['session'];

    }
  
  $smarty->assign('captcha_required', $captcha_required);
  $smarty->assign('social_contacts', $social_contacts);
  $smarty->assign('session', $session);
  $smarty->assign('importing', $importing);
  $smarty->assign('contacts', $contacts);
  $smarty->assign('friends', $friends);
  $smarty->assign('found_friends', $found_friends);
  $smarty->assign('unfound_friends', $unfound_friends);
  $smarty->assign('domain', $domain);
  $smarty->assign('typed_domain', $typed_domain);
  $smarty->assign('login', $post_login);
  
  return array( 'err' => $is_error, 'err_msg' => $error_message, 'captcha_required' => $captcha_required );

  }
  
  
function fi_invite_contacts( $user = null ) {
  global $smarty, $setting;

  if(is_null($user)) {
    $user = new se_user();
  }

  $invite_emails = semods::post('invite_emails','');
  $invite_message = semods::post('invite_message', '');

  $session = semods::post('session');
  
  $invite_ids = semods::post('invite_ids');
  $social_contacts = semods::post('social_contacts', 0);
  
    // if imported from address book
  $imported = semods::post('imported');
  
  if(!$social_contacts) {
      filter_registered_emails( $invite_emails );
    $invited_count = count($invite_emails);
  } else {
    $invited_count = count($invite_ids);
  }

  $is_error = 0;
  $error_message = '';

  if( (!$social_contacts && empty($invite_emails)) || ($social_contacts && empty($invite_ids)) ) {
  
      $is_error = 1;
    $error_message = 100010234;

    } else {
  
    // If sending as not_logged_in user, send as admin
    if($user->user_exists == 0) {
      $user->user_info['user_id'] = 0;
      $user->user_info['user_invitesleft'] = 9999;
      $user->user_info['user_username'] = $setting['setting_email_fromname'];
      $user->user_info['user_email'] = $setting['setting_email_fromemail'];
      
      // SET DISPLAY NAME
      $user->user_displayname();
    }

      // STATS FOR IMPORTED CONTACTS VS ACTUALLY INVITED ONES
    if($imported || $social_contacts) {
      fi_update_stats("invited_contacts", $invited_count);
      }
  
    if($social_contacts) {

      if($setting['setting_signup_invite'] == 0) {
        fi_send_social_invitation($user, $invite_ids, $invite_message, $session);
      } else {
        fi_send_social_invitecode($user, $invite_ids, $invite_message, $session);
      }
      
    } else {

      if($setting['setting_signup_invite'] == 0) {
        fi_send_invitation($user, $invite_emails, $invite_message);
      } else {
        fi_send_invitecode($user, $invite_emails, $invite_message);
      }
      
    }

  }

  // push back in case of error
  $smarty->assign('invite_message', $invite_message);
  $smarty->assign('invite_emails', $invite_emails);

  return array( 'err' => $is_error, 'err_msg' => $error_message );

}

function fi_hook_signup_decide( $arguments = array() ) {
  global $task, $new_user, $smarty;
  global $is_error, $error_message;

  list($domains, $services) = fi_get_top_services();

  // Default to show webcontacts screen
  $screen = semods::post('screen', 'webcontacts');

  // Default to show webmail box
  $provider = semods::getpost('provider', 'auto');
  
  // Fetch Contacts
  $importing = false;

  if($task == "importdo") {

    $fi_result = fi_fetch_contacts( $new_user );
    if($fi_result['err'] && !$fi_result['captcha_required']) {
      $is_error = 1;
      $error_message  = $fi_result['err_msg'];
    }
  
    $task = "step4";
  }
  
  
  // SEND INVITATIONS
  if($task == "importinvitedo") {

    $fi_result = fi_invite_contacts( $new_user );
    if($fi_result['err']) {
      $is_error = 1;
      $error_message  = $fi_result['err_msg'];
    }
  
    // finished or back to invite?
    // if there was error, thank him anyway...
    //
    // SEND USER TO THANK YOU PAGE
    $task = "step5";
  
  }
  
  
  
  if($task == "step4" || $task == "importdo" || $task == "importinvitedo") {
  
    // Default to show webmail box for friends finder
    if(!isset($provider))
      $provider = "auto";
    
  
    // ASSIGN VARIABLES AND INCLUDE FOOTER
    $smarty->assign('error_message', $error_message);

    $smarty->assign('screen', $screen);
    $smarty->assign('provider', $provider);
    $smarty->assign('domains', $domains);
    $smarty->assign('services', $services);
    
  }
    
}






function fi_hook_signup_success( $arguments = array() ) {
  global $fi_task, $new_user, $database, $actions, $notify, $signup_email, $signup_invite;
  global $setting;


  // BEFRIEND BY EMAIL


    
    // for invite code already processed in signup.php
    
    // DEFAULT SYSTEM BEHAVIOUR
    if( semods::get_setting('invite_befriend_by_email') == 0) {

      $invitationsdb = FALSE;
      
    } else {
      
    // CHECKS FOR INVITE DONE ABOVE, NO NEED TO DO IT AGAIN
      // ALSO BEFRIEND ALL OTHERS THAT SENT INVITE TO EMAIL USER REGISTERED WITH RIGHT NOW, DEPENDING ON SETTING
    if($setting['setting_signup_invite'] != 0)
      $invitationsdb = $database->database_query("SELECT * FROM se_invites WHERE invite_email='$signup_email' OR invite_code = '$signup_invite'");
    else
      $invitationsdb = $database->database_query("SELECT * FROM se_invites WHERE invite_email='$signup_email'");

    }
    
    // LOOP OVER RESULTS      
    while( $invitation = $database->database_fetch_assoc($invitationsdb) ) {

      // ADD USER TO INVITER'S FRIENDLIST
      if($invitation['invite_user_id'] != 0) {

      $friend = new se_user(Array($invitation['invite_user_id']));
      if($friend->user_exists == 1) {
  
          // DEFAULT SYSTEM BEHAVIOUR
          if( semods::get_setting('invite_befriend_by_email') == 0) {
          
        if($setting['setting_connection_allow'] == 3 | $setting['setting_connection_allow'] == 1 | ($setting['setting_connection_allow'] == 2 & $new_user->user_info['user_subnet_id'] == $friend->user_info['user_subnet_id'])) {
              
          // SET RESULT, DIRECTION, STATUS
          switch($setting['setting_connection_framework']) {
            case "0":
              $direction = 2;
              $friend_status = 0;
              break;
            case "1":
              $direction = 1;
              $friend_status = 0;
              break;
            case "2":
              $direction = 2;
              $friend_status = 1;
              break;
            case "3":
              $direction = 1;
              $friend_status = 1;
              break;
                
          }

          // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
    	  $friend->user_friend_add($new_user->user_info['user_id'], $friend_status, '', '');

          // IF TWO-WAY CONNECTION AND NON-CONFIRMED, INSERT OTHER DIRECTION
          if($direction == 2 & $friend_status == 1) { $new_user->user_friend_add($friend->user_info['user_id'], $friend_status, '', ''); }
        }
            
          } else {
            // FRIENDS INVITER BEHAVIOUR
            

              // SET RESULT, DIRECTION, STATUS
              switch(semods::get_setting('invite_befriend_by_email')) {
                
                // new user receives incoming friend request from the inviter(s)
                case 1:

                  // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
                  $friend->user_friend_add($new_user->user_info['user_id'], 0, '', '');
                  $notify->notify_add($new_user->user_info[user_id], 'friendrequest', $friend->user_info[user_id]);
                  break;
                
                // new user and inviter(s) become confirmed friends 
                case 2:

                  // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
                  $friend->user_friend_add($new_user->user_info['user_id'], 1, '', '');

                  // INSERT OTHER DIRECTION
                  $new_user->user_friend_add($friend->user_info['user_id'], 1, '', '');

                  // INSERT ACTION
                  $actions->actions_add( $new_user,
                                         "addfriend",
                                         array( $new_user->user_info['user_username'], $new_user->user_displayname,
                                                $friend->user_info['user_username'], $friend->user_displayname
                                                )
                                        );
              
                  // INSERT ACTION
                  $actions->actions_add(  $friend,
                                          "addfriend",
                                          array( $friend->user_info['user_username'], $friend->user_displayname,
                                                 $new_user->user_info['user_username'], $new_user->user_displayname
                                                )
                                        );
                  
                  break;
                
                // inviter(s) receive incoming friend request from the new user.
                case 3:

                // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
                $new_user->user_friend_add($friend->user_info['user_id'], 0, '', '');
                $notify->notify_add($friend->user_info[user_id], 'friendrequest', $new_user->user_info[user_id]);
                  
                  break;
                
              }
            
          }
        
      }
      }

      // DELETE INVITE CODE
      $database->database_query("DELETE FROM se_invites WHERE invite_id='$invitation[invite_id]' LIMIT 1");

    }









  // REFERRER STATS
  // BEFRIEND BY REFERRER


  $signup_referer = isset($_COOKIE['signup_referer']) ? $_COOKIE['signup_referer'] : '';

  // IF REFERED BY SOMEONE - UPDATE STATS
  if(!empty($signup_referer)) {
    $referer = new se_user(Array(0, $signup_referer));
    if($referer->user_exists == 1) {

      // USER STATS
      $database->database_query("INSERT INTO se_invites_stats_user (user_id, invites_converted) VALUES ( " . $referer->user_info['user_id'] . " , 1 ) ON DUPLICATE KEY UPDATE invites_converted = invites_converted + 1 ");

      // USER REFERER
      $database->database_query("UPDATE se_users SET user_referer = " . $referer->user_info['user_id'] . " WHERE user_id = " . $new_user->user_info['user_id'] );

      // GLOBAL STATS
      fi_update_stats("converted_invites");

      // FRIENDS INVITER BEFRIENDNG BEHAVIOUR - SET RESULT, DIRECTION, STATUS
      switch( semods::get_setting('invite_befriend_by_referer') ) {
        
        // new user receives incoming friend request from the inviter(s)
        case 1:

          // CHECK IF USER IS ALREADY FRIENDED (by above process)
          if( !$referer->user_friended($new_user->user_info['user_id']) && !$referer->user_friended($new_user->user_info['user_id'], 0)) {

            // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
            $referer->user_friend_add($new_user->user_info['user_id'], 0, '', '');
            $notify->notify_add($new_user->user_info[user_id], 'friendrequest', $referer->user_info[user_id]);
            
          }
          
          break;
        
        // new user and inviter(s) become confirmed friends 
        case 2:

          // CHECK IF USER IS ALREADY FRIENDED (by above process)
          if( $referer->user_friended($new_user->user_info['user_id'], 1) && $new_user->user_friended($referer->user_info['user_id'], 1) ) {

            // do nothing
            
          } else {

            // INSERT ONE DIRECTION
            if( $referer->user_friended($new_user->user_info['user_id'], 0) ) {

              $database->database_query("UPDATE se_friends SET friend_status=1 WHERE friend_id={$new_user->user_info['user_id']}");
            
            } elseif (!$referer->user_friended($new_user->user_info['user_id'])) {
              
              // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
              $referer->user_friend_add($new_user->user_info['user_id'], 1, '', '');
              
            }
            
            // INSERT OTHER DIRECTION
            if( $new_user->user_friended($referer->user_info['user_id'], 0) ) {

              $database->database_query("UPDATE se_friends SET friend_status=1 WHERE friend_id={$referer->user_info['user_id']}");
            
            } elseif (!$new_user->user_friended($referer->user_info['user_id'])) {
              
              // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
              $new_user->user_friend_add($referer->user_info['user_id'], 1, '', '');
              
            }

            // INSERT ACTION
            $actions->actions_add( $new_user,
                                   "addfriend",
                                    array( $new_user->user_info['user_username'], $new_user->user_displayname,
                                           $referer->user_info['user_username'], $referer->user_displayname
                                           )
                                  );
        
            // INSERT ACTION
            $actions->actions_add(  $referer,
                                    "addfriend",
                                    array( $referer->user_info['user_username'], $referer->user_displayname,
                                           $new_user->user_info['user_username'], $new_user->user_displayname
                                           )
                                  );
            
          }
          
          break;
        

        // inviter(s) receive incoming friend request from the new user.
        case 3:

          // CHECK IF USER IS ALREADY FRIENDED (by above process)
          if( !$new_user->user_friended($referer->user_info['user_id']) && !$new_user->user_friended($referer->user_info['user_id'], 0)) { 

            // INSERT FRIENDS INTO FRIEND TABLE AND EXPLANATION INTO EXPLAIN TABLE
            $new_user->user_friend_add($referer->user_info['user_id'], 0, '', '');
            $notify->notify_add($referer->user_info['user_id'], 'friendrequest', $new_user->user_info['user_id']);
            
          }
          
          break;
        
        case 0:
        default:
        
          break;
        
      }

    }

  }
  
  // Clear signup cookie
  setcookie("signup_referer", "", 0, "/");
  
}





?>