<?

// put these function somewhere in your application
function rc_page_db_get_template ($tpl_name, &$tpl_source, &$smarty_obj)
{
  global $user, $database, $setting;

  $rc_page = new rc_page();
  $page = $rc_page->get_record($tpl_name);

  if ($page) {
    $tpl_source = $page['page_content'];
    return true;
  }
  else {
    return false;
  }
 
}

function rc_page_db_get_timestamp($tpl_name, &$tpl_timestamp, &$smarty_obj)
{
  $tpl_timestamp = time();
  return true;
}

function rc_page_db_get_secure($tpl_name, &$smarty_obj)
{
    // assume all templates are secure
    return true;
}

function rc_page_db_get_trusted($tpl_name, &$smarty_obj)
{
    // not used for templates
}


// register the resource name "db"
$smarty->register_resource("page", array("rc_page_db_get_template",
                                       "rc_page_db_get_timestamp",
                                       "rc_page_db_get_secure",
                                       "rc_page_db_get_trusted"));
