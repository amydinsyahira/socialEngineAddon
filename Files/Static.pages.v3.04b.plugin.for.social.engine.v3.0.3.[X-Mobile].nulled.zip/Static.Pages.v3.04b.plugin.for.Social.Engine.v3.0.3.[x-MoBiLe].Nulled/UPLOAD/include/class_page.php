<?

include_once "class_radcodes.php";

class rc_page extends rc_model 
{
  var $table = 'se_pages';
  var $pk = 'page_id';
   
  function insert($data)
  {
    if (!$data['page_key']) {
      $data['page_key'] = rc_toolkit::strip_text($data['page_name']);
    }
    $data['page_updated_at'] = rc_toolkit::db_to_datetime();  
    return parent::insert($data);
  }
  
  function update($id, $data)
  {
    $data['page_updated_at'] = rc_toolkit::db_to_datetime();
    return parent::update($id, $data);
  }
  
  function get_page_by_key($key)
  {
    return $this->get_record_by_criteria("page_key = '$key'");
  }
}
