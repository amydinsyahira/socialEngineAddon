<?php

$my_name = "x-MoBiLe";
$smarty->assign('my_name', $my_name);
