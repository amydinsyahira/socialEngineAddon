<?
$page = "admin_viewpages_add";
include "admin_header.php";

$task = rc_toolkit::get_request('task','main');
$result = "";
$rc_page = new rc_page();
$rc_validator = new rc_validator();

$page_info = array(
  'page_content' => "{include file='header.tpl'}
<h1>My Header</h1>
<div>This is my content ..</div>
{include file='footer.tpl'}
", 
'page_status' => 1);

$rc_level = new rc_level();
$levels = $rc_level->FindRecordsByCriteria();
$page_levels = array();

$editmode = rc_toolkit::get_request('editmode','code');
$smarty->assign('editmode', $editmode);


if($task == "dosave") {
  
  $page_info['page_name'] = $_POST['page_name'];
  $page_info['page_type'] = (int) $_POST['page_type'];
  $page_info['page_status'] = $_POST['page_status'] ? 1 : 0;
  $page_info['page_script'] = $_POST['page_script'];
  $page_info['page_content'] = htmlspecialchars_decode($_POST['page_content'], ENT_QUOTES);
  
  $rc_validator->is_not_trimmed_blank($page_info['page_name'],11010415);
  
  if ($page_info['page_type'] == 2) {
    $page_levels = (array) $_POST['page_levels'];
    $rc_validator->validate(count($page_levels) > 0, 11010421);
  }
  else {
    $page_levels = array();
  }  
  
  if (!$rc_validator->has_errors()) {
    $page_info['page_levels'] = join(',',$page_levels);
    $page_id = $rc_page->insert($page_info);
    rc_toolkit::redirect("admin_viewpages_edit.php?page_id=$page_id&editmode=$editmode");
  }

}

$page_info['page_content'] = htmlspecialchars($page_info['page_content'], ENT_QUOTES);
$page_info['page_content_editor'] = html_entity_decode(str_replace("\r\n","",$page_info['page_content']));

foreach ($levels as $level) {
  $level->checked = in_array($level->level_id, $page_levels);
}
$smarty->assign('levels', $levels);

$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('page_info', $page_info);
include "admin_footer.php";
