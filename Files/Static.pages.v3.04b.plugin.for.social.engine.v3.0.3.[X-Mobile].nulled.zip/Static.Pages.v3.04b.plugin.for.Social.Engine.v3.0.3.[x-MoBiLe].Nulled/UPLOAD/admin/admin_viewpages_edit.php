<?
$page = "admin_viewpages_edit";
include "admin_header.php";

$task = rc_toolkit::get_request('task','main');
$page_id = rc_toolkit::get_request('page_id');
$result = "";
$rc_page = new rc_page();
$rc_validator = new rc_validator();

$page_info = $rc_page->get_record($page_id);

if (!$page_info) {
  rc_toolkit::redirect("admin_viewpages.php");
}

$rc_level = new rc_level();
$levels = $rc_level->FindRecordsByCriteria();

$page_levels = explode(',', $page_info['page_levels']);


if($task == "dosave") {

  $page_info['page_name'] = $_POST['page_name'];
  $page_info['page_type'] = (int) $_POST['page_type'];
  $page_info['page_status'] = $_POST['page_status'] ? 1 : 0;
  $page_info['page_key'] = $_POST['page_key'];
  $page_info['page_script'] = $_POST['page_script'];
  $page_info['page_content'] = htmlspecialchars_decode($_POST['page_content'], ENT_QUOTES);
  
  $rc_validator->is_not_trimmed_blank($page_info['page_name'] && $page_info['page_key'],11010515);
  $page_key = $rc_page->get_page_by_key($page_info['page_key']);
  $rc_validator->validate(!$page_key || $page_key['page_id'] == $page_info['page_id'], 11010516);
  
  if ($page_info['page_type'] == 2) {
    $page_levels = (array) $_POST['page_levels'];
    $rc_validator->validate(count($page_levels) > 0, 11010521);
  }
  else {
    $page_levels = array();
  }
  
  //rc_toolkit::debug($rc_validator->get_errors());
  if (!$rc_validator->has_errors()) {
    $page_info['page_levels'] = join(',',$page_levels);
    $page_id = $rc_page->update($page_id,$page_info);
    rc_toolkit::redirect("admin_viewpages.php");
  }
}
$page_info['page_content'] = htmlspecialchars($page_info['page_content'], ENT_QUOTES);
$page_info['page_content_editor'] = html_entity_decode(str_replace("\r\n","",$page_info['page_content']));

foreach ($levels as $level) {
  $level->checked = in_array($level->level_id, $page_levels);
}
$smarty->assign('levels', $levels);

$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('page_info', $page_info);
$smarty->assign('editmode',rc_toolkit::get_request('editmode','code'));
include "admin_footer.php";
