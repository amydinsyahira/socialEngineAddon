<?

$plugin_name = "Static Pages";
$plugin_version = "3.04 beta";
$plugin_type = "page";
$plugin_desc = "This plugin allows you to create static pages for your social network. Fixed by x-MoBiLe NULL TEAM";
$plugin_icon = "page_page16.gif";
$plugin_menu_title = "11010001"; 
$plugin_pages_main = "11010002<!>page_viewpages16.gif<!>admin_viewpages.php<~!~>11010003<!>page_settings16.gif<!>admin_page.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^page/([^/]*)?$ \$server_info/content.php?page=$1 [L]";

// lang var = 11010000 - 11019999

if($install == "page") {

  unset($_SESSION['RC_MODEL_CACHE']);
  
  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS NOT BEEN INSTALLED)
  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11010001 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
          (11010001, 1, 'Page Plugin Settings', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
          (11010002, 1, 'View Pages', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
          (11010003, 1, 'Global Page Settings', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, ')");
  }  
  
  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS NOT BEEN INSTALLED)
  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11010101 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
          (11010101, 1, 'Primary Page', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
          (11010102, 1, 'Select the page that would be linked under the Application menu', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
          (11010103, 1, 'Do Not Show On Menu', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
          (11010104, 1, 'Main Page', '')
    ");
  }  
  
  
  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS BEEN INSTALLED)
  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11010201 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
('11010201', 1, 'General Static Page Settings', ''),
('11010202', 1, 'This page contains general static page settings that affect your entire social network.', ''),
('11010203', 1, 'Your changes have been saved.', ''),
('11010204', 1, 'Save Changes', ''),
('11010205', 1, 'Please fill in all the fields.', ''),
('11010206', 1, 'Plugin Activation', ''),
('11010207', 1, 'Would you like to active this page plugin? You can use this to temporary turn off all pages.', ''),
('11010208', 1, 'Yes, activate this plugin.', ''),
('11010209', 1, 'No, deactivate this plugin.', ''),
('11010301', 1, 'View Pages', ''),
('11010302', 1, 'This page lists all of the page that you have created so far.<br><br><b>Instruction:</b> to link to these pages, replace \"page-permanent-key\" or \"page-id\" with corresponding page you want to create a link. You can use any of the following tags in template:<br>
  {\$url->url_create(\'page\', \'page-permanent-key\')}
  <br>{\$url->url_create(\'page\', \'page-id\')}', ''),
('11010303', 1, 'Add Page', ''),
('11010304', 1, 'ID', ''),
('11010305', 1, 'Name', ''),
('11010306', 1, 'Permanent Key', ''),
('11010307', 1, 'Permission', ''),
('11010308', 1, 'Status', ''),
('11010309', 1, 'Last Update', ''),
('11010310', 1, 'Delete Page', ''),
('11010311', 1, 'Are you sure you want to delete this page?', ''),
('11010312', 1, 'Delete Page', ''),
('11010313', 1, 'Cancel', ''),
('11010314', 1, 'The page has been deleted.', ''),
('11010315', 1, 'Options', ''),
('11010316', 1, 'login', ''),
('11010317', 1, 'public', ''),
('11010318', 1, 'disable', ''),
('11010319', 1, 'enable', ''),
('11010320', 1, 'view', ''),
('11010321', 1, 'edit', ''),
('11010322', 1, 'delete', ''),
('11010323', 1, 'Script', ''),
('11010324', 1, 'level:', ''),
('11010325', 1, 'editor', ''),
('11010326', 1, 'Use Editor', ''),
('11010401', 1, 'Add Page', ''),
('11010402', 1, 'To create a new page, complete the following form.', ''),
('11010403', 1, 'Add Page', ''),
('11010404', 1, 'Cancel', ''),
('11010405', 1, 'Page Settings', ''),
('11010406', 1, 'Please enter a descriptive name for this page', ''),
('11010407', 1, 'Permission', ''),
('11010408', 1, 'The public can view this page, no need to login.', ''),
('11010409', 1, 'User must login to view this page.', ''),
('11010410', 1, 'Status', ''),
('11010411', 1, 'Enable, page is active and live.', ''),
('11010412', 1, 'Disable, temporarily down for maintenance.', ''),
('11010413', 1, 'Page Content', ''),
('11010414', 1, 'The HTML and Smarty code for this page is displayed below. After making your desired changes to the template, be sure to click the \"Save Changes\" button. For help with Smarty, see the <a href=\'http://smarty.php.net\' target=\'_blank\'>official website</a> and <a href=\'http://smarty.php.net/crashcourse.php\' target=\'_blank\'>crash course</a>.<br><b>NOTE:</b> If you are using <i>Editor Mode</i>, features such as Image and Linking buttons requires you to have Blog plugin installed.', ''),
('11010415', 1, 'Please make sure you have correctly filled out all fields.', ''),
('11010418', 1, 'Advanced Setting', ''),
('11010419', 1, 'Enter php script file which you would like to be executed. You can use full path or relative path to where SE is installed. A sample usage would be, query database, pull out top 100 popular users, assign to smarty variable, use it on template. If you do not know what this mean, then just leave it blank.<br>Ex: <em>include/page_sample_script.php</em> or <em>/home/mydir/www/social/include/some_php_script.php</em>', ''),
('11010420', 1, 'User must login and belong to specify levels below:', ''),
('11010421', 1, 'You must select at least one level for this permission option.', ''),
('11010501', 1, 'Edit Page', ''),
('11010502', 1, 'To edit this page, please complete the following form. You can use one of tags below to link to this page.', ''),
('11010503', 1, 'Save Page', ''),
('11010504', 1, 'Cancel', ''),
('11010505', 1, 'Page Settings', ''),
('11010506', 1, 'Please enter a descriptive name for this page', ''),
('11010507', 1, 'Permission', ''),
('11010508', 1, 'The public can view this page, no need to login.', ''),
('11010509', 1, 'User must login to view this page.', ''),
('11010510', 1, 'Status', ''),
('11010511', 1, 'Enable, page is active and live.', ''),
('11010512', 1, 'Disable, temporarily down for maintenance.', ''),
('11010513', 1, 'Page Content', ''),
('11010514', 1, 'The HTML and Smarty code for this page is displayed below. After making your desired changes to the template, be sure to click the \"Save Changes\" button. For help with Smarty, see the <a href=\'http://smarty.php.net\' target=\'_blank\'>official website</a> and <a href=\'http://smarty.php.net/crashcourse.php\' target=\'_blank\'>crash course</a>.<br><b>NOTE:</b> If you are using <i>Editor Mode</i>, features such as Image and Linking buttons requires you to have Blog plugin installed.', ''),
('11010515', 1, 'Please make sure you have correctly filled out all fields.', ''),
('11010516', 1, 'The permanent key you enter is used by another page.', ''),
('11010517', 1, 'Please use a unique permanent key for this page.', ''),
('11010518', 1, 'Advanced Setting', ''),
('11010519', 1, 'Enter php script file which you would like to be executed. You can use full path or relative path to where SE is installed. A sample usage would be, query database, pull out top 100 popular users, assign to smarty variable, use it on template. If you do not know what this mean, then just leave it blank.<br>Ex: <em>include/page_sample_script.php</em> or <em>/home/mydir/www/social/include/some_php_script.php</em>', ''),
('11010520', 1, 'User must login and belong to specify levels below:', ''),
('11010521', 1, 'You must select at least one level for this permission option.', ''),
('11010601', 1, 'An Error Has Occurred', ''),
('11010602', 1, 'Return', ''),
('11010603', 1, 'You must be logged in to view this page. <a href=\'login.php\'>Click here</a> to login.', ''),
('11010604', 1, 'This page is temporarily down for maintenance. Sorry for the inconvenient.', ''),
('11010605', 1, 'The page you are trying to view does not exist.', ''),
('11010606', 1, 'You do not have permission to view this page.', '')
      ") or die("Insert Into se_languagevars: ".mysql_error());
  }
  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
					plugin_version,
					plugin_type,
					plugin_desc,
					plugin_icon,
					plugin_menu_title,
					plugin_pages_main,
					plugin_pages_level,
					plugin_url_htaccess
					) VALUES (
					'$plugin_name',
					'$plugin_version',
					'$plugin_type',
					'$plugin_desc',
					'$plugin_icon',
					'$plugin_menu_title',
					'$plugin_pages_main',
					'$plugin_pages_level',
					'$plugin_url_htaccess')");


  //######### UPDATE PLUGIN VERSION IN se_plugins
  } else {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='$plugin_desc',
					plugin_icon='$plugin_icon',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");

  }

  //######### CREATE se_vidfeedertags
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_pages'")) == 0) {
    $database->database_query("CREATE TABLE `se_pages` (
        `page_id` int(9) NOT NULL auto_increment,
        `page_name` varchar(255) NOT NULL default '',
        `page_key` varchar(255) NOT NULL default '',
        `page_type` int(1) NOT NULL default '0',
        `page_status` int(1) NOT NULL default '0',
        `page_content` text,
        `page_updated_at` datetime NOT NULL default '0000-00-00 00:00:00',
        PRIMARY KEY  (`page_id`),
        UNIQUE KEY `nameunq` (`page_key`)
      )");
  }  
  
  if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file='page'")) == 0) {
    $database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Page URL', 'page', 'content.php?page=\$user', 'page/\$user')");
  }
  
  
  
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE  v1.50
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_pages LIKE 'page_script'")) == 0) {
    $database->database_query("ALTER TABLE se_pages 
          ADD COLUMN `page_script` varchar(255) NOT NULL default ''
          ");
  }   
  
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE  v1.75
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_pages LIKE 'page_levels'")) == 0) {
    $database->database_query("ALTER TABLE se_pages 
          ADD COLUMN `page_levels` varchar(255) NOT NULL default ''
          ");
  }   
  
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE  
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_page_main_page_id'")) == 0) {
    $database->database_query("ALTER TABLE se_settings 
          ADD COLUMN `setting_page_main_page_id` int(9) NOT NULL default '0'
    ");
    $database->database_query("UPDATE se_settings SET setting_page_main_page_id='0'");
  }   
  
}  

