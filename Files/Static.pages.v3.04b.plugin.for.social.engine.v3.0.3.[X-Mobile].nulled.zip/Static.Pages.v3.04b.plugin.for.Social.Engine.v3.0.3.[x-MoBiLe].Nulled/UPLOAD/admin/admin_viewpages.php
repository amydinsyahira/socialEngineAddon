<?
$page = "admin_viewpages";
include "admin_header.php";


$task = rc_toolkit::get_request('task','main');
$page_id = rc_toolkit::get_request('page_id',0);

$result = "";

// CREATE THEME OBJECT
$rc_page = new rc_page();
$rc_validator = new rc_validator();


if ($task == "delete") {
  $page_info = $rc_page->get_record($page_id);
  if (!$page_info) {
    rc_toolkit::redirect("admin_viewpages.php");
  }


  if ($_REQUEST['confirm']) {
    
    // SET HIDDEN INPUT ARRAYS FOR TWO TASKS
    $confirm_hidden = array(array('name' => 'task', 'value' => 'delete'),
  			  array('name' => 'page_id', 'value' => $page_id));
    $cancel_hidden = array(array('name' => 'task', 'value' => 'main'));
  
    // LOAD CONFIRM PAGE WITH APPROPRIATE VARIABLES
    $smarty->assign('confirm_form_action', 'admin_viewpages.php');
    $smarty->assign('cancel_form_action', 'admin_viewpages.php');
    $smarty->assign('confirm_hidden', $confirm_hidden);
    $smarty->assign('cancel_hidden', $cancel_hidden);
    $smarty->assign('headline', 11010310);
    $smarty->assign('instructions', 11010311);
    $smarty->assign('confirm_submit', 11010312);
    $smarty->assign('cancel_submit', 11010313);
    $smarty->display("admin_confirm.tpl");
    exit();
  }
  else {
    $res = $rc_page->delete($page_info['page_id']);
    $result = 11010314;
  }    

}

$pages = $rc_page->get_records("ORDER BY page_name asc");

// ASSIGN VARIABLES AND SHOW VIEW ENTRIES PAGE

$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('pages', $pages);
$smarty->assign('result', $result);
include "admin_footer.php";
