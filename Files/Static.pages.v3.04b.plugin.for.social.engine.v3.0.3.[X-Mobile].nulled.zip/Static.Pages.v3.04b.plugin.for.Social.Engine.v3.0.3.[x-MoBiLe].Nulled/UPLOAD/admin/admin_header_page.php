<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE pageS LANGUAGE FILE
//include_once "../lang/lang_".$global_lang."_page.php";
include_once "../include/class_radcodes.php";
include_once "../include/class_page.php";
include_once "../include/functions_page.php";

?>