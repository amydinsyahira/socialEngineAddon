<?
// SITEMODIFICATION.COM  USER_MAP FILE
$page = "user_map";
include "header.php";
require('GoogleMapAPI.class.php');
$map = new GoogleMapAPI('map');
// enter YOUR Google Map Key
$map->setAPIKey('SET YOUR API HERE');

$total_friends = $owner->user_friend_total(0);
$friends = $owner->user_friend_list(0,$total_friends);

$country = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_profiles WHERE profile_user_id='" . $owner->user_info[user_id] . "' LIMIT 1"));
$ctry = $country[profile_1];
$state = $country[profile_4];
$city = $country[profile_5];
$address = $country[profile_7];
$naam= $country[profile_8];
$loc="$city,$state,$ctry";
$smarty->assign('loc', $loc);
$map->addMarkerByAddress("$loc","$naam","<b>$naam</b>");
for ($i=0;$i<$total_friends;$i++)
{
$fc=$database->database_fetch_assoc($database->database_query("SELECT * FROM se_profiles WHERE profile_user_id='" . $friends[$i]->user_info[user_id] . "' LIMIT 1"));
$fctry = $fc[profile_1];
$fstate = $fc[profile_4];
$fcity = $fc[profile_5];
$fadd = $fc[profile_7];
$fnaam= $fc[profile_8];
$floc="$fcity,$fstate,$fctry";
$map->addMarkerByAddress("$floc","$fnaam","$fnaam");
}
$smarty->assign('country', $ctry);
$smarty->assign('state', $state);
$smarty->assign('city', $city);
$smarty->assign('address', $address);
// create some map markers
$map->setHeight('600px');
$map->setWidth('800px');
$map->setZoomLevel(10);
$map->setControlSize = 'small';
$map->disableSidebar();
$map->disableTypeControls();
$map->disableMapControls();
$smarty->assign('google_map_header',$map->getHeaderJS());
$smarty->assign('google_map_js',$map->getMapJS());
$smarty->assign('google_map_sidebar',$map->getSidebar());
$smarty->assign('google_map',$map->getMap());
$smarty->assign('friends', $friends);
$smarty->assign('total_friends', $total_friends);
include "footer.php";
?>