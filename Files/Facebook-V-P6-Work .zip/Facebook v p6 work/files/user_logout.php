<?php
$page = "user_logout";
include "header.php";

$user->user_logout();

// FORWARD TO USER LOGIN PAGE
cheader("index.php");
exit();
?>