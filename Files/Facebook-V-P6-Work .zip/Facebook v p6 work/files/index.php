<?php

include "header.php";

// USER IS LOGGED IN, FORWARD TO USER HOME
if($user->user_exists != 0) { header("Location: user_home.php"); exit(); }




?>








<!DOCTYPE html 	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 	

"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns='http://www.w3.org/1999/xhtml'> 
<head> 
<title>Social Network - Create Your Account</title> 
<base href=''> 
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'> 
<meta name='Description' content="Welcome to the social network! To create your 

account, please provide the following information."> 
 
<link rel="stylesheet" href="./templates/styles_global.css" title="stylesheet" 

type="text/css">  
<link rel="stylesheet" href="./templates/styles.css" title="stylesheet" 

type="text/css">  
<!--[if lte IE 6]>
<link rel="stylesheet" href="./templates/IE6.css" title="stylesheet" 

type="text/css">  
<![endif]--> 
 
<script type="text/javascript" src="./include/js/mootools12.js"></script> 
<script type="text/javascript" src="./include/js/mootools12-more.js"></script> 
<script type="text/javascript" src="./include/js/autogrow.js"></script> 
<script type="text/javascript" src="./include/js/smoothbox.js"></script> 
<script type="text/javascript" src="./include/js/autosuggest.js"></script> 
<script type="text/javascript" src="./include/js/sprintf.js"></script> 
<script type="text/javascript" src="./include/js/ajaxtabs.js"></script> 
 
<script type="text/javascript" src="./include/js/class_base.js"></script> 
<script type="text/javascript" src="./include/js/class_core.js"></script> 
<script type="text/javascript" src="./include/js/class_language.js"></script> 
<script type="text/javascript" src="./include/js/class_url.js"></script> 
<script type="text/javascript" src="./include/js/class_comments.js"></script> 
<script type="text/javascript" src="./include/js/class_tags.js"></script> 
<script type="text/javascript" src="./include/js/class_user.js"></script> 
<script type="text/javascript" src="./include/js/jquery.idTabs.min.js"></script> 
 

 
 
 
 
<script type="text/javascript"> 
<!--
  // ADD TIP FUNCTION
  window.addEvent('domready', function(){
    var Tips1 = new Tips($$('.Tips1'));
  });
//--> 
</script> 
 
 
<link rel="stylesheet" href="./templates/styles_group.css" title="stylesheet" 

type="text/css">  
 
<link rel="stylesheet" href="./templates/styles_album.css" title="stylesheet" 

type="text/css">  
<link rel="stylesheet" href="./templates/styles_blog.css" title="stylesheet" 

type="text/css">  
 
<script type="text/javascript" src="./include/fckeditor/fckeditor.js"></script> 
 
<link rel="stylesheet" href="./templates/styles_poll.css" title="stylesheet" 

type="text/css" /> 
 
 
 
<style type='text/css'></style> 
 
</head> 
<body> 
 
<iframe id='ajaxframe' name='ajaxframe' style='display: none;' 

src='javascript:false;'></iframe> 
<style type="text/css"> 
 
 
 
body {
	background-image:url(./images/index_bg.gif);
	background-repeat:repeat-x;
 
}
 
</style> 
 
<table cellpadding='0' cellspacing='0' class='body' align='center'> 
<tr> 
<td> 
 
 
 
<div class="top_bar_index"> 
 
  <table cellpadding='0' cellspacing='0' style='width:965px; padding-top:1px; 

height:29.5px;' align='center'> 
<tr> 
    <td style="background-image:url(./images/top_left_index.gif); height:85.5px; 

padding-left:5px;" align='left' width="4px">&nbsp;</td> 
    <td width="75"><a href='./'><img style="vertical-align:middle" 

src='./images/logo_index.gif' border='0'></a></td> 
	
	
	
 
	
	
	<td style="padding-left:10px;" align="right"; width="auto"> 
<div style="text-align:right; float:right; color:#98a9ca; margin-top:20px;"> 
 
        <form action='login.php' method='post'> 
        <input style="vertical-align:middle;" type='checkbox' name='persistent' 

value='1' id='rememberme'> <label style="color:#98a9ca; margin-right:70px; 

vertical-align:middle; cursor:pointer;" for='rememberme'>Remember Me</label>  <a 

style="color:#98a9ca; margin-right:65px; " href="lostpass.php">Forgot password?

</a> 
		<br> 
<input type='text' class='text_index' name='email' size='23' maxlength='100' 

value=''> 
<input type='password' class='text_index' name='password' size='23' 

maxlength='100'> 
 
        <input type='submit' class='button_index' value='Login'>&nbsp;
        <NOSCRIPT><input type='hidden' name='javascript_disabled' 

value='1'></NOSCRIPT> 
        <input type='hidden' name='task' value='dologin'> 
        <input type='hidden' name='ip' value=''> 
        </form> 
 
 
</div> 
 
	</td> 
 
	    <td style="background-image:url(./images/top_right_index.gif); 

height:85.5px; padding-left:5px;" align='left' width="13px">&nbsp;</td> 
</tr> 
</table> 
</div> 
</td> 
  </tr> 
  </table> 
 
 
<div style="height:380px; width:960px; margin-right:auto; margin-left:auto;"> 
 
	<div style="width:555px; padding-top:10px; float:left;"> 
			<div style="float:left; width:500px; height:75px; 

padding-left:10px; font-size:20px; text-align:left; font-weight:bold; 

color:#203360;">Facebook helps you connect and share with the people in your 

life.
			</div> 
			<div style="float:left; background-image:url(./images/home_pic.gif); width:550px; height:200px;"> 
			</div> 
	</div> 
	
	<div style="width:375px; float:right; padding-top:20px; text-

align:left;"> 
<font style="font-size:20px; text-align:left; font-weight:bold; 

color:#203360;">Signup</font><br><br> 
<font color="#203360;" style="font-size:20px; text-align:left; 

color:#203360;">It's free and anyone can join</font><br>&nbsp;
<br> 
 
 
 
 
 
  <form action='signup.php' method='POST'> 
  <table cellpadding='0' cellspacing='0'> 
  <tr> 
  <td class='form1' width='100'>Email Address:</td> 
  <td class='form2'> 
    <input name='signup_email' type='text' class='text' maxlength='70' size='40' 

value=''> 
  </td> 
  </tr> 
      <tr> 
    <td class='form1'>Password:</td> 
    <td class='form2'> 
      <input name='signup_password' type='password' class='text' maxlength='50' 

size='40' value=''> 
    </td> 
    </tr> 
    <tr> 
    <td class='form1'>Confirm Password:</td> 
    <td class='form2'> 
      <input name='signup_password2' type='password' class='text' maxlength='50' 

size='40' value=''> 
    </td> 
    </tr> 
    </table> 
 
  <table cellpadding='0' cellspacing='0'> 
      <tr> 
    <td class='form1'>Username:</td> 
    <td class='form2'> 
      <input name='signup_username' type='text' class='text' maxlength='50' 

size='40' value=''> 
            <img src='./images/icons/tip.gif' border='0' class='Tips1' 

title='This is the name others see when they view your profile. If you decide to 

change your username, you must enter one that has not already been taken by 

another person.'> 
    </td> 
    </tr> 
        <tr> 
    <td class='form1'>Account Type:</td> 
    <td class='form2'> 
      <select name='signup_cat'> 
      	<option value='1' selected='selected'>Standard Users</option> 
      	<option value='2'>Musicians</option> 
            </select> 
    </td> 
    </tr> 
    <tr> 
  <td class='form1' width='100'></td> 
  <td class='form2'> 
 
  </td> 
  </tr> 
  </table> 
 
   
  
      <tr> 
    <td class='form1' width='100'>&nbsp;</td> 
    <td class='form2'><input type='checkbox' name='signup_agree' id='tos' 

value='1'><label for='tos'> I have read and agree to the <a href='help_tos.php' 

target='_blank'>terms of service</a>.</label></td> 
    </tr> 
  
  <tr></tr> 
  <tr> 
  <td class='form1'>&nbsp;</td> 
  <td class='form2'><input type='submit' class='button_signup' 

value='Continue...'></td> 
  </tr> 
  </table> 
  <input type='hidden' name='task' value='step1do'> 
  <input type='hidden' name='step' value='1'> 
  </form> 
 
 
 
 
 
 
 
 
 
	
	</div> 
 
</div> 
  
  
<div class='copyright2'> 
  Copyright 2009 &nbsp;-&nbsp;
  <a href='help.php' class='copyright'>FAQ</a> &nbsp;-&nbsp;
  <a href='help_tos.php' class='copyright'>Terms of Service</a> &nbsp;-&nbsp;
  <a href='help_contact.php' class='copyright'>Contact Us</a> 
      &nbsp;-&nbsp;
        <select class='small' name='user_language_id' 

onchange="window.location.href='/facebook_demo/index.php?

&lang_id='+this.options[this.selectedIndex].value;"> 
              <option value='1' selected='selected'>English</option> 
           </select> 
  </div>