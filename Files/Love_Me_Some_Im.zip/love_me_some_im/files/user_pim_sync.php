<?php
$page = "user_pim";
include "header.php";

$task = rc_toolkit::get_request('task','main');

$rc_pim = new rc_pim();
$rc_pim->sync_friends_to_buddies($user);

if ($_SERVER['HTTP_REFERER']) $redirect_to = $_SERVER['HTTP_REFERER'];
else $redirect_to = 'user_home.php';
rc_toolkit::redirect($redirect_to);

