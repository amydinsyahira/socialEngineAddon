<?php

if ($setting['setting_permission_pim'] == 0 || $owner->level_info[level_pim_allow] == 0) {
	return;
}


switch($page) {

  // CODE FOR PROFILE PAGE
  case "profile":
    $rc_pim_user = new rc_pim_user();
    $pim_user = $rc_pim_user->get_record($owner->user_info['user_username']);
    
    $rc_pim = new rc_pim();
    $pim_status = $rc_pim->is_online_text($pim_user['is_online']);

    $pim_buddies = $pim_not_in_buddies = array();
    if ($owner->user_info['user_username'] == $user->user_info['user_username']) {
      $pim_buddies = $rc_pim->get_buddies($owner->user_info['user_username'], '100,2,1');
      $pim_not_in_buddies = $rc_pim->friends_not_in_buddylist($user);      
    }
    $smarty->assign('pim_buddies', $pim_buddies);
    $smarty->assign('pim_status', $pim_status);
    $smarty->assign('pim_not_in_buddies', $pim_not_in_buddies);
    
    
    break;

}
