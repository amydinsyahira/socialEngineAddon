<?php

session_start();

$page = "pim";
include "header.php";


if ($user->user_exists != 0) {
  $_SESSION['rc_pim'] = array(
    'username' => $user->user_info['user_username'],
    'password' => $user->user_info['user_password']
  );
}

if ($setting['setting_permission_pim'] != 0) {
	rc_toolkit::redirect('im/index.php');
}
else {
	rc_toolkit::redirect('home.php');
}

/*
 * session_start();
if ($user->user_exists != 0) {
  $_SESSION['ajaxim_username'] = $user->user_info['user_username'];
  $_SESSION['ajaxim_password'] = $user->user_info['user_password'];
}
*/
