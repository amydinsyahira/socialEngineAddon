<?php

// SET GENERAL VARIABLES, AVAILABLE ON EVERY PAGE
$header_pim[1] = "Messenger";
$header_pim[2] = "Launch";
$header_pim[3] = "Sync Friends to Buddylist";

$header_pim[4] = "Available";
$header_pim[5] = "Friends Only";
$header_pim[6] = "Busy/Away";
$header_pim[7] = "Invisible";
$header_pim[8] = "Offline";
$header_pim[9] = "is";
$header_pim[10] = "No Buddy Online";

// ASSIGN ALL SMARTY GENERAL VARIABLES
foreach ($header_pim as $key=>$val) {
  $smarty->assign("header_pim".$key, $val);
}


// SET LANGUAGE PAGE VARIABLES
switch ($page) {
 
  case "pim":
    $pim[1] = "An Error Has Occurred";
    $pim[2] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
    $pim[3] = "Return";

    break;
	
  case "admin_pim":
    $admin_pim[1] = "General Messenger Settings";
    $admin_pim[2] = "This page contains general Messenger settings that affect your entire social network.";
    $admin_pim[3] = "Your changes have been saved.";
    $admin_pim[4] = "Save Changes";
    
    $admin_pim[5] = "Messenger Activation";
    $admin_pim[6] = "Would you like to enable messenger for your user?";
    $admin_pim[7] = "Yes, allow user to use messenger.";
    $admin_pim[8] = "No, do not allow user to use messenger.";
    
    $admin_pim[9] = "License Key";
    $admin_pim[10] = "Enter the your license key that is provided to you when you purchased this plugin. If you do not know your license key, please contact support team.";
    $admin_pim[11] = "Format: XXXX-XXXX-XXXX-XXXX";
    

    break;
    
	case "admin_levels_pimsettings":
	  $admin_levels_pimsettings[1] = "Messenger Settings";
	  $admin_levels_pimsettings[2] = "Use this page to configure your Messenger per level setting";
	  $admin_levels_pimsettings[3] = "Allow Messenger?";
	  $admin_levels_pimsettings[4] = "If you have selected YES, your users will have access to messenger tool.";
	  $admin_levels_pimsettings[5] = "Yes, users can use messenger.";
	  $admin_levels_pimsettings[6] = "No, users cannot use messenger.";
	  $admin_levels_pimsettings[7] = "Save Changes";
	  $admin_levels_pimsettings[8] = "Your changes have been saved.";
	  $admin_levels_pimsettings[9] = "Editing User Level:";
	  $admin_levels_pimsettings[10] = "You are currently editing this user level's settings. Remember, these settings only apply to the users that belong to this user level. When you're finished, you can edit the <a href='admin_levels.php'>other levels here</a>.";
	
	  break;      
}

// ASSIGN ALL SMARTY VARIABLES
if (is_array(${"$page"})) {
  foreach (${"$page"} as $key=>$val) {
    $smarty->assign($page.$key, $val);
  }
}

