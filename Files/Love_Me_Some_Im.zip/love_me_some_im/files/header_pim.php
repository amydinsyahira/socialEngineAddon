<?php
// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

include_once "./lang/lang_".$global_lang."_pim.php";
include_once "./include/class_radcodes.php";
include_once "./include/class_pim.php";
include_once "./include/functions_pim.php";

// optimized .. only check when login... should be good enough :-)
if ($page == "login" && rc_toolkit::get_request('task') == "dologin" && isset($_POST['email']) && isset($_POST['password'])) {
  $rc_im = new rc_pim();
  $rc_im->init_im_user($_POST['email']);  
}

