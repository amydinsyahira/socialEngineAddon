<?php

include_once "class_radcodes.php";

function pim_online_users($limit=5, $template_var='pim_online_users')
{
  global $smarty, $database;
  $res = $database->database_query("SELECT user_id, user_username, user_photo FROM se_users JOIN rc_pim_users ON user_username = username WHERE is_online IN (100,2,1) ORDER BY last_ping DESC LIMIT $limit");
  $pim_array = Array();
  while($pim = $database->database_fetch_assoc($res)) {
  
    $pim_user = new se_user();
    $pim_user->user_info[user_id] = $pim[user_id];
    $pim_user->user_info[user_username] = $pim[user_username];
    $pim_user->user_info[user_photo] = $pim[user_photo];
  
    $pim_array[] = $pim_user;
  }
  $smarty->assign($template_var, $pim_array);
}




