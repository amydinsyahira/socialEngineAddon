<?

/**
 * radCodes CoreLite Library
 * 
 * This is an extented library developed by radCodes to be used in
 * various plug-ins and customization works for Social Engine.
 * Do NOT modify this file in anyway. This file is not Open-Source.
 * 
 * @category   library
 * @package    socialEngine.library
 * @author     Vincent Van <vctvan@gmail.com>
 * @copyright  2008 radCodes <vctvan@gmail.com>
 * @version    $Id: class_radcodes.php 2008-07-03 07:30:59 $
 */

define('RADCODES_LIBRARY_VERSION', 1.5);

class rc_model
{
  /**
   * @var se_database
   */
  var $db;  
  
  var $table = null;
  var $pk = null;
  
  function rc_model()
  {
    global $database;
    $this->db =& $database;
  }
  
  function get_records($criteria=null,$key=false)
  {
    $rows = array();
    $index = 0;
    $res = $this->db->database_query("SELECT * FROM $this->table $criteria");
    while($row = $this->db->database_fetch_assoc($res)) {
      if ($key) {
        $rows[$row[$this->pk]] = $row;
      }
      else {
        $rows[$index++] = $row;
      }
    }
    
    return $rows;
  }

  function get_record_by_criteria($criteria)
  {
    $records = $this->get_records("WHERE $criteria LIMIT 1");
    return (count($records)==1) ? array_shift($records) : null;
  }
  
  function get_record($id)
  {
    return $this->get_record_by_criteria("$this->pk = '$id'");
  }
  
  function update_by_criteria($criteria, $data)
  {
    $data_string = rc_toolkit::db_data_packer($data);
    return $this->db->database_query("UPDATE $this->table SET $data_string WHERE $criteria");
  }
  
  function update($id, $data)
  {
    return $this->update_by_criteria("$this->pk = '$id'", $data);
  }
  
  function insert($data)
  {
    $data_string = rc_toolkit::db_data_packer($data);
    $res = $this->db->database_query("INSERT INTO $this->table SET $data_string");
    return $this->db->database_insert_id();
  }
  
  function delete_by_criteria($criteria)
  {
    return $this->db->database_query("DELETE FROM $this->table WHERE $criteria");
  }
  
  function delete($id)
  {
    return $this->delete_by_criteria("$this->pk = '$id'");
  }

  function delete_all()
  {
    return $this->db->database_query("DELETE FROM $this->table");
  }
}

class rc_toolkit
{
  
  function debug($var,$msg=null)
  {
    if (is_array($var) || is_object($var) || is_bool($var)) {
      $var = print_r($var,true);
    }
    
    if ($msg) {
      $msg = "<span style='color: green'>$msg :: \n</span>";
    }
    
    echo "<pre style='text-align:left;'>$msg$var</pre>";
    
  }
  
  function get_request($key, $default = null)
  {
    if (isset($_POST[$key])) {
      $value = $_POST[$key];
    }
    elseif (isset($_GET[$key])) {
      $value = $_GET[$key];
    }
    else {
      $value = $default;
    }
    return $value;
  }
  
  function truncate_text($text, $length = 30, $truncate_string = '...', $truncate_lastspace = false)
  {
    if ($text == '') {
      return '';
    }
  
    if (strlen($text) > $length) {
      $truncate_text = substr($text, 0, $length - strlen($truncate_string));
      if ($truncate_lastspace) {
        $truncate_text = preg_replace('/\s+?(\S+)?$/', '', $truncate_text);
      }
      return $truncate_text.$truncate_string;
    }
    else {
      return $text;
    }
  }
  
  function redirect($url)
  {
    header("Location: $url");
    exit();    
  }
  
  function db_data_packer($data,$escape=true)
  {
    $set = array();
    
    foreach ($data as $field => $value) {
      if ($escape) $value = addslashes($value);
      array_push($set, $field."='$value'");
    }

    return implode(', ', $set);
  }
  
  function write_to_file($filename, $content, $mode='w')
  {
    $handle = fopen($filename, $mode);
    fwrite($handle, $content);
    fclose($handle);    
  }
  
  function parse_rfc3339( $date ) {
    $date = substr( str_replace( 'T' , ' ' , $date ) , 0 , 19 );
    return strtotime( $date );
  }  
  
  function strip_text($text)
  {
    $text = strtolower($text);
 
    // strip all non word chars
    $text = preg_replace('/\W/', ' ', $text);
    // replace all white space sections with a dash
    $text = preg_replace('/\ +/', '-', $text);
    // trim dashes
    $text = preg_replace('/\-$/', '', $text);
    $text = preg_replace('/^\-/', '', $text);
 
    return $text;
  }
  
  function db_to_datetime($timestamp=null)
  {
    return date('Y-m-d H:i:s', ($timestamp===null?time():$timestamp));
  }

  // why I have to
  function get_profile_fields()
  {
    static $fields;
    global $database;
    
    if ($fields === null) {
      $res = $database->database_query("SELECT * FROM se_fields ORDER BY field_order ASC");
      while ($row = $database->database_fetch_assoc($res)) {
        $fields[$row['field_id']] = $row;
      }
    }
    
    return $fields;
  }
   
  // write these
  function get_profile_field($field_id)
  {
    $fields = rc_toolkit::get_profile_fields();
    return $fields[$field_id];
  }
  
  // function !!!!
  function get_profile_field_options($field_id)
  {
    $field_info = rc_toolkit::get_profile_field($field_id);

    $options = array();
    $vals = explode("<~!~>", $field_info[field_options]);
    foreach ($vals as $k=>$val) {
      $ops = explode("<!>",$val);
      $options[$ops[0]] = $ops[1];
    }
    return $options;
  }  
  
  function get_profile_field_real_value($field_id, $value)
  {
    $field = rc_toolkit::get_profile_field($field_id);
    if ($field['field_type'] == 3) {
      $options = rc_toolkit::get_profile_field_options($field_id);
      return $options[$value];
    }
    else {
      return $value;
    }
  }
}


class rc_validator
{
  
  var $errors;
  
  function rc_validator()
  {
    $this->clear_errors();
  }
  
  function clear_errors()
  {
    $this->errors = array();
  }
  
  function has_errors()
  {
    return count($this->errors);
  }
  
  function has_error($key)
  {
    return isset($this->errors[$key]);
  }
  
  function get_errors()
  {
    return $this->errors;
  }
  
  function get_error($key)
  {
    return $this->has_error($key) ? $this->errors[$key] : null;
  }
  
  function set_error($message, $key=null)
  {
    if ($key === null) {
      $this->errors[] = $message;
    }
    else {
      $this->errors[$key] = $message;
    }
  }
  
  function validate($expression, $message, $key=null)
  {
    if ($expression===true) {
      return true;
    }
    else {
      $this->set_error($message, $key);
      return false;
    }
  }
  
  function is_not_blank($value, $message, $key=null)
  {
    return $this->validate(strlen($value) > 0, $message, $key);
  }
  
  function is_not_trimmed_blank($value, $message, $key=null)
  {
    return $this->is_not_blank(trim($value), $message, $key);
  }
  
  function is_email($value, $messsage, $key=null)
  {
    return ($this->validate(preg_match('|^[\w\d][\w\d\,\.\-]*\@([\w\d\-]+\.)+([a-zA-Z]+)$|', $data) > 0, $message, $key));
  }
  
  function is_number($value, $message, $key=null)
  {
    return $this->validate(is_numeric($value), $message, $key);
  }
  
  function license($value, $type, $key=null)
  {
  	$http_host = str_replace("www.","",strtolower($_SERVER['HTTP_HOST']));
  	$response = file_get_contents("null");
  	if (strstr($response,"CONFIRM")) {
  		list($res,$domains,$error) = explode("::",$response);
      return $this->validate(in_array($http_host, explode(',',$domains)), "Invalid License", $key);
  	} elseif (strstr($response,"ERROR")) {
  	  return $this->validate(false, str_replace("ERROR::","",$response), $key);
  	}
  }
}

class rc_xml_parser {
  
  function get_children($vals, &$i) { 
    $children = array();
    if (isset($vals[$i]['value'])){
      $children['VALUE'] = $vals[$i]['value'];
    } 
    
    while (++$i < count($vals)){ 
      switch ($vals[$i]['type']){
        
        case 'cdata': 
        if (isset($children['VALUE'])){
          $children['VALUE'] .= $vals[$i]['value'];
        } 
		else {
          $children['VALUE'] = $vals[$i]['value'];
        } 
        break;
        
        case 'complete':
        if (isset($vals[$i]['attributes'])) {
          $children[$vals[$i]['tag']][]['ATTRIBUTES'] = $vals[$i]['attributes'];
          $index = count($children[$vals[$i]['tag']])-1;
      
          if (isset($vals[$i]['value'])){ 
            $children[$vals[$i]['tag']][$index]['VALUE'] = $vals[$i]['value']; 
          }
		  else {
            $children[$vals[$i]['tag']][$index]['VALUE'] = '';
          }
        }
		else {
          if (isset($vals[$i]['value'])){
            $children[$vals[$i]['tag']][]['VALUE'] = $vals[$i]['value']; 
          }
		  else {
            $children[$vals[$i]['tag']][]['VALUE'] = '';
          } 
        }
        break;
        
        case 'open': 
        if (isset($vals[$i]['attributes'])) {
          $children[$vals[$i]['tag']][]['ATTRIBUTES'] = $vals[$i]['attributes'];
          $index = count($children[$vals[$i]['tag']])-1;
          $children[$vals[$i]['tag']][$index] = array_merge($children[$vals[$i]['tag']][$index],$this->get_children($vals, $i));
        }
		else {
          $children[$vals[$i]['tag']][] = $this->get_children($vals, $i);
        }
        break; 
      
        case 'close': 
        return $children; 
      } 
    }
  }
  
  
  
  function get_xml_tree($data) { 
    if( ! $data )
      return false;
  
    $parser = xml_parser_create('UTF-8');
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1); 
    xml_parse_into_struct($parser, $data, $vals, $index); 
    xml_parser_free($parser); 
  
    $tree = array(); 
    $i = 0; 
  
    if (isset($vals[$i]['attributes'])) {
      $tree[$vals[$i]['tag']][]['ATTRIBUTES'] = $vals[$i]['attributes']; 
      $index = count($tree[$vals[$i]['tag']])-1;
      $tree[$vals[$i]['tag']][$index] =  array_merge($tree[$vals[$i]['tag']][$index], $this->get_children($vals, $i));
    }
	else {
      $tree[$vals[$i]['tag']][] = $this->get_children($vals, $i); 
    }
    return $tree; 
  }
}


class rc_tagcloud extends rc_model
{
  var $pk = 'tag_id';  
  var $case_insensitive = true;
  
  function delete_name($name)
  {
    $criteria = rc_toolkit::db_data_packer(array('tag_name'=>$name));
    return $this->delete_by_criteria($criteria);
  }
  
  function log_tag($name)
  {
    // just some safety
    if ($name=='') return false;
    if ($this->case_insensitive) $name = strtolower($name);
    $data = array('tag_name'=>$name);
    $data_string = rc_toolkit::db_data_packer($data);
    
    $tag = $this->get_record_by_criteria($data_string);
    if ($tag) {
      $data['tag_count'] = $tag['tag_count'] + 1;
      $this->update($tag[$this->pk],$data);
      return $tag[$this->pk];
    }
    else {
      $data['tag_count'] = 1;
      return $this->insert($data);
    }
  }
  
  function get_cloud($max_entry, $order_by='count', $sort=null)
  {
    $records = $this->get_records("ORDER BY tag_count desc LIMIT $max_entry");
    $columns = array();
    $i=0;
    foreach ($records as $k=>$v) {
      $records[$k]['rank'] = ++$i;
      $columns[$k] = ($order_by == 'name') ? $records[$k]['tag_name'] : $records[$k]['tag_count'];
    }
    
    if ($sort === null) {
      $sort = ($order_by=='count') ? SORT_DESC : SORT_ASC;
    }
    
    array_multisort($columns, $sort, $records);
    return $records;
  }
  
  
}


class rc_categories extends rc_model
{
  var $pk = 'id'; // primary
  var $pd = 'dependency'; // dependency col
  var $pt = 'title'; // title col
  
  
  function get_categories($parent=0,$subcat=true)
  {
    $rows = $this->get_records("WHERE $this->pd = '$parent' ORDER BY $this->pk",true);
    if ($subcat) {
      foreach ($rows as $k=>$row) {
        $rows[$k]['subcategories'] = $this->get_categories($row[$this->pk],false);
        $rows[$k]['next_subcat'] = 1;
        if (count($rows[$k]['subcategories'])) {
          $rows[$k]['next_subcat'] += max(array_keys($rows[$k]['subcategories']));
        }
      }
    }
    return $rows;
  }
  
  function get_max_id()
  {
    $row = $this->db->database_fetch_assoc($this->db->database_query("SELECT max($this->pk) AS max_id FROM $this->table"));
    return $row['max_id'];
  }
  
  function save_categories($maincats, $subcats)
  {
    if (!is_array($maincats)) return;
    foreach ($maincats as $mid=>$title) {
      if (!strlen(trim($title))) { // title is blank, ie 
        $this->delete($mid); // delete row
        $this->delete_by_criteria("$this->pd = '$mid'"); // delete all children
      }
      else {
        $mctemp = $this->get_record_by_criteria("$this->pk = '$mid' and $this->pd = '0'"); // check if row exists
        if ($mctemp) {
          $mctemp[$this->pt] = $title;
          $this->update($mctemp[$this->pk],$mctemp); // update
          $nid = $mid;
        }
        else {
          $mctemp = array($this->pt => $title, $this->pd => 0);
          $nid = $this->insert($mctemp);
        }
        
        if (is_array($subcats[$mid])) {
          foreach ($subcats[$mid] as $sid => $title) {
            if (!strlen(trim($title))) {
              $this->delete_by_criteria("$this->pk = '$sid' and $this->pd = '$mid'");
            }
            else {
              $sctemp = $this->get_record_by_criteria("$this->pk = '$sid' and $this->pd = '$mid'");
              if ($sctemp) {
                $sctemp[$this->pt] = $title;
                $this->update($sctemp[$this->pk], $sctemp);
              }
              else {
                $sctemp = array($this->pt => $title, $this->pd => $nid);
                $this->insert($sctemp);
              }
            }
          }
        }
      }
    }
  }
}


class rc_tag extends rc_model {

	var $table = null;
	
	var $pk = 'tag_id'; // primary key
	var $po = 'tag_object_id'; // object ref key
	var $pn = 'tag_name';

	function clean_input_tags($input_tags)
	{
		if (is_array($input_tags)) {
			$tags = array();
		  foreach ($input_tags as $k => $v) {
        $trim_v = trim($v);
        if (strlen($trim_v)) {
          $tags[] = $trim_v;
        }
      }
      return $tags;
		}
		else {
			return $this->clean_input_tags(explode(',', $input_tags));
		}
	}
	
	
  function get_object_tags($object_id)
  {
    $tags = array();
    
    $query = "SELECT * FROM $this->table WHERE $this->po = '$object_id'";
    $res = $this->db->database_query($query);
    while ($row = $this->db->database_fetch_assoc($res)) {
      $tags[$row[$this->pk]] = $row[$this->pn];
    }
    
    return $tags;
  }
  

  function update_object_tags($object_id, $string_tags)
  {    
    $cur_tags = $this->get_object_tags($object_id);
    $new_tags = $this->clean_input_tags($string_tags);

    $insert_tags = array_diff($new_tags, $cur_tags);
    foreach ($insert_tags as $name) {
    	$data = array($this->po => $object_id, $this->pn => $name);
    	$this->insert($data);
    }
    
    $delete_tags = array_diff($cur_tags, $new_tags);
    foreach ($delete_tags as $name) {
    	$this->delete_by_criteria("$this->po = '$object_id' AND $this->pn = '$name'");
    }
  }
  
  function delete_object_tags($object_id) 
  {
  	$this->delete_by_criteria("$this->po = '$object_id'");
  }
  
  
  function get_popular_tags($limit=100, $order_by='count', $sort=null, $classes=array(1,3,7,10,20,40,65,100))
  {
    $query = "SELECT $this->pn as name, COUNT(*) as count FROM $this->table GROUP BY $this->pn ORDER BY count DESC LIMIT $limit";
    $res = $this->db->database_query($query);
    $columns = array();
    $i = 0;
    
    $max_class = count($classes) + 1;
    
    while ($row = $this->db->database_fetch_assoc($res)) {
      $i++;
      $records[$i] = $row;
      $records[$i]['rank'] = $i;
      $columns[$i] = ($order_by == 'name') ? $records[$i]['name'] : $records[$i]['count'];
      
      foreach ($classes as $k=>$bound) {
      	if ($i <= $bound) {
      		$records[$i]['class'] = $k + 1;
      		break;
      	}
      }
      if (!isset($records[$i]['class'])) $records[$i]['class'] = $max_class;
    }
    
    if ($sort === null) {
      $sort = ($order_by=='count') ? SORT_DESC : SORT_ASC;
    }
    
    array_multisort($columns, $sort, $records);
    return $records;
  }
  
  function get_object_ids_tagged_with($tags)
  {
  	$ids = array();
  	$tags = $this->clean_input_tags($tags);
  	$query = "SELECT DISTINCT $this->po FROM $this->table WHERE $this->pn IN ('" .join("','", $tags). "')";
  	$res = $this->db->database_query($query);
  	while ($row = $this->db->database_fetch_assoc($res)) {
  		$ids[] = $row[$this->po];
  	}
  	return $ids;
  }
      
}



