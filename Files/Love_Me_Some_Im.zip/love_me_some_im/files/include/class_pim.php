<?php

include_once "class_radcodes.php";


class rc_pim_user extends rc_model {
  var $table = 'rc_pim_users';
  var $pk = 'username';
}

class rc_pim_message extends rc_model {
  var $table = 'rc_pim_messages';
  var $pk = 'id';
}

class rc_pim_chat extends rc_model {
  var $table = 'rc_pim_chats';
  var $pk = 'id';
}

class rc_pim_buddylist extends rc_model {
  var $table = 'rc_pim_buddylists';
  var $pk = 'id';
}

class rc_pim_blocklist extends rc_model {
  var $table = 'rc_pim_blocklists';
  var $pk = 'id';
}

class rc_pim
{
  /**
   * @var se_database
   */
  var $db;
  
  function rc_pim()
  {
    global $database;
    $this->db =& $database;
  }
  
  
  function init_im_user($email)
  {
    $email = strtolower($email);
    $rc_ajaxim_user = new rc_pim_user();
    $im_user = $rc_ajaxim_user->get_record_by_criteria("email = '$email'");
    if (!$im_user) 
    {
      $this->create_im_user($email);
    }
  }
  
  function create_im_user($email)
  {
    $rc_ajaxim_user = new rc_pim_user();
    $res = $this->db->database_query("SELECT * FROM se_users WHERE LOWER(user_email)='$email'");
    $user = $this->db->database_fetch_assoc($res);
    if ($user['user_id']) {
      $im_user = $rc_ajaxim_user->get_record_by_criteria("username = '{$user['user_username']}'");
      if ($im_user) {
        // email may have changed .. so we update it :-)
        $data = array('email' => $user['user_email']);
        $rc_ajaxim_user->update($im_user['username'], $data);
      }
      else {
        // new entry .. create new record
        $data = array(
          'username' => $user['user_username'],
          'email'    => $user['user_email'],
          'admin'    => 0
        );
        $rc_ajaxim_user->insert($data);
      }
    }
  }
  
  function get_buddies($username, $is_online=null)
  {
    $buddies = array();
    
    $u = new rc_pim_user();
    $b = new rc_pim_buddylist();
    
    $query = "SELECT username, is_online, `group` FROM {$u->table}, {$b->table}
      WHERE {$b->table}.user = '$username' AND {$u->table}.username = {$b->table}.buddy
    ";
    if ($is_online !== null) $query .= " AND is_online IN ($is_online)";
    
    $res = $this->db->database_query($query);
    while ($r = $this->db->database_fetch_assoc($res)) {
      $r['status'] = $this->is_online_text($r['is_online']);
      $r['mode'] = $this->is_online_mode($r['is_online']);
      $buddies[] = $r;
    }
    return $buddies;
  }
  
  function is_online_text($is_online)
  {
    global $owner, $user, $header_pim;
    
    if ($is_online == 100) {
      $status = $header_pim[5]; // friend only
    }
    elseif ($is_online == 2) {
      $status = $header_pim[6]; // Busy
    }
    elseif ($is_online == 50 && ($owner->user_info['user_id'] == $user->user_info['user_id'])) {
      $status = $header_pim[7]; // invisiable
    }
    elseif ($is_online == 1) {
      $status = $header_pim[4]; // online
    }
    else {
      $status = $header_pim[8]; // not available
    }
    return $status;
  }
  
  function is_online_mode($is_online)
  {
    if ($is_online == 100 || $is_online == 1) {
      $mode = 1;
    }
    elseif ($is_online == 2) {
      $mode = 2;
    }
    else {
      $mode = 0;
    }
    return $mode;
  }
  
  function friends_not_in_buddylist($user)
  {
    $user_id = $user->user_info['user_id'];
    $username = $user->user_info['user_username'];
    
    $buddies = array();
    $b = new rc_pim_buddylist();
    $buddy_array = $b->get_records("WHERE user='$username'");
    foreach($buddy_array as $ba) {
      $buddies[] = $ba['buddy'];
    }
    
    $res = $this->db->database_query("SELECT se_users.user_username as buddy, friend_type  
    FROM se_friends
    JOIN se_users ON se_users.user_id = friend_user_id2
    WHERE friend_user_id1 = '$user_id'
      AND friend_status = '1'
      AND se_users.user_username NOT IN ('". join("','", $buddies) ."')
    ");
    
    $records = array();
    while ($r = $this->db->database_fetch_assoc($res)) {
    	$records[$r['buddy']] = $r['friend_type'];
    }
    return $records;
  }
  
  
  function sync_friends_to_buddies($user)
  {
  	$new_buddies = $this->friends_not_in_buddylist($user);
  	$username = $user->user_info['user_username'];
  	foreach ($new_buddies as $buddy=>$group) {
  		if (!strlen($group)) $group = 'Friends';
      $this->db->database_query("INSERT INTO rc_pim_buddylists SET user='{$username}', buddy='$buddy', `group`='$group'");
  	}
  }
  
  
}
