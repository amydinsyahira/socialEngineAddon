<?php
///////////////////////////////////
//          ajax im 3.4          //
//    AJAX Instant Messenger     //
//   Copyright (c) 2006-2008     //
//    http://www.ajaxim.com/     //
//   Do not remove this notice   //
///////////////////////////////////
include_once '../include/database_config.php';

// MySQL Database Configuration
$sql_user   = $database_username;
$sql_pass   = $database_password;
$sql_host   = $database_host;
$sql_db     = $database_name;

// do not modify
define('SQL_PREFIX', 'rc_pim_');

// Max buddy icon size
$maxBuddyIconSize = 200; // in KBs, set to 0 to disable uploads

// connect to database //
$link = mysql_connect($sql_host, $sql_user, $sql_pass);
mysql_select_db($sql_db);
//mysql_query('SET NAMES \'utf8\'');

session_start();
