<?php 
include_once 'config.php';
include_once '../include/functions_pim.php';

