<?php
$page = "admin_pim";
include "admin_header.php";

$task = rc_toolkit::get_request('task','main');

$rc_validator = new rc_validator();

$keys = array('setting_permission_pim',
'setting_pim_license'
);

if ($task == 'dosave') {
  
  foreach ($keys as $key) {
    $setting[$key] = $data[$key] = $_POST[$key];
  }
 
}

foreach ($keys as $key) {
  $smarty->assign($key, $setting[$key]);
}

$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('result', $result);
$smarty->display("$page.tpl");
exit();