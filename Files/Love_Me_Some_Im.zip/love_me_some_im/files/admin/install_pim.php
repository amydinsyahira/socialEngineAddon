<?php

$plugin_name = "Messenger Plugin";
$plugin_version = 1.30;
$plugin_type = "pim";
$plugin_desc = "This plugin allows your social network users communicate instantly via messenger. It is a browser-based instant messaging client, use AJAX to create a near real-time IM environment for your community.";
$plugin_icon = "pim16.gif";
$plugin_pages_main = "Global Messenger Settings<!>admin_pim.php<~!~>";
$plugin_pages_level = "Messenger Settings<!>admin_levels_pimsettings.php<~!~>";
$plugin_url_htaccess = "";

if($install == "pim") {

  if ($_REQUEST['clear'] == 'yes') {
    $database->database_query("drop table if exists rc_pim_blocklists");
    $database->database_query("drop table if exists rc_pim_buddylists");
    $database->database_query("drop table if exists rc_pim_chats");
    $database->database_query("drop table if exists rc_pim_messages");
    $database->database_query("drop table if exists rc_pim_users");
    $pim_charset = "ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci";
  
  }
  
  
  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
					plugin_version,
					plugin_type,
					plugin_desc,
					plugin_icon,
					plugin_pages_main,
					plugin_pages_level,
					plugin_url_htaccess
					) VALUES (
					'$plugin_name',
					'$plugin_version',
					'$plugin_type',
					'$plugin_desc',
					'$plugin_icon',
					'$plugin_pages_main',
					'$plugin_pages_level',
					'$plugin_url_htaccess')");


  //######### UPDATE PLUGIN VERSION IN se_plugins
  } else {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='$plugin_desc',
					plugin_icon='$plugin_icon',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");

  }
  
  
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'rc_pim_blocklists'")) == 0) {
    $database->database_query("CREATE TABLE `rc_pim_blocklists` (
      `id` int(11) NOT NULL auto_increment,
      `user` varchar(100) NOT NULL default '',
      `buddy` varchar(100) NOT NULL default '',
      PRIMARY KEY  (`id`),
      KEY `user` (`user`,`buddy`)
    ) $pim_charset");
  }    
  
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'rc_pim_buddylists'")) == 0) {
    $database->database_query("CREATE TABLE `rc_pim_buddylists` (
      `id` int(11) NOT NULL auto_increment,
      `user` varchar(100) NOT NULL default '',
      `buddy` varchar(100) NOT NULL default '',
      `group` varchar(100) NOT NULL default '',
      PRIMARY KEY  (`id`),
      KEY `user` (`user`,`buddy`)
    ) $pim_charset");
  }    

  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'rc_pim_chats'")) == 0) {
    $database->database_query("CREATE TABLE `rc_pim_chats` (
      `room` text,
      `user` text,
      `id` bigint(20) unsigned NOT NULL auto_increment,
      UNIQUE KEY `id` (`id`)
    ) $pim_charset");
  }    

  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'rc_pim_messages'")) == 0) {
    $database->database_query("CREATE TABLE `rc_pim_messages` (
      `recipient` text,
      `sender` text,
      `message` text,
      `type` text,
      `stamp` text,
      `id` bigint(20) unsigned NOT NULL auto_increment,
      UNIQUE KEY `id` (`id`)
    ) $pim_charset");
  }      
  
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'rc_pim_users'")) == 0) {
    $database->database_query("CREATE TABLE `rc_pim_users` (
      `username` varchar(32) default NULL,
      `password` varchar(32) default NULL,
      `email` text,
      `is_online` int(11) default '0',
      `last_ping` text,
      `last_ip` varchar(15) default NULL,
      `banned` tinyint(1) default '0',
      `admin` tinyint(1) default '0',
      `buddyicon` varchar(4) NOT NULL default 'none',
      `profile` text,
      `id` bigint(20) unsigned NOT NULL auto_increment,
      UNIQUE KEY `id` (`id`),
      UNIQUE KEY `username` (`username`)
    ) $pim_charset");
  }   
  
  $res = $database->database_query("SELECT user_username, user_email FROM se_users");
  while ($r = $database->database_fetch_assoc($res)) {
    $database->database_query("INSERT INTO rc_pim_users SET username='{$r['user_username']}', email='{$r['user_email']}', admin='0'");
  }
  
  $res = $database->database_query("SELECT u1.user_username as user, u2.user_username as buddy, friend_type 
            FROM se_friends 
            JOIN se_users as u1 ON u1.user_id = friend_user_id1 
            JOIN se_users as u2 ON u2.user_id = friend_user_id2
            WHERE friend_status = '1'");
  while ($r = $database->database_fetch_assoc($res)) {
    $buddy_group = strlen($r['friend_type']) ? $r['friend_type'] : 'Friends';
    $database->database_query("INSERT INTO rc_pim_buddylists SET user='{$r['user']}', buddy='{$r['buddy']}', `group`='$buddy_group'");
  }
  
  //######### ADD COLUMNS/VALUES TO LEVELS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_levels LIKE 'level_pim_allow'")) == 0) {
    $database->database_query("ALTER TABLE se_levels 
          ADD COLUMN `level_pim_allow` int(1) NOT NULL default '1'");
    $database->database_query("UPDATE se_levels SET level_pim_allow='1'");
  }  
  
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE  
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_permission_pim'")) == 0) {
    $database->database_query("ALTER TABLE se_settings 
          ADD COLUMN `setting_permission_pim` int(1) NOT NULL default '1',
          ADD COLUMN `setting_pim_license` varchar(255) NOT NULL default ''");
    $database->database_query("UPDATE se_settings SET setting_permission_pim='1', setting_pim_license='[Mister-P] NULLED 2008\" disabled=\"disabled\" readonly=\"readonly\'");
  }  
  
}
