<?php

/* $Id:: admin_rss_settings.php 15 2008-02-28 03:57:22Z tsumi             $: */

$page = "admin_rss_settings";
include "admin_header.php";


// SET VARIABLES
$task           = ( isset($_POST['task']) ? $_POST['task'] : "main" );
$results        = array();
$errors         = array();



// Uninstall
$uninstall = ( isset($_GET['uninstall']) ? $_GET['uninstall'] : NULL );
if( isset($uninstall) && $uninstall=="rss" )
{
  // Whoops!
  if( !file_exists('install_rss.php') )
  {
    $errors[] = "To uninstall, the install file of the version that is currently installed must exist in the admin directory.";
  }
  
  // Do uninstall
  else
  {
    include "install_$uninstall";
    cheader("admin_viewplugins.php");
    exit();
  }
}





// SAVE
if( $task=="dosave" )
{
  $post_settings =& $_POST['settings'];
  
  $sql = "
    UPDATE
      se_settings
    SET
      setting_rss_enabled='$post_settings[setting_rss_enabled]'
  ";
  
  $database->database_query($sql) or die($database->database_error());
  
  
  
  // Reload the settings
  $setting = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_settings LIMIT 1"));
  $smarty->assign('setting', $setting);
}










// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('results', $results);
$smarty->assign('errors', $errors);

$smarty->display("$page.tpl");
exit();
?>