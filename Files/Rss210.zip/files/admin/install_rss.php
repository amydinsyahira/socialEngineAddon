<?

/* $Id:: install_rss.php 15 2008-02-28 03:57:22Z tsumi                    $: */

$plugin_name = "RSS Feed Plugin";
$plugin_version = 2.00;
$plugin_type = "rss";
$plugin_desc = "Creates RSS feeds.";
$plugin_icon = "rss16.gif";
$plugin_pages_main = "Global RSS Settings<!>admin_rss_settings.php<~!~>Uninstall Plugin<!>admin_rss_settings.php?uninstall=rss<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";




if($install == "rss")
{


  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
					plugin_version,
					plugin_type,
					plugin_desc,
					plugin_icon,
					plugin_pages_main,
					plugin_pages_level,
					plugin_url_htaccess
					) VALUES (
					'$plugin_name',
					'$plugin_version',
					'$plugin_type',
					'$plugin_desc',
					'$plugin_icon',
					'$plugin_pages_main',
					'$plugin_pages_level',
					'$plugin_url_htaccess')");
  }

  //######### UPDATE PLUGIN VERSION IN se_plugins
  else
  {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='$plugin_desc',
					plugin_icon='$plugin_icon',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");

  }

  

  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
  if($database->database_num_rows($database->database_query(
    "SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_rss_enabled'"
  )) == 0)
  {
    $database->database_query("
      ALTER TABLE
        se_settings 
      ADD COLUMN `setting_rss_enabled`          int(1) NOT NULL default '0'
    ");
    
    $database->database_query("
      UPDATE
        se_settings
      SET
        setting_rss_enabled='1'
    ");
  }


}  











if($uninstall == "rss")
{
  $database->database_query("ALTER TABLE se_settings DROP setting_rss_enabled");
  $database->database_query("DELETE FROM se_plugins WHERE plugin_type='rss' LIMIT 1");
}

?>