<?php

// SET GENERAL VARIABLES, AVAILABLE ON EVERY PAGE
$header_rss[1] = "RSS Feed";
$header_rss[2] = "View Global Feed";
$header_rss[3] = "View This User's Feed";
$header_rss[4] = "for user";
$header_rss[5] = "Error";
$header_rss[6] = "RSS type does not exist for this page.";
$header_rss[7] = "Return";

$header_rss[8] = "Actions";
$header_rss[9] = "Recent Actions";

$header_rss[10] = "Announcements";
$header_rss[11] = "Recent Announcements";

$header_rss[12] = "Friendships";
$header_rss[13] = "Recent Friendships";
$header_rss[14] = "has a new friend.";
$header_rss[15] = "has become friends with";


$header_rss[16] = "Albums";
$header_rss[17] = "Recent Albums";

$header_rss[18] = "Media";
$header_rss[19] = "Recent Media";

$header_rss[20] = "Blogs";
$header_rss[21] = "Recent Blog Entries";

$header_rss[22] = "Events";
$header_rss[23] = "Upcoming and Recent Events";

$header_rss[24] = "Groups";
$header_rss[25] = "Recently Created Groups";

$header_rss[26] = "Untitled";


// ASSIGN ALL SMARTY GENERAL rss VARIABLES
reset($header_rss);
while(list($key, $val) = each($header_rss)) {
  $smarty->assign("header_rss".$key, $val);
}


?>