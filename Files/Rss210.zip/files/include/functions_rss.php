<?php

/* $Id:: functions_rss.php 20 2008-03-10 23:35:18Z tsumi                  $: */


function &generic_rss($type, $start=NULL, $where=NULL, $order=NULL, $limit=NULL)
{
  // Check specific browse function
  $callback = "rss_$type";
  if( !is_callable($callback) ) return FALSE;
  
  // Construct query
  $order_clause = ( isset($order) ? "$order"          : ""        );
  $limit_clause = ( isset($start) ? "$start, $limit"  : ( isset($limit) ? "$limit" : 20 ) );
  $where_clause = ( isset($where) ? "$where"          : ""        );
  
  //if( $where_clause ) $where_clause = security("WHERE $where_clause");
  if( $where_clause ) $where_clause =          "WHERE $where_clause"    ;
  if( $order_clause ) $order_clause = security("ORDER BY $order_clause");
  if( $limit_clause ) $limit_clause = security("LIMIT $limit_clause")   ;
  
  // Call specific browse function
  $channel_data =& $callback($start, $where_clause, $order_clause, $limit_clause);
  
  return $channel_data;
}








/* --------------------------------- general ------------------------------- */
function &rss_action($start, $where_clause, $order_clause, $limit_clause)
{
  global $database, $url, $header_rss;
  
  
  // Construct query
  if( !$order_clause ) $order_clause = "ORDER BY se_actions.action_date DESC";
  //if( $where_clause ) { $where_clause .= " AND "; } else { $where_clause = "WHERE "; }
  //$where_clause .= ""; 
  
  $sql = "
    SELECT
      se_actions.*,
      se_users.user_id,
      se_users.user_username,
      se_users.user_photo
    FROM
      se_actions
    LEFT JOIN
      se_actiontypes
      ON se_actions.action_actiontype_id=se_actiontypes.actiontype_id
    LEFT JOIN
      se_users
      ON se_actions.action_user_id=se_users.user_id
    $where_clause
    $order_clause
    $limit_clause
  ";
  
  
  // Generate return data
  $channel_array = array
  (
    'title'       => $header_rss[8],
    'link'        => $url->url_base,
    'desc'        => $header_rss[9],
    'image'       => $url->url_base."/images/icons/admin_activity16.gif",
    'image_link'  => $url->url_base,
    'items'       => array()
  );
  
  $resource = $database->database_query($sql) or die($database->database_error()." $sql");
  
  while( $result=$database->database_fetch_assoc($resource) )
  {
    $channel_array['items'][] = array
    (
      'title'       => $result['actiontype_name'],
      'link'        => $url->url_base,
      'desc'        => $result['action_text'],
      'category'    => $result['actiontype_name'],
      'pub_date'    => date('r', $result['action_date']),
      'author'      => $result['action_user_id'],
    );
  }
  
  return $channel_array;
}






function &rss_announcement($start, $where_clause, $order_clause, $limit_clause)
{
  global $database, $url, $header_rss;
  
  
  // Construct query
  if( !$order_clause ) $order_clause = "ORDER BY se_announcements.announcement_date DESC";
  
  $sql = "
    SELECT
      se_announcements.*
    FROM
      se_announcements
    $where_clause
    $order_clause
    $limit_clause
  ";
  
  
  // Generate return data
  
  
  // Generate return data
  $channel_array = array
  (
    'title'       => $header_rss[10],
    'link'        => $url->url_base,
    'desc'        => $header_rss[11],
    'image'       => $url->url_base."/images/icons/admin_announcements16.gif",
    'image_link'  => $url->url_base,
    'items'       => array()
  );
  
  $resource = $database->database_query($sql) or die($database->database_error()." $sql");
  
  while( $result=$database->database_fetch_assoc($resource) )
  {
    $channel_array['items'][] = array
    (
      'title'       => ($result['announcement_subject'] ? $result['announcement_subject'] : $header_rss[26]),
      'link'        => "home.php",
      'desc'        => $result['announcement_body'],
      'category'    => NULL,
      'pub_date'    => date('r', $result['announcement_date']),
      //'author'      => "Site Administration"
    );
  }
  
  return $channel_array;
}






function &rss_friend($start, $where_clause, $order_clause, $limit_clause)
{
  global $database, $url, $header_rss;
  
  
  // Construct query
  if( !$order_clause ) $order_clause = "ORDER BY se_friends.friend_id DESC";
  if( $where_clause )
  {
    $where_clause = str_replace("se_users", "friend1", $where_clause) . " AND ";
  }
  else
  {
    $where_clause = "WHERE ";
  }
  
  $where_clause .= "friend1.user_privacy_search='1' AND se_friends.friend_status='1'"; 
  
  $sql = "
    SELECT
      se_friends.*,
      friend1.user_username AS friend1_username,
      friend2.user_username AS friend2_username
    FROM
      se_friends
    LEFT JOIN
      se_users AS friend1
      ON friend1.user_id=se_friends.friend_user_id1
    LEFT JOIN
      se_users AS friend2
      ON friend2.user_id=se_friends.friend_user_id2
    $where_clause
    $order_clause
    $limit_clause
  ";
  
  
  // Generate return data
  
  
  // Generate return data
  $channel_array = array
  (
    'title'       => $header_rss[12],
    'link'        => $url->url_base,
    'desc'        => $header_rss[13],
    'image'       => $url->url_base."/images/icons/friends48.gif",
    'image_link'  => $url->url_base,
    'items'       => array()
  );
  
  $resource = $database->database_query($sql) or die($database->database_error()." $sql");
  
  while( $result=$database->database_fetch_assoc($resource) )
  {
    $channel_array['items'][] = array
    (
      'title'       => $result['friend1_username'].$header_rss[14],
      'link'        => $url->url_create('profile', $result['friend1_username']),
      'desc'        => 
        htmlspecialchars("$result[friend1_username] ".$header_rss[15]." <a href=\"".
        $url->url_create('profile', $result['friend2_username']) .
        "\">$result[friend2_username]</a>."),
      //'category'    => NULL,
      //'pub_date'    => date('r', $result['announcement_date']),
      //'author'      => "Site Administration"
    );
  }
  
  return $channel_array;
}
/* -------------------------------- general -------------------------------- */










/* --------------------------------- album --------------------------------- */
if( in_array('album', $global_plugins) )
{
  function &rss_album($start, $where_clause, $order_clause, $limit_clause)
  {
    global $database, $url, $header_rss;
    
    
    // Construct query
    if( !$order_clause ) $order_clause = "ORDER BY se_albums.album_dateupdated DESC";
    if( $where_clause ) { $where_clause .= " AND "; } else { $where_clause = "WHERE "; }
    $where_clause .= "se_albums.album_search='1'"; 
    
    $sql = "
      SELECT
        se_albums.*,
        se_users.user_id,
        se_users.user_username,
        se_users.user_photo
      FROM
        se_albums
      LEFT JOIN
        se_media
        ON se_albums.album_id=se_media.media_album_id
      LEFT JOIN
        se_users
        ON se_albums.album_user_id=se_users.user_id
      $where_clause
      GROUP BY
        se_albums.album_id
      $order_clause
      $limit_clause
    ";
    
    
    // Generate return data
    $channel_array = array
    (
      'title'       => $header_rss[16],
      'link'        => $url->url_base,
      'desc'        => $header_rss[17],
      'image'       => $url->url_base."/images/icons/image48.gif",
      'image_link'  => $url->url_base,
      'items'       => array()
    );
    
    $resource = $database->database_query($sql) or die($database->database_error()." $sql");
    
    while( $result=$database->database_fetch_assoc($resource) )
    {
      $channel_array['items'][] = array
      (
        'title'       => ($result['album_title'] ? $result['album_title'] : $header_rss[26]),
        'link'        => $url->url_create('album', $result['user_username'], $result['album_id']),
        'desc'        => $result['album_desc'],
        'category'    => NULL,
        'pub_date'    => date('r', $result['album_datecreated']),
        'author'      => $result['user_username']
      );
    }
    
    return $channel_array;
  }







  function &rss_media($start, $where_clause, $order_clause, $limit_clause)
  {
    global $database, $url, $header_rss;
    
    
    // Construct query
    if( !$order_clause ) $order_clause = "ORDER BY se_media.media_date DESC";
    if( $where_clause ) { $where_clause .= " AND "; } else { $where_clause = "WHERE "; }
    $where_clause .= "se_albums.album_search='1'"; 
    
    $sql = "
      SELECT
        se_media.*,
        se_albums.album_id,
        se_albums.album_user_id,
        se_albums.album_title,
        se_users.user_id,
        se_users.user_username,
        se_users.user_photo
      FROM
        se_media
      LEFT JOIN
        se_albums
        ON se_albums.album_id=se_media.media_album_id
      LEFT JOIN
        se_users
        ON se_albums.album_user_id=se_users.user_id
      $where_clause
      GROUP BY
        se_media.media_id
      $order_clause
      $limit_clause
    ";
    
    
    // Generate return data
    $channel_array = array
    (
      'title'       => $header_rss[18],
      'link'        => $url->url_base,
      'desc'        => $header_rss[19],
      'image'       => $url->url_base."/images/icons/image48.gif",
      'image_link'  => $url->url_base,
      'items'       => array()
    );
    
    $resource = $database->database_query($sql) or die($database->database_error()." $sql");
    
    while( $result=$database->database_fetch_assoc($resource) )
    {
      $channel_array['items'][] = array
      (
        'title'       => ($result['media_title'] ? $result['media_title'] : $header_rss[26]),
        'link'        => $url->url_create('album_file', $result['user_username'], $result['media_album_id'], $result['media_id']),
        'desc'        => $result['media_desc'],
        'category'    => NULL,
        'pub_date'    => date('r', $result['media_date']),
        'author'      => $result['user_username']
      );
    }
    
    return $channel_array;
  }
}
/* --------------------------------- album --------------------------------- */










/* --------------------------------- blog --------------------------------- */
if( in_array('blog', $global_plugins) )
{
  function &rss_blog($start, $where_clause, $order_clause, $limit_clause)
  {
    global $database, $url, $header_rss;
    
    
    // Construct query
    if( !$order_clause ) $order_clause = "ORDER BY se_blogentries.blogentry_date DESC";
    if( $where_clause ) { $where_clause .= " AND "; } else { $where_clause = "WHERE "; }
    $where_clause .= "se_blogentries.blogentry_search='1'";
    
    $sql = "
      SELECT
        se_blogentries.*,
        se_blogentrycats.blogentrycat_title,
        se_users.user_id,
        se_users.user_username,
        se_users.user_photo
      FROM
        se_blogentries
      LEFT JOIN
        se_blogentrycats
        ON se_blogentries.blogentry_blogentrycat_id=se_blogentrycats.blogentrycat_id
      LEFT JOIN
        se_users
        ON se_blogentries.blogentry_user_id=se_users.user_id
      $where_clause
      $order_clause
      $limit_clause
    ";
    
    
    // Generate return data
    $channel_array = array
    (
      'title'       => $header_rss[20],
      'link'        => $url->url_base,
      'desc'        => $header_rss[21],
      'image'       => $url->url_base."/images/icons/blog48.gif",
      'image_link'  => $url->url_base,
      'items'       => array()
    );
    
    $resource = $database->database_query($sql) or die($database->database_error()." $sql");
    
    while( $result=$database->database_fetch_assoc($resource) )
    {
      $channel_array['items'][] = array
      (
        'title'       => ($result['blogentry_title'] ? $result['blogentry_title'] : $header_rss[26]),
        'link'        => $url->url_create('blog_entry', $blog_entry['user_username'], $result['blogentry_id']),
        'desc'        => $result['blogentry_body'],
        'category'    => $result['blogentry_blogentrycat_id'],
        'pub_date'    => date('r', $result['blogentry_date']),
        'author'      => $result['user_username']
      );
    }
    
    return $channel_array;
  }
}
/* --------------------------------- blog --------------------------------- */










/* --------------------------------- event --------------------------------- */
if( in_array('event', $global_plugins) )
{
  function &rss_event($start, $where_clause, $order_clause, $limit_clause)
  {
    global $database, $url, $header_rss;
    
    
    // Construct query
    if( !$order_clause ) $order_clause = "ORDER BY se_events.event_date_start DESC";
    //if( !$where_clause ) $where_clause = "WHERE se_events.event_date_start>'".time()."'";
    if( $where_clause ) { $where_clause .= " AND "; } else { $where_clause = "WHERE "; }
    $where_clause .= "se_events.event_search='1'";
    
    $sql = "
      SELECT
        se_events.*,
        se_users.user_id,
        se_users.user_username,
        se_users.user_photo
      FROM
        se_events
      LEFT JOIN
        se_users
        ON se_events.event_user_id=se_users.user_id
      $where_clause
      $order_clause
      $limit_clause
    ";
    
    
    // Generate return data
    $channel_array = array
    (
      'title'       => $header_rss[22],
      'link'        => $url->url_base,
      'desc'        => $header_rss[23],
      'image'       => $url->url_base."/images/icons/event22.gif",
      'image_link'  => $url->url_base,
      'items'       => array()
    );
    
    $resource = $database->database_query($sql) or die($database->database_error()." $sql");
    
    while( $result=$database->database_fetch_assoc($resource) )
    {
      $channel_array['items'][] = array
      (
        'title'       => ($result['event_title'] ? $result['event_title'] : $header_rss[26]),
        'link'        => $url->url_base."event.php?event_id=".$result['event_id'],
        'desc'        => $result['event_desc'],
        'category'    => $result['eventcat_title'],
        'pub_date'    => date('r', $result['event_date_start']),
        'author'      => $result['user_username']
      );
    }
    
    return $channel_array;
  }
}
/* --------------------------------- event --------------------------------- */










/* --------------------------------- group --------------------------------- */
if( in_array('group', $global_plugins) )
{
  function &rss_group($start, $where_clause, $order_clause, $limit_clause)
  {
    global $database, $url, $header_rss;
    
    
    // Construct query
    if( !$order_clause ) $order_clause = "ORDER BY se_groups.group_datecreated DESC";
    if( $where_clause ) { $where_clause .= " AND "; } else { $where_clause = "WHERE "; }
    $where_clause .= "se_groups.group_search='1'";
    
    $sql = "
      SELECT
        se_groups.*,
        se_users.user_id,
        se_users.user_username,
        se_users.user_photo
      FROM
        se_groups
      LEFT JOIN
        se_groupcats
        ON se_groups.group_groupcat_id=se_groupcats.groupcat_id
      LEFT JOIN
        se_users
        ON se_groups.group_user_id=se_users.user_id
      $where_clause
      $order_clause
      $limit_clause
    ";
    
    
    // Generate return data
    $channel_array = array
    (
      'title'       => $header_rss[24],
      'link'        => $url->url_base,
      'desc'        => $header_rss[25],
      'image'       => $url->url_base."/images/icons/group48.gif",
      'image_link'  => $url->url_base,
      'items'       => array()
    );
    
    $resource = $database->database_query($sql) or die($database->database_error()." $sql");
    
    while( $result=$database->database_fetch_assoc($resource) )
    {
      $channel_array['items'][] = array
      (
        'title'       => $result['group_title'],
        'link'        => $url->url_base."group.php?group_id=".$result['group_id'],
        'desc'        => $result['group_desc'],
        'category'    => $result['groupcat_title'],
        'pub_date'    => date('r', $result['group_datecreated']),
        'author'      => $result['user_username']
      );
    }
    
    return $channel_array;
  }
}
/* --------------------------------- group --------------------------------- */
