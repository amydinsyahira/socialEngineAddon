<?

/* $Id:: header_rss.php 20 2008-03-10 23:35:18Z tsumi                     $: */
// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// Must be enabled
if( !$setting['setting_rss_enabled'] ) return;

// INCLUDE RSS LANGUAGE FILE
include "./lang/lang_".$global_lang."_rss.php";


// Get the feed type
$feed_type = NULL;
$feed_owner = NULL;

// Make the feed
switch( $page )
{
  case "album":
  case "album_file":
    $feed_owner = TRUE;
    
  case "user_album":
    $feed_type = "media";
    break;
    
  case "albums":
    $feed_owner = TRUE;
    
  case "user_album_friends":
    $feed_type = "album";
    break;
    
  case "blog":
  case "blog_entry":
    $feed_owner = TRUE;
    
  case "user_blog":
    $feed_type = "blog";
    break;
    
  case "event":
    $feed_owner = TRUE;
    
  case "user_event":
    $feed_type = "event";
    break;
    
  case "group":
    $feed_owner = TRUE;
    
  case "user_group":
  case "user_group_edit":
    $feed_type = "group";
    break;
    
  case "home":
    $feed_type = "announcement";
    break;
    
  case "profile":
    $feed_type = "action";
    $feed_owner = TRUE;
    break;
    
  case "user_friends":
    $feed_type = "friend";
    $feed_owner = TRUE;
    break;
    
  case "user_home":
    $feed_type = "action";
    $feed_owner = TRUE;
    break;
}




if( isset($feed_type) )
{
  $feed_page = $page;
  if( $feed_owner ) ( $owner->user_exists ? $feed_owner=&$owner : $feed_owner=&$user );
  
  $smarty->assign_by_ref('feed_page',  $feed_page  );
  $smarty->assign_by_ref('feed_type',  $feed_type  );
  $smarty->assign_by_ref('feed_owner', $feed_owner );
}



// Turn it into a feed
if( array_key_exists('feed', $_REQUEST) && $feed_type )
{
  // Mimic query
  $_REQUEST['type']   = ( !empty($_REQUEST['feed']) ? $_REQUEST['feed'] : $feed_type );
  $_REQUEST['where']  = ( !empty($_REQUEST['user']) ? "se_users.user_username='".security($_REQUEST['user'])."'" : NULL );
  
  $page = "rss";
  include "rss.php";
  exit();
}

?>