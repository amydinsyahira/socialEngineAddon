<?php

/* $Id:: rss.php 20 2008-03-10 23:35:18Z tsumi                            $: */

// Allow for inclusion or standalone operation
if( !isset($page) )
{
  $page = 'rss';
  include "header.php";
}

include "./include/functions_rss.php";

$type     = ( isset($_REQUEST['type'])      ? $_REQUEST['type']     : NULL  );
$start    = ( isset($_REQUEST['start'])     ? $_REQUEST['start']    : NULL  );
$order    = ( isset($_REQUEST['order'])     ? $_REQUEST['order']    : NULL  );
$where    = ( isset($_REQUEST['where'])     ? $_REQUEST['where']    : NULL  );
$limit    = ( isset($_REQUEST['limit'])     ? $_REQUEST['limit']    : 20    );







// Redirect if disabled
if( !$setting['setting_rss_enabled'] ) { cheader("home.php"); exit(); }



// Create new feed
$rss_channel = generic_rss($type, $start, $where, $order, $limit);

if( isset($_REQUEST['user']) ) $rss_channel['title'] .= " ".$header_rss[4]." \"".$_REQUEST['user']."\"";



// RSS type doesn't exists 
if( !$rss_channel )
{
  // ASSIGN VARIABLES AND DISPLAY ERROR PAGE
  $page = "error";
  $smarty->assign('error_header', $header_rss[5]);
  $smarty->assign('error_message', $header_rss[6]);
  $smarty->assign('error_submit', $header_rss[7]);
  include "footer.php";
  exit();
}







$smarty->assign('channels', array(&$rss_channel));

include "footer.php";
?>