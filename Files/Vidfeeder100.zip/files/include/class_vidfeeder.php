<?php

include_once "class_radcodes.php";

class rc_vidfeeder
{
  var $entries_per_page;
  var $cache_enable;
  var $cache_timeout;
  var $main_keyword;
  var $listing_keywords;
  
  var $gdata;
  
  function rc_vidfeeder()
  {
    $this->load_settings();
  }
  
  function load_settings()
  {
    global $setting;
    
    $this->entries_per_page = $setting['setting_vidfeeder_entries_per_page'];
    $this->entries_in_tagcloud = $setting['setting_vidfeeder_entries_in_tagcloud'];
    $this->cache_enable = $setting['setting_vidfeeder_xml_cache_enable'];
    $this->cache_timeout = $setting['setting_vidfeeder_xml_cache_timeout'];      
    $this->main_keyword = $setting['setting_vidfeeder_main_keyword'];
    $this->listing_keywords = array_map('trim', explode(',',$setting['setting_vidfeeder_listing_keywords']));     
  }
  
  function clear_cache()
  {
    $dir = "../vidfeeder_cache";
    if (!$dh = @opendir($dir)) return;
    while (false !== ($obj = readdir($dh))) {
        if($obj=='.' || $obj=='..' || $obj=='index.php') continue;
        @unlink($dir.'/'.$obj);
    }

    closedir($dh);
  }
  
  function get_videos_by_keyword($keyword, $page=1)
  {
    $keyword = urlencode($keyword);
    
    if ($page < 1) $page = 1;
    
    $start_index = ($page-1) * $this->entries_per_page + 1;
    
    $url = "http://gdata.youtube.com/feeds/videos?orderby=updated&racy=exclude&&alt=atom&format=5".
          "&vq={$keyword}".
          "&start-index={$start_index}".
          "&max-results={$this->entries_per_page}";

    $data = $this->cache_enable ? $this->get_xml_response_cache($url) : file_get_contents($url);

    $xml_parser = new rc_xml_parser();
    $this->gdata = $xml_parser->get_xml_tree($data);         

    $videos = array();
    
    foreach ($this->gdata['FEED'][0]['ENTRY'] as $k=>$data) {
      $videos[] = $this->yt_fetch_video($data);
    }
    
    return $videos;
  }
  
  function get_xml_response_cache($url)
  {
    $cachefile = "./vidfeeder_cache/".md5($url).".txt";
    if (file_exists($cachefile) && ( (time()-filemtime($cachefile)) < $this->cache_timeout)) {
      $content = file_get_contents($cachefile);
    }
    else {
      $content = file_get_contents($url);
      rc_toolkit::write_to_file($cachefile,$content);
    }
    return $content;
  }
  
  
  function get_total_entries()
  {
    return (int) $this->gdata['FEED'][0]['OPENSEARCH:TOTALRESULTS'][0]['VALUE'];
  }
  
  function get_video($id)
  {
    $url = "http://gdata.youtube.com/feeds/videos/$id";
    
    $data = $this->cache_enable ? $this->get_xml_response_cache($url) : file_get_contents($url);

    $xml_parser = new rc_xml_parser();
    $this->gdata = $xml_parser->get_xml_tree($data);    

    $video = $this->yt_fetch_video($this->gdata['ENTRY'][0]);
    
    return $video;
  }
  
	function yt_fetch_video($vid)
	{
		if( ! $vid )
			return false;

		$guid = explode( "/" , $vid['ID'][0]['VALUE'] );
		$id = $guid[ count($guid) - 1 ];
		$tags = array();
		foreach( $vid['CATEGORY'] as $tag ) {
			if( ereg( "keywords" , $tag['ATTRIBUTES']['SCHEME'] ) )
				array_push( $tags , $tag['ATTRIBUTES']['TERM'] );
		}
		
		$views = $r_avg = $r_count = 0;
		
		if( isset($vid['GD:RATING']) ) {
			$r_avg = $vid['GD:RATING'][0]['ATTRIBUTES']['AVERAGE'];
			$r_count = $vid['GD:RATING'][0]['ATTRIBUTES']['NUMRATERS'];
		}
		
		if( isset($vid['YT:STATISTICS']) )
			$views = $vid['YT:STATISTICS'][0]['ATTRIBUTES']['VIEWCOUNT'];
		
		return array(
			"id" => $id,
			"author" => $vid['AUTHOR'][0]['NAME'][0]['VALUE'],
			"upload_time" => rc_toolkit::parse_rfc3339($vid['PUBLISHED'][0]['VALUE']),
			"tags" => $tags,
			"title" => $vid['TITLE'][0]['VALUE'],
			"content" => $vid['CONTENT'][0]['VALUE'],
			"description" => $vid['MEDIA:GROUP'][0]['MEDIA:DESCRIPTION'][0]['VALUE'],
			"duration" => $vid['MEDIA:GROUP'][0]['YT:DURATION'][0]['ATTRIBUTES']['SECONDS'],
			"view_count" => $views,
			"rating_avg" => $r_avg,
			"rating_count" => $r_count,
			"thumbnail_url" => $vid['MEDIA:GROUP'][0]['MEDIA:THUMBNAIL'][0]['ATTRIBUTES']['URL']
		);
	}
  
}

class rc_vidfeeder_tag extends rc_tagcloud 
{
  var $table = 'se_vidfeedertags';
  
}
