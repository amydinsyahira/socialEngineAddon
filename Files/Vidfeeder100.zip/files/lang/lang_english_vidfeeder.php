<?

// SET GENERAL VARIABLES, AVAILABLE ON EVERY PAGE
$header_vidfeeder[1] = "Video Feeder";
$header_vidfeeder[2] = "On-demand live for your social network";
$header_vidfeeder[3] = "Category";
$header_vidfeeder[4] = "Search Video";
$header_vidfeeder[5] = "Popular Tags";
$header_vidfeeder[6] = "Videos";

// ASSIGN ALL SMARTY GENERAL BLOG VARIABLES
foreach ($header_vidfeeder as $key=>$val) {
  $smarty->assign("header_vidfeeder".$key, $val);
}


// SET LANGUAGE PAGE VARIABLES
switch ($page) {

  case "vidfeeder":
	$vidfeeder[1] = "An Error Has Occurred";
	$vidfeeder[2] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$vidfeeder[3] = "Return";
    
	$vidfeeder[4] = "Search";
	$vidfeeder[5] = "Length:";
	$vidfeeder[6] = "Rating:";
	$vidfeeder[7] = "View:";
	$vidfeeder[8] = "Author:";
	$vidfeeder[9] = "Tags";
	
	$vidfeeder[10] = "Last Page";
	$vidfeeder[11] = "viewing entry";
	$vidfeeder[12] = "of";
	$vidfeeder[13] = "viewing entries";
	$vidfeeder[14] = "Next Page";	
	
	$vidfeeder[15] = "No videos found.";	
	
	break;  
  
  case "vidfeeder_view":
	$vidfeeder_view[1] = "An Error Has Occurred";
	$vidfeeder_view[2] = "You must be logged in to view this page. <a href='login.php'>Click here</a> to login.";
	$vidfeeder_view[3] = "Return";
    
	$vidfeeder_view[4] = "Search";
	$vidfeeder_view[5] = "Length:";
	$vidfeeder_view[6] = "Rating:";
	$vidfeeder_view[7] = "View:";
	$vidfeeder_view[8] = "Author:";
	$vidfeeder_view[9] = "Tags";
	$vidfeeder_view[10] = "Added On:";
	
	$vidfeeder_view[11] = "No video found.";		
	
	break;
	
  case "admin_vidfeeder":
	$admin_vidfeeder[1] = "General Video Feeder Settings";
	$admin_vidfeeder[2] = "This page contains general video feeder settings that affect your entire social network.";
	$admin_vidfeeder[3] = "Your changes have been saved.";
	$admin_vidfeeder[4] = "Save Changes";
	
	$admin_vidfeeder[5] = "Public Permission Defaults";
	$admin_vidfeeder[6] = "Select whether or not you want to let the public (visitors that are not logged-in) to view the following sections of your social network. In some cases (such as Profiles, Blogs, and Albums), if you have given them the option, your users will be able to make their pages private even though you have made them publically viewable here. For more permissions settings, please visit the <a href='admin_general.php'>General Settings</a> page.";
	$admin_vidfeeder[7] = "Yes, the public can view video feeder unless they are made private.";
	$admin_vidfeeder[8] = "No, the public cannot view video feeder.";
	
	$admin_vidfeeder[9] = "Video Listing";
	$admin_vidfeeder[10] = "Enter the main keyword for main front page.";
	$admin_vidfeeder[11] = "List all other keywords that would become categories (separated by commas). Example: Music, Movies, Extreme, Sports, Kids";
	$admin_vidfeeder[12] = "Enter the number of video entries you would like to have per page.";
	
	$admin_vidfeeder[13] = "Cache Configuration";
	$admin_vidfeeder[14] = "By default, the plugin would pull out live feed from youTube per each request. This would put alot unnecessary load on your server. Caching feeds easy the server's load. You can manually <a href='admin_vidfeeder.php?task=clearcache'>clear cache</a> without turning it off.";
	$admin_vidfeeder[15] = "Yes, turn on caching and refresh content periodic.";
	$admin_vidfeeder[16] = "No, turn off caching. (NOT RECOMMENDED)";
	$admin_vidfeeder[17] = "How often would you like to clear cache? (in seconds)";
	
	$admin_vidfeeder[18] = "Tags Cloud";
	$admin_vidfeeder[19] = "This tag cloud let you know the popularity of keywords. Everytime user click on a video tag, the system registers that. The more clicks it get, the bigger it shows in cloud.  Please note the default style for tagcloud in <a href='admin_templates_edit.php?t=styles_vidfeeder.css'>styles_vidfeeder.css</a> is for 20 entries. You can style it for any number of entries anyway you want. To reset tag cloud, please <a href='admin_vidfeeder.php?task=cleartags'>delete all tags</a>.";
	$admin_vidfeeder[20] = "tags shall be shown in tag cloud section.";
	$admin_vidfeeder[21] = "Popular tags are shown below. Click on tag to delete it from the cloud.";
	$admin_vidfeeder[22] = "Please make sure you have correctly filled out all fields.";

    break;
	
}

// ASSIGN ALL SMARTY VARIABLES
if (is_array(${"$page"})) {
  foreach (${"$page"} as $key=>$val) {
    $smarty->assign($page.$key, $val);
  }
}

