<?
$page = "vidfeeder";
include "header.php";


// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_vidfeeder] == 0) {
  $page = "error";
  $smarty->assign('error_header', $vidfeeder[1]);
  $smarty->assign('error_message', $vidfeeder[2]);
  $smarty->assign('error_submit', $vidfeeder[3]);
  include "footer.php";
}

$task = rc_toolkit::get_request('task','main');
$p = rc_toolkit::get_request('p',1);
$keyword = rc_toolkit::get_request('keyword','');
$tag = rc_toolkit::get_request('tag','');

$rc_vidfeeder = new rc_vidfeeder();
$rc_vidfeedertag = new rc_vidfeeder_tag();

$search = $rc_vidfeeder->main_keyword;
if ($keyword) $search .= " $keyword";
if ($tag) {
  $search .= " $tag";
  $rc_vidfeedertag->log_tag($tag);
}
if ($task=='search' && $keyword) {
  $rc_vidfeedertag->log_tag($keyword);
}

$videos = $rc_vidfeeder->get_videos_by_keyword($search, $p);
$total_videoentries = $rc_vidfeeder->get_total_entries();

$page_vars = make_page($total_videoentries, $rc_vidfeeder->entries_per_page, $p);


$tagclouds = $rc_vidfeedertag->get_cloud($rc_vidfeeder->entries_in_tagcloud,'name');


$smarty->assign('tag', $tag);
$smarty->assign('keyword', $keyword);
$smarty->assign('tagclouds',$tagclouds);
$smarty->assign('videos', $videos);
$smarty->assign('keywords', $rc_vidfeeder->listing_keywords);
$smarty->assign('main_keyword', $rc_vidfeeder->main_keyword);

$smarty->assign('total_videoentries', $total_videoentries);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($videos));

include "footer.php";
?>