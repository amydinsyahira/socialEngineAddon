<?
$page = "vidfeeder_view";
include "header.php";


// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_vidfeeder] == 0) {
  $page = "error";
  $smarty->assign('error_header', $vidfeeder[1]);
  $smarty->assign('error_message', $vidfeeder[2]);
  $smarty->assign('error_submit', $vidfeeder[3]);
  include "footer.php";
}


$vid = rc_toolkit::get_request('id');
$keyword = rc_toolkit::get_request('keyword','');
$tag = rc_toolkit::get_request('tag','');

$rc_vidfeeder = new rc_vidfeeder();
$video = $rc_vidfeeder->get_video($vid);


$rc_vidfeedertag = new rc_vidfeeder_tag();
$tagclouds = $rc_vidfeedertag->get_cloud($rc_vidfeeder->entries_in_tagcloud,'name');

$smarty->assign('tag', $tag);
$smarty->assign('keyword', $keyword);
$smarty->assign('tagclouds',$tagclouds);
$smarty->assign('video', $video);
$smarty->assign('keywords', $rc_vidfeeder->listing_keywords);
$smarty->assign('main_keyword', $rc_vidfeeder->main_keyword);

include "footer.php";
?>