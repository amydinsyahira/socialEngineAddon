<?

$page = "admin_vidfeeder";
include "admin_header.php";


$task = rc_toolkit::get_request('task','main');

$rc_validator = new rc_validator();
$rc_vidfeeder = new rc_vidfeeder();
$rc_vidfeedertag = new rc_vidfeeder_tag();
  
  $keys = array('setting_permission_vidfeeder',
'setting_vidfeeder_entries_per_page',
'setting_vidfeeder_entries_in_tagcloud',
'setting_vidfeeder_xml_cache_enable',
'setting_vidfeeder_xml_cache_timeout',
'setting_vidfeeder_main_keyword',
'setting_vidfeeder_listing_keywords');

if ($task == 'dosave') {
  foreach ($keys as $key) {
    $setting[$key] = $data[$key] = $_POST[$key];
    $rc_validator->is_not_trimmed_blank($data[$key],$admin_vidfeeder[22],$key);
  }

  $rc_validator->is_number($data['setting_vidfeeder_entries_per_page'],$admin_vidfeeder[22],'setting_vidfeeder_entries_per_page');
  $rc_validator->is_number($data['setting_vidfeeder_entries_in_tagcloud'],$admin_vidfeeder[22],'setting_vidfeeder_entries_in_tagcloud');
  $rc_validator->is_number($data['setting_vidfeeder_xml_cache_timeout'],$admin_vidfeeder[22],'setting_vidfeeder_xml_cache_timeout');
   
  if (!$rc_validator->has_errors()) {
    $database->database_query("UPDATE se_settings SET ".rc_toolkit::db_data_packer($data));
    $setting = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_settings LIMIT 1"));
    $result = $admin_vidfeeder[3];
  }
  else {
    $rc_validator->clear_errors();
    $rc_validator->set_error($admin_vidfeeder[22]); // use a general msg .. lazy :-)
  }
}
elseif ($task == 'clearcache') {
  $rc_vidfeeder->clear_cache();
  $result = $admin_vidfeeder[3];
}
elseif ($task == 'cleartags') {
  $rc_vidfeedertag->delete_all();
  $result = $admin_vidfeeder[3];
}
elseif ($task == 'deletetag') {
  $rc_vidfeedertag->delete_name(rc_toolkit::get_request('name'));
  $result = $admin_vidfeeder[3];
}

$tagclouds = $rc_vidfeedertag->get_cloud($rc_vidfeeder->entries_in_tagcloud,'count');

foreach ($keys as $key) {
  $smarty->assign($key, $setting[$key]);
}

$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('result', $result);
$smarty->assign('tagclouds', $tagclouds);
$smarty->display("$page.tpl");
exit();