<?

$plugin_name = "Video Feeder Plugin";
$plugin_version = 1.00;
$plugin_type = "vidfeeder";
$plugin_desc = "This plugin allows your social network to have dynamic, content rich videos on your website without leaving a finger tip. Great utility for displaying videos for your community.
It doesn&#39;t require you to upload any of the actual video content to your server. The plug in would dynamically pulls in YouTube content based on keywords you specify. 
In fact, the video content itself is automatically updated periodically per your configuration.";
$plugin_icon = "vidfeeder16.gif";
$plugin_pages_main = "Global Video Feeder Settings<!>admin_vidfeeder.php<~!~>";
$plugin_pages_level = "";
$plugin_url_htaccess = "";

if($install == "vidfeeder") {

  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
					plugin_version,
					plugin_type,
					plugin_desc,
					plugin_icon,
					plugin_pages_main,
					plugin_pages_level,
					plugin_url_htaccess
					) VALUES (
					'$plugin_name',
					'$plugin_version',
					'$plugin_type',
					'$plugin_desc',
					'$plugin_icon',
					'$plugin_pages_main',
					'$plugin_pages_level',
					'$plugin_url_htaccess')");


  //######### UPDATE PLUGIN VERSION IN se_plugins
  } else {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='$plugin_desc',
					plugin_icon='$plugin_icon',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");

  }

  //######### CREATE se_vidfeedertags
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_vidfeedertags'")) == 0) {
    $database->database_query("CREATE TABLE `se_vidfeedertags` (
      `tag_id` int(9) NOT NULL auto_increment,
      `tag_name` varchar(255) NOT NULL default '',
      `tag_count` int(11) NOT NULL default '0',
      PRIMARY KEY  (`tag_id`),
      UNIQUE KEY `nameunq` (`tag_name`)
    )");
  }  
  
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE  
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_permission_vidfeeder'")) == 0) {
    $database->database_query("ALTER TABLE se_settings 
					ADD COLUMN `setting_permission_vidfeeder` int(1) NOT NULL default '0',
					ADD COLUMN `setting_vidfeeder_entries_per_page` int(11) NOT NULL default '0',
					ADD COLUMN `setting_vidfeeder_entries_in_tagcloud` int(11) NOT NULL default '0',
					ADD COLUMN `setting_vidfeeder_xml_cache_enable` int(1) NOT NULL default '0',
					ADD COLUMN `setting_vidfeeder_xml_cache_timeout` int(11) NOT NULL default '0',
					ADD COLUMN `setting_vidfeeder_main_keyword` varchar(255) NOT NULL default '',
					ADD COLUMN `setting_vidfeeder_listing_keywords` varchar(255) NOT NULL default ''");
    $database->database_query("UPDATE se_settings SET setting_permission_vidfeeder='1', setting_vidfeeder_entries_per_page='10', setting_vidfeeder_entries_in_tagcloud='20', setting_vidfeeder_xml_cache_enable='1', setting_vidfeeder_main_keyword='Funny', setting_vidfeeder_listing_keywords='Music, Movies, Extreme, Sports, Kids', setting_vidfeeder_xml_cache_timeout='86400'");
  }

}  

?>