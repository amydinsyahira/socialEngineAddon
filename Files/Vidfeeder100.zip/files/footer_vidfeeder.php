<?

switch($page) {

  // CODE FOR PROFILE PAGE
  case "profile":

    break;

}
?>