<?


// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

include_once "./lang/lang_".$global_lang."_vidfeeder.php";
include_once "./include/class_radcodes.php";
include_once "./include/class_vidfeeder.php";
include_once "./include/functions_vidfeeder.php";

