<?php

$plugin_name = "Location Plugin";
$plugin_version = 3.03;
$plugin_type = "location";
$plugin_desc = "This plugin allows your user to have multiple location per profile. You can use this plugin for any type of location listing you like, for example: Places I have lived, Places I have traveled, Office Locations, My Interest Points etc..";
$plugin_icon = "location16.gif";
$plugin_menu_title = "11060001"; 
$plugin_pages_main = "11060002<!>location16.gif<!>admin_location.php<~!~>";
$plugin_pages_level = "11060003<!>admin_levels_locationsettings.php<~!~>";
$plugin_url_htaccess = "";

// lang var = 11060000 - 11069999


if($install == "location") {

  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
          plugin_version,
          plugin_type,
          plugin_desc,
          plugin_icon,
          plugin_menu_title,
          plugin_pages_main,
          plugin_pages_level,
          plugin_url_htaccess
          ) VALUES (
          '$plugin_name',
          '$plugin_version',
          '$plugin_type',
          '$plugin_desc',
          '$plugin_icon',
          '$plugin_menu_title',
          '$plugin_pages_main',
          '$plugin_pages_level',
          '$plugin_url_htaccess')");


  //######### UPDATE PLUGIN VERSION IN se_plugins
  } else {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='$plugin_desc',
					plugin_icon='$plugin_icon',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");

  }
  
  //######### CREATE TABLES
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'rc_locations'")) == 0) {
    $database->database_query("CREATE TABLE `rc_locations` (
    `location_id` int(9) NOT NULL auto_increment,
    `location_user_id` int(9) NOT NULL default '0',
    `location_name` varchar(128) NOT NULL default '',
    `location_address` varchar(128) NOT NULL default '',
    `location_city` varchar(128) NOT NULL default '',
    `location_region` varchar(128) NOT NULL default '',
    `location_country` varchar(128) NOT NULL default '',
    `location_notes` text NULL,
    PRIMARY KEY  (`location_id`),
    KEY `INDEX` (`location_user_id`)
    )");
  }
  
  //######### ADD COLUMNS/VALUES TO LEVELS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_levels LIKE 'level_location_allow'")) == 0) {
    $database->database_query("ALTER TABLE se_levels 
          ADD COLUMN `level_location_allow` int(1) NOT NULL default '1'");
    $database->database_query("UPDATE se_levels SET level_location_allow='1'");
  }
  
  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE  
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_settings LIKE 'setting_permission_location'")) == 0) {
    $database->database_query("ALTER TABLE se_settings 
          ADD COLUMN `setting_permission_location` int(1) NOT NULL default '0',
          ADD COLUMN `setting_location_license` varchar(255) NOT NULL default ''
          ");
    $database->database_query("UPDATE se_settings SET setting_permission_location='1', setting_location_license='XXXX-XXXX-XXXX-XXXX'");
  }   
   
  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS NOT BEEN INSTALLED)
  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11060001 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
          (11060001, 1, 'Location Plugin', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
          (11060002, 1, 'Global Location Settings', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
          (11060003, 1, 'Location Settings', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_albumsettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, ')");
  }  
  
  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS BEEN INSTALLED)
  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11060101 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES   
('11060101', 1, 'Location', ''),
('11060102', 1, 'Manage Locations', ''),
('11060103', 1, 'Some other text', ''),
('11060104', 1, 'Address:', ''),
('11060105', 1, 'City/Town:', ''),
('11060106', 1, 'State/Province:', ''),
('11060107', 1, 'Country:', ''),
('11060201', 1, 'Location Settings', ''),
('11060202', 1, 'Use this page to configure your location per level setting', ''),
('11060203', 1, 'Allow Access?', ''),
('11060204', 1, 'If you have selected YES, your users will have access to tool.', ''),
('11060205', 1, 'Yes, users can use plugin.', ''),
('11060206', 1, 'No, users cannot use plugin.', ''),
('11060207', 1, 'Save Changes', ''),
('11060208', 1, 'Your changes have been saved.', ''),
('11060209', 1, 'Editing User Level:', ''),
('11060210', 1, 'You are currently editing this user level\'s settings. Remember, these settings only apply to the users that belong to this user level. When you\'re finished, you can edit the <a href=\'admin_levels.php\'>other levels here</a>.', ''),
('11060301', 1, 'General Location Settings', ''),
('11060302', 1, 'This page contains general location settings that affect your entire social network.', ''),
('11060303', 1, 'Your changes have been saved.', ''),
('11060304', 1, 'Save Changes', ''),
('11060305', 1, 'Public Permission Defaults', ''),
('11060306', 1, 'Select whether or not you want to let the public (visitors that are not logged-in) to search or browse global location page of your social network', ''),
('11060307', 1, 'Yes, the public can access that page.', ''),
('11060308', 1, 'No, the public cannot access that page.', ''),
('11060309', 1, 'Google Map API Key', ''),
('11060310', 1, 'Please enter your Google Map API Key, if you do not have one, you can get one for free at <a href=\'http://code.google.com/apis/maps/signup.html\' target=\'_blank\'>Google Maps API</a>', ''),
('11060311', 1, 'Format: aVeryLongStringWhichProbablyMuchLongerThanThisOne', ''),
('11060312', 1, 'Please fill in all the fields.', ''),
('11060313', 1, 'Profile Field Mapping', ''),
('11060314', 1, 'Please select the field which best matches with the following fields that would use for member location.', ''),
('11060315', 1, 'Street Address', ''),
('11060316', 1, 'City/Town', ''),
('11060317', 1, 'Region/State/Province', ''),
('11060318', 1, 'Country', ''),
('11060319', 1, 'Your license key is invalid.', ''),
('11060320', 1, 'Please enter Google Map API Key.', ''),
('11060324', 1, 'Would you like to embedded mini map on user profile page? The popup vesion always available even though you disable this feature.', ''),
('11060325', 1, 'Yes, embed member location on profile page.', ''),
('11060326', 1, 'No, do not show any map on profile page.', ''),
('11060327', 1, 'Map Icon', ''),
('11060328', 1, 'If you would like to replace the default icon on Google Map, please enter full url to image icon in field below', ''),
('11060701', 1, 'Search Location', ''),
('11060702', 1, 'You can search for user\'s location records using the form below.', ''),
('11060703', 1, 'Search Criteria', ''),
('11060704', 1, 'No location matched your search criteria.', ''),
('11060706', 1, 'Name:', ''),
('11060709', 1, 'Address:', ''),
('11060710', 1, 'City/Town:', ''),
('11060711', 1, 'State/Province:', ''),
('11060712', 1, 'Country:', ''),
('11060713', 1, 'Search', ''),
('11060714', 1, 'Last Page', ''),
('11060715', 1, 'viewing result', ''),
('11060716', 1, 'viewing results', ''),
('11060717', 1, 'of', ''),
('11060718', 1, 'Next Page', ''),
('11060719', 1, 'You must be logged in to view this page. <a href=\'login.php\'>Click here</a> to login.', ''),
('11060720', 1, 'An Error Has Occurred.', ''),
('11060721', 1, 'Return', ''),
('11060801', 1, 'My Location', ''),
('11060802', 1, 'You can manage your locations using the form below.', ''),
('11060803', 1, 'Do you really want to delete this location?', ''),
('11060804', 1, 'Add New Location (name is required)', ''),
('11060805', 1, 'Delete This Location', ''),
('11060806', 1, 'Name:', ''),
('11060807', 1, 'Notes:', ''),
('11060808', 1, 'Use on map', ''),
('11060809', 1, 'Address:', ''),
('11060810', 1, 'City/Town:', ''),
('11060811', 1, 'State/Province:', ''),
('11060812', 1, 'Country:', ''),
('11060813', 1, 'Save Changes', ''),
('11060814', 1, 'Your location changes saved.', '')
      ") or die("Insert Into se_languagevars: ".mysql_error());
    
  }  
}
