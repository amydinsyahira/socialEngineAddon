<?php
// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

//include_once "../lang/lang_".$global_lang."_location.php";
include_once "../include/class_radcodes.php";
include_once "../include/class_location.php";
include_once "../include/functions_location.php";
