<?php

include_once "class_radcodes.php";

class rc_location extends rc_model 
{
  var $table = 'rc_locations';
  var $pk = 'location_id';

  function _build_get_records_query($criteria=null)
  {
    $u = new rc_user();
    
    $query = "SELECT * FROM $this->table
     JOIN $u->table ON {$u->table}.{$u->pk} = {$this->table}.location_user_id
     $criteria
    ";

    return $query;
  }
  
  function _build_count_records_query($criteria=null)
  {
    $u = new rc_user();
    
    $query = "SELECT COUNT(location_id) as total FROM $this->table
     JOIN $u->table ON {$u->table}.{$u->pk} = {$this->table}.location_user_id
     $criteria
    ";
     
    return $query;
  }
  
  
  function FindRecordsByCriteria($criteria='', $key=true)
  {
    $objs = array();
    $datas = $this->get_records($criteria, $key);
    foreach ($datas as $k => $data) {
      $obj = new $this->_class($this);
      $obj->setProperties($data);
      
      $user = new rc_user();
      $user->setProperties($data);
      $obj->rc_user = $user;
      
      $obj->build_searchable_fields();
      
      $objs[$k] = $obj;    
    }
    return $objs;
  }  
  
  function get_user_locations($uid)
  {
    return $this->FindRecordsByCriteria("WHERE location_user_id = '$uid' ORDER BY location_name DESC");
  }
  
  function build_searchable_fields()
  {
    $data = $this->extractProperties();
    foreach ($data as $field => $value) {
      if (strlen($value)) {
        $search_value = "search[$field]=".urlencode($value);
        $this->{"search_$field"} = "<a href='search_location.php?task=browse&amp;{$search_value}'>{$value}</a>";
      }
    }
  }
  
  function init_se_user()
  {
    $u = new se_user();
    $u->user_info[user_id] = $this->rc_user->user_id;
    $u->user_info[user_username] = $this->rc_user->user_username;
    $u->user_info[user_photo] = $this->rc_user->user_photo;
    $this->se_user = $u;
  }
  
  
  /*
  function insert($data)
  {
    if ($this->user_id) $data['location_user_id'] = $this->user_id;
    return rc_model::insert($data);
  }
  
  function get_user_criteria()
  {
    return ($this->user_id) ? "location_user_id = '$this->user_id'" : null;
  }
  
  function join_user_criteria($criteria)
  {
    $uc = $this->get_user_criteria();
    return ($uc) ? "$criteria AND $uc" : $criteria;
  }
  
  function get_locations($condition,$key=true)
  {
    if ($condition) $condition = " AND ".$condition;
    $criteria = "WHERE ".$this->get_user_criteria()." $condition ORDER BY location_name ASC";
    return $this->get_records($criteria, $key);
  }
  
  function get_record_by_criteria($criteria)
  {
    return rc_model::get_record_by_criteria($this->join_user_criteria($criteria));
  }  
  
  function update_by_criteria($criteria, $data)
  {
    return rc_model::update_by_criteria($this->join_user_criteria($criteria),$data);
  }  
  
  function delete_by_criteria($criteria)
  {
    return rc_model::delete_by_criteria($this->join_user_criteria($criteria));
  }
*/
}

/*
class rc_location_map extends rc_map_api 
{
  function rc_location_map($map_id = 'rc_location', $app_id = 'rc_location_app')
  {
    rc_map_api::rc_map_api($map_id, $app_id);
    $this->setAPIKey($this->setting["setting_location_api"]);
  }
}
*/