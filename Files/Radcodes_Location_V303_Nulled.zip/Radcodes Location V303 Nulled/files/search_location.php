<?
$page = "search_location";
include "header.php";

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 & $setting[setting_permission_location] == 0) {
  $page = "error";
  $smarty->assign('error_header', 11060720);
  $smarty->assign('error_message', 11060719);
  $smarty->assign('error_submit', 11060721);
  include "footer.php";
}


$task = rc_toolkit::get_request('task','browse');
$p = rc_toolkit::get_request('p',1);

$result = "";
$rc_validator = new rc_validator();
$rc_location = new rc_location();

//if($user->level_info[level_location_allow] == 0) { header("Location: user_home.php"); exit(); }

$locations_per_page = 20;

$searched_fields = rc_toolkit::get_request('search',array());

if ($task == 'search' || $task == 'browse') {
  
  $searchable_fields = array(
    'location_name',
    'location_address',
    'location_city',
    'location_region',
    'location_country',
    'location_notes'
  );
  
  $operation = strtolower(rc_toolkit::get_request('operation','and'));
  if (!in_array($operation, array('and','or'))) $operation = 'and';

  foreach ($searched_fields as $field => $value) {
    // security filter !!
    if (in_array($field, $searchable_fields)) {
      $value = mysql_real_escape_string($value);
      $search_data[$field] = " $field LIKE '%$value%' ";
      $search_query .= "search[$field]=".urlencode($value).'&';
    }
  }
  
  
  if (count($search_data)) {
    $criteria .= "WHERE " . join (" $operation ", $search_data);
  }
  
  $total_locations = $rc_location->CountByCriteria($criteria);
    
  $page_vars = make_page($total_locations, $locations_per_page, $p);

  $criteria .= " ORDER BY location_name ASC LIMIT $page_vars[0], $locations_per_page";
  $locations = $rc_location->FindRecordsByCriteria($criteria);
  foreach ($locations as $k=>$v) {
    $locations[$k]->init_se_user();
  }

}

//rc_toolkit::debug($locations);

$smarty->assign('task', $task);

$smarty->assign('search_query', $search_query);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($locations));

$smarty->assign('search', $searched_fields);
$smarty->assign('total_locations', $total_locations);

// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('locations', $locations);
$smarty->assign('rc_location', $rc_location);

$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('result', $result);

include "footer.php";
?>