<?
$page = "user_location";
include "header.php";

if($user->level_info[level_location_allow] == 0) { header("Location: user_home.php"); exit(); }


$task = rc_toolkit::get_request('task','main');
$result = "";
$rc_validator = new rc_validator();
$rc_location = new rc_location();

$keys = array(
  'location_id' => 'new',
  'location_name' => '',
  'location_address' => '',
  'location_city' => '',
  'location_region' => '',
  'location_country' => '',
  'location_notes' => ''
);

if ($task == 'dosave') {
  $locations = $_POST['locations'];
  //rc_toolkit::debug($locations);
  foreach ($locations as $eid=>$location) {

    $obj = new rc_location();
    foreach ($keys as $k => $v) {
      $obj->$k = $location[$k];
    }
    $obj->location_id = $eid;
    $obj->location_user_id = $user->user_info['user_id'];
    if (strlen($obj->location_name)==0) {
      $obj->delete($obj->location_id);
    }
    else {
      if ($obj->location_id == 'new') {
        unset($obj->location_id);
      }
      $obj->save();
    }
  }
  
  $result = 11060814;
  
}

$locations = $rc_location->get_user_locations($user->user_info['user_id']);
$locations['new'] = $keys;

$smarty->assign('locations', $locations);
$smarty->assign('rc_location', $rc_location);

$smarty->assign('is_error', $rc_validator->has_errors());
$smarty->assign('error_message', join(" ",$rc_validator->get_errors()));
$smarty->assign('result', $result);

include "footer.php";
?>