<?php
$page = "user_game";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($user->level_info[level_game_allow] == 0) { header("Location: user_home.php"); exit(); }


// CREATE GAME OBJECT
$game = new se_game($user->user_info[user_id]);


// BE SURE GAME BELONGS TO THIS USER, DELETE GAME
if($task == "delete") {
  $game_id = $_GET['game_id'];
  if($database->database_num_rows($database->database_query("SELECT game_id FROM se_games WHERE game_id='$game_id' AND game_user_id='".$user->user_info[user_id]."'")) == 1) { 
    $game->game_delete($game_id);    
  }



// MOVE GAME UP
} elseif($task == "moveup") {
  $game_id = $_GET['game_id'];

  $game_query = $database->database_query("SELECT game_id, game_order FROM se_games WHERE game_id='$game_id' AND game_user_id='".$user->user_info[user_id]."'");
  if($database->database_num_rows($game_query) == 1) { 

    $game_info = $database->database_fetch_assoc($game_query);

    $prev_query = $database->database_query("SELECT game_id, game_order FROM se_games WHERE game_user_id='".$user->user_info[user_id]."' AND game_order<$game_info[game_order] ORDER BY game_order DESC LIMIT 1");
    if($database->database_num_rows($prev_query) == 1) {

      $prev_info = $database->database_fetch_assoc($prev_query);

      // SWITCH ORDER
      $database->database_query("UPDATE se_games SET game_order=$prev_info[game_order] WHERE game_id=$game_info[game_id]");
      $database->database_query("UPDATE se_games SET game_order=$game_info[game_order] WHERE game_id=$prev_info[game_id]");

      // SEND AJAX CONFIRMATION
      echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type='text/javascript'>";
      echo "window.parent.reordergame('$game_info[game_id]', '$prev_info[game_id]');";
      echo "</script></head><body></body></html>";
      exit();

    } 
  }
}


// GET GAMES
$total_games = $game->game_total();
$game_array = $game->game_list(0, $total_games, "game_order ASC");

$space_used = $game->game_space();
$total_files = $game->game_files();

// CALCULATE SPACE FREE, CONVERT TO MEGABYTES
if($user->level_info[level_game_storage]) {
  $space_free = $user->level_info[level_game_storage] - $space_used;
} else {
  $space_free = ( $dfs=disk_free_space("/") ? $dfs : pow(2, 32) );
} 
$space_free = ($space_free / 1024) / 1024;
$space_free = round($space_free, 2);


// ASSIGN VARIABLES AND SHOW VIEW GAMES PAGE
$smarty->assign('space_free', $space_free);
$smarty->assign('total_files', $total_files);
$smarty->assign('games_total', $total_games);
$smarty->assign('games', $game_array);
include "footer.php";
?>