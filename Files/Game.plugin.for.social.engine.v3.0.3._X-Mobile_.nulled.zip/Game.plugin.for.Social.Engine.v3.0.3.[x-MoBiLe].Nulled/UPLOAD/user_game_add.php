<?php
$page = "user_game_add";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($user->level_info[level_game_allow] == 0) { header("Location: user_home.php"); exit(); }

// CHECK THAT MAX GAMES HAVEN'T BEEN REACHED
$game = new se_game($user->user_info[user_id]);
$total_games = $game->game_total();
if($total_games >= $user->level_info[level_game_maxnum]) { $task = "main"; }

// GET PRIVACY SETTINGS
$level_game_privacy = unserialize($user->level_info[level_game_privacy]);
rsort($level_game_privacy);
$level_game_comments = unserialize($user->level_info[level_game_comments]);
rsort($level_game_comments);
$level_game_tag = unserialize($user->level_info[level_game_tag]);
rsort($level_game_tag);

// SET VARS
$is_error = 0;
$game_title = "";
$game_desc = "";
$game_search = 1;
$game_privacy = $level_game_privacy[0];
$game_comments = $level_game_comments[0];
$game_tag = $level_game_tag[0];


if($task == "doadd") {

  $game_title = censor($_POST['game_title']);
  $game_desc = censor(str_replace("\r\n", "<br>", $_POST['game_desc']));
  $game_search = $_POST['game_search'];
  $game_privacy = $_POST['game_privacy'];
  $game_comments = $_POST['game_comments'];
  $game_tag = $_POST['game_tag'];
  $game_datecreated = time();

  // MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
  if(!in_array($game_privacy, $level_game_privacy)) { $game_privacy = $level_game_privacy[0]; }
  if(!in_array($game_comments, $level_game_comments)) { $game_comments = $level_game_comments[0]; }
  if(!in_array($game_tag, $level_game_tag)) { $game_tag = $level_game_tag[0]; }

  // CHECK THAT TITLE IS NOT BLANK
  if(trim($game_title) == "") { $is_error = 11000073; }

  // IF NO ERROR, CONTINUE
  if($is_error == 0) {

    // GET MAX ORDER
    $max = $database->database_fetch_assoc($database->database_query("SELECT max(game_order) AS max FROM se_games WHERE game_user_id='".$user->user_info[user_id]."'"));
    $game_order = $max[max]+1;

    // INSERT NEW GAME INTO DATABASE
    $database->database_query("INSERT INTO se_games (
				game_user_id,
				game_datecreated,
				game_dateupdated,
				game_title, 
				game_desc, 
				game_search,
				game_privacy,
				game_comments,
				game_tag,
				game_order
				) VALUES (
				'".$user->user_info[user_id]."',
				'$game_datecreated',
				'$game_datecreated',
				'$game_title',
				'$game_desc',
				'$game_search',
				'$game_privacy',
				'$game_comments',
				'$game_tag',
				'$game_order')
				");

    // GET GAME ID
    $game_id = $database->database_insert_id();

    // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
    $user->user_lastupdate();

    // INSERT ACTION
    if(strlen($game_title) > 100) { $game_title = substr($game_title, 0, 97); $game_title .= "..."; }
    $actions->actions_add($user, "newgame", Array($user->user_info[user_username], $user->user_displayname, $game_id, $game_title), Array(), 0, FALSE, "user", $user->user_info[user_id], $game_privacy);

    // CALL GAME CREATION HOOK
    ($hook = SE_Hook::exists('se_game_create')) ? SE_Hook::call($hook, array()) : NULL;

    // SEND TO UPLOAD PAGE
    header("Location: user_game_upload.php?game_id=$game_id&new_game=1");
    exit();
  }
}





// GET PREVIOUS PRIVACY SETTINGS
for($c=0;$c<count($level_game_privacy);$c++) {
  if(user_privacy_levels($level_game_privacy[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_privacy[$c]));
    $privacy_options[$level_game_privacy[$c]] = user_privacy_levels($level_game_privacy[$c]);
  }
}

for($c=0;$c<count($level_game_comments);$c++) {
  if(user_privacy_levels($level_game_comments[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_comments[$c]));
    $comment_options[$level_game_comments[$c]] = user_privacy_levels($level_game_comments[$c]);
  }
}

for($c=0;$c<count($level_game_tag);$c++) {
  if(user_privacy_levels($level_game_tag[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_tag[$c]));
    $tag_options[$level_game_tag[$c]] = user_privacy_levels($level_game_tag[$c]);
  }
}



// ASSIGN VARIABLES AND SHOW ADD GAME PAGE
$smarty->assign('is_error', $is_error);
$smarty->assign('total_games', $total_games);
$smarty->assign('game_title', $game_title);
$smarty->assign('game_desc', str_replace("<br>", "\r\n", $game_desc));
$smarty->assign('game_search', $game_search);
$smarty->assign('game_privacy', $game_privacy);
$smarty->assign('game_comments', $game_comments);
$smarty->assign('game_tag', $game_tag);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
$smarty->assign('tag_options', $tag_options);
include "footer.php";
?>