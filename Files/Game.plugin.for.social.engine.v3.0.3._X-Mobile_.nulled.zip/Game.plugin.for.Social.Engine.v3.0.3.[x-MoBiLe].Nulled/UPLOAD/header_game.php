<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE GAME CLASS FILE
include "./include/class_game.php";

// INCLUDE GAME FUNCTION FILE
include "./include/functions_game.php";


// PRELOAD LANGUAGE
SE_Language::_preload_multi(11000007, 11000123, 11000137);

// SET MAIN MENU VARS
$plugin_vars[menu_main] = Array('file' => 'browse_games.php', 'title' => 11000123);

// SET USER MENU VARS
if($user->level_info[level_game_allow] == 1) {
  $plugin_vars[menu_user] = Array('file' => 'user_game.php', 'icon' => 'game_game16.gif', 'title' => 11000007);
}

// SET PROFILE MENU VARS
if($owner->level_info[level_game_allow] == 1 && $page == "profile") {

  // START GAME
  $game = new se_game($owner->user_info[user_id]);
  $sort = "game_id DESC";

  // GET PRIVACY LEVEL AND SET WHERE
  $game_privacy_max = $owner->user_privacy_max($user);
  $where = "(game_privacy & $game_privacy_max)";

  // GET TOTAL GAMES
  $total_games = $game->game_total($where);

  // GET GAME ARRAY
  $games = $game->game_list(0, $total_games, $sort, $where);

  // ASSIGN GAMES SMARY VARIABLE
  $smarty->assign('games', $games);
  $smarty->assign('total_games', $total_games);

  // SET PROFILE MENU VARS
  if($total_games != 0) {

    // DETERMINE WHERE TO SHOW GAMES
    $level_game_profile = explode(",", $owner->level_info[level_game_profile]);
    if(!in_array($owner->user_info[user_profile_game], $level_game_profile)) { $user_profile_game = $level_game_profile[0]; } else { $user_profile_game = $owner->user_info[user_profile_game]; }

    // SHOW GAME IN APPROPRIATE LOCATION
    if($user_profile_game == "tab") {
      $plugin_vars[menu_profile_tab] = Array('file'=> 'profile_game_tab.tpl', 'title' => 11000007);
    } else {
      $plugin_vars[menu_profile_side] = Array('file'=> 'profile_game_side.tpl', 'title' => 11000007);
    }
  }

  // CHECK TO SEE IF USER HAS BEEN TAGGED IN ANY PHOTOS
  $tagged = $database->database_num_rows($database->database_query("SELECT game_mediatag_id FROM se_game_mediatags WHERE game_mediatag_user_id={$owner->user_info[user_id]} GROUP BY game_mediatag_game_media_id"));
  if($tagged > 0) {
    $plugin_vars[menu_profile_menu] = Array('file' => "game.php?user=".$owner->user_info[user_username], 'icon' => 'game_game16.gif', 'title' => 11000137, 'title_1' => $owner->user_displayname_short, 'title_2' => $tagged);
  }

}


// SET SEARCH HOOK
if($page == "search") {
  SE_Hook::register("se_search_do", search_game);
}


// SET USER DELETION HOOK
SE_Hook::register("se_user_delete", deleteuser_game);

?>