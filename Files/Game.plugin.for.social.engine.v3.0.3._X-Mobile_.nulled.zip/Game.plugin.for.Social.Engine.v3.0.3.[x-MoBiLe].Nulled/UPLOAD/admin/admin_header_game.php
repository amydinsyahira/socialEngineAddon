<?php

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE GAME CLASS FILE
include "../include/class_game.php";

// INCLUDE GAME FUNCTION FILE
include "../include/functions_game.php";


// SET USER DELETION HOOK
SE_Hook::register("se_user_delete", deleteuser_game);

?>