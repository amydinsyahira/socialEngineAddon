<?

$plugin_name = "GAME Plugin";
$plugin_version = "3.02beta";
$plugin_type = "game";
$plugin_desc = "This plugin gives your users their own personal Game games. These games can be configured to store Games, videos, or any other file types you choose to allow. Users can interact by commenting on each others Games and viewing their friends' recent updates.";
$plugin_icon = "game_game16.gif";
$plugin_menu_title = "11000003";	
$plugin_pages_main = "11000004<!>game_game16.gif<!>admin_viewgames.php<~!~>11000005<!>game_settings16.gif<!>admin_game.php<~!~>";
$plugin_pages_level = "11000006<!>admin_levels_gamesettings.php<~!~>";
$plugin_url_htaccess = "RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/games/([0-9]+)/([0-9]+)/?$ \$server_info/game_file.php?user=\$1&game_id=\$2&game_media_id=\$3 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/games/([0-9]+)/?$ \$server_info/game.php?user=\$1&game_id=\$2 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/games/([0-9]+)/([^/]+)?$ \$server_info/game.php?user=\$1&game_id=\$2\$3 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^/]+)/games/?$ \$server_info/games.php?user=\$1 [L]";




if($install == "game") {


  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
					plugin_version,
					plugin_type,
					plugin_desc,
					plugin_icon,
					plugin_menu_title,
					plugin_pages_main,
					plugin_pages_level,
					plugin_url_htaccess
					) VALUES (
					'$plugin_name',
					'$plugin_version',
					'$plugin_type',
					'".str_replace("'", "\'", $plugin_desc)."',
					'$plugin_icon',
					'$plugin_menu_title',
					'$plugin_pages_main',
					'$plugin_pages_level',
					'$plugin_url_htaccess')");


  //######### UPDATE PLUGIN VERSION IN se_plugins
  } else {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
					plugin_icon='$plugin_icon',
					plugin_menu_title='$plugin_menu_title',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");

  }



  //######### CREATE se_games
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_games'")) == 0) {
    $database->database_query("CREATE TABLE `se_games` (
      `game_id` int(9) NOT NULL auto_increment,
      `game_user_id` int(9) NOT NULL default '0',
      `game_datecreated` int(14) NOT NULL default '0',
      `game_dateupdated` int(14) NOT NULL default '0',
      `game_title` varchar(50) NOT NULL default '',
      `game_desc` text NULL,
      `game_search` int(1) NOT NULL default '0',
      `game_privacy` int(2) NOT NULL default '0',
      `game_comments` int(2) NOT NULL default '0',
      `game_cover` int(9) NOT NULL default '0',
      `game_views` int(9) NOT NULL default '0',
      PRIMARY KEY  (`game_id`),
      KEY `INDEX` (`game_user_id`)
    ) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
  }


  //######### ALTER se_games ADD ORDER COLUMN
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_games` LIKE 'game_order'")) == 0) {
    $database->database_query("ALTER TABLE se_games 
					ADD COLUMN `game_order` int(1) NOT NULL default '0',
					ADD COLUMN `game_tag` int(2) NOT NULL default '0'");
    $database->database_query("UPDATE se_games SET game_order=game_id, game_tag=3");
  }


  //######### CREATE se_game_media
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_game_media'")) == 0) {
    $database->database_query("CREATE TABLE `se_game_media` (
      `game_media_id` int(9) NOT NULL auto_increment,
      `game_media_game_id` int(9) NOT NULL default '0',
      `game_media_date` int(14) NOT NULL default '0',
      `game_media_title` varchar(50) NOT NULL default '',
      `game_media_desc` text NULL,
      `game_media_ext` varchar(8) NOT NULL default '',
      `game_media_filesize` int(9) NOT NULL default '0',
      PRIMARY KEY  (`game_media_id`),
      KEY `INDEX` (`game_media_game_id`)
    ) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
  }

  //######### ALTER se_game_media ADD ORDER COLUMN
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_game_media` LIKE 'game_media_order'")) == 0) {
    $database->database_query("ALTER TABLE se_game_media 
					ADD COLUMN `game_media_order` int(1) NOT NULL default '0'");
    $database->database_query("UPDATE se_game_media SET game_media_order=game_media_id");
  }


  //######### CREATE se_game_mediacomments
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_game_mediacomments'")) == 0) {
    $database->database_query("CREATE TABLE `se_game_mediacomments` (
      `game_mediacomment_id` int(9) NOT NULL auto_increment,
      `game_mediacomment_game_media_id` int(9) NOT NULL default '0',
      `game_mediacomment_authoruser_id` int(9) NOT NULL default '0',
      `game_mediacomment_date` int(14) NOT NULL default '0',
      `game_mediacomment_body` text NULL,
      PRIMARY KEY  (`game_mediacomment_id`),
      KEY `INDEX` (`game_mediacomment_game_media_id`,`game_mediacomment_authoruser_id`)
    ) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
  }


  //######### CREATE se_game_mediatags
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_game_mediatags'")) == 0) {
    $database->database_query("CREATE TABLE IF NOT EXISTS `se_game_mediatags` (
	`game_mediatag_id` int(9) NOT NULL auto_increment,
	`game_mediatag_game_media_id` int(9) NOT NULL default '0',
	`game_mediatag_user_id` int(9) NOT NULL default '0',
	`game_mediatag_x` int(9) NOT NULL default '0',
	`game_mediatag_y` int(9) NOT NULL default '0',
	`game_mediatag_height` int(9) NOT NULL default '0',
	`game_mediatag_width` int(9) NOT NULL default '0',
	`game_mediatag_text` varchar(255) NOT NULL default '',
	PRIMARY KEY  (`game_mediatag_id`),
	KEY `INDEX` (`game_mediatag_game_media_id`,`game_mediatag_user_id`)
      ) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
  }


  //######### CREATE se_gamestyles
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_gamestyles'")) == 0) {
    $database->database_query("CREATE TABLE `se_gamestyles` (
    `gamestyle_id` int(9) NOT NULL auto_increment,
    `gamestyle_user_id` int(9) NOT NULL default '0',
    `gamestyle_css` text NULL,
    PRIMARY KEY  (`gamestyle_id`),
    KEY `INDEX` (`gamestyle_user_id`)
    ) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_unicode_ci");
  }

  //######### INSERT se_urls
  if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file='games'")) == 0) {
    $database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Game List URL', 'games', 'games.php?user=\$user', '\$user/games/')");
  }
  if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file='game'")) == 0) {
    $database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('Game URL', 'game', 'game.php?user=\$user&game_id=\$id1', '\$user/games/\$id1')");
  }
  if($database->database_num_rows($database->database_query("SELECT url_id FROM se_urls WHERE url_file='game_file'")) == 0) {
    $database->database_query("INSERT INTO se_urls (url_title, url_file, url_regular, url_subdirectory) VALUES ('GAME URL', 'game_file', 'game_file.php?user=\$user&game_id=\$id1&game_media_id=\$id2', '\$user/games/\$id1/\$id2')");
  }


  //######### INSERT se_actiontypes
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newgame'")) == 0) {
    $actiontype_desc = SE_Language::edit(0, 'Creating an Game', NULL, LANGUAGE_INDEX_ACTIONS);
    $actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> created a new game: <a href="game.php?user=%1$s&game_id=%3$s">%4$s</a>', NULL, LANGUAGE_INDEX_ACTIONS);
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('newgame', 'game_action_newgame.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname],[id],[title]', '0')");
    $actiontypes[] = $database->database_insert_id();
  }
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newgame_media'")) == 0) {
    $actiontype_desc = SE_Language::edit(0, 'Uploading Games to an Game', NULL, LANGUAGE_INDEX_ACTIONS);
    $actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> uploaded new Games to their game: <a href="game.php?user=%1$s&game_id=%3$s">%4$s</a><div class="recentaction_div_game_media">[game_media]</div>', NULL, LANGUAGE_INDEX_ACTIONS);
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('newgame_media', 'game_action_newgame_media.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname],[id],[title]', '1')");
    $actiontypes[] = $database->database_insert_id();
  }
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='game_mediacomment'")) == 0) {
    $actiontype_desc = SE_Language::edit(0, 'Posting a Game Comment', NULL, LANGUAGE_INDEX_ACTIONS);
    $actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> posted a comment on <a href="profile.php?user=%3$s">%4$s</a>\'s <a href="game_file.php?user=%3$s&game_media_id=%6$s">Game</a>:<div class="recentaction_div">%5$s</div>', NULL, LANGUAGE_INDEX_ACTIONS);
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('game_mediacomment', 'action_postcomment.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username1],[displayname1],[username2],[displayname2],[comment],[game_mediaid]', '0')");
    $actiontypes[] = $database->database_insert_id();
  }
  if($database->database_num_rows($database->database_query("SELECT actiontype_id FROM se_actiontypes WHERE actiontype_name='newtag'")) == 0) {
    $actiontype_desc = SE_Language::edit(0, 'Getting Tagged in a Game', NULL, LANGUAGE_INDEX_ACTIONS);
    $actiontype_text = SE_Language::edit(0, '<a href="profile.php?user=%1$s">%2$s</a> was tagged in these Games:<div class="recentaction_div_game_media">[game_media]</div>', NULL, LANGUAGE_INDEX_ACTIONS);
    $database->database_query("INSERT INTO se_actiontypes (actiontype_name, actiontype_icon, actiontype_setting, actiontype_enabled, actiontype_desc, actiontype_text, actiontype_vars, actiontype_media) VALUES ('newtag', 'game_action_newtag.gif', '1', '1', '$actiontype_desc', '$actiontype_text', '[username],[displayname]', '1')");
    $actiontypes[] = $database->database_insert_id();
  }
  if(count($actiontypes) != 0) {
    $database->database_query("UPDATE se_usersettings SET usersetting_actions_display = CONCAT(usersetting_actions_display, ',', '".implode(",", $actiontypes)."')");
  }


  //######### INSERT se_notifytypes
  if($database->database_num_rows($database->database_query("SELECT notifytype_id FROM se_notifytypes WHERE notifytype_name='game_mediacomment'")) == 0) {
    $notifytype_desc = SE_Language::edit(0, '%1$d New Game Comment(s): %2$s', NULL, LANGUAGE_INDEX_NOTIFY);
    $notifytype_title = SE_Language::edit(0, 'When I receive a new Game comment.', NULL, LANGUAGE_INDEX_NOTIFY);
    $database->database_query("INSERT INTO se_notifytypes (notifytype_name, notifytype_title, notifytype_icon, notifytype_url, notifytype_desc) VALUES ('game_mediacomment', '$notifytype_title', 'action_postcomment.gif', 'game_file.php?user=%1\$s&game_media_id=%2\$s', '$notifytype_desc')");
  }
  if($database->database_num_rows($database->database_query("SELECT notifytype_id FROM se_notifytypes WHERE notifytype_name='newtag'")) == 0) {
    $notifytype_desc = SE_Language::edit(0, '%1$d New Game(s) Tagged of You: %2$s', NULL, LANGUAGE_INDEX_NOTIFY);
    $notifytype_title = SE_Language::edit(0, 'When I am tagged in a Game.', NULL, LANGUAGE_INDEX_NOTIFY);
    $database->database_query("INSERT INTO se_notifytypes (notifytype_name, notifytype_title, notifytype_icon, notifytype_url, notifytype_desc) VALUES ('newtag', '$notifytype_title', 'game_action_newtag.gif', 'game_file.php?user=%1\$s&game_id=0&game_media_id=%2\$s', '$notifytype_desc')");
  }
  if($database->database_num_rows($database->database_query("SELECT notifytype_id FROM se_notifytypes WHERE notifytype_name='game_mediatag'")) == 0) {
    $notifytype_desc = SE_Language::edit(0, '%1$d New Tag(s) on Your Game: %2$s', NULL, LANGUAGE_INDEX_NOTIFY);
    $notifytype_title = SE_Language::edit(0, 'When someone tags a Game I own.', NULL, LANGUAGE_INDEX_NOTIFY);
    $database->database_query("INSERT INTO se_notifytypes (notifytype_name, notifytype_title, notifytype_icon, notifytype_url, notifytype_desc) VALUES ('game_mediatag', '$notifytype_title', 'game_action_newtag.gif', 'game_file.php?user=%1\$s&game_media_id=%2\$s', '$notifytype_desc')");
  }


  //######### ADD COLUMNS/VALUES TO LEVELS TABLE IF GAME HAS NEVER BEEN INSTALLED
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_game_allow'")) == 0) {
    $database->database_query("ALTER TABLE se_levels 
					ADD COLUMN `level_game_allow` int(1) NOT NULL default '1',
					ADD COLUMN `level_game_maxnum` int(3) NOT NULL default '10',
					ADD COLUMN `level_game_exts` text NOT NULL,
					ADD COLUMN `level_game_mimes` text NOT NULL,
					ADD COLUMN `level_game_storage` bigint(11) NOT NULL default '5242880',
					ADD COLUMN `level_game_maxsize` bigint(11) NOT NULL default '2048000',
					ADD COLUMN `level_game_width` varchar(4) NOT NULL default '500',
					ADD COLUMN `level_game_height` varchar(4) NOT NULL default '500',
					ADD COLUMN `level_game_style` int(1) NOT NULL default '1',
					ADD COLUMN `level_game_search` int(1) NOT NULL default '1',
					ADD COLUMN `level_game_privacy` varchar(100) NOT NULL default 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"3\";i:2;s:1:\"7\";i:3;s:2:\"15\";i:4;s:2:\"31\";i:5;s:2:\"63\";}',
					ADD COLUMN `level_game_comments` varchar(100) NOT NULL default 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
    $database->database_query("UPDATE se_levels SET level_game_exts='jpg,gif,jpeg,png,bmp,mp3,mpeg,avi,mpa,mov,qt,swf', level_game_mimes='image/jpeg,image/pjpeg,image/jpg,image/jpe,image/pjpg,image/x-jpeg,image/x-jpg,image/gif,image/x-gif,image/png,image/x-png,image/bmp,audio/mpeg,video/mpeg,video/x-msvideo,video/avi,video/quicktime,application/x-shockwave-flash'");

  } else {
    $columns = mysql_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_game_privacy'");
    while($column_info = mysql_fetch_assoc($columns)) {
      $field_name = $column_info['Field'];
      $field_type = $column_info['Type'];
      $field_default = $column_info['Default'];
      if($field_type == "varchar(10)") {
        mysql_query("ALTER TABLE se_levels CHANGE level_game_privacy level_game_privacy varchar(100) NOT NULL default ''");
        mysql_query("UPDATE se_levels SET level_game_privacy='a:6:{i:0;s:1:\"1\";i:1;s:1:\"3\";i:2;s:1:\"7\";i:3;s:2:\"15\";i:4;s:2:\"31\";i:5;s:2:\"63\";}'");
        mysql_query("UPDATE se_games SET game_privacy='63' WHERE game_privacy='0'");
        mysql_query("UPDATE se_games SET game_privacy='31' WHERE game_privacy='1'");
        mysql_query("UPDATE se_games SET game_privacy='15' WHERE game_privacy='2'");
        mysql_query("UPDATE se_games SET game_privacy='7' WHERE game_privacy='3'");
        mysql_query("UPDATE se_games SET game_privacy='3' WHERE game_privacy='4'");
        mysql_query("UPDATE se_games SET game_privacy='1' WHERE game_privacy='5'");
      }
    }
    $columns = mysql_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_game_comments'");
    while($column_info = mysql_fetch_assoc($columns)) {
      $field_name = $column_info['Field'];
      $field_type = $column_info['Type'];
      $field_default = $column_info['Default'];
      if($field_type == "varchar(10)") {
        mysql_query("ALTER TABLE se_levels CHANGE level_game_comments level_game_comments varchar(100) NOT NULL default ''");
        mysql_query("UPDATE se_levels SET level_game_comments='a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
        mysql_query("UPDATE se_games SET game_comments='63' WHERE game_comments='0'");
        mysql_query("UPDATE se_games SET game_comments='31' WHERE game_comments='1'");
        mysql_query("UPDATE se_games SET game_comments='15' WHERE game_comments='2'");
        mysql_query("UPDATE se_games SET game_comments='7' WHERE game_comments='3'");
        mysql_query("UPDATE se_games SET game_comments='3' WHERE game_comments='4'");
        mysql_query("UPDATE se_games SET game_comments='1' WHERE game_comments='5'");
      }
    }
  }

  //######### ADD COLUMNS/VALUES TO LEVELS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_levels` LIKE 'level_game_profile'")) == 0) {
    $database->database_query("ALTER TABLE se_levels 
					ADD COLUMN `level_game_profile` SET('side', 'tab'),
					ADD COLUMN `level_game_tag` varchar(100) NOT NULL default 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
    $database->database_query("UPDATE se_levels SET level_game_profile='tab', level_game_tag='a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"3\";i:3;s:1:\"7\";i:4;s:2:\"15\";i:5;s:2:\"31\";i:6;s:2:\"63\";}'");
  }


  //######### ADD COLUMNS/VALUES TO SETTINGS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_settings` LIKE 'setting_permission_game'")) == 0) {
    $database->database_query("ALTER TABLE se_settings 
					ADD COLUMN `setting_permission_game` int(1) NOT NULL default '1'");
  }

  //######### ADD COLUMNS/VALUES TO SYSTEM EMAILS TABLE
  if($database->database_num_rows($database->database_query("SELECT systememail_id FROM se_systememails WHERE systememail_name='game_mediacomment'")) == 0) {
    $systememail_subject = SE_Language::edit(0, 'New Media Comment', NULL, LANGUAGE_INDEX_EMAILS);
    $systememail_body = SE_Language::edit(0, 'Hello %1$s,\n\nA new comment has been posted on one of your Games by %2$s. Please click the following link to view it:\n\n%3$s\n\nBest Regards,\nSocial Network Administration', NULL, LANGUAGE_INDEX_EMAILS);
    $database->database_query("INSERT INTO se_systememails (systememail_name, systememail_title, systememail_desc, systememail_subject, systememail_body, systememail_vars) VALUES ('game_mediacomment', '11000001', '11000002', '$systememail_subject', '$systememail_body', '[displayname],[commenter],[link]')");
  }
  if($database->database_num_rows($database->database_query("SELECT systememail_id FROM se_systememails WHERE systememail_name='newtag'")) == 0) {
    $systememail_subject = SE_Language::edit(0, 'You have Been Tagged in a Game!', NULL, LANGUAGE_INDEX_EMAILS);
    $systememail_body = SE_Language::edit(0, 'Hello %1$s,\n\nYou have been tagged in a Game. Please click the following link to view it:\n\n%2$s\n\nBest Regards,\nSocial Network Administration', NULL, LANGUAGE_INDEX_EMAILS);
    $database->database_query("INSERT INTO se_systememails (systememail_name, systememail_title, systememail_desc, systememail_subject, systememail_body, systememail_vars) VALUES ('newtag', '11000151', '11000152', '$systememail_subject', '$systememail_body', '[displayname],[link]')");
  }
  if($database->database_num_rows($database->database_query("SELECT systememail_id FROM se_systememails WHERE systememail_name='game_mediatag'")) == 0) {
    $systememail_subject = SE_Language::edit(0, 'New Game Tag', NULL, LANGUAGE_INDEX_EMAILS);
    $systememail_body = SE_Language::edit(0, 'Hello %1$s,\n\nA new tag has been posted on one of your Games by %2$s. Please click the following link to view it:\n\n%3$s\n\nBest Regards,\nSocial Network Administration', NULL, LANGUAGE_INDEX_EMAILS);
    $database->database_query("INSERT INTO se_systememails (systememail_name, systememail_title, systememail_desc, systememail_subject, systememail_body, systememail_vars) VALUES ('game_mediatag', '11000153', '11000154', '$systememail_subject', '$systememail_body', '[displayname],[tagger],[link]')");
  }


  //######### ADD COLUMNS/VALUES TO USER SETTINGS TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_usersettings` LIKE 'usersetting_notify_game_mediacomment'")) == 0) {
    $database->database_query("ALTER TABLE se_usersettings 
					ADD COLUMN `usersetting_notify_game_mediacomment` int(1) NOT NULL default '1'");
  }
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_usersettings` LIKE 'usersetting_notify_newtag'")) == 0) {
    $database->database_query("ALTER TABLE se_usersettings 
					ADD COLUMN `usersetting_notify_newtag` int(1) NOT NULL default '1',
					ADD COLUMN `usersetting_notify_game_mediatag` int(1) NOT NULL default '1'");
  }

  //######### ADD COLUMNS/VALUES TO USER TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM `$database_name`.`se_users` LIKE 'user_profile_game'")) == 0) {
    $database->database_query("ALTER TABLE se_users 
					ADD COLUMN `user_profile_game` ENUM('tab', 'side') NOT NULL default 'tab'");
  }


  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS NOT BEEN INSTALLED)
  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11000001 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
					(11000001, 1, 'New GAME MEDIA Comment Email', ''),
					(11000002, 1, 'This is the email that gets sent to a user when a new comment is posted on one of their Games.', ''),
					(11000003, 1, 'Game Plugin Settings', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_gamesettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
					(11000004, 1, 'View Game Games', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_gamesettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
					(11000005, 1, 'Global Game Settings', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_gamesettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
					(11000006, 1, 'Game Settings', 'admin_viewusers_edit, admin_viewusers, admin_viewreports, admin_viewplugins, admin_viewadmins, admin_url, admin_templates, admin_subnetworks, admin_stats, admin_signup, admin_profile, admin_lostpass_reset, admin_lostpass, admin_login, admin_log, admin_levels_usersettings, admin_levels_messagesettings, admin_levels_edit, admin_levels_gamesettings, admin_levels, admin_language_edit, admin_language, admin_invite, admin_home, admin_general, admin_fields, admin_faq, admin_emails, admin_connections, admin_banning, admin_announcements, admin_ads_modify, admin_ads, admin_activity, '),
					(11000007, 1, 'Games', 'header, ')");

  }

  //######### INSERT LANGUAGE VARS (v3 COMPATIBLE HAS BEEN INSTALLED)
  if($database->database_num_rows($database->database_query("SELECT languagevar_id FROM se_languagevars WHERE languagevar_id=11000008 LIMIT 1")) == 0) {
    $database->database_query("INSERT INTO `se_languagevars` (`languagevar_id`, `languagevar_language_id`, `languagevar_value`, `languagevar_default`) VALUES 
					(11000008, 1, 'This page contains general game settings that affect your entire social network.', ''),
					(11000009, 1, 'Select whether or not you want to let the public (visitors that are not logged-in) to view the following sections of your social network. In some cases (such as Profiles, Blogs, and Games), if you have given them the option, your users will be able to make their pages private even though you have made them publically viewable here. For more permissions settings, please visit the <a href=\'admin_general.php\'>General Settings</a> page.', ''),
					(11000010, 1, 'Yes, the public can view games unless they are made private.', ''),
					(11000011, 1, 'No, the public cannot view games.', ''),
					(11000012, 1, 'Your maximum filesize field must contain an integer between 1 and 204800.', ''),
					(11000013, 1, 'Your maximum width and height fields must contain integers between 1 and 9999.', ''),
					(11000014, 1, 'Your maximum allowed games field must contain an integer between 1 and 999.', ''),
					(11000015, 1, 'If you have allowed users to have file games, you can adjust their details from this page.', ''),
					(11000016, 1, 'Allow Games?', ''),
					(11000017, 1, 'Do you want to let users have games? If set to no, all other settings on this page will not apply.', ''),
					(11000018, 1, 'Yes, allow games.', ''),
					(11000019, 1, 'No, do not allow games.', ''),
					(11000020, 1, 'Game Privacy Options', ''),
					(11000021, 1, 'If you enable this feature, users will be able to exclude their games from search results. Otherwise, all games will be included in search results.', ''),
					(11000022, 1, 'Yes, allow users to exclude their games from search results.', ''),
					(11000023, 1, 'No, force all games to be included in search results.', ''),
					(11000024, 1, 'Game Privacy Options', ''),
					(11000025, 1, 'Your users can choose from any of the options checked below when they decide who can see their games. If you do not check any options, everyone will be allowed to view games.', ''),
					(11000026, 1, 'GAME MEDIA Comment Options', ''),
					(11000027, 1, 'Your users can choose from any of the options checked below when they decide who can post comments on their media. If you do not check any options, everyone will be allowed to post comments on media.', ''),
					(11000028, 1, 'Maximum Allowed Games', ''),
					(11000029, 1, 'Enter the maximum number of allowed games. The field must contain an integer between 1 and 999.', ''),
					(11000030, 1, 'allowed games', ''),
					(11000031, 1, 'Allowed File Types', ''),
					(11000032, 1, 'List the following file extensions that users are allowed to upload. Separate file extensions with commas, for example: jpg, gif, jpeg, png, bmp', ''),
					(11000033, 1, 'Allowed MIME Types', ''),
					(11000034, 1, 'To successfully upload a file, the file must have an allowed filetype extension as well as an allowed MIME type. This prevents users from disguising malicious files with a fake extension. Separate MIME types with commas, for example: image/jpeg, image/gif, image/png, image/bmp', ''),
					(11000035, 1, 'Allowed Storage Space', ''),
					(11000036, 1, 'How much storage space should each user have to store their files?', ''),
					(11000037, 1, 'unlimited', ''),
					(11000038, 1, 'Maximum Filesize', ''),
					(11000039, 1, 'Enter the maximum filesize for uploaded files in KB. This must be a number between 1 and 204800.', ''),
					(11000040, 1, 'Enter the maximum width and height (in pixels) for images uploaded to games. Images with dimensions outside this range will be sized down accordingly if your server has the GD Libraries installed. Note that unusual image types like TIFF, RAW, and others may not be resized.', ''),
					(11000041, 1, 'Allow Custom CSS Styles?', ''),
					(11000042, 1, 'If you enable this feature, your users will be able to customize the colors and fonts of their games by altering their CSS styles.', ''),
					(11000043, 1, 'Yes, enable custom CSS styles.', ''),
					(11000044, 1, 'No, disable custom CSS styles.', ''),
					(11000045, 1, 'This page lists all of the file games that users have created on your social network. Depending on the settings you have specified in this control panel, users can create games and use them to upload, organize, and share Games, music, videos, and other files. You can use this page to monitor these games and delete offensive material if necessary. Entering criteria into the filter fields will help you find specific games. Leaving the filter fields blank will show all the games on your social network.', ''),
					(11000046, 1, 'Title', ''),
					(11000047, 1, 'Owner', ''),
					(11000048, 1, 'No games were found.', ''),
					(11000049, 1, '%1\$d Games Found', ''),
					(11000050, 1, 'Files', ''),
					(11000051, 1, 'Space Used', ''),
					(11000052, 1, 'view', ''),
					(11000053, 1, 'Are you sure you want to delete this game? Warning: All images within this game will also be deleted.', ''),
					(11000054, 1, 'Delete Game?', ''),
					(11000055, 1, 'My Games', ''),
					(11000056, 1, 'Game Settings', ''),
					(11000057, 1, 'You have %1\$d games and %2\$d Games.', ''),
					(11000058, 1, 'You have %1\$s MB of free space remaining.', ''),
					(11000059, 1, 'Create New Game', ''),
					(11000060, 1, 'My Games Link:', ''),
					(11000061, 1, 'Created:', ''),
					(11000062, 1, 'Last Update:', ''),
					(11000063, 1, 'Files:', ''),
					(11000064, 1, '%1\$s Games (%2\$s MB)', ''),
					(11000065, 1, 'Views:', ''),
					(11000066, 1, '%1\$d views', ''),
					(11000067, 1, 'Viewable By:', ''),
					(11000068, 1, 'View Game', ''),
					(11000069, 1, 'Edit Game', ''),
					(11000070, 1, 'Delete Game', ''),
					(11000071, 1, 'You do not have any games.', ''),
					(11000072, 1, 'Create an game to begin uploading files.', ''),
					(11000073, 1, 'Please enter a name for this game.', ''),
					(11000074, 1, 'Please give us some information about your new game.', ''),
					(11000075, 1, 'You have reached the maximum number of allowed games (%1\$d). You must delete some of your old games before you can create a new one.', ''),
					(11000076, 1, 'Return to My Games', ''),
					(11000077, 1, 'Game Name:', ''),
					(11000078, 1, 'Game Description:', ''),
					(11000079, 1, 'Include this game in search/browse results?', ''),
					(11000080, 1, 'Yes, include this game in search/browse results.', ''),
					(11000081, 1, 'No, exclude this game from search/browse results.', ''),
					(11000082, 1, 'Who can see this game?', ''),
					(11000083, 1, 'Who can comment in this game?', ''),
					(11000084, 1, 'Create Game', ''),
					(11000085, 1, 'You do not have enough free space to upload %1\$s.', ''),
					(11000086, 1, '%1\$s was uploaded successfully.', ''),
					(11000087, 1, 'Upload Games:', ''),
					(11000088, 1, 'To upload Games from your computer, click the \"Browse\" button, locate them on your computer, then click the \"Upload\" button.', ''),
					(11000089, 1, 'Back to Games', ''),
					(11000090, 1, 'You may upload files of the following types: %1\$s', ''),
					(11000091, 1, 'You may upload files with sizes up to %1\$s KB.', ''),
					(11000092, 1, 'Your game has been created. You can begin uploading Games below.', ''),
					(11000093, 1, 'Edit Game Details', ''),
					(11000094, 1, 'Use this page to change the game name, description, or privacy level.', ''),
					(11000095, 1, 'Edit Games:', ''),
					(11000096, 1, 'All Games inside this game are listed below.<br>This game contains <b>%1\$s files</b> and has been viewed <b>%2\$s times</b>.', ''),
					(11000097, 1, 'Back to Games', ''),
					(11000098, 1, 'Add New Games', ''),
					(11000099, 1, 'Edit Game Info', ''),
					(11000100, 1, 'There are no files in this game.', ''),
					(11000101, 1, 'Click here to begin adding files.', ''),
					(11000102, 1, 'Caption', ''),
					(11000103, 1, 'Delete Game', ''),
					(11000104, 1, 'Game Cover', ''),
					(11000105, 1, 'Move To:', ''),
					(11000106, 1, 'Profile Position', ''),
					(11000107, 1, 'Your users can choose from any of the options checked below when they decide where they want their games to appear on their profile. ', ''),
					(11000108, 1, 'Display Games in Tab', ''),
					(11000109, 1, 'Display Games in Side Gutter', ''),
					(11000110, 1, 'Where do you want your games to display on your profile?', ''),
					(11000111, 1, 'Edit game settings such as your game\'s style.', ''),
					(11000112, 1, 'My Games\' Style', ''),
					(11000113, 1, 'You can change the colors, fonts, and styles of your games by adding CSS code below. The contents of the text area below will be output between &lt;style&gt; tags on your game.', ''),
					(11000114, 1, 'Move Up', ''),
					(11000115, 1, 'Rotate Left', ''),
					(11000116, 1, 'Rotate Right', ''),
					(11000118, 1, '%1\$d games/Games', ''),
					(11000119, 1, 'Game: %1\$s', ''),
					(11000120, 1, 'Game: %1\$s', ''),
					(11000121, 1, 'GAME MEDIA posted by <a href=\'%1\$s\'>%2\$s</a><br>%3\$s', ''),
					(11000122, 1, 'Game created by <a href=\'%1\$s\'>%2\$s</a><br>%3\$s', ''),
					(11000123, 1, 'Games', ''),
					(11000124, 1, 'updated %1\$s by <a href=\'%2\$s\'>%3\$s</a>', ''),
					(11000125, 1, 'You do not have permission to view this file.', ''),
					(11000126, 1, 'Uploaded', ''),
					(11000127, 1, 'Browse Game Games', ''),
					(11000128, 1, 'View:', ''),
					(11000129, 1, 'Everyone\'s Games', ''),
					(11000130, 1, 'My Friend\'s Games', ''),
					(11000131, 1, 'Show:', ''),
					(11000132, 1, 'Recently Updated', ''),
					(11000133, 1, 'Recently Created', ''),
					(11000134, 1, 'Game Tagging Options', ''),
					(11000135, 1, 'Your users can choose from any of the options checked below when they decide who can tag their Games. If you do not check any options, everyone will be allowed to tag Games.', ''),
					(11000136, 1, 'Who can tag Games in this game?', ''),
					(11000137, 1, 'Games of %1\$s (%2\$d)', ''),
					(11000138, 1, '<a href=\'%1\$s\'>%2\$s</a>\'s games', ''),
					(11000139, 1, '%1\$s does not have any games.', ''),
					(11000140, 1, 'Updated %1\$s', ''),
					(11000141, 1, '<a href=\'%1\$s\'>%2\$s</a>\'s <a href=\'%3\$s\'>games</a>', ''),
					(11000142, 1, 'download audio', ''),
					(11000143, 1, 'download video', ''),
					(11000144, 1, 'download this file', ''),
					(11000145, 1, 'Viewing #%1\$d of %2\$d in <a href=\'%3\$s\'>%4\$s</a>', ''),
					(11000146, 1, 'Last', ''),
					(11000147, 1, 'Next', ''),
					(11000148, 1, 'Report Inappropriate Content', ''),
					(11000149, 1, 'Games of <a href=\'%1\$s\'>%2\$s</a>', ''),
					(11000150, 1, 'Viewing #%1\$d of %2\$d <a href=\'%3\$s\'>Games of %4\$s</a> &nbsp;|&nbsp; <a href=\'%5\$s\'>Return to %4\$s\'s Profile</a>', ''),
					(11000151, 1, 'Notification of Being Tagged', ''),
					(11000152, 1, 'This is the email that gets sent to a user when someone tags them in a Game.', ''),
					(11000153, 1, 'New Game Tag Email', ''),
					(11000154, 1, 'This is the email that gets sent to a user when someone tags one of their Games.', ''),
					(11000155, 1, '%1\$s\'s game: %2\$s', ''),
					(11000156, 1, '%1\$s', ''),
					(11000157, 1, 'From %1\$s by <a href=\'%2\$s\'>%3\$s</a>', ''),
					(11000158, 1, '%1\$s\'s Game - %2\$s', ''),
					(11000159, 1, '%1\$s', ''),
					(11000160, 1, '%1\$s\'s games', ''),
					(11000161, 1, '%1\$s\'s games', ''),
					(11000162, 1, 'In this Game: ', ''),
					(11000163, 1, 'Add Tag', ''),
					(11000164, 1, 'Share This', ''),
					(11000165, 1, 'To share this Game or embed it on another web page, please copy and paste the code of your choosing:', ''),
					(11000166, 1, 'Direct Link', ''),
					(11000167, 1, 'HTML - Embedded Image', ''),
					(11000168, 1, 'HTML - Text Link', ''),
					(11000169, 1, 'UBB Code (for forums)', ''),
					(11000170, 1, 'Close Window', ''),
					(11000171, 1, 'Games', ''),
					(11000172, 1, '%1\$d Games', ''),
					(11000173, 1, 'remove tag', '')") or die("Insert Into se_languagevars: ".mysql_error());

  }

}  

?>