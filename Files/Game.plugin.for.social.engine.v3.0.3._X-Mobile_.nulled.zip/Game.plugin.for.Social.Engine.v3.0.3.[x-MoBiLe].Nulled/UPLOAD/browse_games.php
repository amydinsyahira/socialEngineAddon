<?php
$page = "browse_games";
include "header.php";

if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }
if(isset($_POST['s'])) { $s = $_POST['s']; } elseif(isset($_GET['s'])) { $s = $_GET['s']; } else { $s = "game_datecreated DESC"; }
if(isset($_POST['v'])) { $v = $_POST['v']; } elseif(isset($_GET['v'])) { $v = $_GET['v']; } else { $v = 0; }

// ENSURE SORT/VIEW ARE VALID
if($s != "game_datecreated DESC" && $s != "game_dateupdated DESC") { $s = "game_dateupdated DESC"; }
if($v != "0" && $v != "1") { $v = 0; }


// SET WHERE CLAUSE
$where = "CASE
	    WHEN se_games.game_user_id={$user->user_info[user_id]}
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_REGISTERED) AND {$user->user_exists}<>0)
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_ANONYMOUS) AND {$user->user_exists}=0)
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_FRIEND) AND (SELECT TRUE FROM se_friends WHERE friend_user_id1=se_games.game_user_id AND friend_user_id2={$user->user_info[user_id]} AND friend_status='1' LIMIT 1))
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_SUBNET) AND {$user->user_exists}<>0 AND (SELECT TRUE FROM se_users WHERE user_id=se_games.game_user_id AND user_subnet_id={$user->user_info[user_subnet_id]} LIMIT 1))
	      THEN TRUE
	    WHEN ((se_games.game_privacy & @SE_PRIVACY_FRIEND2) AND (SELECT TRUE FROM se_friends AS friends_primary LEFT JOIN se_users ON friends_primary.friend_user_id1=se_users.user_id LEFT JOIN se_friends AS friends_secondary ON friends_primary.friend_user_id2=friends_secondary.friend_user_id1 WHERE friends_primary.friend_user_id1=se_games.game_user_id AND friends_secondary.friend_user_id2={$user->user_info[user_id]} AND se_users.user_subnet_id={$user->user_info[user_subnet_id]} LIMIT 1))
	      THEN TRUE
	    ELSE FALSE
	END";


// ONLY MY FRIENDS' GAMES
if($v == "1" && $user->user_exists) {

  // SET WHERE CLAUSE
  $where .= " AND (SELECT TRUE FROM se_friends WHERE friend_user_id1={$user->user_info[user_id]} AND friend_user_id2=se_games.game_user_id AND friend_status=1)";

}



// CREATE GAME OBJECT
$game = new se_game();

// GET TOTAL GAMES
$total_games = $game->game_total($where);

// MAKE ENTRY PAGES
$games_per_page = 10;
$page_vars = make_page($total_games, $games_per_page, $p);

// GET GAME ARRAY
$game_array = $game->game_list($page_vars[0], $games_per_page, $s, $where);


// ASSIGN SMARTY VARIABLES AND DISPLAY GAMES PAGE
$smarty->assign('games', $game_array);
$smarty->assign('total_games', $total_games);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($game_array));
$smarty->assign('s', $s);
$smarty->assign('v', $v);
include "footer.php";
?>