<?php

//  THIS CLASS CONTAINS GAME ENTRY-RELATED METHODS 
//  METHODS IN THIS CLASS:
//    se_game()
//    game_total()
//    game_list()
//    game_space()
//    game_delete()
//    game_delete_selected()
//    game_files()
//    game_game_media_upload()
//    game_game_media_list()
//    game_game_media_update()
//    game_game_media_delete()
//    game_game_media_rotate()





class se_game {

	// INITIALIZE VARIABLES
	var $is_error;			// DETERMINES WHETHER THERE IS AN ERROR OR NOT

	var $user_id;			// CONTAINS THE USER ID OF THE USER WHOSE GAME WE ARE EDITING








	// THIS METHOD SETS INITIAL VARS
	// INPUT: $user_id (OPTIONAL) REPRESENTING THE USER ID OF THE USER WHOSE GAMES WE ARE CONCERNED WITH
	// OUTPUT: 
	function se_game($user_id = 0) {

	  $this->user_id = $user_id;

	} // END se_game() METHOD








	// THIS METHOD RETURNS THE TOTAL NUMBER OF GAMES
	// INPUT: $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF GAMES
	function game_total($where = "") {
	  global $database;

	  // BEGIN GAME QUERY
	  $game_query = "SELECT game_id FROM se_games";

	  // IF NO USER ID SPECIFIED, JOIN TO USER TABLE
	  if($this->user_id == 0) { $game_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" || $this->user_id != 0) { $game_query .= " WHERE"; }

	  // ENSURE USER ID IS NOT EMPTY
	  if($this->user_id != 0) { $game_query .= " game_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 && $where != "") { $game_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $game_query .= " $where"; }

	  // GET AND RETURN TOTAL PHOTO GAMES
	  $game_total = $database->database_num_rows($database->database_query($game_query));
	  return $game_total;


	} // END game_total() METHOD








	// THIS METHOD RETURNS AN ARRAY OF GAMES
	// INPUT: $start REPRESENTING THE GAME TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF GAMES TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY OF GAMES
	function game_list($start, $limit, $sort_by = "game_id DESC", $where = "") {
	  global $database, $user, $owner;

	  // BEGIN QUERY
	  $game_query = "SELECT se_games.*, count(se_game_media.game_media_id) AS total_files, sum(se_game_media.game_media_filesize) AS total_space";
	
	  // IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
	  if($this->user_id == 0) { $game_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo, se_users.user_fname, se_users.user_lname"; }

	  // CONTINUE QUERY
	  $game_query .= " FROM se_games LEFT JOIN se_game_media ON se_games.game_id=se_game_media.game_media_game_id";

	  // IF NO USER ID SPECIFIED, JOIN TO USER TABLE
	  if($this->user_id == 0) { $game_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" || $this->user_id != 0) { $game_query .= " WHERE"; }

	  // ENSURE USER ID IS NOT EMPTY
	  if($this->user_id != 0) { $game_query .= " game_user_id=".$this->user_id; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 && $where != "") { $game_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $game_query .= " $where"; }

	  // ADD GROUP BY, ORDER, AND LIMIT CLAUSE
	  $game_query .= " GROUP BY game_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $games = $database->database_query($game_query);

	  // GET GAMES INTO AN ARRAY
	  $game_array = Array();
	  while($game_info = $database->database_fetch_assoc($games)) {

	    // IF NO USER ID SPECIFIED, CREATE OBJECT FOR AUTHOR
	    if($this->user_id == 0) {
	      $author = new se_user();
	      $author->user_exists = 1;
	      $author->user_info[user_id] = $game_info[user_id];
	      $author->user_info[user_username] = $game_info[user_username];
	      $author->user_info[user_fname] = $game_info[user_fname];
	      $author->user_info[user_lname] = $game_info[user_lname];
	      $author->user_info[user_photo] = $game_info[user_photo];
	      $author->user_displayname();

	    // OTHERWISE, SET AUTHOR TO OWNER/LOGGED-IN USER
	    } elseif($owner->user_exists != 0 && $owner->user_info[user_id] == $game_info[game_user_id]) {
	      $author = $owner;
	    } elseif($user->user_exists != 0 && $user->user_info[user_id] == $game_info[game_user_id]) {
	      $author = $user;
	    }

	    // CONVERT SPACE TO MB
	    $game_space_mb = ($game_info[total_space] / 1024) / 1024;
	    $game_space_mb = round($game_space_mb, 2);

	    // GET PATH OF GAME COVER
	    $game_cover_id = 0;
	    $game_cover_ext = "";
	    if($game_info[game_cover] != 0) {
	      $game_cover_query = $database->database_query("SELECT game_media_id, game_media_ext FROM se_game_media WHERE game_media_id='$game_info[game_cover]' AND game_media_game_id='$game_info[game_id]'");
	      if($database->database_num_rows($game_cover_query) == 1) {
	        $game_cover_array = $database->database_fetch_assoc($game_cover_query);
	        $game_cover_id = $game_cover_array[game_media_id];
	        $game_cover_ext = $game_cover_array[game_media_ext];
	      }
	    }

	    // CREATE ARRAY OF GAME DATA
	    SE_Language::_preload(user_privacy_levels($game_info[game_privacy]));
	    $game_array[] = Array('game_id' => $game_info[game_id],
				     'game_user_id' => $game_info[game_user_id],
				     'game_author' => $author,
				     'game_datecreated' => $game_info[game_datecreated],
				     'game_dateupdated' => $game_info[game_dateupdated],
				     'game_dateupdated_raw' => $game_info[game_dateupdated],
				     'game_title' => $game_info[game_title],
				     'game_desc' => $game_info[game_desc],
				     'game_files' => $game_info[total_files],
				     'game_space' => $game_space_mb,
				     'game_privacy' => user_privacy_levels($game_info[game_privacy]),
				     'game_cover_id' => $game_cover_id,
				     'game_cover_ext' => $game_cover_ext,
				     'game_views' => $game_info[game_views]);

	  }

	  // RETURN ARRAY
	  return $game_array;

	} // END game_list() METHOD








	// THIS METHOD RETURNS THE SPACE USED
	// INPUT: $game_id (OPTIONAL) REPRESENTING THE ID OF THE GAME TO CALCULATE
	// OUTPUT: AN INTEGER REPRESENTING THE SPACE USED
	function game_space($game_id = 0) {
	  global $database;

	  // BEGIN QUERY
	  $game_query = "SELECT sum(se_game_media.game_media_filesize) AS total_space";
	
	  // CONTINUE QUERY
	  $game_query .= " FROM se_games LEFT JOIN se_game_media ON se_games.game_id=se_game_media.game_media_game_id";

	  // ADD WHERE IF NECESSARY
	  if($this->user_id != 0 || $game_id != 0) { $game_query .= " WHERE"; }

	  // ENSURE USER ID IS NOT EMPTY
	  if($this->user_id != 0) { $game_query .= " game_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 && $game_id != 0) { $game_query .= " AND"; }

	  // SPECIFY GAME IF NECESSARY
	  if($game_id != 0) { $game_query .= " game_id='$game_id'"; }

	  // GET AND RETURN TOTAL SPACE USED
	  $space_info = $database->database_fetch_assoc($database->database_query($game_query));
	  return $space_info[total_space];

	} // END game_space() METHOD








	// THIS METHOD DELETES A SPECIFIED GAME
	// INPUT: $game_id REPRESENTING THE ID OF THE GAME TO DELETE
	// OUTPUT: 
	function game_delete($game_id) {
	  global $database, $url;

	  $game_media = $database->database_query("SELECT game_media_id, game_media_ext FROM se_game_media WHERE game_media_game_id='$game_id'");

	  // LOOP OVER GAME MEDIA
	  while($game_media_info = $database->database_fetch_assoc($game_media)) {
	    $game_media_path = $url->url_userdir($this->user_id).$game_media_info[game_media_id].".".$game_media_info[game_media_ext];
	    if(file_exists($game_media_path)) { unlink($game_media_path); }
	    $thumb_path = $url->url_userdir($this->user_id).$game_media_info[game_media_id]."_thumb.".$game_media_info[game_media_ext];
	    if(file_exists($thumb_path)) { unlink($thumb_path); }
	  }

	  $database->database_query("DELETE FROM se_games, se_game_media, se_game_mediacomments, se_game_mediatags USING se_games LEFT JOIN se_game_media ON se_games.game_id=se_game_media.game_media_game_id LEFT JOIN se_game_mediacomments ON se_game_media.game_media_id=se_game_mediacomments.game_mediacomment_game_media_id LEFT JOIN se_game_mediatags ON se_game_media.game_media_id=se_game_mediatags.game_mediatag_game_media_id WHERE se_games.game_id='$game_id'");

	  // CALL GAME CREATION HOOK
	  ($hook = SE_Hook::exists('se_game_delete')) ? SE_Hook::call($hook, array()) : NULL;


	} // END game_delete() METHOD








	// THIS METHOD DELETES SELECTED GAMES
	// INPUT: $start REPRESENTING THE GAME TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF GAMES TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: 
	function game_delete_selected($start, $limit, $sort_by = "game_id DESC", $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $game_query = "SELECT se_games.*, count(se_game_media.game_media_id) AS total_files, sum(se_game_media.game_media_filesize) AS total_space";
	
	  // IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
	  if($this->user_id == 0) { $game_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo"; }

	  // CONTINUE QUERY
	  $game_query .= " FROM se_games LEFT JOIN se_game_media ON se_games.game_id=se_game_media.game_media_game_id";

	  // IF NO USER ID SPECIFIED, JOIN TO USER TABLE
	  if($this->user_id == 0) { $game_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" || $this->user_id != 0) { $game_query .= " WHERE"; }

	  // ENSURE USER ID IS NOT EMPTY
	  if($this->user_id != 0) { $game_query .= " game_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 && $where != "") { $game_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $game_query .= " $where"; }

	  // ADD GROUP BY, ORDER, AND LIMIT CLAUSE
	  $game_query .= " GROUP BY game_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $games = $database->database_query($game_query);

	  // GET GAMES INTO AN ARRAY
	  $game_array = Array();
	  while($game_info = $database->database_fetch_assoc($games)) {
    	    $var = "delete_game_".$game_info[game_id];
	    if($_POST[$var] == 1) { $this->game_delete($game_info[game_id]); }
	  }

	} // END game_delete_selected() METHOD








	// THIS METHOD RETURNS THE NUMBER OF FILES
	// INPUT: $game_id (OPTIONAL) REPRESENTING THE ID OF THE GAME TO CALCULATE
	//	  $where (OPTIONAL) REPRESENTING A WHERE CLAUSE
	// OUTPUT: AN INTEGER REPRESENTING THE NUMBER OF FILES
	function game_files($game_id = 0, $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $game_query = "SELECT count(se_game_media.game_media_id) AS total_files";
	
	  // CONTINUE QUERY
	  $game_query .= " FROM se_games LEFT JOIN se_game_media ON se_games.game_id=se_game_media.game_media_game_id";

	  // ADD WHERE IF NECESSARY
	  if($this->user_id != 0 || $game_id != 0 || $where != "") { $game_query .= " WHERE"; }

	  // ENSURE USER ID IS NOT EMPTY
	  if($this->user_id != 0) { $game_query .= " game_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 && ($game_id != 0 || $where != "")) { $game_query .= " AND"; }

	  // SPECIFY GAME IF NECESSARY
	  if($game_id != 0) { $game_query .= " game_id='$game_id'"; }

	  // INSERT AND IF NECESSARY
	  if($game_id != 0 && $where != "") { $game_query .= " AND"; }

	  // ADD WHERE CLAUSE
	  if($where != "") { $game_query .= " $where"; }

	  // GET AND RETURN TOTAL FILES
	  $file_info = $database->database_fetch_assoc($database->database_query($game_query));
	  return $file_info[total_files];

	} // END game_files() METHOD








	// THIS METHOD UPLOADS GAME MEDIA TO AN GAME
	// INPUT: $file_name REPRESENTING THE NAME OF THE FILE INPUT
	//	  $game_id REPRESENTING THE ID OF THE GAME TO UPLOAD THE GAME MEDIA TO
	//	  $space_left REPRESENTING THE AMOUNT OF SPACE LEFT
	// OUTPUT:
	function game_game_media_upload($file_name, $game_id, &$space_left) {
	  global $database, $url, $user;

	  // SET KEY VARIABLES
	  $file_maxsize = $user->level_info[level_game_maxsize];
	  $file_exts = explode(",", str_replace(" ", "", strtolower($user->level_info[level_game_exts])));
	  $file_types = explode(",", str_replace(" ", "", strtolower($user->level_info[level_game_mimes])));
	  $file_maxwidth = $user->level_info[level_game_width];
	  $file_maxheight = $user->level_info[level_game_height];

	  $new_game_media = new se_upload();
	  $new_game_media->new_upload($file_name, $file_maxsize, $file_exts, $file_types, $file_maxwidth, $file_maxheight);

	  // UPLOAD AND RESIZE PHOTO IF NO ERROR
	  if($new_game_media->is_error == 0) {

	    // GET MAX ORDER
	    $max = $database->database_fetch_assoc($database->database_query("SELECT max(game_media_order) AS max FROM se_game_media LEFT JOIN se_games ON se_game_media.game_media_game_id=se_games.game_id WHERE se_games.game_user_id='".$user->user_info[user_id]."'"));
	    $game_media_order = $max[max]+1;


	    // INSERT ROW INTO GAME MEDIA TABLE
	    $database->database_query("INSERT INTO se_game_media (
							game_media_game_id,
							game_media_date,
							game_media_order
							) VALUES (
							'$game_id',
							'".time()."',
							'$game_media_order'
							)");
	    $game_media_id = $database->database_insert_id();

	    // CHECK IF IMAGE RESIZING IS AVAILABLE, OTHERWISE MOVE UPLOADED IMAGE
	    if($new_game_media->is_image == 1) {
	      $file_dest = $url->url_userdir($user->user_info[user_id]).$game_media_id.".jpg";
	      $thumb_dest = $url->url_userdir($user->user_info[user_id]).$game_media_id."_thumb.jpg";

	      // UPLOAD THUMB
	      $new_game_media->upload_thumb($thumb_dest, 200);

	      // UPLOAD FILE
	      $new_game_media->upload_photo($file_dest);

	      $file_ext = "jpg";
	      $file_filesize = filesize($file_dest);
	    } else {
	      $file_dest = $url->url_userdir($user->user_info[user_id]).$game_media_id.".".$new_game_media->file_ext;

	      // UPLOAD THUMB IF NECESSARY
	      if($new_game_media->file_ext == 'gif') {
	        $thumb_dest = $url->url_userdir($user->user_info[user_id]).$game_media_id."_thumb.jpg";
	        $new_game_media->upload_thumb($thumb_dest, 200);
	      }

	      // MOVE FILE
	      $new_game_media->upload_file($file_dest);
	      $file_ext = $new_game_media->file_ext;
	      $file_filesize = filesize($file_dest);
	    }

	    // CHECK SPACE LEFT
	    if($file_filesize > $space_left) {
	      $new_game_media->is_error = 11000085;
	    } else {
	      $space_left = $space_left-$file_filesize;
	    }

	    // DELETE FROM DATABASE IF ERROR
	    if($new_game_media->is_error != 0) {
	      $database->database_query("DELETE FROM se_game_media WHERE game_media_id='$game_media_id' AND game_media_game_id='$game_id'");
	      @unlink($file_dest);

	    // UPDATE ROW IF NO ERROR
	    } else {
	      $database->database_query("UPDATE se_game_media SET game_media_ext='$file_ext', game_media_filesize='$file_filesize' WHERE game_media_id='$game_media_id' AND game_media_game_id='$game_id'");
	    }
	  }
	
	  // RETURN FILE STATS
	  $file_result = Array('is_error' => $new_game_media->is_error,
			'file_name' => $_FILES[$file_name]['name'],
			'game_media_id' => $game_media_id,
			'game_media_ext' => $file_ext,
			'game_media_filesize' => $file_filesize);

	  return $file_result;

	} // END game_game_media_upload() METHOD








	// THIS METHOD RETURNS AN ARRAY OF GAME MEDIA
	// INPUT: $start REPRESENTING THE GAME MEDIA TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF GAME MEDIA TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	//	  $select (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO SELECT
	// OUTPUT: AN ARRAY OF GAME MEDIA
	function game_game_media_list($start, $limit, $sort_by = "game_media_id DESC", $where = "", $select = "") {
	  global $database, $user, $owner;

	  // BEGIN QUERY
	  $game_media_query = "SELECT se_game_media.*, se_games.game_id, se_games.game_user_id, se_games.game_title, count(se_game_mediacomments.game_mediacomment_id) AS total_comments";
	
	  // IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
	  if($this->user_id == 0) { $game_media_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo"; }
	
	  // ADD ADDITIONAL SELECTS
	  if($select != "") { $game_media_query .= $select; }

	  // CONTINUE QUERY
	  $game_media_query .= " FROM se_game_media LEFT JOIN se_game_mediacomments ON se_game_mediacomments.game_mediacomment_game_media_id=se_game_media.game_media_id LEFT JOIN se_games ON se_games.game_id=se_game_media.game_media_game_id";

	  // IF NO USER ID SPECIFIED, JOIN TO USER TABLE
	  if($this->user_id == 0) { $game_media_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" || $this->user_id != 0) { $game_media_query .= " WHERE"; }

	  // ENSURE USER ID IS NOT EMPTY
	  if($this->user_id != 0) { $game_media_query .= " game_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 && $where != "") { $game_media_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $game_media_query .= " $where"; }

	  // ADD GROUP BY, ORDER, AND LIMIT CLAUSE
	  $game_media_query .= " GROUP BY game_media_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $game_media = $database->database_query($game_media_query);

	  // GET GAME MEDIA INTO AN ARRAY
	  $game_media_array = Array();
	  while($game_media_info = $database->database_fetch_assoc($game_media)) {

	    // IF NO USER ID SPECIFIED, CREATE OBJECT FOR AUTHOR
	    if($this->user_id == 0) {
	      $author = new se_user();
	      $author->user_exists = 1;
	      $author->user_info[user_id] = $game_media_info[user_id];
	      $author->user_info[user_username] = $game_media_info[user_username];
	      $author->user_info[user_photo] = $game_media_info[user_photo];

	    // OTHERWISE, SET AUTHOR TO OWNER/LOGGED-IN USER
	    } elseif($owner->user_exists != 0 && $owner->user_info[user_id] == $game_media_info[game_user_id]) {
	      $author = $owner;
	    } elseif($user->user_exists != 0 && $user->user_info[user_id] == $game_media_info[game_user_id]) {
	      $author = $user;
	    }

	    // CREATE ARRAY OF GAME MEDIA DATA
	    $game_media_array[] = Array('game_media_id' => $game_media_info[game_media_id],
					'game_media_game_id' => $game_media_info[game_media_game_id],
					'game_media_author' => $author,
					'game_media_date' => $game_media_info[game_media_date],
					'game_media_title' => $game_media_info[game_media_title],
					'game_media_desc' => str_replace("<br>", "\r\n", $game_media_info[game_media_desc]),
					'game_media_ext' => $game_media_info[game_media_ext],
					'game_media_filesize' => $game_media_info[game_media_filesize],
					'game_media_comments_total' => $game_media_info[total_comments]);

	  }

	  // RETURN ARRAY
	  return $game_media_array;

	} // END game_game_media_list() METHOD








	// THIS METHOD UPDATES GAME MEDIA INFORMATION
	// INPUT: $start REPRESENTING THE GAME MEDIA TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF GAME MEDIA TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT: AN ARRAY CONTAINING ALL THE GAME MEDIA ID
	function game_game_media_update($start, $limit, $sort_by = "game_media_id DESC", $where = "") {
	  global $database;

	  // BEGIN QUERY
	  $game_media_query = "SELECT se_game_media.*, se_games.game_id, se_games.game_user_id, se_games.game_title, count(se_game_mediacomments.game_mediacomment_id) AS total_comments";
	
	  // IF NO USER ID SPECIFIED, RETRIEVE USER INFORMATION
	  if($this->user_id == 0) { $game_media_query .= ", se_users.user_id, se_users.user_username, se_users.user_photo"; }

	  // CONTINUE QUERY
	  $game_media_query .= " FROM se_game_media LEFT JOIN se_game_mediacomments ON se_game_mediacomments.game_mediacomment_game_media_id=se_game_media.game_media_id LEFT JOIN se_games ON se_games.game_id=se_game_media.game_media_game_id";

	  // IF NO USER ID SPECIFIED, JOIN TO USER TABLE
	  if($this->user_id == 0) { $game_media_query .= " LEFT JOIN se_users ON se_games.game_user_id=se_users.user_id"; }

	  // ADD WHERE IF NECESSARY
	  if($where != "" || $this->user_id != 0) { $game_media_query .= " WHERE"; }

	  // ENSURE USER ID IS NOT EMPTY
	  if($this->user_id != 0) { $game_media_query .= " game_user_id='".$this->user_id."'"; }

	  // INSERT AND IF NECESSARY
	  if($this->user_id != 0 && $where != "") { $game_media_query .= " AND"; }

	  // ADD WHERE CLAUSE, IF NECESSARY
	  if($where != "") { $game_media_query .= " $where"; }

	  // ADD GROUP BY, ORDER, AND LIMIT CLAUSE
	  $game_media_query .= " GROUP BY game_media_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $game_media = $database->database_query($game_media_query);

	  // GET GAME MEDIA INTO AN ARRAY
	  $game_media_array = Array();
	  while($game_media_info = $database->database_fetch_assoc($game_media)) {
	    $var1 = "game_media_title_".$game_media_info[game_media_id];
	    $var2 = "game_media_desc_".$game_media_info[game_media_id];
	    $var3 = "game_media_game_id_".$game_media_info[game_media_id];
	    $game_media_title = censor($_POST[$var1]);
	    $game_media_desc = censor(str_replace("\r\n", "<br>", $_POST[$var2]));
	    $game_media_game_id = $_POST[$var3];
	    if($game_media_title != $game_media_info[game_media_title] || $game_media_desc != $game_media_info[game_media_desc] || $game_media_game_id != $game_media_info[game_media_game_id]) {
	      if($game_media_game_id != $game_media_info[game_media_game_id]) {
		if($database->database_num_rows($database->database_query("SELECT game_id FROM se_games WHERE game_id='$game_media_game_id' AND game_user_id='".$this->user_id."' LIMIT 1")) != 1) {
		  $game_media_game_id = $game_media_info[game_media_game_id];
		}
	      }
	      $database->database_query("UPDATE se_game_media SET game_media_title='$game_media_title', game_media_desc='$game_media_desc', game_media_game_id='$game_media_game_id' WHERE game_media_id='$game_media_info[game_media_id]'");
	    }
	    
	    if($game_media_game_id == $game_media_info[game_media_game_id]) {
	      $game_media_array[] = $game_media_info[game_media_id];
	    }
	  }

	  return $game_media_array;

	} // END game_game_media_update() METHOD








	// THIS METHOD DELETES SELECTED GAME MEDIA
	// INPUT: $start REPRESENTING THE GAME MEDIA TO START WITH
	//	  $limit REPRESENTING THE NUMBER OF GAME MEDIA TO RETURN
	//	  $sort_by (OPTIONAL) REPRESENTING THE ORDER BY CLAUSE
	//	  $where (OPTIONAL) REPRESENTING ADDITIONAL THINGS TO INCLUDE IN THE WHERE CLAUSE
	// OUTPUT:
	function game_game_media_delete($start, $limit, $sort_by = "game_media_id DESC", $where = "") {
	  global $database, $url;

	  $delete = $_POST['delete'];
	  if(count($delete) == 0) { return; }

	  // BEGIN QUERY
	  $game_media_query = "SELECT se_game_media.game_media_id, se_game_media.game_media_ext FROM se_game_media LEFT JOIN se_game_mediacomments ON se_game_mediacomments.game_mediacomment_game_media_id=se_game_media.game_media_id LEFT JOIN se_games ON se_games.game_id=se_game_media.game_media_game_id";

	  // ADD WHERE IF NECESSARY
	  $game_media_query .= " WHERE se_game_media.game_media_id IN(".implode(", ", $delete).") AND game_user_id='".$this->user_id."'";

	  // ADD WHERE CLAUSE IF NECESSARY
	  if($where != "") { $game_media_query .= " AND $where"; }

	  // ADD GROUP BY, ORDER, AND LIMIT CLAUSE
	  $game_media_query .= " GROUP BY game_media_id ORDER BY $sort_by LIMIT $start, $limit";

	  // RUN QUERY
	  $game_media = $database->database_query($game_media_query);

	  // LOOP OVER GAME MEDIA
	  $thumbs = Array();
	  while($game_media_info = $database->database_fetch_assoc($game_media)) {
	    $game_media_path = $url->url_userdir($this->user_id).$game_media_info[game_media_id].".".$game_media_info[game_media_ext];
	    if(file_exists($game_media_path)) { unlink($game_media_path); }
	    $thumb_path = $url->url_userdir($this->user_id).$game_media_info[game_media_id]."_thumb.jpg";
	    if(file_exists($thumb_path)) { unlink($thumb_path); }
	    $thumbs[] = $url->url_base.substr($url->url_userdir($this->user_id), 2).$game_media_info[game_media_id]."_thumb.jpg";
	  }

	  // DELETE ACTION GAME MEDIA IF NECESSARY
	  $database->database_query("DELETE FROM se_actionmedia WHERE actionmedia_path IN ('".implode("', '", $thumbs)."')");

	  // DELETE GAME MEDIA FROM DATABASE
	  $database->database_query("DELETE FROM se_game_media, se_game_mediacomments, se_game_mediatags USING se_game_media LEFT JOIN se_game_mediacomments ON se_game_media.game_media_id=se_game_mediacomments.game_mediacomment_game_media_id LEFT JOIN se_game_mediatags ON se_game_media.game_media_id=se_game_mediatags.game_mediatag_game_media_id WHERE se_game_media.game_media_id IN(".implode(", ", $delete).")");

	  return true;

	} // END game_game_media_delete() METHOD








	// THIS METHOD ROTATES SELECTED GAME MEDIA
	// INPUT: $game_media_id REPRESENTING THE ID OF THE GAME MEDIA TO ROTATE
	//	  $angle REPRESENTING THE NUMBER OF DEGREES TO ROTATE THE IMAGE
	// OUTPUT:
	function game_game_media_rotate($game_media_id, $dir) {
	  global $database, $url;

	  // ENSURE GAME MEDIA BELONGS TO USER
	  $game_media = $database->database_query("SELECT se_game_media.* FROM se_game_media LEFT JOIN se_games ON se_game_media.game_media_game_id=se_games.game_id WHERE game_media_id='$game_media_id' AND game_user_id='".$this->user_id."'");
	  if($database->database_num_rows($game_media) != 1) { return; }
	  $game_media_info = $database->database_fetch_assoc($game_media);

	  // GET IMAGE INFORMATION
	  $game_media_path = $url->url_userdir($this->user_id).$game_media_info[game_media_id].".".$game_media_info[game_media_ext];
	  $game_media_dimensions = @getimagesize($game_media_path);
	  $game_media_width = $game_media_dimensions[0];
	  $game_media_height = $game_media_dimensions[1];

	  // ROTATE IMAGE
	  switch($game_media_info[game_media_ext]) {
	    case "gif":
	      $old = imagecreatefromgif($game_media_path);
	      $rotate = imagerotate($old, $dir, 0);
	      imagejpeg($rotate, $game_media_path, 100);
	      ImageDestroy($old);
	      ImageDestroy($rotate);
	      break;
	    case "bmp":
	      $old = imagecreatefrombmp($game_media_path);
	      $rotate = imagerotate($old, $dir, 0);
	      imagejpeg($rotate, $game_media_path, 100);
	      ImageDestroy($old);
	      ImageDestroy($rotate);
	      break;
	    case "jpeg":
	    case "jpg":
	      $old = imagecreatefromjpeg($game_media_path);
	      $rotate = imagerotate($old, $dir, 0);
	      imagejpeg($rotate, $game_media_path, 100);
	      ImageDestroy($old);
	      ImageDestroy($rotate);
	      break;
	    case "png":
	      $old = imagecreatefrompng($game_media_path);
	      $rotate = imagerotate($old, $dir, 0);
	      imagejpeg($rotate, $game_media_path, 100);
	      ImageDestroy($old);
	      ImageDestroy($rotate);
	      break;
	  } 


	  // GET THUMB INFO
	  $thumb_path = $url->url_userdir($this->user_id).$game_media_info[game_media_id]."_thumb.jpg";
	  $thumb_dimensions = @getimagesize($thumb_path);
	  $thumb_width = $thumb_dimensions[0];
	  $thumb_height = $thumb_dimensions[1];

	  // ROTATE THUMB
	  $old = imagecreatefromjpeg($thumb_path);
	  $rotate = imagerotate($old, $dir, 0);
	  imagejpeg($rotate, $thumb_path, 100);
	  ImageDestroy($old);
	  ImageDestroy($rotate);

	} // END game_game_media_rotate() METHOD

}
?>