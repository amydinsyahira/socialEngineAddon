<?

//  THIS FILE CONTAINS GAME-RELATED FUNCTIONS
//  FUNCTIONS IN THIS CLASS:
//    search_game()
//    deleteuser_game()













// THIS FUNCTION IS RUN DURING THE SEARCH PROCESS TO SEARCH THROUGH GAMES AND GAME MEDIA
// INPUT: 
// OUTPUT: 
function search_game() {
	global $database, $url, $results_per_page, $p, $search_text, $t, $search_objects, $results, $total_results;

	// CONSTRUCT QUERY
	$game_query = "
	(
	SELECT
          '1' AS sub_type,
	  se_game_media.game_media_game_id AS game_id,
	  se_game_media.game_media_title AS title,
	  se_game_media.game_media_desc AS description,
	  se_game_media.game_media_id AS game_media_id,
	  se_game_media.game_media_ext AS game_media_ext,
	  se_users.user_id,
	  se_users.user_username,
	  se_users.user_photo,
	  se_users.user_fname,
	  se_users.user_lname
	FROM
	  se_game_media,
	  se_games,
	  se_users,
	  se_levels
	WHERE
	  se_game_media.game_media_game_id=se_games.game_id AND
	  se_games.game_user_id=se_users.user_id AND
	  se_users.user_level_id=se_levels.level_id AND
	  (
	    se_games.game_search='1' OR
	    se_levels.level_game_search='0'
	  )
	  AND
	  (
	    se_game_media.game_media_title LIKE '%$search_text%' OR
	    se_game_media.game_media_desc LIKE '%$search_text%'
	  )
	ORDER BY game_media_id DESC
	)
	UNION ALL
	(
	SELECT
	  '2' AS sub_type,
	  se_games.game_id AS game_id,
	  se_games.game_title AS title,
	  se_games.game_desc AS description,
	  se_games.game_cover AS game_media_id,
	  se_game_media.game_media_ext AS game_media_ext,
	  se_users.user_id,
	  se_users.user_username,
	  se_users.user_photo,
	  se_users.user_fname,
	  se_users.user_lname
	FROM
	  se_games,
	  se_users,
	  se_levels,
	  se_game_media
	WHERE
	  se_games.game_user_id=se_users.user_id AND
	  se_users.user_level_id=se_levels.level_id AND
	  se_games.game_cover=se_game_media.game_media_id AND 
	  (
	    se_games.game_search='1' OR
	    se_levels.level_game_search='0'
	  )
	  AND
	  (
	    se_games.game_title LIKE '%$search_text%' OR
	    se_games.game_desc LIKE '%$search_text%'
	  )
	ORDER BY game_id DESC
	)"; 

	// GET TOTAL RESULTS
	$total_games = $database->database_num_rows($database->database_query($game_query." LIMIT 201"));

	// IF NOT TOTAL ONLY
	if($t == "game") {

	  // MAKE GAME PAGES
	  $start = ($p - 1) * $results_per_page;
	  $limit = $results_per_page+1;

	  // SEARCH GAMES
	  $games = $database->database_query($game_query." ORDER BY game_id DESC LIMIT $start, $limit");
	  while($game_info = $database->database_fetch_assoc($games)) {

	    // CREATE AN OBJECT FOR USER
	    $profile = new se_user();
	    $profile->user_info[user_id] = $game_info[user_id];
	    $profile->user_info[user_username] = $game_info[user_username];
	    $profile->user_info[user_fname] = $game_info[user_fname];
	    $profile->user_info[user_lname] = $game_info[user_lname];
	    $profile->user_info[user_photo] = $game_info[user_photo];
	    $profile->user_displayname();

	    // RESULT IS A GAME MEDIA
	    if($game_info[sub_type] == 1) {
	      $result_url = $url->url_create('game_file', $game_info[user_username], $game_info[game_id], $game_info[game_media_id]);
	      $result_name = 11000119;
	      $result_desc = 11000121;

	    // RESULT IS AN GAME
	    } else {
	      $result_url = $url->url_create('game', $game_info[user_username], $game_info[game_id]);
	      $result_name = 11000120;
	      $result_desc = 11000122;
	    }

	    // SET THUMBNAIL, IF AVAILABLE
	    switch($game_info[game_media_ext]) {
		case "jpeg": case "jpg": case "gif": case "png": case "bmp":
		  $thumb_path = $url->url_userdir($game_info[user_id]).$game_info[game_media_id]."_thumb.jpg";
		  break;
		case "mp3": case "mp4": case "wav":
		  $thumb_path = "./images/icons/audio_big.gif";
		  break;
		case "mpeg": case "mpg": case "mpa": case "avi": case "swf": case "mov": case "ram": case "rm":
		  $thumb_path = "./images/icons/video_big.gif";
		  break;
		default:
		  $thumb_path = "./images/icons/file_big.gif";
	    }

	    if(!file_exists($thumb_path)) { $thumb_path = "./images/icons/file_big.gif"; }

	    // IF NO TITLE
	    if($game_info[title] == "") { SE_Language::_preload(589); SE_Language::load(); $game_info[title] = SE_Language::_get(589); }

	    // IF DESCRIPTION IS LONG
	    if(strlen($game_info[description]) > 150) { $game_info[description] = substr($game_info[description], 0, 147)."..."; }

	    $results[] = Array('result_url' => $result_url,
				'result_icon' => $thumb_path,
				'result_name' => $result_name,
				'result_name_1' => $game_info[title],
				'result_desc' => $result_desc,
				'result_desc_1' => $url->url_create('profile', $game_info[user_username]),
				'result_desc_2' => $profile->user_displayname,
				'result_desc_3' => $game_info[description]);
	  }

	  // SET TOTAL RESULTS
	  $total_results = $total_games;

	}

	// SET ARRAY VALUES
	SE_Language::_preload_multi(11000118, 11000119, 11000120, 11000121, 11000122);
	if($total_games > 200) { $total_games = "200+"; }
	$search_objects[] = Array('search_type' => 'game',
				'search_lang' => 11000118,
				'search_total' => $total_games);

} // END search_game() FUNCTION









// THIS FUNCTION IS RUN WHEN A USER IS DELETED
// INPUT: $user_id REPRESENTING THE USER ID OF THE USER BEING DELETED
// OUTPUT: 
function deleteuser_game($user_id) {
	global $database;

	// DELETE GAMES, GAME MEDIA, AND COMMENTS
	$database->database_query("DELETE FROM se_games, se_game_media, se_game_mediacomments, se_game_mediatags USING se_games LEFT JOIN se_game_media ON se_games.game_id=se_game_media.game_media_game_id LEFT JOIN se_game_mediacomments ON se_game_media.game_media_id=se_game_mediacomments.game_mediacomment_game_media_id LEFT JOIN se_game_mediatags ON se_game_media.game_media_id=se_game_mediatags.game_mediatag_game_media_id WHERE se_games.game_user_id='$user_id'");

	// DELETE TAGS OF USER
	$database->database_query("UPDATE se_game_mediatags SET game_mediatag_user_id='0' WHERE game_mediatag_user_id=$user_id");

	// DELETE STYLE
	$database->database_query("DELETE FROM se_gamestyles WHERE gamestyle_user_id='$user_id'");

} // END deleteuser_game() FUNCTION

?>