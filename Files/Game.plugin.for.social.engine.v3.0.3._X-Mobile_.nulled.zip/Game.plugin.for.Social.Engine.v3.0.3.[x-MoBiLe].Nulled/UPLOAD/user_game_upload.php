<?php
$page = "user_game_upload";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }
if(isset($_POST['game_id'])) { $game_id = $_POST['game_id']; } elseif(isset($_GET['game_id'])) { $game_id = $_GET['game_id']; } else { $game_id = 0; }

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($user->level_info[level_game_allow] == 0) { header("Location: user_home.php"); exit(); }

// BE SURE GAME BELONGS TO THIS USER
$game = $database->database_query("SELECT * FROM se_games WHERE game_id='$game_id' AND game_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($game) != 1) { header("Location: user_game.php"); exit(); }
$game_info = $database->database_fetch_assoc($game);

// SET GAME
$game = new se_game($user->user_info[user_id]);

// SET RESULT AND ERROR VARS
$result = "";
$is_error = 0;
$show_uploader = 1;
$file_result = Array();

// GET TOTAL SPACE USED
$space_used = $game->game_space();
if($user->level_info[level_game_storage]) {
  $space_left = $user->level_info[level_game_storage] - $space_used;
} else {
  $space_left = ( $dfs=disk_free_space("/") ? $dfs : pow(2, 32) );
} 



// UPLOAD FILES
if($task == "doupload") {
  $isAjax = $_POST['isAjax'];
  $file_result = Array();

  // WORKAROUND FOR FLASH UPLOADER
  if($_FILES['file1']['type'] == "application/octet-stream" && $isAjax) { 
    $file_types = explode(",", str_replace(" ", "", strtolower($user->level_info[level_game_mimes])));
    $_FILES['file1']['type'] = $file_types[0];
  }

  // RUN FILE UPLOAD FUNCTION FOR EACH SUBMITTED FILE
  $update_game = 0;
  $new_game_cover = "";
  $action_media = Array();
  for($f=1;$f<6;$f++) {
    $fileid = "file".$f;
    if($_FILES[$fileid]['name'] != "") {
      $file_result[$fileid] = $game->game_game_media_upload($fileid, $game_id, $space_left);
      if($file_result[$fileid]['is_error'] == 0) {
  	$file_result[$fileid]['message'] = 11000086;
	$new_game_cover = $file_result[$fileid]['game_media_id'];
	$game_media_path = $url->url_base.substr($url->url_userdir($user->user_info[user_id]), 2).$file_result[$fileid]['game_media_id']."_thumb.jpg";
	if(file_exists(substr($url->url_userdir($user->user_info[user_id]), 2).$file_result[$fileid]['game_media_id']."_thumb.jpg")) { 
          $game_media_width = $misc->photo_size($game_media_path, "100", "100", "w");
          $game_media_height = $misc->photo_size($game_media_path, "100", "100", "h");
          $action_media[] = Array('game_media_link' => $url->url_create('game_file', $user->user_info[user_username], $game_id, $file_result[$fileid]['game_media_id']),
				'game_media_path' => $game_media_path,
				'game_media_width' => $game_media_width,
				'game_media_height' => $game_media_height);
	} 
        $update_game = 1;
      } else {
  	$file_result[$fileid]['message'] = $file_result[$fileid]['is_error'];
      }
      SE_Language::_preload($file_result[$fileid]['message']);
    }
  }

  // UPDATE GAME UPDATED DATE AND GAME COVER IF FILE UPLOADED
  if($update_game) {
    $newdate = time();
    if($game_info[game_cover] != 0) { $new_game_cover = $game_info[game_cover]; }
    $database->database_query("UPDATE se_games SET game_cover='$new_game_cover', game_dateupdated='$newdate' WHERE game_id='$game_id'");

    // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
    $user->user_lastupdate();

    // INSERT ACTION
    $game_title = $game_info[game_title];
    if(strlen($game_title) > 100) { $game_title = substr($game_title, 0, 97)."..."; }
    $actions->actions_add($user, "newgame_media", Array($user->user_info[user_username], $user->user_displayname, $game_id, $game_title), $action_media, 60, FALSE, "user", $user->user_info[user_id], $game_info[game_privacy]);
  }

  // OUTPUT JSON RESULT
  if($isAjax) {
    SE_Language::load();
    if($update_game) {
      $result = "success"; 
      $size = sprintf(SE_Language::_get($file_result['file1']['message']), $file_result['file1']['file_name']);
      $error = null; 
    } else {
      $result = "failure";
      $error = sprintf(SE_Language::_get($file_result['file1']['message']), $file_result['file1']['file_name']);
      $size = null;
    }
    $json = '{"result":"'.$result.'","error":"'.$error.'","size":"'.$size.'"}';
    if(!headers_sent()) { header('Content-type: application/json'); }
    echo $json;
    exit();

  // SHOW PAGE WITH RESULTS
  } else {
   $show_uploader = 0;
  }

} // END TASK



// FIND OUT IF GAME WAS JUST CREATED
if(isset($_GET['new_game']) AND $_GET['new_game'] == 1) { $new_game = 1; } else { $new_game = 0; }

// GET MAX FILESIZE ALLOWED
$max_filesize_kb = ($user->level_info[level_game_maxsize]) / 1024;
$max_filesize_kb = round($max_filesize_kb, 0);

// CONVERT UPDATED SPACE LEFT TO MB
$space_left_mb = ($space_left / 1024) / 1024;
$space_left_mb = round($space_left_mb, 2);


// START NEW SESSION AND SET SESSION VARS FOR UPLOADER
session_start();
$_SESSION = array();
session_regenerate_id();
$_SESSION['upload_token'] = md5(uniqid(rand(), true));
$_SESSION['action'] = "user_game_upload.php";
$_SESSION['user_id'] = $_COOKIE['user_id'];
$_SESSION['user_email'] = $_COOKIE['user_email'];
$_SESSION['user_password'] = $_COOKIE['user_password'];

// SET INPUTS
$inputs = Array('game_id' => $game_info[game_id]);

// ASSIGN VARIABLES AND SHOW UPLOAD FILES PAGE
$smarty->assign('new_game', $new_game);
$smarty->assign('show_uploader', $show_uploader);
$smarty->assign('session_id', session_id());
$smarty->assign('upload_token', $_SESSION['upload_token']);
$smarty->assign('file_result', $file_result);
$smarty->assign('game_info', $game_info);
$smarty->assign('inputs', $inputs);
$smarty->assign('space_left', $space_left_mb);
$smarty->assign('allowed_exts', str_replace(",", ", ", $user->level_info[level_game_exts]));
$smarty->assign('max_filesize', $max_filesize_kb);
include "footer.php";
?>