<?php
$page = "user_game_settings";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($user->level_info[level_game_allow] == 0) { header("Location: user_home.php"); exit(); }

// SET VARS
$result = 0;
$level_game_profile = explode(",", $user->level_info[level_game_profile]);

// SAVE NEW CSS
if($task == "dosave") {
  $style_game = addslashes(str_replace("-moz-binding", "", strip_tags(htmlspecialchars_decode($_POST['style_game'], ENT_QUOTES))));
  $user_profile_game = $_POST['user_profile_game'];

  // ENSURE USER SELECTED APPROPRIATE OPTION
  if(!in_array($user_profile_game, $level_game_profile)) { $user_profile_game = $level_game_profile[0]; }

  $database->database_query("UPDATE se_gamestyles SET gamestyle_css='$style_game' WHERE gamestyle_user_id='".$user->user_info[user_id]."'");
  $database->database_query("UPDATE se_users SET user_profile_game='$user_profile_game' WHERE user_id='".$user->user_info[user_id]."'");
  $user->user_lastupdate();
  $user->user_info[user_profile_game] = $user_profile_game;
  $result = 1;
}



// GET THIS USER'S GAME CSS
$style_query = $database->database_query("SELECT gamestyle_css FROM se_gamestyles WHERE gamestyle_user_id='".$user->user_info[user_id]."' LIMIT 1");
if($database->database_num_rows($style_query) == 1) { 
  $style_info = $database->database_fetch_assoc($style_query); 
} else {
  $database->database_query("INSERT INTO se_gamestyles (gamestyle_user_id, gamestyle_css) VALUES ('".$user->user_info[user_id]."', '')");
  $style_info = $database->database_fetch_assoc($database->database_query("SELECT gamestyle_css FROM se_gamestyles WHERE gamestyle_user_id='".$user->user_info[user_id]."' LIMIT 1")); 
}

// ENSURE PROFILE LOCATION IS ALLOWED
if(!in_array($user->user_info[user_profile_game], $level_game_profile)) { $user->user_info[user_profile_game] = $level_game_profile[0]; }

// ASSIGN SMARTY VARIABLES AND DISPLAY GAME STYLE PAGE
$smarty->assign('result', $result);
$smarty->assign('level_game_profile', $level_game_profile);
$smarty->assign('style_game', htmlspecialchars($style_info[gamestyle_css], ENT_QUOTES, 'UTF-8'));
include "footer.php";
?>