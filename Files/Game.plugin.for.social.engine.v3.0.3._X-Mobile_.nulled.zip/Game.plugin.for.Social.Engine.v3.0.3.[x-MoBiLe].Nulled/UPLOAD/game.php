<?php
$page = "game";
include "header.php";

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_game] == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if($owner->user_exists == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($owner->level_info[level_game_allow] == 0) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

if(isset($_POST['p'])) { $p = $_POST['p']; } elseif(isset($_GET['p'])) { $p = $_GET['p']; } else { $p = 1; }
if(isset($_GET['game_id'])) { $game_id = $_GET['game_id']; } else { $game_id = 0; }


// SET VARS
$game_media_per_page = 20;


// IF GAME ID IS 0, GET TAGGED PHOTOS OF OWNER
if($game_id == 0) {

  // SET GAME VARS
  $game_info[game_id] = 0;

  // CHECK PRIVACY
  $privacy_max = $owner->user_privacy_max($user);
  if(!($owner->user_info[user_privacy] & $privacy_max)) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

  // CREATE GAME OBJECT
  $game = new se_game();

  // SET WHERE/SORTBY
  $where = "(game_media_id IN (SELECT game_mediatag_game_media_id FROM se_game_mediatags WHERE game_mediatag_user_id={$owner->user_info[user_id]}))";
  $sortby = "game_mediatag_id DESC";
  $select = ", (SELECT game_mediatag_id FROM se_game_mediatags WHERE game_mediatag_user_id={$owner->user_info[user_id]} AND game_mediatag_game_media_id=se_game_media.game_media_id ORDER BY game_mediatag_id DESC LIMIT 1) AS game_mediatag_id";


// OTHERWISE BE SURE GAME BELONGS TO THIS USER
} else {

  // GET GAME INFO
  $game_query = $database->database_query("SELECT * FROM se_games WHERE game_id='$game_id' AND game_user_id='".$owner->user_info[user_id]."'");
  if($database->database_num_rows($game_query) != 1) { header("Location: ".$url->url_create('games', $owner->user_info[user_username])); exit(); }
  $game_info = $database->database_fetch_assoc($game_query);

  // CREATE GAME OBJECT
  $game = new se_game($owner->user_info[user_id]);

  // SET WHERE/SORTBY
  $where = "(game_media_game_id='$game_info[game_id]')";
  $sortby = "game_media_order ASC";
  $select = "";

  // GET CUSTOM GAME STYLE IF ALLOWED
  if($owner->level_info[level_game_style] != 0) {
    $gamestyle_info = $database->database_fetch_assoc($database->database_query("SELECT gamestyle_css FROM se_gamestyles WHERE gamestyle_user_id='".$owner->user_info[user_id]."' LIMIT 1"));
    $global_css = $gamestyle_info[gamestyle_css];
  }

  // CHECK PRIVACY
  $privacy_max = $owner->user_privacy_max($user);
  if(!($game_info[game_privacy] & $privacy_max)) {
    $page = "error";
    $smarty->assign('error_header', 639);
    $smarty->assign('error_message', 11000125);
    $smarty->assign('error_submit', 641);
    include "footer.php";
  }

  // UPDATE GAME VIEWS
  if($user->user_info[user_id] != $owner->user_info[user_id]) {
    $game_views_new = $game_info[game_views] + 1;
    $database->database_query("UPDATE se_games SET game_views='$game_views_new' WHERE game_id='$game_info[game_id]' LIMIT 1");
  }

}


// GET TOTAL FILES IN GAME
$total_files = $game->game_files($game_info[game_id], $where);

// MAKE GAME MEDIA PAGES
$page_vars = make_page($total_files, $game_media_per_page, $p);

// GET GAME MEDIA ARRAY
$file_array = $game->game_game_media_list($page_vars[0], $game_media_per_page, $sortby, $where, $select);

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 11000155;
$global_page_title[1] = $owner->user_displayname;
$global_page_title[2] = $game_info[game_title];
$global_page_description[0] = 11000156;
$global_page_description[1] = $game_info[game_desc];

// ASSIGN VARIABLES AND DISPLAY GAME PAGE
$smarty->assign('game_info', $game_info);
$smarty->assign('files', $file_array);
$smarty->assign('total_files', $total_files);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('maxpage', $page_vars[2]);
$smarty->assign('p_start', $page_vars[0]+1);
$smarty->assign('p_end', $page_vars[0]+count($file_array));
include "footer.php";
?>