<?php
$page = "user_game_update";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_GET['game_id'])) { $game_id = $_GET['game_id']; } elseif(isset($_POST['game_id'])) { $game_id = $_POST['game_id']; } else { $game_id = 0; }

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($user->level_info[level_game_allow] == 0) { header("Location: user_home.php"); exit(); }

// BE SURE GAME BELONGS TO THIS USER
$game = $database->database_query("SELECT * FROM se_games WHERE game_id='$game_id' AND game_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($game) != 1) { header("Location: user_game.php"); exit(); }
$game_info = $database->database_fetch_assoc($game);


// SET VARS
$result = 0;
$game = new se_game($user->user_info[user_id]);



// ROTATE
if($task == "rotate") {
  $game_media_id = $_GET['game_media_id'];
  $dir = $_GET['dir'];

  if($dir == "cc") { $dir = 90; } else { $dir = 270; }

  // ROTATE IMAGE
  $game->game_game_media_rotate($game_media_id, $dir);

  // SET THUMBPATH
  $thumb_path = $url->url_userdir($user->user_info[user_id]).$game_media_id."_thumb.jpg?".rand();

  // SEND AJAX CONFIRMATION
  echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type='text/javascript'>";
  echo "var img = window.parent.document.getElementById('file_$game_media_id');";
  echo "img.src = '$thumb_path';";
  echo "</script></head><body></body></html>";
  exit();




// UPDATE FILES IN THIS GAME
} elseif($task == "doupdate") {

  // GET TOTAL FILES
  $total_files = $game->game_files($game_info[game_id]);

  // DELETE NECESSARY FILES
  $game->game_game_media_delete(0, $total_files, "game_media_id ASC", "(game_media_game_id='$game_info[game_id]')");

  // UPDATE NECESSARY FILES
  $game_media_array = $game->game_game_media_update(0, $total_files, "game_media_id ASC", "(game_media_game_id='$game_info[game_id]')");

  // SET GAME COVER AND UPDATE DATE
  $newdate = time();
  $game_info[game_cover] = $_POST['game_cover'];
  if(!in_array($game_info[game_cover], $game_media_array)) { $game_info[game_cover] = $game_media_array[0]; }
  $database->database_query("UPDATE se_games SET game_cover='$game_info[game_cover]', game_dateupdated='$newdate' WHERE game_id='$game_info[game_id]'");

  // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
  $user->user_lastupdate();

  // SHOW SUCCESS MESSAGE
  $result = 1;



// MOVE GAME MEDIA UP
} elseif($task == "moveup") {
  $game_media_id = $_GET['game_media_id'];

  $game_media_query = $database->database_query("SELECT game_media_id, game_media_order, game_media_game_id FROM se_game_media LEFT JOIN se_games ON se_game_media.game_media_game_id=se_games.game_id WHERE game_media_id='$game_media_id' AND se_games.game_user_id='".$user->user_info[user_id]."'");
  if($database->database_num_rows($game_media_query) == 1) { 

    $game_media_info = $database->database_fetch_assoc($game_media_query);

    $prev_query = $database->database_query("SELECT game_media_id, game_media_order FROM se_game_media LEFT JOIN se_games ON se_game_media.game_media_game_id=se_games.game_id WHERE se_game_media.game_media_game_id='$game_media_info[game_media_game_id]' AND se_games.game_user_id='".$user->user_info[user_id]."' AND game_media_order<$game_media_info[game_media_order] ORDER BY game_media_order DESC LIMIT 1");
    if($database->database_num_rows($prev_query) == 1) {

      $prev_info = $database->database_fetch_assoc($prev_query);

      // SWITCH ORDER
      $database->database_query("UPDATE se_game_media SET game_media_order=$prev_info[game_media_order] WHERE game_media_id=$game_media_info[game_media_id]");
      $database->database_query("UPDATE se_game_media SET game_media_order=$game_media_info[game_media_order] WHERE game_media_id=$prev_info[game_media_id]");

      // SEND AJAX CONFIRMATION
      echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type='text/javascript'>";
      echo "window.parent.reorderMedia('$game_media_info[game_media_id]', '$prev_info[game_media_id]');";
      echo "</script></head><body></body></html>";
      exit();

    } 
  }
}




// SHOW FILES IN THIS GAME
$total_files = $game->game_files($game_info[game_id]);
$file_array = $game->game_game_media_list(0, $total_files, "game_media_order ASC", "(game_media_game_id='$game_info[game_id]')");


// GET LIST OF OTHER GAMES
$total_games = $game->game_total("game_id<>'$game_info[game_id]'");
$game_array = $game->game_list(0, $total_games, "game_order ASC", "game_id<>'$game_info[game_id]'");


// ASSIGN VARIABLES AND SHOW UDPATE GAMES PAGE
$smarty->assign('result', $result);
$smarty->assign('files', $file_array);
$smarty->assign('files_total', $total_files);
$smarty->assign('game_info', $game_info);
$smarty->assign('games', $game_array);
$smarty->assign('games_total', $total_games);
include "footer.php";
?>