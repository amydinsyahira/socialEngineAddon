<?php
$page = "games";
include "header.php";

// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_game] == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if($owner->user_exists == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($owner->level_info[level_game_allow] == 0) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }


// SET PRIVACY LEVEL AND WHERE CLAUSE
$privacy_max = $owner->user_privacy_max($user);
$where = "(game_privacy & $privacy_max)";


// CREATE GAME OBJECT
$game = new se_game($owner->user_info[user_id]);

// GET TOTAL GAMES
$total_games = $game->game_total($where);

// GET GAME ARRAY
$game_array = $game->game_list(0, $total_games, "game_order ASC", $where);

// GET CUSTOM GAME STYLE IF ALLOWED
if($owner->level_info[level_game_style] != 0) {
  $gamestyle_info = $database->database_fetch_assoc($database->database_query("SELECT gamestyle_css FROM se_gamestyles WHERE gamestyle_user_id='".$owner->user_info[user_id]."' LIMIT 1"));
  $global_css = $gamestyle_info[gamestyle_css];
}

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 11000160;
$global_page_title[1] = $owner->user_displayname;
$global_page_description[0] = 11000161;
$global_page_description[1] = $owner->user_displayname;

// ASSIGN SMARTY VARIABLES AND DISPLAY GAMES PAGE
$smarty->assign('games', $game_array);
$smarty->assign('total_games', $total_games);
include "footer.php";
?>