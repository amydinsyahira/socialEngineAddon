<?php
$page = "user_game_edit";
include "header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_GET['game_id'])) { $game_id = $_GET['game_id']; } elseif(isset($_POST['game_id'])) { $game_id = $_POST['game_id']; } else { exit(); }

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($user->level_info[level_game_allow] == 0) { header("Location: user_home.php"); exit(); }

// BE SURE GAME BELONGS TO THIS USER
$game = $database->database_query("SELECT * FROM se_games WHERE game_id='$game_id' AND game_user_id='".$user->user_info[user_id]."'");
if($database->database_num_rows($game) != 1) { header("Location: user_game.php"); exit(); }
$game_info = $database->database_fetch_assoc($game);

// SET VARIABLES
$result = 0;
$is_error = 0;


// GET PRIVACY SETTINGS
$level_game_privacy = unserialize($user->level_info[level_game_privacy]);
rsort($level_game_privacy);
$level_game_comments = unserialize($user->level_info[level_game_comments]);
rsort($level_game_comments);
$level_game_tag = unserialize($user->level_info[level_game_tag]);
rsort($level_game_tag);


// SAVE NEW INFO
if($task == "dosave") {
  $game_info[game_title] = censor($_POST['game_title']);
  $game_info[game_desc] = censor(str_replace("\r\n", "<br>", $_POST['game_desc']));
  $game_info[game_search] = $_POST['game_search'];
  $game_info[game_privacy] = $_POST['game_privacy'];
  $game_info[game_comments] = $_POST['game_comments'];
  $game_info[game_tag] = $_POST['game_tag'];
  $game_info[game_dateupdated] = time();


  // MAKE SURE SUBMITTED PRIVACY OPTIONS ARE ALLOWED, IF NOT, SET TO EVERYONE
  if(!in_array($game_info[game_privacy], $level_game_privacy)) { $game_info[game_privacy] = $level_game_privacy[0]; }
  if(!in_array($game_info[game_comments], $level_game_comments)) { $game_info[game_comments] = $level_game_comments[0]; }
  if(!in_array($game_info[game_tag], $level_game_tag)) { $game_info[game_tag] = $level_game_tag[0]; }

  // CHECK THAT TITLE IS NOT BLANK
  if(trim($game_info[game_title]) == "") { $is_error = 11000073; }

  // IF NO ERROR, CONTINUE
  if($is_error == 0) {

    // EDIT GAME IN DATABASE
    $database->database_query("UPDATE se_games SET game_title='$game_info[game_title]',
				    game_desc='$game_info[game_desc]',
				    game_search='$game_info[game_search]',
				    game_privacy='$game_info[game_privacy]',
				    game_comments='$game_info[game_comments]',
				    game_tag='$game_info[game_tag]',
				    game_dateupdated='$game_info[game_dateupdated]' WHERE game_id='$game_info[game_id]'");

    // UPDATE LAST UPDATE DATE (SAY THAT 10 TIMES FAST)
    $user->user_lastupdate();

    $result = 1;
  }
}




// GET PREVIOUS PRIVACY SETTINGS
for($c=0;$c<count($level_game_privacy);$c++) {
  if(user_privacy_levels($level_game_privacy[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_privacy[$c]));
    $privacy_options[$level_game_privacy[$c]] = user_privacy_levels($level_game_privacy[$c]);
  }
}

for($c=0;$c<count($level_game_comments);$c++) {
  if(user_privacy_levels($level_game_comments[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_comments[$c]));
    $comment_options[$level_game_comments[$c]] = user_privacy_levels($level_game_comments[$c]);
  }
}

for($c=0;$c<count($level_game_tag);$c++) {
  if(user_privacy_levels($level_game_tag[$c]) != "") {
    SE_Language::_preload(user_privacy_levels($level_game_tag[$c]));
    $tag_options[$level_game_tag[$c]] = user_privacy_levels($level_game_tag[$c]);
  }
}

// RESTORE LINE BREAKS
$game_info[game_desc] = str_replace("<br>", "\r\n", $game_info[game_desc]);

// ASSIGN VARIABLES AND SHOW EDIT GAMES PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('game_info', $game_info);
$smarty->assign('privacy_options', $privacy_options);
$smarty->assign('comment_options', $comment_options);
$smarty->assign('tag_options', $tag_options);
include "footer.php";
?>