<?php
$page = "game_file";
include "header.php";


// DISPLAY ERROR PAGE IF USER IS NOT LOGGED IN AND ADMIN SETTING REQUIRES REGISTRATION
if($user->user_exists == 0 && $setting[setting_permission_game] == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 656);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// DISPLAY ERROR PAGE IF NO OWNER
if($owner->user_exists == 0) {
  $page = "error";
  $smarty->assign('error_header', 639);
  $smarty->assign('error_message', 828);
  $smarty->assign('error_submit', 641);
  include "footer.php";
}

// ENSURE GAMES ARE ENABLED FOR THIS USER
if($owner->level_info[level_game_allow] == 0) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

if(isset($_POST['task'])) { $task = $_POST['task']; } elseif(isset($_GET['task'])) { $task = $_GET['task']; } else { $task = "main"; }
if(isset($_POST['game_media_id'])) { $game_media_id = $_POST['game_media_id']; } elseif(isset($_GET['game_media_id'])) { $game_media_id = $_GET['game_media_id']; } else { $game_media_id = 0; }
if(isset($_POST['game_id'])) { $game_id = $_POST['game_id']; } elseif(isset($_GET['game_id'])) { $game_id = $_GET['game_id']; } else { $game_id = ""; }

// MAKE SURE GAME MEDIA EXISTS
$game_media_query = $database->database_query("SELECT * FROM se_game_media WHERE game_media_id='$game_media_id' LIMIT 1");
if($database->database_num_rows($game_media_query) != 1) { header("Location: ".$url->url_create('games', $owner->user_info[user_username])); exit(); }
$game_media_info = $database->database_fetch_assoc($game_media_query);


// IF GAME ID IS 0, ENSURE THIS PHOTO HAS OWNER IN TAG
if($game_id == "0") {

  // BE SURE THIS IMAGE HAS A TAG OF OWNER
  if($database->database_num_rows($database->database_query("SELECT game_mediatag_id FROM se_game_mediatags WHERE game_mediatag_game_media_id=$game_media_info[game_media_id] AND game_mediatag_user_id={$owner->user_info[user_id]} LIMIT 1")) != 1) { header("Location: ".$url->url_create('game', $owner->user_info[user_username], 0)); exit(); }

  // CHECK PRIVACY
  $privacy_max = $owner->user_privacy_max($user);
  if(!($owner->user_info[user_privacy] & $privacy_max)) { header("Location: ".$url->url_create('profile', $owner->user_info[user_username])); exit(); }

  // GET REAL GAME/OWNER INFO
  $game_info = $database->database_fetch_assoc($database->database_query("SELECT * FROM se_games WHERE game_id='$game_media_info[game_media_game_id]'"));
  $game_info[game_id] = 0;
  $game_owner_info = $database->database_fetch_assoc($database->database_query("SELECT user_id, user_username, user_fname, user_lname, user_level_id FROM se_users WHERE user_id={$game_info[game_user_id]}"));
  $game_owner = new se_user();
  $game_owner->user_exists = 1;
  $game_owner->user_info[user_id] = $game_owner_info[user_id];
  $game_owner->user_info[user_username] = $game_owner_info[user_username];
  $game_owner->user_info[user_fname] = $game_owner_info[user_fname];
  $game_owner->user_info[user_lname] = $game_owner_info[user_lname];
  $game_owner->user_displayname();
  $game_owner->level_info = $database->database_fetch_assoc($database->database_query("SELECT level_id, level_game_width FROM se_levels WHERE level_id={$game_owner_info[user_level_id]}"));
  
  // GET GAME MEDIA IN GAME FOR CAROUSEL
  $game_media_array = Array();
  $game_media_query = $database->database_query("SELECT game_media_id, game_media_ext, game_user_id FROM se_game_mediatags LEFT JOIN se_game_media ON se_game_mediatags.game_mediatag_game_media_id=se_game_media.game_media_id LEFT JOIN se_games ON se_game_media.game_media_game_id=se_games.game_id WHERE game_mediatag_user_id='{$owner->user_info[user_id]}' ORDER BY game_mediatag_id DESC");
  while($thisgame_media = $database->database_fetch_assoc($game_media_query)) { $game_media_array[$thisgame_media[game_media_id]] = $thisgame_media; }




// OTHERWISE BE SURE GAME BELONGS TO THIS USER
} else {


  // BE SURE GAME BELONGS TO THIS USER
  $game = $database->database_query("SELECT * FROM se_games WHERE game_id='$game_media_info[game_media_game_id]' AND game_user_id='".$owner->user_info[user_id]."'");
  if($database->database_num_rows($game) != 1) { header("Location: ".$url->url_create('games', $owner->user_info[user_username])); exit(); }
  $game_info = $database->database_fetch_assoc($game);

  // CHECK PRIVACY
  $privacy_max = $owner->user_privacy_max($user);
  if(!($game_info[game_privacy] & $privacy_max)) {
    $page = "error";
    $smarty->assign('error_header', 639);
    $smarty->assign('error_message', 11000125);
    $smarty->assign('error_submit', 641);
    include "footer.php";
  }

  // SET GAME OWNER
  $game_owner = $owner;

  // GET CUSTOM GAME STYLE IF ALLOWED
  if($owner->level_info[level_game_style] != 0) {
    $gamestyle_info = $database->database_fetch_assoc($database->database_query("SELECT gamestyle_css FROM se_gamestyles WHERE gamestyle_user_id='".$owner->user_info[user_id]."' LIMIT 1"));
    $global_css = $gamestyle_info[gamestyle_css];
  }

  // GET GAME MEDIA IN GAME FOR CAROUSEL
  $game_media_array = Array();
  $game_media_query = $database->database_query("SELECT game_media_id, game_media_ext, '{$owner->user_info[user_id]}' AS game_user_id FROM se_game_media WHERE game_media_game_id='$game_info[game_id]' ORDER BY game_media_order ASC");
  while($thisgame_media = $database->database_fetch_assoc($game_media_query)) { $game_media_array[$thisgame_media[game_media_id]] = $thisgame_media; }

}




// GET GAME MEDIA WIDTH/HEIGHT
$game_mediasize = @getimagesize($url->url_userdir($game_owner->user_info[user_id]).$game_media_info[game_media_id].'.'.$game_media_info[game_media_ext]);
$game_media_info[game_media_width] = $game_mediasize[0];
$game_media_info[game_media_height] = $game_mediasize[1];


// GET GAME TAG PRIVACY
$allowed_to_tag = 1;
if(!($privacy_max & $game_info[game_tag])) { $allowed_to_tag = 0; }

// GET GAME COMMENT PRIVACY
$allowed_to_comment = 1;
if(!($privacy_max & $game_info[game_comments])) { $allowed_to_comment = 0; }





// TAG PHOTO
if($task == "tag") {
  $game_mediatag_user_id = $_GET['game_mediatag_user_id'];
  $game_mediatag_text = $_GET['game_mediatag_text'];
  $game_mediatag_x = $_GET['game_mediatag_x'];
  $game_mediatag_y = $_GET['game_mediatag_y'];
  $game_mediatag_height = $_GET['game_mediatag_height'];
  $game_mediatag_width = $_GET['game_mediatag_width'];

  // GET TAGGED USER
  $tagged_query = $database->database_query("SELECT user_id, user_username, user_email, user_fname, user_lname, user_privacy FROM se_users WHERE user_id='$game_mediatag_user_id'");
  if($database->database_num_rows($tagged_query) == 1) {
    $tagged = $database->database_fetch_assoc($tagged_query);

    $taggeduser = new se_user();
    $taggeduser->user_exists = 1;
    $taggeduser->user_info[user_id] = $tagged[user_id];
    $taggeduser->user_info[user_username] = $tagged[user_username];
    $taggeduser->user_info[user_email] = $tagged[user_email];
    $taggeduser->user_info[user_fname] = $tagged[user_fname];
    $taggeduser->user_info[user_lname] = $tagged[user_lname];
    $taggeduser->user_info[user_privacy] = $tagged[user_privacy];
    $taggeduser->user_displayname();

    $game_mediatag_user_username = $tagged[user_username];
    $game_mediatag_link = $url->url_create("profile", $tagged[user_username]);
    $game_mediatag_text = $taggeduser->user_displayname;
  } elseif(trim($game_mediatag_text) != "") {
    $game_mediatag_text = substr($game_mediatag_text, 0, 40);
    $game_mediatag_link = "";
    $game_mediatag_user_id = 0;
    $game_mediatag_user_username = "";
  } else {
    $is_error = 1;
  }

  // VALIDATE TAG HEIGHT AND WIDTH BASED ON IMAGE SIZE
  if($game_mediatag_x+$game_mediatag_height > $game_media_info[game_media_height]) { $game_mediatag_x = $game_mediatag_x-(($game_mediatag_x+$game_mediatag_height)-$game_media_info[game_media_height]); }
  if($game_mediatag_y+$game_mediatag_width > $game_media_info[game_media_width]) { $game_mediatag_y = $game_mediatag_y-(($game_mediatag_y+$game_mediatag_width)-$game_media_info[game_media_width]); }


  // CHECK TO ENSURE THIS USER CAN TAG
  if($allowed_to_tag == 0) { $is_error = 1; }

  // NO ERROR
  if($is_error == 0) {

    $database->database_query("INSERT INTO se_game_mediatags (game_mediatag_game_media_id, game_mediatag_user_id, game_mediatag_x, game_mediatag_y, game_mediatag_height, game_mediatag_width, game_mediatag_text) VALUES ('$game_media_info[game_media_id]', '$game_mediatag_user_id', '$game_mediatag_x', '$game_mediatag_y', '$game_mediatag_height', '$game_mediatag_width', '$game_mediatag_text')");
    $game_mediatag_id = $database->database_insert_id();

    // SET OBJECT TITLE
    $object_title = $game_media_info[game_media_title];
    if($object_title == "") {
      SE_Language::_preload(589);
      SE_Language::load();
      $object_title = SE_Language::_get(589);
    }

    // SEND NOTIFICATION TO OWNER
    if($game_owner->user_info[user_id] != $user->user_info[user_id]) {
      $notify->notify_add($game_owner->user_info[user_id], 'game_mediatag', $game_media_info[game_media_id], Array($game_owner->user_info[user_username], $game_media_info[game_media_id]), Array($object_title));
      $game_owner->user_settings();
      if($game_owner->usersetting_info[usersetting_notify_game_mediatag]) { send_systememail('game_mediatag', $game_owner->user_info[user_email], Array($game_owner->user_displayname, $user->user_displayname, "<a href=\"".$url->url_create("game_file", $game_owner->user_info[user_username], $game_media_info[game_media_game_id], $game_media_info[game_media_id])."\">".$url->url_create("game_file", $game_owner->user_info[user_username], $game_media_info[game_media_game_id], $game_media_info[game_media_id])."</a>")); }
    }

    // INSERT ACTION AND SEND NOTIFICATION TO TAGGED USER
    if($taggeduser->user_exists == 1) {
      // ENSURE USER ISN'T ALREADY TAGGED IN THIS PHOTO
      if($database->database_num_rows($database->database_query("SELECT game_mediatag_id FROM se_game_mediatags WHERE game_mediatag_game_media_id={$game_media_info[game_media_id]} AND game_mediatag_user_id={$taggeduser->user_info[user_id]}")) == 1) {
        $game_media_path = $url->url_base.substr($url->url_userdir($game_owner->user_info[user_id]), 2).$game_media_info[game_media_id]."_thumb.jpg";
        $game_media_width = $misc->photo_size($game_media_path, "100", "100", "w");
        $game_media_height = $misc->photo_size($game_media_path, "100", "100", "h");
        $action_game_media[] = Array('game_media_link' => $url->url_create('game_file', $taggeduser->user_info[user_username], 0, $game_media_info[game_media_id]),
				'game_media_path' => $game_media_path,
				'game_media_width' => $game_media_width,
				'game_media_height' => $game_media_height);
        $actions->actions_add($taggeduser, "newtag", Array($taggeduser->user_info[user_username], $taggeduser->user_displayname), $action_media, 600, false, "user", $taggeduser->user_info[user_id], $taggeduser->user_info[user_privacy]);
      }
      if($taggeduser->user_info[user_id] != $game_owner->user_info[user_id] && $taggeduser->user_info[user_id] != $user->user_info[user_id]) {
        $notify->notify_add($taggeduser->user_info[user_id], 'newtag', $game_media_info[game_media_id], Array($taggeduser->user_info[user_username], $game_media_info[game_media_id]), Array($object_title));
        $taggeduser->user_settings();
        if($taggeduser->usersetting_info[usersetting_notify_newtag]) { send_systememail('newtag', $taggeduser->user_info[user_email], Array($taggeduser->user_displayname, "<a href=\"".$url->url_create("game_file", $taggeduser->user_info[user_username], 0, $game_media_info[game_media_id])."\">".$url->url_create("game_file", $taggeduser->user_info[user_username], 0, $game_media_info[game_media_id])."</a>")); }
      }
    }


    // RUN JAVASCRIPT FUNCTION
    echo "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'><script type=\"text/javascript\">";
    echo "window.parent.insertTag('$game_mediatag_id', '$game_mediatag_link', '$game_mediatag_text', '$game_mediatag_x', '$game_mediatag_y', '$game_mediatag_width', '$game_mediatag_height', '".$game_owner->user_info[user_username]."', '$game_media_info[game_media_game_id]', '$game_media_info[game_media_id]', '$game_mediatag_user_username');";
    echo "</script></head><body></body></html>";
    exit();


  // IS ERROR
  } else {
    exit();
  }

// REMOVE TAG
} elseif($task == "tag_remove") {
  $game_mediatag_id = $_GET['game_mediatag_id'];

  // GET GAME MEDIA TAG
  $game_mediatag = $database->database_query("SELECT game_mediatag_id FROM se_game_mediatags LEFT JOIN se_game_media ON se_game_mediatags.game_mediatag_game_media_id=se_game_media.game_media_id LEFT JOIN se_games ON se_game_media.game_media_game_id=se_games.game_id WHERE game_mediatag_id={$game_mediatag_id} AND (game_mediatag_user_id={$user->user_info[user_id]} OR game_user_id={$user->user_info[user_id]})");

  // DELETE TAG
  if($database->database_num_rows($game_mediatag) == 1) {
    $database->database_query("DELETE FROM se_game_mediatags WHERE game_mediatag_game_media_id=$game_media_info[game_media_id] AND game_mediatag_id=$game_mediatag_id");
  }

  exit();

}






// GET GAME MEDIA COMMENTS
$comment = new se_comment('game_media', 'game_media_id', $game_media_info[game_media_id]);
$total_comments = $comment->comment_total();

// UPDATE GAME VIEWS
if($user->user_info[user_id] != $game_owner->user_info[user_id] && $game_info[game_id] != 0) {
  $game_views_new = $game_info[game_views] + 1;
  $database->database_query("UPDATE se_games SET game_views='$game_views_new' WHERE game_id='$game_info[game_id]' LIMIT 1");
}

// UPDATE NOTIFICATIONS
if($user->user_info[user_id] == $owner->user_info[user_id]) {
  $database->database_query("DELETE FROM se_notifys USING se_notifys LEFT JOIN se_notifytypes ON se_notifys.notify_notifytype_id=se_notifytypes.notifytype_id WHERE se_notifys.notify_user_id='".$owner->user_info[user_id]."' AND (se_notifytypes.notifytype_name='game_mediacomment' OR se_notifytypes.notifytype_name='game_mediatag' OR se_notifytypes.notifytype_name='newtag') AND notify_object_id='".$game_media_info[game_media_id]."'");
}



// RETRIEVE TAGS FOR THIS PHOTO
$tag_array = Array();
$tags = $database->database_query("SELECT se_game_mediatags.*, se_users.user_id, se_users.user_username, se_users.user_fname, se_users.user_lname FROM se_game_mediatags LEFT JOIN se_users ON se_game_mediatags.game_mediatag_user_id=se_users.user_id WHERE game_mediatag_game_media_id='$game_media_info[game_media_id]' ORDER BY game_mediatag_id ASC");
while($tag = $database->database_fetch_assoc($tags)) { 

  $taggeduser = new se_user();
  if($tag[user_id] != NULL) {
    $taggeduser->user_exists = 1;
    $taggeduser->user_info[user_id] = $tag[user_id];
    $taggeduser->user_info[user_username] = $tag[user_username];
    $taggeduser->user_info[user_fname] = $tag[user_fname];
    $taggeduser->user_info[user_lname] = $tag[user_lname];
    $taggeduser->user_displayname();
  } else {
    $taggeduser->user_exists = 0;
  }

  $tag[tagged_user] = $taggeduser;
  $tag_array[] = $tag; 
}

// SET GLOBAL PAGE TITLE
$global_page_title[0] = 11000158;
$global_page_title[1] = $owner->user_displayname;
$global_page_title[2] = $game_media_info[game_media_title];
$global_page_description[0] = 11000159;
$global_page_description[1] = $game_media_info[game_media_desc];

// ASSIGN VARIABLES AND DISPLAY GAME FILE PAGE
$smarty->assign('game_owner', $game_owner);
$smarty->assign('game_info', $game_info);
$smarty->assign('game_media_info', $game_media_info);
$smarty->assign('total_comments', $total_comments);
$smarty->assign('allowed_to_comment', $allowed_to_comment);
$smarty->assign('allowed_to_tag', $allowed_to_tag);
$smarty->assign('game_media', $game_media_array);
$smarty->assign('game_media_keys', array_keys($game_media_array));
$smarty->assign('tags', $tag_array);
include "footer.php";
?>