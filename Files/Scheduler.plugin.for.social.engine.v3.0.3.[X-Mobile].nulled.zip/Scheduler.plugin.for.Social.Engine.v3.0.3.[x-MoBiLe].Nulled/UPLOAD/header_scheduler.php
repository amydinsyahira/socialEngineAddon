<?php

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE SEMODS CLASS FILE
include_once "./include/class_semods.php";

// INCLUDE CLASS FILE
//include_once "./include/class_scheduler.php";

// INCLUDE FUNCTIONS FILE
include_once "./include/functions_scheduler.php";


?>