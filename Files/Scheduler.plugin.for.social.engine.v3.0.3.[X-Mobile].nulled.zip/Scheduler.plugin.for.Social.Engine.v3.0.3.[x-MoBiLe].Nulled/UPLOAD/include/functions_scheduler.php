<?php

$scheduler_log_buffer = '';
$scheduler_log_has_errors = false;






/*********************** CRONTAB FUNCTIONS *********************/


function scheduler_find_php_binary() {
  $binaries = array(  '/usr/local/php5/bin/php5', // hostgator
                      '/usr/local/php/bin/php',
                      '/usr/bin/php5',
                      '/usr/bin/php',
                      '/usr/local/bin/php'
                    );

  // find php executable
  
  // pass 1 - test if file exists and has valid strings (php5)
  foreach($binaries as $binary) {
    if( @file_exists( $binary ) ) {

      // check if it's php5. if result is empty array => it's not php5
      exec( "strings $binary | grep 'PHP 5'", $result );
      if(empty($result))
        continue;

      // found the beast
      return $binary;
    
    //  break;
    }
  }

  // pass 2 - test if file exists
  foreach($binaries as $binary) {
    if( file_exists( $binary ) ) {
      // found the beast
      return $binary;
      break;
    }
  }

  return '';
}


// returns
// 1 - couldn't find php binary
// 0 - all ok
function scheduler_guess_crontab_line(&$crontab_line, $caller_script = __FILE__) {
  $result = 0;
  $php5_binary = scheduler_find_php_binary();

  if(empty($php5_binary)) {
    $php5_binary = 'please_enter_path_to_php_binary';
    $result = 1;
  }
  
  $basedir = dirname($caller_script);
  $crontab_line = $php5_binary . ' -q ' . $basedir . '/semods_scheduler.php';
  
  return $result;
}









function scheduler_send_log() {
  global $scheduler_log_has_errors;
  global $scheduler_log_buffer;
  
  if(empty($scheduler_log_buffer))
    return;
  
  if($scheduler_log_has_errors) {
    
    if (semods::get_setting('crontab_notify_on_error')) {
      scheduler_send_note_to_admin( 'Background Job - Notification of ERRORS', $scheduler_log_buffer );
    }
    
  } else {

    if (semods::get_setting('crontab_notify_on_success')) {
      scheduler_send_note_to_admin( 'Background Job - Notification of success', $scheduler_log_buffer );
    }
    
  }
  
  echo $scheduler_log_buffer . "\n";
  
  $scheduler_log_buffer = '';
  $scheduler_log_has_errors = false;
}



function scheduler_log($message, $failure = false) {
  global $scheduler_log_buffer, $scheduler_log_has_errors;
  
  $scheduler_log_buffer .= $message . "\n";
  
  if($failure)
    $scheduler_log_has_errors = true;
}



function scheduler_log_error($message) {
  scheduler_log_log($message, true);
}



class semods_scheduler {

  var $errMsg;
  var $errID;
  
  
  // PROXY !? SSL ?!
  function scheduler_exec_url( $url, $params ) {
    
    // url MUST have scheme
    
    $start = strpos( $url, '//' ) + 2;
    $end = strpos( $url, '/', $start );
    $host = substr( $url, $start, $end - $start );
    $post_path = substr( $url, $end );
    // TBD: "ssl://" . 
    $fp = fsockopen( $host, 80, $errno, $errstr );
    if (!$fp) {
      $this->errMsg = 'HTTP Error';
      $this->errID = 1;
      return null;
    }
    fputs( $fp, "POST $post_path HTTP/1.0\n" .
                "Host: $host\n" . 
                'User-Agent: ContactsImporter API PHP4 Client 0.3 (non-curl) '. phpversion() . "\n" . 
                "Content-Type: application/x-www-form-urlencoded\n" .
                "Content-Length: " . strlen($data) . "\n\n" . 
                "$data\n\n" );
    $response = '';
    while(!feof($fp)) {
        $response .= fgets($fp, 4096);
    }
    fclose ($fp);
    // get response code
    preg_match( '/^\S+\s(\S+)/', $response, $matches );
    if( $matches[1] != "200" ) {
      $this->errMsg = 'HTTP Error';
      $this->errID = 1;
      return null;
    }
    // get response body
    preg_match( '/\r?\n\r?\n(.*?)$/sD', $response, $matches );
    $response = $matches[1];
    return $response;
  }
  
  
}


// basic version 
function scheduler_exec_url( $url, $params ) {
  
  // url MUST have scheme
  
  $start = strpos( $url, '//' ) + 2;
  $end = strpos( $url, '/', $start );
  $host = substr( $url, $start, $end - $start );
  $post_path = substr( $url, $end );
  // TBD: "ssl://" . 
  $fp = fsockopen( $host, 80, $errno, $errstr );
  if (!$fp)
    return false;

  fputs( $fp, "GET $post_path HTTP/1.0\n" .
              "Host: $host\n" . 
              'User-Agent: Scheduler 0.1 (non-curl) '. phpversion() . "\n" . 
              "\n\n" );
  $response = '';
  while(!feof($fp)) {
      $response .= fgets($fp, 4096);
  }
  fclose ($fp);
  // get response code
  preg_match( '/^\S+\s(\S+)/', $response, $matches );
  if( $matches[1] != "200" ) {
    return false;
  }
  
  return true;
}




function scheduler_enablejob( $job_typename ) {
  global $database;
  
  $database->database_query("UPDATE se_semods_jobs SET job_enabled = 1 WHERE job_typename = '$job_typename'");
}



function scheduler_disablejob( $job_typename ) {
  global $database;
  
  $database->database_query("UPDATE se_semods_jobs SET job_enabled = 0 WHERE job_typename = '$job_typename'");
}


function scheduler_addjob( $job_name, $job_typename, $job_type, $job_command, $job_period, $job_enabled = 1, $job_metadata = array() ) {
  global $database;
  
  $job_metadata = serialize($job_metadata);
  
  $database->database_query("INSERT INTO se_semods_jobs (
                              job_name,
                              job_typename,
                              job_type,
                              job_command,
                              job_metadata,
                              job_period,
                              job_enabled
                              ) VALUES (
                              '$job_name',
                              '$job_typename',
                              $job_type,
                              '$job_command',
                              '$job_metadata',
                              $job_period,
                              $job_enabled )
                              ");
}



function scheduler_removejob( $job_typename  ) {
  global $database;
  
  $database->database_query("DELETE FROM se_semods_jobs WHERE job_typename = '$job_typename'");
}





/********************* EMAIL FUNCTIONS *********************/





// THIS FUNCTION SENDS HELP EMAIL
// INPUT: $admin_email REPRESENTING THE RECIPIENT'S EMAIL ADDRESS
//	  $from_email REPRESENTING THE SENDER'S EMAIL ADDRESS
//	  $subject REPRESENTING THE SUBJECT
//	  $message REPRESENTING THE MESSAGE
// OUTPUT:
function scheduler_send_note_to_admin($subject, $message) {
	global $setting;

	// DECODE SUBJECT AND EMAIL FOR SENDING
    $from_email = "{$setting[setting_email_fromname]} <{$setting[setting_email_fromemail]}>";
    $admin_email = $setting['setting_email_fromemail'];
	$subject = htmlspecialchars_decode($subject, ENT_QUOTES);
	$message = htmlspecialchars_decode($message, ENT_QUOTES);

	// ENCODE SUBJECT FOR UTF8
	$subject="=?UTF-8?B?".base64_encode($subject)."?=";

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

	// SET HEADERS
	$headers = "MIME-Version: 1.0"."\n";
	$headers .= "Content-type: text/html; charset=utf-8"."\n";
	$headers .= "Content-Transfer-Encoding: 8bit"."\n";
	$headers .= "From: $from_email"."\n";
	$headers .= "Return-Path: $from_email"."\n";
	$headers .= "Reply-To: $from_email";

	// SEND MAIL
	@mail($admin_email, $subject, $message, $headers);

	return true;
}


?>