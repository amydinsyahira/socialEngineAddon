<?
$page = "admin_scheduler_viewjobs";
include "admin_header.php";


$sql = "SELECT * FROM se_semods_jobs";
$sql_count = "SELECT COUNT(*) FROM se_semods_jobs";
		
// GET TOTAL USERS
$total_items = semods::db_query_count( $sql_count );

// MAKE USER PAGES
$items_per_page = 100;
$page_vars = make_page($total_items, $items_per_page, $p);

$page_array = Array();
for($x=0;$x<=$page_vars[2]-1;$x++) {
  if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
  $page_array[$x] = Array('page' => $x+1,
                          'link' => $link);
}


// PULL ITEMS INTO AN ARRAY
$jobs = Array();
$rows = $database->database_query($sql);
while($row = $database->database_fetch_assoc($rows)) {

  $jobs[] = $row;
}



// ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('total_items', $total_items);
$smarty->assign('pages', $page_array);
$smarty->assign('jobs', $jobs);
include "admin_footer.php";
?>