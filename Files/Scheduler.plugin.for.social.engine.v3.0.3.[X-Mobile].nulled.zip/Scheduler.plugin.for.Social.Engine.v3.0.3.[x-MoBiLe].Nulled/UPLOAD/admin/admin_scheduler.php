<?
$page = "admin_scheduler";
include "admin_header.php";

if(isset($_POST['task'])) { $task = $_POST['task']; } else { $task = "main"; }


// SET RESULT VARIABLE
$result = 0;

// SAVE CHANGES
if($task == "reset_crontab_line") {
  
  if( scheduler_guess_crontab_line( $setting_crontab_line, __FILE__ ) == 1 ) {
    $result = 1;
    $error = $admin_scheduler[43];
  }

  $setting_crontab_line = security($setting_crontab_line);
  $database->database_query("UPDATE se_semods_settings SET setting_crontab_line = '$setting_crontab_line'");
 
}


// SAVE CHANGES
if($task == "dosave") {

  $setting_crontab_line = semods::post('setting_crontab_line','');
  $setting_crontab_enabled = semods::post('setting_crontab_enabled', 0);
  $setting_crontab_period = intval(semods::post('setting_crontab_period'));

  $setting_crontab_notify_on_error = intval(semods::post('setting_crontab_notify_on_error'));
  $setting_crontab_notify_on_success = intval(semods::post('setting_crontab_notify_on_success'));

  $crontab_prev_state = intval(semods::post('crontab_prev_state'));

  $database->database_query("UPDATE se_semods_settings SET 
            setting_crontab_line = '$setting_crontab_line',
            setting_crontab_enabled = $setting_crontab_enabled,
            setting_crontab_period = $setting_crontab_period,
            setting_crontab_notify_on_error = $setting_crontab_notify_on_error,
            setting_crontab_notify_on_success = $setting_crontab_notify_on_success
			");

  $result = 1;

  // run crontab functions, if state transitions ...
  // V enabled -> enabled,
  // V enabled -> disabled
  // V disabled -> enabled
  // X disabled -> disabled
  if($setting_crontab_enabled || $crontab_prev_state) {
  
    include_once "../include/class.crontab.php";
    $cron = new Crontab(get_current_user());
    $cronModified = false;
    
    // remove all references to 'process_mail_queue.php'
    for ($i = 0; $i < count($cron->linetypes); $i++) {
      if( $cron->linetypes[$i] != CRON_CMD)
        continue;
      
      // remove all calls to semods_scheduler.php
      if(false !== strpos($cron->crontabs[$i]['command'], 'semods_scheduler.php') ) {
        $cronModified = true;
        $cron->delEntry( $i );
      }
    }
    
    // setup crontab 
    if($setting_crontab_enabled) {
      $minute = intval($setting_crontab_period % 60);
      
      $cron->addCron( $minute ? "*/" . $minute : 0, "*", "*", "*", "*", $setting_crontab_line );
      $cronModified = true;
    }
    
    if($cronModified) {
      if( !$cron->writeCrontab() ) {
        $error = sprintf( $admin_scheduler[42], $cron->error );
      }
    }
  }
  
}


// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('error', $error);

$smarty->assign('setting_crontab_line', semods::get_setting('crontab_line') );
$smarty->assign('setting_crontab_enabled', semods::get_setting('crontab_enabled') );
$smarty->assign('setting_crontab_period', semods::get_setting('crontab_period') );
$smarty->assign('setting_crontab_notify_on_error', semods::get_setting('crontab_notify_on_error') );
$smarty->assign('setting_crontab_notify_on_success', semods::get_setting('crontab_notify_on_success') );

include "admin_footer.php";
?>