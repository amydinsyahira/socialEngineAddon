<?php

// GET TO GROUND LEVEL
chdir( dirname(__FILE__) );

$page = "admin_login";
include "admin_header.php";

include_once "../include/functions_scheduler.php";

// SET ERROR REPORTING
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

// TBD: reentrancy?

// PROCESS ALL QUEUED TASKS

$processed_tasks = array();

for(;;) {
  
  $task = semods::db_query_assoc('SELECT * FROM se_semods_jobs WHERE job_enabled = 1 AND ( UNIX_TIMESTAMP( NOW() ) - job_lastrun >= job_period ) ORDER BY job_id ASC LIMIT 1');
  
  // No more tasks
  if($task === false)
    break;

  $task_processed = false;

  // Mark it as run
  $database->database_query("UPDATE se_semods_jobs SET job_lastrun = UNIX_TIMESTAMP( NOW() ) WHERE job_id = {$task['job_id']}");
    
  switch($task['job_type']) {

    // function call
    case 0:

      if(is_callable($task['job_command'])) {
        call_user_func( $task['job_command'], $task['job_metadata'] );
      }
      
      $task_processed = true;
      
      break;
    
    // file - must be absolute
    // how this can be protected from fatal errors?
    case 1:

      if(file_exists($task['job_command'])) {
        include $task['job_command'];
      }
      $task_processed = true;
      
      break;
    
    // url
    case 2:
      
      scheduler_exec_url( $task['job_command'], $task['job_medadata'] );
      $task_processed = true;
      
      break;
    
  }
   
} 


scheduler_send_log();


?>