<?php
$plugin_name = "Scheduler";
$plugin_version = "3.0";
$plugin_type = "scheduler";
$plugin_desc = "This plugin allows scheduling and running background jobs.";
$plugin_icon = "scheduler16.gif";
$plugin_menu_title = "100012000";
$plugin_pages_main = "100012001<!>scheduler16.gif<!>admin_scheduler_viewjobs.php<~!~>100012002<!>scheduler16.gif<!>admin_scheduler.php";
$plugin_pages_level = "";
$plugin_url_htaccess = "";

if($install == "scheduler") {

  //######### INSERT ROW INTO se_plugins
  $database->database_query("INSERT INTO se_plugins (

                  plugin_name,
                  plugin_version,
                  plugin_type,
                  plugin_desc,
                  plugin_icon,
                  plugin_menu_title,
                  plugin_pages_main,
                  plugin_pages_level,
                  plugin_url_htaccess
                  ) VALUES (
                  '$plugin_name',
                  '$plugin_version',
                  '$plugin_type',
                  '".str_replace("'", "\'", $plugin_desc)."',
                  '$plugin_icon',
                  '$plugin_menu_title',
                  '$plugin_pages_main',
                  '$plugin_pages_level',
                  '$plugin_url_htaccess')
  
                  ON DUPLICATE KEY UPDATE

                  plugin_version='$plugin_version',
                  plugin_desc='".str_replace("'", "\'", $plugin_desc)."',
                  plugin_icon='$plugin_icon',
                  plugin_menu_title='$plugin_menu_title',
                  plugin_pages_main='$plugin_pages_main',
                  plugin_pages_level='$plugin_pages_level',
                  plugin_url_htaccess='$plugin_url_htaccess'
                  
  ");


  //######### INSERT LANGUAGE VARS
  $database->database_query("INSERT IGNORE INTO se_languagevars (languagevar_id, languagevar_language_id, languagevar_value, languagevar_default) VALUES (100012000, 1, 'Scheduler', ''),(100012001, 1, 'View Jobs List', ''),(100012002, 1, 'Scheduler Settings', ''),(100012003, 1, '', ''),(100012004, 1, 'Scheduler Settings', ''),(100012005, 1, 'This page contains scheduling service settings.', ''),(100012006, 1, 'Your changes have been saved.', ''),(100012007, 1, 'Save Changes', ''),(100012008, 1, 'Scheduler allows processing queued jobs. Note: </b> Currently works on unix/linux based servers only.', ''),(100012009, 1, 'Enable scheduler', ''),(100012010, 1, 'Crontab settings', ''),(100012011, 1, 'Crontab line - path to php binary (php4 or php5) and processing script. The background processing script is located in your SocialEngine admin folder: <i>admin/semods_scheduler.php</i>, the path should be absolute.', ''),(100012012, 1, 'Autodetect crontab line', ''),(100012013, 1, 'Crontab period - period to run background email process script. Note: Some hosting companies limit crontab jobs period to minimum of 15 minutes.', ''),(100012014, 1, 'min', ''),(100012015, 1, 'hour', ''),(100012016, 1, 'Estimated time to send these emails:', ''),(100012017, 1, 'days', ''),(100012018, 1, 'hours', ''),(100012019, 1, 'minutes', ''),(100012020, 1, 'Notifications from background processing script, will be sent to administrator email', ''),(100012021, 1, 'Notify on error', ''),(100012022, 1, 'Notify on success', ''),(100012023, 1, 'There was an error running crontab( %s ). Please make sure your hoster allows executing crontab or add the \'crontab line\' manually from your cpanel crontab editor.', ''),(100012024, 1, 'Could not find php binary. Please enter manually.', ''),(100012025, 1, 'Jobs List', ''),(100012026, 1, 'View scheduled background jobs', ''),(100012027, 1, 'No jobs.', ''),(100012028, 1, 'ID', ''),(100012029, 1, 'Job Name', ''),(100012030, 1, 'Job Period', ''),(100012031, 1, 'Last run', ''),(100012032, 1, 'Enabled?', ''),(100012033, 1, 'Yes', ''),(100012034, 1, 'No', ''),(100012035, 1, 'Jobs Found', ''),(100012036, 1, 'Page:', ''),(100012037, 1, 'Never', '')");

  

  
  


  //######### CREATE DATABASE STRUCTURE

  if(!function_exists('chain_sql')) {
    function chain_sql( $sql ) {
      global $database;
  
      $rows = explode( ';', $sql);
      foreach($rows as $row) {
        $row = trim($row);
        if(empty($row))
          continue;
        $database->database_query( $row );
      }
  
    }
  }

  chain_sql(
<<<EOC

CREATE TABLE IF NOT EXISTS `se_semods_jobs` (
  `job_id` int(11) NOT NULL auto_increment,
  `job_name` varchar(50) NOT NULL,
  `job_typename` varchar(50) NOT NULL,
  `job_type` tinyint(4) NOT NULL,
  `job_command` text NOT NULL,
  `job_metadata` text NOT NULL,
  `job_lastrun` int(11) NOT NULL DEFAULT '0',
  `job_enabled` tinyint(1) NOT NULL,
  `job_period` int(11) NOT NULL,
  PRIMARY KEY  (`job_id`)
);

EOC
);



  /*** SHARED ELEMENTS ***/



  //######### CREATE se_semods_settings
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_semods_settings'")) == 0) {
    $database->database_query("CREATE TABLE `se_semods_settings` (
	  `setting_crontab_line` varchar(255) NOT NULL default '',
	  `setting_crontab_enabled` tinyint(1) NOT NULL default '0',
	  `setting_crontab_period` tinyint(4) NOT NULL default '15',
	  `setting_crontab_notify_on_error` tinyint(4) NOT NULL default '1',
	  `setting_crontab_notify_on_success` tinyint(4) NOT NULL default '0'
    )");

    $database->database_query("INSERT INTO `se_semods_settings` (`setting_crontab_enabled`) VALUES (0)");
  }

  // UPGRADE / MODIFY
  //######### ADD COLUMNS/VALUES TO se_semods_settings TABLE
  if($database->database_num_rows($database->database_query("SHOW COLUMNS FROM ".$database_name.".se_semods_settings LIKE 'setting_crontab_enabled'")) == 0) {
    $database->database_query("ALTER TABLE se_semods_settings
					ADD COLUMN `setting_crontab_line` varchar(255) NOT NULL default '',
					ADD COLUMN `setting_crontab_enabled` tinyint(1) NOT NULL default '0',
					ADD COLUMN `setting_crontab_period` tinyint(4) NOT NULL default '15',
					ADD COLUMN `setting_crontab_notify_on_error` tinyint(4) NOT NULL default '1',
					ADD COLUMN `setting_crontab_notify_on_success` tinyint(4) NOT NULL default '0'
	");
  }


}


?>