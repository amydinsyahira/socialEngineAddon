<?php
$page = "payment";
include 'header.php';

header("Expire: 0");
header("Cache-Control: no-cache");
header("Pragma: nocache");

$task = semods::getpost('task','main');
$paymentgw_id = semods::getpost('paymentgw_id', 1); // hack -> default paypal

if($task == 'checkout') {
  
  $cart = new semods_cart();
  if($cart->cart_exists == false) {
    header("Location: home.php");
  }
  
  $paymentgw = semods_paymengtw_factory( $paymentgw_id );
  
  if(!$paymentgw->checkout( $cart )) {
    $is_error = 1;
    $error_message = $payment[10];
  }

}





if($task == 'pay') {

  // PROCESS CART

  // also must link to current userid .. ?
  // in paypal case cart is got from "custom"

  /*
  $cart = new semods_cart( $cart_id );
  if($cart->cart_exists == false) {
    header("Location: home.php");
  }
  */
  
  $cart = null;
  
  $paymentgw = semods_paymengtw_factory( $paymentgw_id );
  
  if(!$paymentgw->pay( $cart ) ) {
    $is_error = 1;
    $error_message = $payment[11];
    $hide_cart = true;
  } else {
    $result = 1;
    $success_message = $payment[13];
    $hide_cart = true;
  }

}





if($task == 'main') {
  // show cart contents & payment buttons

  $cart = new semods_cart();
  if($cart->cart_exists == false) {

    $is_error = 1;
    $error_message = $payment[12];

  } else {
    
    $smarty->assign( 'cart', $cart );
    $smarty->assign( 'cart_total', $cart->total() );
    
  }
  

}

$currency_code = semods::get_setting('payment_currency');
if(empty($currency_code))
  $currency_code = 'USD';
  
// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('is_error', $is_error);
$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
$smarty->assign('success_message', $success_message);
$smarty->assign('currency_code', $currency_code);
$smarty->assign('hide_cart', $hide_cart);
include "footer.php";
?>