<?php

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE LANGUAGE FILE
include_once "./lang/lang_".$global_lang."_subscriber.php";

// INCLUDE SEMODS CLASS FILE
include_once "./include/class_semods.php";

// INCLUDE CLASS FILE
include_once "./include/class_subscriber.php";

// INCLUDE FUNCTIONS FILE
include_once "./include/functions_subscriber.php";

// INCLUDE PAYMENT STUFF
include_once "./lang/lang_".$global_lang."_payment.php";
include_once "./include/functions_payment.php";
include_once "./include/class_payment.php";
include_once "./include/class_semods_cart.php";



$subscriber_enabled = semods::get_setting('subscriber_enable_subscriptions');

if($subscriber_enabled) {
  
  switch($page) {
  
    // SIGNUP HIJACK
    case "signup":
  
      if ( ($subscriber_enabled) && semods::get_setting('subscriber_require_on_signup') ) {
  
      $signup_plan = semods::getpost('signup_plan');
      
      // Try from cookie
      if(empty($signup_plan)) {
        $signup_plan = semods::g($_COOKIE, 'signup_plan');
      }
      
      $plan_is_error = 0;
      
      $task = semods::post('task');
      if(($task == "step1do") || ($task == "step2do")) {
        if(empty($signup_plan)) {
          $_POST['task'] = 'step1';
          $plan_is_error = 1;
            $plan_error_message = $signup[810];
        } else {
          setcookie("signup_plan", "$signup_plan", 0, "/");
        }
      }
      
        
      $smarty->assign('signup_plan', $signup_plan);
      
      }
      
      $smarty->assign('subscriber_require_on_signup', semods::get_setting('subscriber_require_on_signup'));
      
        
      break;
    
    // ALWAYS ALLOWED PAGES
    case 'help';
    case 'help_contact';
    case 'help_tos';
    case 'payment';
    case 'user_plan';
    case 'user_plan_renew';
    case 'user_plan_upgrade';
    case 'user_plan_history';
    case 'user_logout';
      break;
    
    
    case 'profile':
  
      // RESTRICT VIEW PAGES PER LEVEL - REQUIRE SUBSCRIPTION
      if($user->user_exists) {
        
        if($user->level_info['level_subscriber_require_subscription']) {
          header("Location: user_plan_upgrade.php?require");
          exit();
        }
        
      }
      
      // RESTRICT PROFILE VIEW
      if($user->user_exists) {
        
        if(($user->level_info['level_subscriber_allow_profileview'] == 0) && ($owner->user_info['user_id'] != $user->user_info['user_id'])) {
          header("Location: user_home.php");
          exit();
        }
        
      }
      
      break;
    
    
    default:
  
      // RESTRICT VIEW PAGES PER LEVEL - REQUIRE SUBSCRIPTION
      if($user->user_exists) {
        
        if($user->level_info['level_subscriber_require_subscription']) {
          header("Location: user_plan_upgrade.php?require");
          exit();
        }
        
      }
      
      break;
    
  }

}

$smarty->assign('subscriber_enabled', $subscriber_enabled);


?>