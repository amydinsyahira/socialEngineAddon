<?
$page = "user_plan_upgrade";
include "header.php";

$task = semods::getpost('task', "main");
$from_plan = intval( semods::getpost('from_plan') );

if(!empty($from_plan)) {
  $userplan = new semods_userplan( $from_plan, $user->user_info['user_id'] );
}

if($userplan->userplan_exists == 0) {
  // Now - only one plan
  // Later - multiple plans => display list to choose from
  $userplan = new semods_userplan( 0, $user->user_info['user_id'] );
}
  
// TBD: also show "self", i.e. "from_plan" plan if userplan is expired .. or it's renew task only ?
if($task == 'upgrade') {
  $signup_plan = intval(semods::getpost('signup_plan'));

  for(;;) {
    
    if(empty($signup_plan)) {
      $error_message = $user_plan_upgrade[12];
      break;
    }

    // Can't upgrade to self - it's renew? - only if expired / cancelled
    if(($userplan->userplan_exists != 0) && ($signup_plan == $userplan->userplan_info['plan_id']) && (!in_array( intval($userplan->userplan_info['userplan_state']), array(2,3) )) ){
      $error_message = $user_plan_upgrade[12];
      break;
    }
    

    // Validate this plan can be upgraded to
    $sql = "SELECT COUNT(*)
            FROM se_semods_plans
            WHERE
            plan_enabled = 1 AND 
            (FIND_IN_SET({$user->user_info['user_level_id']},plan_levels) OR plan_levels='')";
                                          
    if($userplan->userplan_exists != 0)  {
      $sql .= " AND (FIND_IN_SET({$userplan->userplan_info['plan_id']},plan_upgrade_from) OR plan_upgrade_from='')";
    }
    
    $sql .= " AND plan_id = $signup_plan";

    // Can't upgrade to self - it's renew? - only if expired / cancelled
    if(($userplan->userplan_exists != 0) && ($signup_plan == $userplan->userplan_info['plan_id']) && (!in_array( intval($userplan->userplan_info['userplan_state']), array(2,3) )) ){
      $sql .= " AND plan_id != {$userplan->userplan_info['plan_id']}";
    }
    
    if(semods::db_query_count( $sql ) == 0) {
      $error_message = $user_plan_upgrade[12];
      break;
    }



    // CREATE CART & REDIRECT
    // TODO: pro-rate
    $plan = new semods_plan( $signup_plan );

    if(($plan->plan_info['plan_price'] == 0) && ($plan->plan_info['plan_onetime_price'] == 0) ) {
      $plan_free = true;
    }
    else
      $plan_free = false;
      
    if(!$plan_free) {
      
      $cart = new semods_cart();
      $cart->create_cart( $user->user_info['user_id'] );

      $cart_item = new semods_subscription_cartitem(  $plan->plan_info['plan_name'],
                                                      $plan->plan_info['plan_id'],
                                                      $plan->plan_info['plan_price'],
                                                      array( 'uid'  => $user->user_info['user_id'],
                                                             'pid'  => $plan->plan_info['plan_id'] )
                                                      );

      $cart_item->set_user_id( $user->user_info['user_id'] );


      // plan_onetime_price - initial price
      $cart_item->set_initial_price( $plan->plan_info['plan_onetime_price'] );
      
      // Decide if trials are allowed
      if( ($userplan->userplan_exists == 1) && (semods::get_setting('subscriber_allow_multiple_trials') == 1) ) {
      
        // Trial
        if($plan->plan_info['plan_trialperiod'] != 0) {
          $cart_item->add_trial_period( $plan->plan_info['plan_trialperiodprice'],
                                        $plan->plan_info['plan_trialperiod'],
                                        $plan->plan_info['plan_trialperiodtype'] );
        }
        
      }
      
      // Subscription - TBD: recurring number of times
      $cart_item->add_period( $plan->plan_info['plan_price'],
                              $plan->plan_info['plan_period'],
                              $plan->plan_info['plan_periodtype'],
                              $plan->plan_info['plan_recurring'],
                              $plan->plan_info['plan_recurring_cycles'] );
      
      $cart->add_item( $cart_item );
      

      // GO TO PAYMENT PROCESSOR
      header("Location: payment.php");
      exit;
      
    } else {

      // act on free plan

      // subscribe a user for free plan right away ... 
      $plan->plan_subscribe( $user->user_info['user_id'], 0, array(), false );

      // redirect somewhere with msg?

      // GO TO PLANS HOME
      header("Location: user_plan.php?upgradesuccess");
      exit;
      
    }
   
    break; 
  }
  
}


//if($task == 'main') {

  // Find out which plans can be upgraded to
  $sql = "SELECT *
          FROM se_semods_plans
          WHERE
          plan_enabled = 1 AND 
          (FIND_IN_SET({$user->user_info['user_level_id']},plan_levels) OR plan_levels='')";
                                        
  if($userplan->userplan_exists != 0)  {
    $sql .= " AND (FIND_IN_SET({$userplan->userplan_info['plan_id']},plan_upgrade_from) OR plan_upgrade_from='')";
  }

  // Can't upgrade to self - it's renew? - only if expired / cancelled
  if(($userplan->userplan_exists != 0) && (!in_array( intval($userplan->userplan_info['userplan_state']), array(2,3) )) ){
    $sql .= " AND plan_id != {$userplan->userplan_info['plan_id']}";
  }
  
  $rows = $database->database_query( $sql );
  
  $plans = array();
  while($row = $database->database_fetch_assoc($rows)) {
    $row['plan_trialperiodtypetext'] = $plan_periodtypes[ $row['plan_trialperiodtype'] ]['f'];
    $row['plan_periodtypetext'] = $plan_periodtypes[ $row['plan_periodtype'] ]['f'];
    $plans[] = $row;
  }

//}

// ASSIGN VARIABLES AND INCLUDE FOOTER

$smarty->assign('require', isset($_REQUEST['require']) );
$smarty->assign('currency_code', semods::get_setting('payment_currency'));

$smarty->assign('result', $result);
$smarty->assign('is_error', empty($error_message) ? 0 : 1);
$smarty->assign('error_message', $error_message);
$smarty->assign('plans', $plans);
$smarty->assign('from_plan', $from_plan);
include "footer.php";
?>