<?php

class Paypal {
	var $ipn_validation_request;
	var $ipn_req_id = null;
	var $txn_id = '';
	var $tx_data = array();

    var $paypal_form = null;
    
    var $err_msg;
    var $err_id;
    
    var $config = array();

    var $log_fp = null;
    var $debug = false;

	var $tx_fields = array( 'item_name', 'business', 'item_number', 'payment_status', 'mc_gross', 'mc_currency', 'txn_id', 'receiver_email',
								 'receiver_id', 'quantity', 'num_cart_items', 'payment_date', 'first_name', 'last_name', 'payment_type',
								 'payment_status', 'payment_gross', 'payment_fee', 'settle_amount', 'memo', 'payer_email', 'txn_type',
								 'payer_status', 'address_street', 'address_city', 'address_state', 'address_zip', 'address_country', 'address_status',
								 'item_number', 'tax', 'option_name1', 'option_selection1', 'option_name2', 'option_selection2', 'for_auction',
								 'invoice', 'custom', 'notify_version', 'verify_sign', 'payer_business_name', 'payer_id', 'mc_currency', 'mc_fee',
								 'exchange_rate', 'settle_currency', 'parent_txn_id', 'pending_reason', 'reason_code',
                                 'residence_country', 'currency_code' );
		
	var $tx_subscription_fields = array( 'subscr_id', 'subscr_date', 'subscr_effective', 'period1', 'period2', 'period3', 'amount1', 'amount2',
										  'amount3', 'mc_amount1', 'mc_amount2', 'mcamount3', 'recurring', 'reattempt', 'retry_at', 'recur_times',
										  'username', 'password'  );

	var $tx_recurring_payment_fields = array( 'payment_cycle', 'initial_payment_status', 'next_payment_date', 'initial_payment_amount',
                                            'time_created', 'period_type', 'product_type', 'initial_payment_txn_id', 'amount_per_cycle',
                                            'profile_status', 'outstanding_balance', 'recurring_payment_id', 'product_name' );
		
	var $tx_auction_fields = array( 'for_auction', 'auction_closing_date', 'auction_multi_item', 'auction_buyer_id'  );
 
 
 
 
 
    function Paypal($params) {
      $this->config['openssl'] = "/usr/bin/openssl";
      $this->config['sandbox'] = false;

      if($params)
        $this->config = array_merge( $this->config, $params );

    }
    
	// 999 - unprocessed, "stuck"
	// 0 - all ok
	// 1 - invalid txnid
	// 2 - duplicate txnid
	// 3 - "INVALID" response from paypal
	// 4 - http error / other response from paypal
	function log_ipn_request( $status = 999 ) {
		// just log to file ?
		/*
		if($status !=1) $txn_id = $this->txn_id;
		DB::db_query( "INSERT INTO semods_paypal_ipn_log (txnid, paypal_post, status, datecreated) VALUES('$txn_id','" . base64_encode($this->ipn_validation_request) . "', $status, NOW())" );
		$this->ipn_req_id = DB::db_insert_id();
		*/
	}

    function log( $message ) {
      if($this->debug) {
        
        if(!$this->log_fp) {
            $this->log_fp = fopen( 'paypal_ipn_log.txt', 'a');
            fwrite( $this->log_fp, "****************************************************************************************************\n" );
        }
        
        fwrite($this->log_fp, strftime("%d %b %Y %H:%M:%S ") . "[class_semods_paypal.php] $message\n" );
        
      }
    }

    function store_tx_data() {
		global $database;
    
      $txn_id = $this->txn_id;
      $txn_type = $this->tx_data['txn_type'];
      $num_cart_items = $this->tx_data['num_cart_items'];

      $ipn_data = $this->tx_data;
/*
 recurring_payment_failed
recurring_payment_profile_cancel
recurring_payment
recurring_payment_profile_created
recurring_payment_expired
recurring_payment_skipped
recurring_payment_outstanding_payment
recurring_payment_outstanding_payment_failed
recurring_payment_suspended
recurring_payment_suspended_due_to_max_failed_payment
*/
        $ignored_tx_types = array( 'recurring_payment_profile_created', 'recurring_payment_profile_cancel', 'recurring_payment_expired', 'recurring_payment_suspended' );

        if(in_array($txn_type, $ignored_tx_types))
            return true;
            
      
      // check if transaction ID has been processed before
      $sql = "SELECT * FROM se_semods_paypal_payment_info WHERE txnid='".$txn_id."'";
	  $paypal_payment_info = $database->database_query( $sql );
	
	  // if Transaction known
      if( mysql_num_rows($paypal_payment_info) != 0 ) {

		// check if it's transaction status update
		if($ipn_data['payment_status'] == $paypal_payment_info['payment_status']) {

            $this->log("DUPLICATE RECORD");		
			// No, it's a duplicate call
			return false;

		} else {

            $this->log("UPDATE record, new status: " . $ipn_data['payment_status']);		

			// Yes, it is an update
			$database->database_query( "UPDATE se_semods_paypal_payment_info SET paymentstatus = '{$ipn_data['payment_status']}' WHERE txnid = '$txn_id'" );
			return true;
		}

      }

		
	  switch($txn_type) {
		
		case "cart":

          $this->log("NEW record - cart");		
              
          $sql = "INSERT INTO se_semods_paypal_payment_info (paymentstatus, buyer_email, firstname, lastname, street, city, state, zipcode, country, mc_gross, mc_fee, memo, paymenttype, paymentdate, txnid, pendingreason, reasoncode, tax, txntype, datecreation )
                  VALUES ('".$ipn_data['payment_status']."','".$ipn_data['payer_email']."','".$ipn_data['first_name']."','".$ipn_data['last_name']."','".$ipn_data['address_street']."','".$ipn_data['address_city']."','".$ipn_data['address_state']."','".$ipn_data['address_zip']."','".$ipn_data['address_country']."','".$ipn_data['mc_gross']."','".$ipn_data['mc_fee']."','".$ipn_data['memo']."','".$ipn_data['payment_type']."','".$ipn_data['payment_date']."','".$ipn_data['txn_id']."','".$ipn_data['pending_reason']."','".$ipn_data['reason_code']."','".$ipn_data['tax']."','".$ipn_data['txn_type']."', NOW() )";
  
            $this->log("sql: $sql");		
            
          $database->database_query( $sql );
          
          $num_cart_items = $this->tx_data['num_cart_items'];
          //$num_cart_items = intval($ipn_data['num_cart_items']);
          
          for ($i = 1; $i <= $num_cart_items; $i++) {
              $itemname = "item_name".$i;
              $itemnumber = "item_number".$i;
              $on0 = "option_name1_".$i;
              $os0 = "option_selection1_".$i;
              $on1 = "option_name2_".$i;
              $os1 = "option_selection2_".$i;
              $quantity = "quantity".$i;
     
              $sql = "INSERT INTO se_semods_paypal_cart_info (txnid,itemnumber,itemname,os0,on0,os1,on1,quantity,invoice,custom)
                      VALUES ('". $txn_id ."','" . $_POST[$itemnumber]."','".$_POST[$itemname]."','".$_POST[$on0]."','".$_POST[$os0]."','".$_POST[$on1]."','".$_POST[$os1]."','".$_POST[$quantity]."','".$ipn_data['invoice']."','".$ipn_data['custom']."')";

            $this->log("sql: $sql");		
              $database->database_query( $sql );
		  }
			
			break;
		
		case "subscr_payment":	// what's this for?
			
          $this->log("NEW record - subscription payment - " . $txn_type);		
              
          $sql = "INSERT INTO se_semods_paypal_payment_info (
						paymentstatus,
						buyer_email,
						firstname,
						lastname,
						street,
						city,
						state,
						zipcode,
						country,
						mc_gross,
						mc_fee,
						memo,
						paymenttype,
						paymentdate,
						txnid,
						pendingreason,
						reasoncode,
						tax,
						txntype,
						datecreation
					) VALUES (
						'".$ipn_data['payment_status']."',
						'".$ipn_data['payer_email']."',
						'".$ipn_data['first_name']."',
						'".$ipn_data['last_name']."',
						'".$ipn_data['address_street']."',
						'".$ipn_data['address_city']."',
						'".$ipn_data['address_state']."',
						'".$ipn_data['address_zip']."',
						'".$ipn_data['address_country']."',
						'".$ipn_data['mc_gross']."',
						'".$ipn_data['mc_fee']."',
						'".$ipn_data['memo']."',
						'".$ipn_data['payment_type']."',
						'".$ipn_data['payment_date']."',
						'".$ipn_data['txn_id']."',
						'".$ipn_data['pending_reason']."',
						'".$ipn_data['reason_code']."',
						'".$ipn_data['tax']."',
						'".$ipn_data['txn_type']."',
						NOW() )";
  
            $this->log("sql: $sql");
			
          $database->database_query( $sql );
		  
		  break;


		  
		// these guys don't receive txn_id
		
		case "subscr_signup":
		case "subscr_cancel":
		case "subscr_failed":
		case "subscr_eot":
		case "subscr_modify":

          $this->log("NEW record - subscription - " . $txn_type);		
			
		  $sql = "INSERT INTO se_semods_paypal_subscription_info(
						subscr_id,
						sub_event,
						subscr_date,
						subscr_effective,
						period1,
						period2,
						period3,
						amount1,
						amount2,
						amount3,
						mc_amount1,
						mc_amount2,
						mc_amount3,
						recurring,
						reattempt,
						retry_at,
						recur_times,
						username,
						password,
						txn_id,
						subscriber_emailaddress,
						datecreation
					) VALUES (
						'".$ipn_data['subscr_id']."',
						'".$ipn_data['txn_type']."',
						'".$ipn_data['subscr_date']."',
						'".$ipn_data['subscr_effective']."',
						'".$ipn_data['period1']."',
						'".$ipn_data['period2']."',
						'".$ipn_data['period3']."',
						'".$ipn_data['amount1']."',
						'".$ipn_data['amount2']."',
						'".$ipn_data['amount3']."',
						'".$ipn_data['mc_amount1']."',
						'".$ipn_data['mc_amount2']."',
						'".$ipn_data['mc_amount3']."',
						'".$ipn_data['recurring']."',
						'".$ipn_data['reattempt']."',
						'".$ipn_data['retry_at']."',
						'".$ipn_data['recur_times']."',
						'".$ipn_data['username']."',
						'".$ipn_data['password']."',
						'".$ipn_data['txn_id']."',
						'".$ipn_data['payer_email']."',
						NOW() )";

            $this->log("sql: $sql");		
          $database->database_query( $sql );
			
			break;
		
		
		// regular payment or others
		default:
		
            $this->log("NEW record - one item");		

            $sql = "INSERT INTO se_semods_paypal_payment_info (paymentstatus,buyer_email,firstname,lastname,street,city,state,zipcode,country,mc_gross,mc_fee,itemnumber,itemname,os0,on0,os1,on1,quantity,memo,paymenttype,paymentdate,txnid,pendingreason,reasoncode,tax,txntype,datecreation)
            VALUES ('".$ipn_data['payment_status']."','".$ipn_data['payer_email']."','".$ipn_data['first_name']."','".$ipn_data['last_name']."','".$ipn_data['address_street']."','".$ipn_data['address_city']."','".$ipn_data['address_state']."','".$ipn_data['address_zip']."','".$ipn_data['address_country']."','".$ipn_data['mc_gross']."','".$ipn_data['mc_fee']."','".$ipn_data['item_number']."','".$ipn_data['item_name']."','".$ipn_data['option_name1']."','".$ipn_data['option_selection1']."','".$ipn_data['option_name2']."','".$ipn_data['option_selection2']."','".$ipn_data['quantity']."','".$ipn_data['memo']."','".$ipn_data['payment_type']."','".$ipn_data['payment_date']."','".$ipn_data['txn_id']."','".$ipn_data['pending_reason']."','".$ipn_data['reason_code']."','".$ipn_data['tax']."','".$ipn_data['txn_type']."', NOW())";

            $database->database_query( $sql );
      }
  

      return true;
      
    }



    /************ IPN ************/



	
	function preprocess_ipn_post() {

/*
		// read the post from PayPal system and add 'cmd'
		$req = 'cmd=_notify-validate';
		foreach ($_POST as $key => $value) {
			$value = urlencode(stripslashes($value));
			$req .= "&$key=$value";
		}
		
		$this->ipn_validation_request = $req;
*/

        $raw_post = trim(file_get_contents('php://input'));
		
		$this->ipn_validation_request = $raw_post . '&cmd=_notify-validate';

        // Log
        $tmpAr = array_merge($_POST, array("cmd" => "_notify-validate"));
        $postFieldsAr = array();
        foreach ($tmpAr as $name => $value) {
            $postFieldsAr[] = "$name=$value";
        }
        $this->log( "Sending IPN values:\n".implode("\n", $postFieldsAr) );

	}

   
	function process_ipn() {

        // check the payment_status is Completed
        // check that txn_id has not been previously processed
        // check that receiver_email is your Primary PayPal email
        // check that payment_amount/payment_currency are correct
        // process payment


		$this->preprocess_ipn_post();

		$this->txn_id = $txn_id = semods::post('txn_id', '');

    	$this->log( "Received IPN,  TX ID : " . $this->txn_id );

		switch( $this->verify_ipn() ) {
			// verified
			case 0:
	
				$this->log( "VERIFIED Response,  TX ID : " . $this->txn_id );
					
				break;
			
			// invalid
			case 1:
	        	$this->log( "INVALID from Paypal" );
				return false;
				

			// unknown response from paypal
			case 2:
	        	$this->log( $this->err_msg );
				return false;

			// curl / http error
			case 3:
	        	$this->log( "Http Error" );
				return false;
				
			default:
	
	        	$this->log( "Never reached error" );
				return false;

				break;
			
		}


		// Take POSTed fields
		
        // General Fields
		foreach($this->tx_fields as $field) {
			$this->tx_data[$field] = semods::post($field, '');
		}

		// Subscription Fields
		foreach($this->tx_subscription_fields as $field) {
			$this->tx_data[$field] = semods::post($field, '');
		}
        
        // Recurring Payment fields
		foreach($this->tx_recurring_payment_fields as $field) {
			$this->tx_data[$field] = semods::post($field, '');
		}
	
		// check that receiver_email is your Primary PayPal email
		if($this->config['business'] != $this->tx_data['receiver_email']) {
        	$this->log( "BAD RECEIVER EMAIL " . $this->tx_data['receiver_email'] );
			return false;
		}


        return $this->store_tx_data();
          
	}
	
	// Returns:
	// 0 - all ok
	// 1 - invalid
	// 2 - unknown response from paypal
	// 3 - curl / http error
	// 
	function verify_ipn() {

        if(function_exists('curl_init')) {

			//$this->log( "Using CURL" );

            /*** CURL ***/
            
            if($this->config['sandbox']) 
                $ch = curl_init( 'https://www.sandbox.paypal.com/cgi-bin/webscr' );
            else
                $ch = curl_init('http://www.paypal.com/cgi-bin/webscr');
                
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
            curl_setopt( $ch, CURLOPT_POST, 1 );
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $this->ipn_validation_request );
			curl_setopt( $ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0 );
            
            $response = curl_exec($ch);
            if(curl_errno($ch)) {
                $this->err_msg = curl_error( $ch );
                return 3;
            }
            curl_close( $ch );

        } else {

			//$this->log( "Using Sockets" );

            /*** SOCKETS ***/
            
            if($this->config['sandbox']) 
                $fp = fsockopen ('www.sandbox.paypal.com', 80, $errno, $errstr, 30);
            else
                $fp = fsockopen ('www.paypal.com', 80, $errno, $errstr, 30);
                
            if (!$fp) {
                $this->err_msg = "Http error";
                return 3;
            }
            
            $header = '';
            $header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
            $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
            $header .= "Content-Length: " . strlen($this->ipn_validation_request) . "\r\n\r\n";
    
            fputs ($fp, $header . $this->ipn_validation_request);
    
            $response = '';
            $headerdone = false;
            while (!feof($fp)) {
                $line = fgets ($fp, 1024);
                if (strcmp($line, "\r\n") == 0) {
                    // read the header
                    $headerdone = true;
                }
                else if ($headerdone) {
                    // header has been read. now read the contents
                    $response .= $line;
                }
            }
    
            fclose ($fp);
        }
		
		if( strcmp($response, "VERIFIED") == 0 ) {
            
			return 0;
        
		} else if( strcmp($response, "INVALID") == 0 ) {
            
			return 1;
        
		} else {
            
			$this->err_msg = "Unknown response from paypal: " . $response;
			return 2;
        
		}
		
		// never reached
	}
    
    function tx_status() {
      return $this->tx_data['payment_status'];
    }
    
    function add_field($field, $value) {
      if(!$this->paypal_form) {
        $this->paypal_form = array(
                'cmd'           => '_xclick',
                'business'      => $this->config['business'],
                'cert_id'       => $this->config['cert_id'],
                'lc'            => 'US',
                'currency_code' => 'USD',
                'no_shipping'   => '1',
                'rm'            => '2'    // response as post
                );
      }
      
      $this->paypal_form[$field] = $value;
      
    }
    
    function paypal_encrypt_form() {
      
      if (!file_exists($this->config['ssl_myprivkey_file'])) {
        $this->err_msg = "ERROR: My Private Key File {$this->config['ssl_myprivkey_file']} not found";
        return false;
      }

      if (!file_exists($this->config['ssl_mypubcert_file'])) {
        $this->err_msg = "ERROR: My Public Certificate File {$this->config['ssl_mypubcert_file']} not found";
        return false;
      }
      
      if (!file_exists($this->config['ssl_paypalcert_file'])) {
        $this->err_msg = "ERROR: Paypal Certificate File {$this->config['ssl_paypalcert_file']} not found";
        return false;
      }
      
      if (!file_exists($this->config['openssl'])) {
        $this->err_msg = "ERROR: Openssl binary {$this->config['openssl']} not found";
        return false;
      }
      
      //Assign Build Notation for PayPal Support
      $this->add_field( 'bn', 'SocialEngineMods.PHP.paypal1' );
    
      $openssl_cmd = "{$this->config['openssl']} smime -sign -signer {$this->config['ssl_mypubcert_file']} -inkey {$this->config['ssl_myprivkey_file']} " .
                  "-outform der -nodetach -binary | {$this->config['openssl']} smime -encrypt " .
                  "-des3 -binary -outform pem {$this->config['ssl_paypalcert_file']}";
  
      $descriptors = array(
              0 => array("pipe", "r"),
              1 => array("pipe", "w"),
      );
  
      $process = proc_open($openssl_cmd, $descriptors, $pipes);

      if (!is_resource($process)) {
        $this->err_msg = "Error creating openssl process";
        return false;
      }
      
      foreach ($this->paypal_form as $key => $value) {
          if ($value != "") {
              fwrite($pipes[0], "$key=$value\n");
          }
      }
      
      fflush($pipes[0]);
      fclose($pipes[0]);

      $output = "";
      while (!feof($pipes[1])) {
          $output .= fgets($pipes[1]);
      }

      fclose($pipes[1]); 
      $return_value = proc_close($process);
	  
      return $output;
    }
	
	
	
	function paypal_encrypt_data() {

		$data = '';
		foreach ($this->paypal_form as $key => $value) {
			if ($value != "") {

				$data .= "$key=$value\n";
			}
		}

		/*************************
		* Originally From:
		* http://paypal.forums.liveworld.com/thread.jspa?messageID=100005107#100011900
		* and adapted by raccettura
		*************************/
		
		// we'll make temp files based on this name (needed to end in .txt on my system)
		//$tmp_path = $this->encrypt_dir.'/'.$this->randomHash();
	    $tmp_path = tempnam( "", "upp" );
		$tmp_file = $tmp_path . '_data.txt';
		
		// save data string to file
		file_put_contents( $tmp_file, $data );
		
		error_reporting(E_ALL);
		// transform data file to signed file - roughly equivilent to...
		if (function_exists('openssl_pkcs7_sign') && function_exists('openssl_pkcs7_encrypt')) {
			// openssl smime -sign -in {$tmp_path}_data.txt -signer $base/my-pubcert.pem -inkey $base/my-prvkey.pem -outform der -nodetach -binary
			openssl_pkcs7_sign( "{$tmp_path}_data.txt",
							   "{$tmp_path}_signed.txt",
							   file_get_contents($this->config['ssl_mypubcert_file']),
							   file_get_contents($this->config['ssl_myprivkey_file']),
							   array(),
							   PKCS7_BINARY );
			$data = file_get_contents("{$tmp_path}_signed.txt");
			$data = explode("\n\n", $data); // openssl_pkcs7_sign gives us a file with
			$data = $data[1]; // headers which need to be removed and a
			$data = base64_decode($data); // base64 encoded body that needs decoding
			file_put_contents( "{$tmp_path}_signed.txt", $data );
			//$this->writeFile("{$tmp_path}_signed.txt", $data);
			
			//transform signed file to encrypted file - roughly equivilent to...
			// openssl smime -encrypt -des3 -binary -outform pem $base/PayPal.pem
			openssl_pkcs7_encrypt("{$tmp_path}_signed.txt",
								  "{$tmp_path}_encrypted.txt",
								  file_get_contents($this->config['ssl_paypalcert_file']),
								  array(),
								  PKCS7_BINARY);
			
			$data = file_get_contents("{$tmp_path}_encrypted.txt");
			$data = explode("\n\n", $data); // openssl_pkcs7_encrypt gives us a file with
			$data = $data[1]; // headers which need to be removed
		} else {
            $this->log("ERROR: function \"openssl_pkcs7_sign\" unavailable: Please install OpenSSL extension");		
		}
		
		// add wrapper
		$data = "-----BEGIN PKCS7-----$data-----END PKCS7-----";
		
		// delete temporary files
		if(file_exists($tmp_path)){
			unlink($tmp_path);
		}
		
		unlink("{$tmp_path}_data.txt");
		unlink("{$tmp_path}_signed.txt");
		unlink("{$tmp_path}_encrypted.txt");
		
		return ($data);
	}
	
    
}

?>