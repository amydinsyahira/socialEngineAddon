<?php


/* PAYMENT GATEWAY BASE CLASS */

class semods_paymentgw_base {
  

  function semods_paymentgw_base( $params ) {
    
  }
  
  
  function cancel_subscription()  {
    
  }

  // api supporting gateways like paypal -> create session & redirect to payment processor
  // cart - semods_Cart
  function checkout( $cart ) {
    
  }

  // api supporting gateways like paypal -> pay for cart items + paypal recurring hach
  // cart - semods_cart, can be null, e.g. in paypal case where it's retrieved from "custom"
  function pay( $cart = null ) {
    
  }
  
}

?>