<?php

class semods_cartitem {

  var $item_type;
  var $item_name;
  var $item_number;
  var $item_price;
  var $item_quantity;
  var $item_quantity_fixed = 0;
  var $params;
  var $callback;
  var $callback_params;
  
  function semods_cartitem( $item_type, $item_name, $item_number, $item_price, $item_quantity, $params, $callback, $callback_params ) {

    $this->item_type = $item_type;
    $this->item_name = $item_name;
    $this->item_number = $item_number;
    $this->item_price = $item_price;
    $this->item_quantity = $item_quantity;

    $this->params = $params;
    $this->callback = $callback;
    $this->callback_params = $callback_params;
    
  }
  
}


class semods_subscription_cartitem extends semods_cartitem {

  /*
   * $item_number - plan_id
   *
   */
  function semods_subscription_cartitem( $item_name, $item_number, $item_price, $params = array(), $callback = '', $callback_params = array() ) {
    parent::semods_cartitem( 1, $item_name, $item_number, $item_price, 1, $params, 'subscriber_payment_notification', array( 'pid' => $item_number ) );

    $this->item_quantity_fixed = 1;
    
  }

  function set_initial_price( $price) {
    $this->params['initial_price'] = $price;
  }
  
  function add_trial_period( $price, $period, $periodtype) {
    $this->params['trial_price'] = $price;
    $this->params['trial_period'] = $period;
    $this->params['trial_periodtype'] = $periodtype;
  }
  
  function add_period( $price, $period, $periodtype, $recurring = true, $recurring_cycles = 0) {
    $this->params['price'] = $price;
    $this->params['period'] = $period;
    $this->params['periodtype'] = $periodtype;
    $this->params['recurring'] = intval($recurring);
    $this->params['recurring_cycles'] = intval($recurring_cycles);
  }
  
  function set_user_id( $user_id ) {
    $this->callback_params['uid'] = $user_id;  
  }
  
}


class semods_payment_cartitem extends semods_cartitem {

  function semods_payment_cartitem( $item_name, $item_number, $item_price, $item_quantity = 1, $params = null, $callback = '', $callback_params = null ) {
    parent::semods_cartitem( 0, $item_name, $item_number, $item_price, $item_quantity, $params, $callback, $callback_params );
  }
  
}




class semods_cart {

  var $cart_id = 0;
  var $user_id = 0;
  
  var $cart_exists = false;
  var $cart_info = array();
  var $cart_items = array();
  
  function semods_cart($cart_id = 0, $user_id = 0) {
    global $database;
    
    // Try to get from session
    if($cart_id == 0) {
      // prevent warnings on already started sessions
      $error_level = error_reporting( 0 );
      session_start();
      error_reporting( $error_level );
      $cart_id = semods::g( $_SESSION, 'cart_id', 0 );
    }

    $this->cart_id = $cart_id;
    $this->user_id = $user_id;
    
    // TODO: Also require cart not paid already?
    if($cart_id) {
      $this->cart_info = semods::db_query_assoc("SELECT * FROM se_semods_cart WHERE cart_id = $cart_id");

      if($this->cart_info) {
        $this->cart_exists = true;
        $this->load_cart_items();
      }
      
    }
    
  }
  
  function load_cart_items() {
    global $database;
      
    $this->cart_items = array();
    $rows = $database->database_query( "SELECT * FROM se_semods_cartitems WHERE cartitem_cart_id = {$this->cart_id}" );
    if($rows) {
      while($row = $database->database_fetch_assoc($rows)) {
        $this->cart_items[] = $row;
      }
    }

  }    
  
  // TODO: if cart exists - just clear all contents?
  function create_cart( $user_id ) {
    global $database;
    
    $this->user_id = $user_id;
    $database->database_query("INSERT INTO se_semods_cart (cart_user_id) VALUES( $user_id ) ");
    $this->cart_id = $database->database_insert_id();

    // prevent warnings on already started sessions
    $error_level = error_reporting( 0 );
    session_start();
    error_reporting( $error_level );
    $_SESSION['cart_id'] = $this->cart_id;
  }
  
  function valid_product( $item_id ) {
  
    return true;  
  }
  
  
  /*
   * $cart_item - semods_cart_item class
   *
   *
   */
   
  
  function add_item( &$cart_item ) {
    global $database;

    
    if($cart_item->item_quantity <=0)
      return;
    
    $item_metadata = $cart_item->params ? serialize($cart_item->params) : '';
    $item_callback_params = $cart_item->callback_params ? serialize($cart_item->callback_params) : '';
    
    $database->database_query( "INSERT INTO se_semods_cartitems (
                 cartitem_cart_id,
                 cartitem_type,
                 cartitem_name,
                 cartitem_number,
                 cartitem_quantity,
                 cartitem_quantityfixed,
                 cartitem_price,
                 cartitem_metadata,
                 cartitem_callback,
                 cartitem_callbackparams
                 )
                 VALUES(
                 {$this->cart_id},
                 {$cart_item->item_type},
                 '{$cart_item->item_name}',
                 {$cart_item->item_number},
                 {$cart_item->item_quantity},
                 {$cart_item->item_quantity_fixed},
                 {$cart_item->item_price},
                 '$item_metadata',
                 '{$cart_item->callback}',
                 '$item_callback_params'
                 )
                 ON DUPLICATE KEY UPDATE cartitem_quantity = cartitem_quantity + {$cart_item->item_quantity}");
  
    // Refresh. TBD: do better
    $this->load_cart_items();
    
  }
  
  
    
  
  function set_item_quantity( $item_number, $item_quantity = 1 ) {
    global $database;
    //if(!$this->valid_product($item_id))
    //  return;

    //$item_id = intval($item_id);
    //$quantity = intval($quantity);

    if($item_quantity < 0)
      $item_quantity = 0;
    
    if($quantity > 0) {
      $database->database_query("UPDATE se_semods_cartitems
                                SET cartitem_quantity = $item_quantity
                                WHERE cartitem_cart_id = {$this->cart_id} AND cartitem_number = $item_number");
    } else {
      $database->database_query("DELETE FROM se_semods_cartitems WHERE cartitem_cart_id = {$this->cart_id} AND cartitem_number = $item_number");
    }

    // Refresh. TBD: do better
    $this->load_cart_items();

    // $this->products[$item_id]['quantity'] = $quantity;

  }
  
  function total() {
    $total = 0;
    foreach($this->cart_items as $cart_item) {
      $total += $cart_item['cartitem_quantity']*$cart_item['cartitem_price'];
    }
    $total = sprintf( "%.2f", $total );
    return $total;
  }

  function total_without_subscriptions() {
    $total = 0;
    foreach($this->cart_items as $cart_item) {
      if($cart_item['cartitem_type'] == 1)
        continue;
      
      $total += $cart_item['cartitem_quantity']*$cart_item['cartitem_price'];
    }
    $total = sprintf( "%.2f", $total );
    return $total;
  }
  
  function on_cart_paid() {
    
    if($this->cart_info['cart_paid']) {
      // WTF, processing already paid cart!
      
    } else {
      $this->cart_info['cart_paid'] = true;
      $database->database_query("UPDATE se_semods_cart SET cart_paid = 1 WHERE cart_id = {$this->cart_id}");
      
      foreach($this->cart_items as $cart_item) {
        if( !empty($cart_item['cartitem_callback']) && is_callable($cart_item['cartitem_callback']) ) {
          // TBD: also push all cart item params? e.g. quantity, etc
          call_user_func_array( $cart_item['cartitem_callback'], unserialize($cart_item['cartitem_callbackparams']));
        }
      }
    }
  }    
  
  
}
?>