
// will overwrite?
SEMods.Controls = function() { };


SEMods.Controls.Dialog = function( params ) {
  
  this.title = params.title ? params.title : '';
  this.text = params.text;
  
  if(params.yesButtonText) this.yesButtonText = params.yesButtonText;
  if(params.noButtonText) this.noButtonText = params.noButtonText;
  if(params.onYes) this.onYes= params.onYes;
  if(params.onNo) this.onNo= params.onNo;
  if(params.width) this.width = params.width;
  if(params.height) this.height = params.height;
  
  this.init();
  this.show();
  
}

SEMods.Controls.Dialog.close = function(id) {
  var dlg = SEMods.B.ge("semods_dlg" + id);
  dlg._obj.onNoClick();
}

SEMods.Controls.Dialog.prototype = {
  title : null,
  text : null,
  yesButtonText : 'Yes',
  noButtonText : 'No',
  width : null,
  height : null,
  dlgElem : null,
  onYes : null,
  onNo : null,
  id : null,
  
  init : function() {

    this.id = Math.floor(Math.random()*1000000);
    this.dlgElem = document.createElement("DIV");
    this.dlgElem._obj = this;
    this.dlgElem.className = "semods_dialog";
    this.dlgElem.id = "semods_dlg" + this.id;
    this.dlgElem.style.left = "200px";
    this.dlgElem.style.top = "200px";
    this.dlgElem.style.display = "none";

    this.dlgElem.style.width = this.width ? this.width : "500px";
    this.dlgElem.style.height = this.height ? this.height : "300px";

    this.dlgElem.innerHTML = "<div id=semods_dlgheader><div style='float:right'><a href=javascript:SEMods.Controls.Dialog.close('" + this.id + "')>close</a></div></div>";
    this.dlgElem.innerHTML += "<div id=semods_dlgtitle> " + this.title + "</div>";
    this.dlgElem.innerHTML += "<div id=semods_dlgtext>" + this.text + "</div>";
    this.dlgElem.innerHTML += "<div id=semods_dlgbuttons><input type='button' class='button' id='semods_dlgbtnyes'><input type='button' class='button' id='semods_dlgbtnno'></div>";

    var inputs = this.dlgElem.getElementsByTagName("INPUT");
    SEMods.B.addEvent( inputs[0], "click", this.onYesClick.bind(this) );
    inputs[0].value = this.yesButtonText;
    SEMods.B.addEvent( inputs[1], "click", this.onNoClick.bind(this) );
    inputs[1].value = this.noButtonText;

    document.body.appendChild( this.dlgElem );
    
  },
  
  show : function() {
    SEMods.B.show( this.dlgElem );
  },
  
  hide : function() {
    SEMods.B.hide( this.dlgElem );
  },
  
  onYesClick : function() {
    this.hide();
    if(this.onYes)
      this.onYes();
  },

  onNoClick : function() {
    this.hide();
    //document.removeChild( this.dlgElem );
    if(this.onNo)
      this.onNo();
  },
  
  _cancelEvent : function(e) {
      var e = e ? e : window.event;
          
      if(e.preventDefault)
          e.preventDefault();
  
      if(e.stopPropagation) 
          e.stopPropagation(); 
  
      e.cancelBubble = true;
  
      e.returnValue = false;
      return false;
  }
  
}