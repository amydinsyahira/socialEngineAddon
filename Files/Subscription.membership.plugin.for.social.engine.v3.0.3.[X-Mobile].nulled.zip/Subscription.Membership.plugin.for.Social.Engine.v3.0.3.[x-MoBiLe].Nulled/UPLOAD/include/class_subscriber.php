<?php

$plan_periodtypes = array(  0 => array( 'id'  => 0, 's' => 'D', 'f' => $functions_subscriber[1], 'p' => 'day',   'max' => 90 ),
                            1 => array( 'id'  => 1, 's' => 'W', 'f' => $functions_subscriber[2], 'p' => 'week',  'max' => 52 ),
                            2 => array( 'id'  => 2, 's' => 'M', 'f' => $functions_subscriber[3], 'p' => 'month', 'max' => 12 ),
                            3 => array( 'id'  => 3, 's' => 'Y', 'f' => $functions_subscriber[4], 'p' => 'year',  'max' => 1 )
                          );

/*
 * userplan_state
 * 0 - active
 * 1 - active_trial
 * 2 - expired
 * 3 - cancelled
 * 4 - suspended(?)
 * 5 - created - waiting for payment confirmation
 * 6 - future??? - subscribed but not yet activated, when previous plan is still active and "downgrading" plan
 * 7 - suspended - failed payment
 * 
 */

$userplan_states = array( 0  => $functions_subscriber[10],
                          1  => $functions_subscriber[11],
                          2  => $functions_subscriber[12],
                          3  => $functions_subscriber[13],
                          4  => $functions_subscriber[14],
                          5  => $functions_subscriber[15],
                          7  => $functions_subscriber[17],
                          );


class semods_plan {
  
  var $plan_exists = 0;
  var $plan_info = array();
  
  var $userplan = null;
  var $user_id = null;
  
  
  
  function semods_plan( $plan_id, $user_id = null ) {
    global $plan_periodtypes;
    
    $plan_id = intval($plan_id);
    $user_id = intval($user_id);
    
    $this->user_id = $user_id;
    
    $this->plan_info = semods::db_query_assoc("SELECT * FROM se_semods_plans WHERE plan_id = $plan_id");
    if($this->plan_info) {
        $this->plan_exists = 1;
        $this->plan_info['plan_trialperiodtypetext'] = $plan_periodtypes[ $this->plan_info['plan_trialperiodtype'] ]['f'];
        $this->plan_info['plan_periodtypetext'] = $plan_periodtypes[ $this->plan_info['plan_periodtype'] ]['f'];
        
        if(!is_null($user_id)) {
          $this->userplan = new semods_userplan( 0, $user_id, $this->plan_info['plan_id'] );
        }
    }
  }


  function plan_subscribe( $user_id, $handler_id, $metadata = array(), $has_trial = true ) {
    global $database, $plan_periodtypes, $functions_subscriber;
    
    /*
     * 1. Create or extend user plan
     *  Extending works by adding plan's period to current time
     *
     * 2. Set associated user level
     *
     */

    $now = time();
    
    $this->user_id = $user_id;

    // Check for plan in the same category and silently cancel it
    //$userplan = new semods_userplan( null, $user_id, null, $this->plan_info['plan_category'] );

    // Check for plan - now only one plan per user
    $userplan = new semods_userplan( null, $user_id );
    if($userplan->userplan_exists) {
      $userplan->cancel_plan( 1, 1 );
      $userplan->delete_plan();
    }
    
    // NEW PLAN SUBSCRIPTION

    // IF TRIAL PERIOD, SET EXPIRATION TO END OF TRIAL PERIOD, OTHERWISE,
    // NOT -> END OF SUBSCRIPTION PERIOD
    // +1H ? same day, plan_extend will extend the period after payment confirmed?
    
    if($this->is_free_plan()) {
      
        $expiration_date = 0; // never
        $userplan_state = 0;  // active
      
    } else {
      
      if( !$has_trial || ($this->plan_info['plan_trialperiod'] == 0) ) {
  
        $expiration_date = $now + 3600;
        $userplan_state = 0;  // active
  
      } else {
    
          // TBD: doG! convert periods to seconds
          
        // there will be no "payment" notifications
        if($this->plan_info['plan_trialperiodprice'] == 0) {
          
          $extension_period = "+{$this->plan_info['plan_trialperiod']} "  . $plan_periodtypes[ $this->plan_info['plan_trialperiodtype'] ]['p'];
          $expiration_date = strtotime( $extension_period, $now );
          
        }
        else {
          
          $expiration_date = $now + 3600;
          
        }
  
        $userplan_state = 1;  // active_trial
  
      }
      
    }

    $userplan_field1 = semods::g( $metadata, 'field1', '' );
    $userplan_metadata = serialize($metadata);
    
    // CREATE USER PLAN
    $database->database_query( "INSERT INTO se_semods_userplans(
                                  userplan_user_id,
                                  userplan_plan_id,
                                  userplan_startdate,
                                  userplan_expiredate,
                                  userplan_state,
                                  userplan_handler,
                                  userplan_metadata,
                                  userplan_field1)
                                VALUES (
                                  $user_id,
                                  {$this->plan_info['plan_id']},
                                  $now,
                                  $expiration_date,
                                  $userplan_state,
                                  $handler_id,
                                  '$userplan_metadata',
                                  '$userplan_field1'
                                  )
                              ");
    
    $newplan_id = $database->database_insert_id();
    

    // UPDATE USER LEVEL, UNLESS "NO LEVEL"
    if($this->plan_info['plan_level_id'] != 0) {
      $database->database_query( "UPDATE se_users SET user_level_id = {$this->plan_info['plan_level_id']} WHERE user_id = $user_id " );
    }
    

    subscriber_log_activity ( $user_id,
                              $functions_subscriber[100],
                              100,
                              array( '[plan_name]'  => $this->plan_info['plan_name'],
                                     '[plan_id]'    => $this->plan_info['plan_id']
                                    )
                            );
    
    subscriber_email_subscription_created( $user_id, $this->plan_info );
    
    return new semods_userplan( $newplan_id );
    
  }




  // this actually should be method of semods_userplan
  function plan_extend( ) {

    // Extending / continuing plan
    if($this->userplan && $this->userplan->userplan_exists) {
      $this->userplan->extend_plan();
    }
    
  }

  
  function is_free_plan() {
    return (($this->plan_info['plan_price'] == 0) && ($this->plan_info['plan_onetime_price'] == 0));
  }
  
  
  function enable($enabled) {
    global $database;

    // TBD: what to do with guys with active plan
    if($this->plan_exists == 1)
      $database->database_query("UPDATE se_semods_plans SET plan_enabled = $enabled WHERE plan_id = {$this->plan_info['plan_id']}");
  }
  
  
  
  function delete() {
    global $database;

    // TBD: what to do with guys with active plan
    if($this->plan_exists == 1)
      $database->database_query("DELETE FROM se_semods_plans WHERE plan_id = {$this->plan_info['plan_id']}");
  }
  
  
  
  function total_users() {
    return semods::db_query_count("SELECT COUNT(*) FROM se_semods_userplans WHERE userplan_plan_id = {$this->plan_info['plan_id']} ");
  }
  
  function total_active_users() {
    return semods::db_query_count("SELECT COUNT(*) FROM se_semods_userplans WHERE userplan_plan_id = {$this->plan_info['plan_id']} AND userplan_state IN(0,1,3,4,5,7)");
  }

  function total_managed_users() {
    return semods::db_query_count("SELECT COUNT(*) FROM se_semods_userplans WHERE userplan_plan_id = {$this->plan_info['plan_id']} AND userplan_state IN(0,1,3,4,5,7) AND userplan_handler != 0");
  }
  
}






class semods_userplan {
  
  var $userplan_exists = 0;
  var $userplan_info = array();
  
  
  
  function semods_userplan( $userplan_id, $user_id = null, $plan_id = null, $plan_cat = null, $plan_field1 = null ) {
    global $plan_periodtypes, $userplan_states;
    
    if(!is_null($user_id)) {
      
      if(!is_null($plan_id)) {
        $this->userplan_info = semods::db_query_assoc("SELECT *
                                                   FROM se_semods_userplans UP
                                                   LEFT JOIN se_semods_plans P
                                                    ON UP.userplan_plan_id = P.plan_id
                                                   WHERE userplan_user_id = $user_id AND userplan_plan_id = $plan_id 
                                                  ");
      } else if(!is_null($plan_cat)) {
        $this->userplan_info = semods::db_query_assoc("SELECT *
                                                   FROM se_semods_userplans UP
                                                   LEFT JOIN se_semods_plans P
                                                    ON UP.userplan_plan_id = P.plan_id
                                                   WHERE userplan_user_id = $user_id AND plan_category = $plan_cat 
                                                  ");
      } else if(!empty($userplan_id)) {
        $this->userplan_info = semods::db_query_assoc("SELECT *
                                                   FROM se_semods_userplans UP
                                                   LEFT JOIN se_semods_plans P
                                                    ON UP.userplan_plan_id = P.plan_id
                                                   WHERE userplan_user_id = $user_id AND userplan_id = $userplan_id
                                                  ");
      } else {
        $this->userplan_info = semods::db_query_assoc("SELECT *
                                                   FROM se_semods_userplans UP
                                                   LEFT JOIN se_semods_plans P
                                                    ON UP.userplan_plan_id = P.plan_id
                                                   WHERE userplan_user_id = $user_id
                                                  ");
      }
      
    } elseif(!is_null($plan_field1)) {
      $this->userplan_info = semods::db_query_assoc("SELECT *
                                                 FROM se_semods_userplans UP
                                                 LEFT JOIN se_semods_plans P
                                                  ON UP.userplan_plan_id = P.plan_id
                                                 WHERE userplan_field1 = '$plan_field1'
                                                ");
    } else {
      $this->userplan_info = semods::db_query_assoc("SELECT *
                                                 FROM se_semods_userplans UP
                                                 LEFT JOIN se_semods_plans P
                                                  ON UP.userplan_plan_id = P.plan_id
                                                 WHERE userplan_id = $userplan_id
                                                ");
    }
    
    if($this->userplan_info) {
        $this->userplan_exists = 1;
        $this->userplan_info['plan_trialperiodtypetext'] = $plan_periodtypes[ $this->userplan_info['plan_trialperiodtype'] ]['f'];
        $this->userplan_info['plan_periodtypetext'] = $plan_periodtypes[ $this->userplan_info['plan_periodtype'] ]['f'];
        $this->userplan_info['userplan_statetext'] = $userplan_states[ $this->userplan_info['userplan_state'] ];
    }
    
  }
  
  
  
  // $period_type -
  //  0 : regular
  //  1 : trial
  //
  function extend_plan( $period_type = 0 ) {
    global $database, $plan_periodtypes, $functions_subscriber;

    /*
     * 1. Extend user plan
     *  Extending works by adding plan's period to current time if plan was cancelled / expired
     *  or adding adding plan's period to userplan_expiredate
     *
     */
    
    $now = time();

    // regular
    if($period_type == 0) {
      $extension_period = "+{$this->userplan_info['plan_period']} "  . $plan_periodtypes[ $this->userplan_info['plan_periodtype'] ]['p'];
      $plan_state = 0;  // active
    } else {
      // trial
      $extension_period = "+{$this->userplan_info['plan_trialperiod']} "  . $plan_periodtypes[ $this->userplan_info['plan_trialperiodtype'] ]['p'];
      $plan_state = 1;  // active_trial
    }
    
    // UPDATE USER PLAN

    // If not
    //  0 - active
    //  1 - active_trial - (expired, cancelled, etc) - refresh start date
    //  5 - created - waiting for payment confirmation
    if(!in_array( intval($this->userplan_info['userplan_state']), array(0,1,5) )) {

      $expiration_date = strtotime( $extension_period, $now );
      
      $database->database_query( "UPDATE se_semods_userplans SET
                                    userplan_startdate = $now,
                                    userplan_state = $plan_state,
                                    userplan_expiredate = $expiration_date 
                                  WHERE userplan_id = {$this->userplan_info['userplan_id']}
                                ");

    } else {

      // if plan is expired and receive payment - extend, but start date not changed? - this may happen if payment was failed but profile is still active

      $expiration_date = strtotime( $extension_period, $this->userplan_info['userplan_expiredate'] );

      $database->database_query( "UPDATE se_semods_userplans SET
                                    userplan_state = $plan_state,
                                    userplan_expiredate = $expiration_date 
                                  WHERE userplan_id = {$this->userplan_info['userplan_id']}
                                ");
      
    }

    subscriber_log_activity ( $this->userplan_info['userplan_user_id'],
                              $functions_subscriber[103],
                              103,
                              array( '[plan_name]'  => $this->userplan_info['plan_name'],
                                     '[plan_id]'    => $this->userplan_info['plan_id']
                                    )
                            );

    subscriber_email_subscription_renewed( $this->userplan_info['userplan_user_id'], $this->userplan_info );
    
  }
  
  
  
  function cancel_plan( $fast = 0, $silent = 0, $remote_cancel = 0 ) {
    global $database, $functions_subscriber;

    // can cancel only when: active(0), active_trial(1), suspended(4), suspended_failed_payment(7), ? pending payment 5?
    if($this->userplan_exists == false)
      return false;
    
    if(!in_array( $this->userplan_info['userplan_state'], array(0,1,4,7)))
      return false;
    
    // if silent -> don't notify user
    // if fast & provider doesn't support fast_cancel -> queue in tasks
    
    if($fast) {
    
      $notify = intval(!$silent);
      
      // Queue task
      $database->database_query( "INSERT INTO se_semods_plantasks (
                                plantask_type,
                                plantask_metadata,
                                plantask_paymentgw,
                                plantask_notify
                                ) VALUES (
                                'cancel_subscription',
                                '{$this->userplan_info['userplan_metadata']}',
                                {$this->userplan_info['userplan_handler']},
                                $notify)" );
    } else {
    
      if($remote_cancel == 0)  {
        
        if($this->userplan_info['userplan_handler'] != 0) {
        $paymentgw = semods_paymengtw_factory( $this->userplan_info['userplan_handler'] );
      
          // Log Error
          if(!$paymentgw) {
            subscriber_log_error( "Error cancelling plan - Failed instantiating Payment Handler (id={$this->userplan_info['userplan_handler']})", 1000, $this->userplan_info['userplan_user_id'] );
          } else {
      
        // TBD: check creation was ok
        $result = $paymentgw->cancel_subscription( array( 'fast' => $fast, 'metadata' => $this->userplan_info['userplan_metadata'] ) );

        // Log Error
        if(!$result) {
          subscriber_log_activity ( $this->userplan_info['userplan_user_id'],
                                    $functions_subscriber[1001],
                                    1001,
                                    array( '[plan_name]'  => $this->userplan_info['plan_name'],
                                           '[plan_id]'    => $this->userplan_info['plan_id'],
                                           '[err_msg]'              => $paymentgw->errMsg,
                                           '[paymentgateway_name]'  => $paymentgw->name,
                                          )
                                  );
          // TODO
          // email_notify_admin(error cancelling ?  queue task? );
        
        }
        
      }
      
    }

      }
      
    }

    if($remote_cancel == 0)  {
          
      subscriber_log_activity ( $this->userplan_info['userplan_user_id'],
                                $functions_subscriber[101],
                                101,
                                array( '[plan_name]'  => $this->userplan_info['plan_name'],
                                       '[plan_id]'    => $this->userplan_info['plan_id']
                                      )
                              );
      } else {

      subscriber_log_activity ( $this->userplan_info['userplan_user_id'],
                                $functions_subscriber[101] . $functions_subscriber[99],
                                101,
                                array( '[plan_name]'  => $this->userplan_info['plan_name'],
                                       '[plan_id]'    => $this->userplan_info['plan_id']
                                      )
                              );

      }
      
//    if(!$silent) {
      subscriber_email_subscription_cancelled( $this->userplan_info['userplan_user_id'], $this->userplan_info );
//    }

    // Update status, though plan may not have been fully cancelled yet
    $database->database_query("UPDATE se_semods_userplans SET userplan_state = 3, userplan_handler = 0 WHERE userplan_id = {$this->userplan_info['userplan_id']}");
    
  }
  
  
  function change_state( $new_state ) {
    global $database;
    
    // Same state? 
    if($this->userplan_info['userplan_state'] == $new_state)
      return;
    
    // Update status, though plan may not have been fully cancelled yet
    $database->database_query("UPDATE se_semods_userplans SET userplan_state = $new_state WHERE userplan_id = {$this->userplan_info['userplan_id']}");
    
    /*
     * userplan_state
     * 0 - active
     * 1 - active_trial
     * 2 - expired
     * 3 - cancelled
     * 4 - suspended(?)
     * 5 - created - waiting for payment confirmation
     * 6 - future??? - subscribed but not yet activated, when previous plan is still active and "downgrading" plan
     * 7 - suspended - failed payment
     * 
     */

    switch($new_state) {
      case 2:
      case 3:
      case 4:
      case 7:
        $this->downgrade();
        break;
      
      case 0:
      case 1:
      case 5:
        $this->upgrade();
        break;
      
    }
    
  }



  function expire_plan( ) {
    global $database, $functions_subscriber;

    // can expire only when: active(0), active_trial(1), suspended(4), suspended_failed_payment(7), ? pending payment 5?
    
    if(!in_array( $this->userplan_info['userplan_state'], array(0,1,4,7)))
      return false;
    
    $paymentgw = semods_paymengtw_factory( $this->userplan_info['userplan_handler'] );
    
    // Do we need this?
    if($paymentgw) {
      
      // TBD: check creation was ok
      $result = $paymentgw->cancel_subscription( array( 'fast' => $fast, 'metadata' => $this->userplan_info['userplan_metadata'] ) );

      if(!$result) {
        // notify_admin_on_error
      }
      
    } else {
      // error?
    }
    
    

    // Update status, though plan may not have been fully cancelled yet
    $database->database_query("UPDATE se_semods_userplans SET userplan_state = 2 WHERE userplan_id = {$this->userplan_info['userplan_id']}");
    $this->downgrade();
    

    subscriber_log_activity ( $this->userplan_info['userplan_user_id'],
                              $functions_subscriber[102],
                              102,
                              array( '[plan_name]'  => $this->userplan_info['plan_name'],
                                     '[plan_id]'    => $this->userplan_info['plan_id']
                                    )
                            );

    subscriber_email_subscription_expired( $this->userplan_info['userplan_user_id'], $this->userplan_info );
    
  }




  function suspend_plan_failed_payment() {
    global $database, $functions_subscriber;

    if($this->userplan_exists == 0)
      return false;
    
    // can suspend active(0), active_trial(1), cancelled (3)
    if(!in_array( $this->userplan_info['userplan_state'], array(0,1,3)))
      return false;
    
    // Update status, though plan may not have been fully cancelled yet
    $database->database_query("UPDATE se_semods_userplans SET userplan_state = 7 WHERE userplan_id = {$this->userplan_info['userplan_id']}");
    $this->downgrade();

    subscriber_log_activity ( $this->userplan_info['userplan_user_id'],
                              $functions_subscriber[104],
                              104,
                              array( '[plan_name]'  => $this->userplan_info['plan_name'],
                                     '[plan_id]'    => $this->userplan_info['plan_id']
                                    )
                            );

    subscriber_email_subscription_suspended_no_payment( $this->userplan_info['userplan_user_id'], $this->userplan_info );
  }



  function  set_expiration_date($new_expiration_date_unixtimestamp) {
    global $database;

    // Same date? 
    if($this->userplan_info['userplan_expiredate'] == $new_expiration_date_unixtimestamp)
      return;
    
    // Update expiration date
    $database->database_query("UPDATE se_semods_userplans SET userplan_expiredate = $new_expiration_date_unixtimestamp WHERE userplan_id = {$this->userplan_info['userplan_id']}");
    
  }



  // Downgrade user level, if applicable
  function downgrade() {
    global $database;

    // DOWNGRADE USER LEVEL, UNLESS "NO LEVEL"
    if($this->userplan_info['plan_downgrade_level_id'] != 0) {
      $database->database_query( "UPDATE se_users SET user_level_id = {$this->userplan_info['plan_downgrade_level_id']} WHERE user_id = {$this->userplan_info['userplan_user_id']}" );
    }
    
  }
  

  // Upgrade user level, if applicable
  function upgrade() {
    global $database;

    // UPDATE USER LEVEL, UNLESS "NO LEVEL"
    if($this->userplan_info['plan_level_id'] != 0) {
      $database->database_query( "UPDATE se_users SET user_level_id = {$this->userplan_info['plan_level_id']} WHERE user_id = {$this->userplan_info['userplan_user_id']} " );
    }
    
  }
  

  
  function delete_plan() {
    global $database;
    
    $database->database_query("DELETE FROM se_semods_userplans WHERE userplan_id = {$this->userplan_info['userplan_id']}");
  }
  
}








?>