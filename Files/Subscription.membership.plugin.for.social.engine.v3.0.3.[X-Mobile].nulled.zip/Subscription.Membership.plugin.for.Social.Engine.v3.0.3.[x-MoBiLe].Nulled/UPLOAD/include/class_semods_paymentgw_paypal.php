<?php

class semods_paymentgw_paypal extends semods_paymentgw_base {

  var $paypalapi;
  
  var $errID;
  var $errMsg;

  var $name = "Paypal";
  
  function semods_paymentgw_paypal( $params ) {
    global $url, $folder;
    
    if($folder == "base") {
    include './include/class_semods_paypalapi.php';
    } else {
      include '../include/class_semods_paypalapi.php';
    }

    // TBD: this urls stuff is external 
    $return_url = $url->url_base . 'payment.php?task=pay';
    $cancel_url = $url->url_base . 'payment.php?task=cancel';
    $notify_url = $url->url_base . 'payment_paypal.php?action=ipn';

    $this->paypalapi = new semods_paypalapi( array( 'user'       => $params['api_username'],
                                            'pwd'        => $params['api_password'],
                                            'signature'  => $params['api_signature'],
                                            'returnurl'  => $return_url,
                                            'cancelurl'  => $cancel_url,
                                            'notifyurl'  => $notify_url
                                           )
                                    );

  }
  
  
  
  
  
  
  function cancel_subscription( $params )  {
    $metadata = unserialize( $params['metadata'] );
    $result = $this->paypalapi->CancelRecurringPaymentsProfile( array( 'PROFILEID' => $metadata['field1'] ) );

    if(!$result) {
      $this->errID = 1;
      $this->errMsg = "Paypal Error during CancelRecurringPaymentsProfile ( PROFILEID = {$metadata['field1']} ): " . $this->paypalapi->errMsg . "\nPaypal Response:\n" . $this->paypalapi->paypal_rawresponse_to_string();
      return false;
    }
    
    return true;
  }
  
  
  
  
  
  
  
  function checkout( &$cart ) {
    global $functions_payment;
  
    $items = array();
    $billing_items = array();
    
    foreach($cart->cart_items as $cart_item) {
      switch($cart_item['cartitem_type']) {
        
        // regular product
        case 0:
          $items[] = array( 'name'    => $cart_item['cartitem_name'],
                            'number'  => $cart_item['cartitem_number'],
                            'qty'     => $cart_item['cartitem_quantity'],
                            'amt'     => $cart_item['cartitem_price'],
  //                          'desc'    => $cart_item['cartitem_name'],   // future - when paypal will finish full detail in checkout express
                            'taxamt'  => 0
                            ); 
          break;
        
        // subscription
        case 1:
        
          $billing_items[] = array( 'type'  => 'RecurringPayments',
                                    'desc'  => $cart_item['cartitem_name']
                                    );
          break;
        
      }
    }
  
    // TODO: make sure amount is > 0
    
    $payment_amount = $cart->total();
    $payment_type = $functions_payment[31];;
    
    $currency_code = semods::get_setting('setting_payment_currency');

    $no_shipping = 1;

    $desc = $functions_payment[30];
    
    $custom = $cart->cart_info['cart_id'];
    
    $params = array(  'AMT'			  => $payment_amount,
                      'CURRENCYCODE'  => $currency_code,
                      'NOSHIPPING'    => $no_shipping,
                      'CUSTOM'        => $custom
                    );
    
    if($items) {
      $params['PAYMENTACTION'] = $payment_type;
      $params['DESC'] = $desc;
    }
    
    // TODO: check payment > 0, without subscriptions
    
    $result = $this->paypalapi->SetExpressCheckout( $params,
                                             $items,
                                             $billing_items
                                            );
    
    if(!$result) {
      $this->errID = 1;
      $this->errMsg = 'Paypal Error during checkout(SetExpressCheckout): ' . $this->paypalapi->errMsg . "\nPaypal Response:\n" . $this->paypalapi->paypal_rawresponse_to_string();
      return false;
    }
    
    return true;
    
  }




  /***** PAYMENT FUNCTION *****/



  // SHOULD BE ONLY CALLED AFTER SUCCESSFULL checkout()

  function pay( $cart = null ) {
    global $functions_payment;


    $token = semods::getpost('token');
  
    $this->paypalapi->set_session_params( array( 'TOKEN'  => $token ) );
  
    $result = $this->paypalapi->GetExpressCheckoutDetails( array() );
  
    if(!$result) {
      $this->errID = 1;
      $this->errMsg = 'Paypal Error in GetExpressCheckoutDetails: ' . $this->paypalapi->errMsg . "\nPaypal Response:\n" . $this->paypalapi->paypal_rawresponse_to_string();
      return false;
    }
    
    
    $payer_id = $this->paypalapi->response['PAYERID'];
    $cart_id = $this->paypalapi->response['CUSTOM'];
  

    $cart = new semods_cart( $cart_id );
    if($cart->cart_exists == false) {
      $this->errID = 2;
      $this->errMsg = "Error during payment - cart (id=$cart_id) doesn't exist";
      return false;
    }

  
    
  // PAYMENT
  
  // if have discount => pay as whole cart !?
  // how to apply discount to subscription plan ?!
  
    $payment_amount = $cart->total_without_subscriptions();
    $payment_type = $functions_payment[31];
    $currency_code = semods::get_setting('setting_payment_currency');;
  
    if($payment_amount > 0 ) {
      
      $result = $this->paypalapi->DoExpressCheckoutPayment( array(  'AMT'			=> $payment_amount,
                                                              'PAYMENTACTION' => $payment_type,
                                                              'CURRENCYCODE'  => $currency_code,
                                                              'PAYERID'		=> $payer_id
                                                            )
                                              );
      
      if(!$result) {
        $this->errID = 1;
        $this->errMsg = 'Paypal Error during DoExpressCheckoutPayment: ' . $this->paypalapi->errMsg . "\nPaypal Response:\n" . $this->paypalapi->paypal_rawresponse_to_string();
        return false;
      }
  
    }
  
  
  
  // SUBSCRIPTION
  
    $paypal_plan_periodtypes = array( 0 => 'Day',
                                      1 => 'Week',
                                      2 => 'Month',
                                      3 => 'Year' 
                              );
  
  
    foreach($cart->cart_items as $cart_item) {
  
      // subscription    
      if ($cart_item['cartitem_type'] == 1) {
        
        $metadata = unserialize($cart_item['cartitem_metadata']);
  
        // ECHECK not supported for recurring payments now --> http://www.pdncommunity.com/pdn/board/message?board.id=payflow&message.id=4326
        
        $start_time = strtotime(date('m/d/Y'));
        $profile_startdate = date( 'Y-m-d\T00:00:00\Z', $start_time );
        
        //$profile_startdate = date(DATE_ATOM);
  
        $params = array( 'PROFILESTARTDATE'	=> $profile_startdate,
                         'BILLINGPERIOD'	=> $paypal_plan_periodtypes[ $metadata['periodtype'] ],
                         'BILLINGFREQUENCY'	=> $metadata['period'],
                         'AMT'				=> $cart_item['cartitem_price'],
                         'DESC'				=> $cart_item['cartitem_name'],
                        );
  
        
        if( $metadata['recurring'] ) {
          $params['TOTALBILLINGCYCLES'] = $metadata['recurring_cycles'];
        } else {
          $params['TOTALBILLINGCYCLES'] = 0;
        }
        
        // TBD: how coupon can affect trial price?
        // TBD: add more trial billing cycles?
        if( isset($metadata['trial_period']) ) {
          $params['TRIALBILLINGPERIOD'] = $paypal_plan_periodtypes[ $metadata['trial_periodtype'] ];
          $params['TRIALBILLINGFREQUENCY'] = $metadata['trial_period'];
          $params['TRIALAMT'] = $metadata['trial_price'];
          $params['TRIALTOTALBILLINGCYCLES'] = 1;
          //$params['TRIALTAXAMT'] = ;
        }

        if( isset($metadata['initial_price']) && $metadata['initial_price'] > 0 ) {
          $params['INITAMT'] = $metadata['initial_price'];
        }
      
        $params['AUTOBILLOUTAMT'] = 'AddToNextBilling';
        
        $result = $this->paypalapi->CreateRecurringPaymentsProfile( $params );
        
        /*
         AUTOBILLOUTAMT 
         TOTALBILLINGCYCLES
         
         DESC - must match the one in setEC
         CURRENCYCODE
         
         PROFILEREFERENCE - "custom" The merchant's own unique reference or invoice number.
                                      Character length and limitations: 127 single-byte alphanumeric
                                      characters
         
         TRIALBILLINGPERIOD
         TRIALBILLINGFREQUENCY
         TRIALAMT
         TRIALTOTALBILLINGCYCLES -> required if trial present
         TRIALTAXAMT
         
         INITAMT
         FAILEDINITAMTACTION
         
        */
  
        if(!$result) {
          $this->errID = 1;
          $this->errMsg = 'Paypal Error during CreateRecurringPaymentsProfile: ' . $this->paypalapi->errMsg . "\nPaypal Response:\n" . $this->paypalapi->paypal_rawresponse_to_string();
          return false;
        }


        // EVERYTHING WENT OK, RECURRING PAYMENTS PROFILE WAS CREATED - CREATE SUBSCRIPTION (AND CANCEL OTHERS) BUT STATUS - WAITING FOR PAYMENT
  
        $profile_id = $this->paypalapi->response['PROFILEID'];
        
        $plan = new semods_plan( $metadata['pid'] );

        if($plan->plan_exists == 0) {
          // should never happen
          $this->errID = 2;
          $this->errMsg = "Error creating profile - profile (id={$metadata['pid']}) doesn't exist";
          return false;
        }
        
        // Also get trial period status from cart (can be cancelled by rules)
        $plan->plan_subscribe( $metadata['uid'],                          // user_id
                              1,                                          // handler_id - paypal
                              array( 'field1' => $profile_id ),            //metadata
                              isset($metadata['trial_period']) ? true : false
                              );
          
          
        
        // wtf?      
          break;
        
      }
  
      
    }
    
    return true;
   
  }
  
  
  /*
   * Retrieve Paypal Balance via API
   * Used just for testing API
   *
   */
  function get_balance() {

    $result = $this->paypalapi->GetBalance( );
    
    if(!$result) {
      $this->errID = $this->paypalapi->errID;
      $this->errMsg = 'Paypal Error during GetBalance: ' . $this->paypalapi->errMsg;
      return false;
    }

    return array( 'balance'       => $this->paypalapi->response['L_AMT1'],
                  'currencycode'  => $this->paypalapi->response['L_CURRENTYCODE1'] );

  }
  
  /*
   * Retrieve Paypal Balance via API
   * Used just for testing API
   *
   */
  function get_transaction_details( $transaction_id ) {

    $result = $this->paypalapi->GetTransactionDetails( array( 'TRANSACTIONID' => $transaction_id ) );
    
    if(!$result) {
      $this->errID = $this->paypalapi->errID;
//      $this->errMsg = 'Paypal Error during GetTransactionDetails: ' . $this->paypalapi->errMsg . "\nPaypal said: " . $this->paypalapi->response_raw;
      $this->errMsg = 'Paypal Error during GetTransactionDetails: ' . $this->paypalapi->errMsg;
      return false;
    }

    return array( 'transaction_id' => $this->paypalapi->response['TRANSACTIONID'] );
  }
  
}

?>