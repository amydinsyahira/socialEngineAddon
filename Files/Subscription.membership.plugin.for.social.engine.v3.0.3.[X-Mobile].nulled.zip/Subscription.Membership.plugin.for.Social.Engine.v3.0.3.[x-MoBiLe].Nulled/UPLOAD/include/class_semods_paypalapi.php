<?php

class semods_paypalapi {
  var $token;

  var $config = array();
  
  /* Parsed response from paypal */
  var $response = array();

  /* Raw response from paypal */
  var $response_raw = '';

  var $log_fp = null;

  var $errID;
  var $errMsg;
  
  var $session_params = array();
  
  
  function semods_paypalapi($params) {
    
//      $this->config['version'] = '3.0';
//      $this->config['version'] = '50.0';
      $this->config['version'] = '51.0';

      $this->config['use_proxy'] = false;
      $this->config['sandbox'] = false;

      $this->config['currency'] = 'USD';

      if($params)
        $this->config = array_merge( $this->config, $params );

      // sandbox / live values
      if($this->config['sandbox']) {      
        $this->config['api_endpoint'] = 'https://api-3t.sandbox.paypal.com/nvp';
        $this->config['paypal_url'] = 'https://www.sandbox.paypal.com/webscr&cmd=_express-checkout&token=';
        $this->config['user'] = 'sdk-three_api1.sdk.com';
        $this->config['pwd'] = 'QFZCWN5HZM8VBG7Q';
        $this->config['signature'] = 'A-IzJhZZjhg29XQ2qnhapuwxIDzyAZQ92FRP5dqBzVesOkzbdUONzmOU';
      } else {
        $this->config['api_endpoint'] = 'https://api-3t.paypal.com/nvp';
        $this->config['paypal_url'] = 'https://www.paypal.com/webscr&cmd=_express-checkout&token=';
      }
      
      $this->session_params['ReturnUrl'] = $params['returnurl'];
      $this->session_params['CancelURL'] = $params['cancelurl'];
      $this->session_params['NOTIFYURL'] = $params['notifyurl'];
      
//      $this->config['proxy_host'] = '';
//      $this->config['proxy_port'] = '';
      

  }


  function SetExpressCheckout( $params, $items = null, $billing_items = null ) {

    if($items) {
      for($i=0; $i<count($items); $i++) {
        $params['L_NAME'.$i] = $items[$i]['name'];
        $params['L_NUMBER'.$i] = $items[$i]['number'];
        $params['L_QTY'.$i] = $items[$i]['qty'];
        $params['L_AMT'.$i] = $items[$i]['amt'];
        $params['L_TAXAMT'.$i] = $items[$i]['taxamt'];
      }
    }

    if($billing_items) {
      for($i=0; $i<count($billing_items); $i++) {
        $params['L_BILLINGTYPE'.$i] = $billing_items[$i]['type'];
        $params['L_BILLINGAGREEMENTDESCRIPTION'.$i] = $billing_items[$i]['desc'];
        $params['L_BILLINGAGREEMENTCUSTOM'.$i] = $i;
      }
    }

    // TBD: LOCALECODE 
    
    if($this->call_method( 'SetExpressCheckout', $params )) {
      // Redirect to paypal.com here
      $paypal_url = $this->config['paypal_url'] . $this->response['TOKEN'];
      header("Location: " . $paypal_url);
      exit();
    }
    
    return false;
      
  }
  
  function GetExpressCheckoutDetails( $params ) {
    return $this->call_method( 'GetExpressCheckoutDetails', $params );
  }


  function DoExpressCheckoutPayment( $params ) {
    return $this->call_method( 'DoExpressCheckoutPayment', $params );
  }

  function CreateRecurringPaymentsProfile( $params ) {
    return $this->call_method( 'CreateRecurringPaymentsProfile', $params );
  }
  
  function CancelRecurringPaymentsProfile( $params ) {
    $params['ACTION'] = 'Cancel';
    return $this->call_method( 'ManageRecurringPaymentsProfileStatus', $params );
  }

  function SuspendRecurringPaymentsProfile( $params ) {
    $params['ACTION'] = 'Suspend';
    return $this->call_method( 'ManageRecurringPaymentsProfileStatus', $params );
  }

  function ReactivateRecurringPaymentsProfile( $params ) {
    $params['ACTION'] = 'Reactivate';
    return $this->call_method( 'ManageRecurringPaymentsProfileStatus', $params );
  }

  function GetBalance( $params = array() ) {
    return $this->call_method( 'GetBalance', $params );
  }

  function GetTransactionDetails( $params ) {
    return $this->call_method( 'GetTransactionDetails', $params );
  }

  function TransactionSearch( $params ) {
    return $this->call_method( 'TransactionSearch', $params );
  }

  // token, return_url, cancel_url
  function set_session_params( $params ) {
    $this->session_params = array_merge( $this->session_params, $params );
  }
  
  
  
  
  
  /*************  UTILITY FUNCTIONS *************/
  
  
  
  
  
  function log( $message ) {
      if(!$this->log_fp) {
          $this->log_fp = fopen( 'paypalapi_log.txt', 'a');
          fwrite( $this->log_fp, "****************************************************************************************************\n" );
      }
      
      fwrite($this->log_fp, strftime("%d %b %Y %H:%M:%S ") . "[class_semods_paypalapi.php] $message\n" );
  }

  function call_method( $method, $params ) {
    
    $result = $this->post_request( $method, $params );

    // HTTP ERROR
    if(!$result)
      return false;
    
    $this->response_raw = $result;
    
    // TBD: php4?
    parse_str( $result, $this->response );
    
    if(strtoupper($this->response["ACK"]) != "SUCCESS") {
      
      // parse errors
      $this->paypal_errors = array();
      for($i=0;;$i++) {
        if(isset($this->response['L_ERRORCODE'.$i])) {
          $this->paypal_errors[] = array( 'error_code'    => $this->response['L_ERRORCODE'.$i],
                                          'short_message' => $this->response['L_SHORTMESSAGE'.$i],
                                          'long_message'  => $this->response['L_LONGMESSAGE'.$i],
                                          'severity_code' => $this->response['L_SEVERITYCODE'.$i]
                                          );
        } else {
          break;
        }
      }
      $this->errID = $this->paypal_errors[0]['error_code'];
      $this->errMsg = "Paypal API Error - " . $this->paypal_errors[0]['long_message'];
      return false;
    }
    
    return true;
  }


  function post_request( $method, $params ) {

    $params['METHOD'] = $method;
    $params['VERSION'] = $this->config['version'];
    $params['USER'] = $this->config['user'];
    $params['PWD'] = $this->config['pwd'];
    $params['SIGNATURE'] = $this->config['signature'];
    
    // add TOKEN, returnurl, cancelurl
    $params = array_merge( $params, $this->session_params );
    
    // DEBUG
    //if($method != 'SetExpressCheckout')
    //  var_dump($params);
      
    $post_string = $this->convert_array_to_params( $params );

    // Use CURL if installed
    if (function_exists('curl_init'))
      return $this->post_request_with_curl( $post_string );
    else if ( PHP_VERSION >= '5.0.0' )
      return $this->post_request_without_curl( $post_string );
    else
      return $this->post_request_without_curl_php4( $post_string );
  }


  function post_request_with_curl($data) {

      $ch = curl_init();
      
      curl_setopt( $ch, CURLOPT_URL, $this->config['api_endpoint'] );
      curl_setopt( $ch, CURLOPT_POSTFIELDS, $data );
      curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
      curl_setopt( $ch, CURLOPT_ENCODING, '' );
    
      curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
      curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );

      if($this->config['use_proxy'])
          curl_setopt( $ch, CURLOPT_PROXY, $this->config['proxy_host'].":".$this->config['proxy_port'] ); 

                                    
      $result = curl_exec($ch);
      if(curl_errno($ch)) {
        $this->errMsg = 'HTTP Error: ' . curl_error( $ch );
        $this->errID = 1000;//$API_E_HTTP;
        return null;
      }
      curl_close($ch);
      return $result;
  }


  // PROXY !?
  function post_request_without_curl($data) {
      $context_opts =
        array('http' =>
              array('method' => 'POST',
                    'header' => 'Content-Type: application/x-www-form-urlencoded' . "\r\n" .
                                'Content-Length: ' . strlen($data),
                    'content' => $data));
      $context = stream_context_create($context_opts);
      $fp = @fopen($this->config['api_endpoint'], 'r', false, $context);
      if (!$fp) {
        $this->errMsg = 'HTTP Error';
        $this->errID = 1000;//$API_E_HTTP;
        return null;
      }
      $result = @stream_get_contents($fp);
      if( $result === false ) {
        $this->errMsg = 'HTTP Error';
        $this->errID = 1000;//$API_E_HTTP;
        return null;
      }
      return $result;
  }


  // PROXY !? SSL ?!
  function post_request_without_curl_php4($data) {
    
    // url MUST have scheme
    
	$start = strpos( $this->config['api_endpoint'], '//' ) + 2;
	$end = strpos( $this->config['api_endpoint'], '/', $start );
	$host = substr( $this->config['api_endpoint'], $start, $end - $start );
	$post_path = substr( $this->config['api_endpoint'], $end );
    $fp = fsockopen( "ssl://" . $host, 443, $errno, $errstr );
    if (!$fp) {
      $this->errMsg = 'HTTP Error';
      $this->errID = 1;
      return null;
    }
    fputs( $fp, "POST $post_path HTTP/1.0\n" .
                "Host: $host\n" . 
                'User-Agent: ContactsImporter API PHP4 Client 0.3 (non-curl) '. phpversion() . "\n" . 
                "Content-Type: application/x-www-form-urlencoded\n" .
                "Content-Length: " . strlen($data) . "\n\n" . 
                "$data\n\n" );
	$response = '';
	while(!feof($fp)) {
		$response .= fgets($fp, 4096);
	}
	fclose ($fp);
    // get response code
    preg_match( '/^\S+\s(\S+)/', $response, $matches );
    if( $matches[1] != "200" ) {
      $this->errMsg = 'HTTP Error';
      $this->errID = 1;
      return null;
    }
    // get response body
    preg_match( '/\r?\n\r?\n(.*?)$/sD', $response, $matches );
    $response = $matches[1];
	return $response;
  }



  function convert_array_to_params($params) {
    $post_params = array();
    foreach ($params as $key => $val) {
      $post_params[] = $key.'='.urlencode($val);
    }

    return implode('&', $post_params);
  }
  
  
  
  function paypal_rawresponse_to_string() {
    return str_replace( "&", "\n", $this->response_raw );
  }
  
}


// errors
// 1000 - http(s)
// 1 - api error

?>