<?php

// TODO: separation
$payment_states =  array( 0  => $functions_payment[20],
                          1  => $functions_payment[21],
                          2  => $functions_payment[22],
                          3  => $functions_payment[23],
                          4  => $functions_payment[24]
                          );




/*** PAYMENT FUNCTIONS ***/






// loads paymentgw extension and instantiates class
function semods_paymengtw_factory( $paymentgw_id ) {
  global $folder;
 
  $paymengtw = semods::db_query_assoc("SELECT * FROM se_semods_paymentgateways WHERE paymentgateway_id = $paymentgw_id");

  if($paymentgw === false) {
    // no known gateways
    return null;
  }
  
  if($folder == "base") {
      $serverpath = ".";
  } else {
      $serverpath = "..";
  }

  if(!file_exists($serverpath . '/include/class_semods_paymentgw_' . $paymengtw['paymentgateway_typename'] . '.php')) {
    return null;
  }

  include $serverpath . '/include/class_semods_paymentgw_' . $paymengtw['paymentgateway_typename'] . '.php';

  $class_name = "semods_paymentgw_" . $paymengtw['paymentgateway_typename'];

  // call_user_function(array(&$myClass,$func),$param);
  $params = unserialize( $paymengtw['paymentgateway_metadata'] );
  return new $class_name ( $params );

}





/*

function semods_subscriber_period_to_seconds( $period, $periodtype ) {

  switch($periodtype) {

    // Day
    case 0:
        return 86400 * $period;
      break;

    // Week
    case 1:
        return 604800 * $period;
      break;
    
    case 2:
      break;
    
    case 3:
      break;

  }
    
$plan_periodtypes = array(  0 => array( 'id'  => 0, 's' => 'D', 'f' => $functions_subscriber[1] ),
                            1 => array( 'id'  => 1, 's' => 'W', 'f' => $functions_subscriber[2] ),
                            2 => array( 'id'  => 2, 's' => 'M', 'f' => $functions_subscriber[3] ),
                            3 => array( 'id'  => 3, 's' => 'Y', 'f' => $functions_subscriber[4] )
                          );
    
  }
}
*/




// create invoice

// type:
// 1 - recurring / subscription payment
// 2 - initial recurring / subscription payment

// state
// 0 - completed
// 1 - pending (?)
// 2 - refunded
// 3 - reversed

// TBD: tax, fee
// paymentgw txn_id, paymentgw_id ?
function semods_payment_invoice( $user_id, $date, $type, $state, $text, $amount, $txn_id, $handler, $client_firstname = '', $client_lastname = '', $client_email = '', $client_street = '', $client_city = '', $client_state = '', $client_zipcode = '', $client_country = '' ) {
  global $database;

  // Find out if this is known client
  $client_id = semods::db_query_count("SELECT client_id FROM se_semods_clients WHERE client_email = '$client_email'");
  
  if(!$client_id) {
    // New Client
    $database->database_query( "INSERT INTO se_semods_clients (
                                  client_user_id,
                                  client_firstname,
                                  client_lastname,
                                  client_email,
                                  client_street,
                                  client_city,
                                  client_state,
                                  client_zipcode,
                                  client_country
                                  ) VALUES (
                                  $user_id,
                                  '$client_firstname',
                                  '$client_lastname',
                                  '$client_email',
                                  '$client_street',
                                  '$client_city',
                                  '$client_state',
                                  '$client_zipcode',
                                  '$client_country' )" );

    $client_id = $database->database_insert_id();
    
  }
  
  $database->database_query( "INSERT INTO se_semods_userpaymenthistory (
                                userpaymenthistory_date,
                                userpaymenthistory_user_id,
                                userpaymenthistory_client_id,
                                userpaymenthistory_type,
                                userpaymenthistory_state,
                                userpaymenthistory_text,
                                userpaymenthistory_amount,
                                userpaymenthistory_handler,
                                userpaymenthistory_txnid
                                ) VALUES (
                                $date,
                                $user_id,
                                $client_id,
                                $type,
                                $state,
                                '$text',
                                $amount,
                                $handler,
                                '$txn_id' )"
                           );

}






/********************* SYSTEM FUNCTIONS *********************/





function deleteuser_payment( $params ) {
  global $database;
  
  $user_id = $params[0];
  
  // Related Client Data
  $database->database_query("DELETE * FROM se_semods_clients WHERE client_user_id = $user_id");

  // Payment History
  $database->database_query("DELETE * FROM se_semods_userpaymenthistory WHERE userpaymenthistory_user_id = $user_id");
  
  // Clear cart stuff
  $database->database_query("DELETE FROM se_semods_cart, se_semods_cartitems USING se_semods_cart LEFT JOIN se_semods_cartitems ON se_semods_cart.cart_id = se_semods_cartitems.cartitem_cart_id WHERE se_semods_cart.cart_user_id = $user_id");

}



?>