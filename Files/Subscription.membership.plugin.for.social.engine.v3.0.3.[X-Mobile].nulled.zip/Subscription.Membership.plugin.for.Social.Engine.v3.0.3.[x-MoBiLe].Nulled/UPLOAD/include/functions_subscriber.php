<?php


$activity_msg_types = array( 0    => $functions_subscriber[79],
                             1000 => $functions_subscriber[78],
                             100  => $functions_subscriber[80],
                             101  => $functions_subscriber[81],
                             102  => $functions_subscriber[82],
                             103  => $functions_subscriber[83],
                             104  => $functions_subscriber[84]
                             );



/*
 * Cart Item callback function
 *
 */
function subscriber_payment_notification( $params ) {

  //$user_id = $fields[0];
  //$plan_id = $fields[1];
  
  $plan = new semods_plan( $params['pid'], $params['uid']);
  
  if($plan->plan_exists == 0) {
    // error - deleted plan while there are users signed up for it
  }

}





/*
 * Log activity item
 *
 * types:
 *  0 - general message
 *  
 *  100 - plan subscribed
 *  101 - plan cancelled
 *  102 - plan expired
 *  103 - plan renewed
 *  
 *  1000 - error
 *
 *  0-1000    gen messages
 *  1000-2000 errors
 *
 */
function subscriber_log_activity( $user_id, $text, $type = 0, $replacements = array() ) {
  global $database, $url;
  
  $text = str_replace( array_keys( $replacements ),
                       array_values( $replacements ),
                       $text );
  
  $text = addslashes( $text );
  
  $database->database_query( "INSERT INTO se_semods_userplanactivity (userplanactivity_user_id, userplanactivity_type, userplanactivity_text, userplanactivity_date) VALUES ($user_id, $type, '$text', UNIX_TIMESTAMP( NOW() ))" );
}


  
function subscriber_log_error( $text, $type = 1000, $user_id = 0 ) {
  subscriber_log_activity( $user_id, $text, $type );
}





/********************* SYSTEM FUNCTIONS *********************/





function deleteuser_subscriber( $params ) {
  global $database;
  
  $user_id = $params[0];
  
  // Cancel plan(s)
  $userplan = new semods_userplan( 0, $user_id );
  $userplan->cancel_plan( 1, 1 );
  
  // Delete all user-related data
  $database->database_query("DELETE * FROM se_semods_userplans WHERE userplan_user_id = $user_id");

  $database->database_query("DELETE * FROM se_semods_userplanactivity WHERE userplanactivity_user_id = $user_id");
  
  // mean hack
  if(function_exists('deleteuser_payment')) {
	call_user_func_array('deleteuser_payment', $params ); 
  }
}





/********************* EMAIL FUNCTIONS *********************/





/*
 * Notify user about new subscription
 *
 */
function subscriber_email_subscription_created($user_id, $plan_info) {
	global $setting, $url;
	global $database;

    $user = new se_user( array( $user_id ));
    if($user->user_exists == 0)
      return;
    $user_info = $user->user_info;
    
	$time = time();

	// GET SERVER INFO
	$prefix = $url->url_base;

	// DECODE SUBJECT AND EMAIL FOR SENDING
	$subject = htmlspecialchars_decode( semods::get_setting('subscriber_email_newsubscription_subject'), ENT_QUOTES );
	$message = htmlspecialchars_decode( semods::get_setting('subscriber_email_newsubscription_message'), ENT_QUOTES );

    $subscription_details = $plan_info['plan_name'];
/*
    $subscription_details = "Start Date: \n";
    $subscription_details .= "Billing period: \n";
    $subscription_details .= "Price: \n";
    $subscription_details .= "Next Payment Date: \n";
*/

    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[link]',
                                 '[subscription_details]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 "<a href=\"$prefix"."user_plan.php\">$prefix"."user_plan.php</a>",
                                 $subscription_details
                                ),
                          
                          array( $message,
                                 $subject ) );


	// ENCODE SUBJECT FOR UTF8
	$subject="=?UTF-8?B?".base64_encode($subject)."?=";

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

    if(semods::get_setting('crontab_enabled') && function_exists("semods_send_mail_queued")) {
      semods_send_mail_queued( $setting['setting_email_fromname'],
                               $setting['setting_email_fromemail'],
                               $user_info['user_email'],
                               $subject,
                               $message );
    } else {

      // SET HEADERS
      $from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
      $headers = "MIME-Version: 1.0"."\n";
      $headers .= "Content-type: text/html; charset=utf-8"."\n";
      $headers .= "Content-Transfer-Encoding: 8bit"."\n";
      $headers .= "From: $from_email"."\n";
      $headers .= "Return-Path: $from_email"."\n";
      $headers .= "Reply-To: $from_email";

      @mail($user_info['user_email'], $subject, $message, $headers);
    }

	return true;
}


function subscriber_email_subscription_cancelled($user_id, $plan_info) {
	global $setting, $url;
	global $database;

    $user = new se_user( array( $user_id ));
    if($user->user_exists == 0)
      return;
    $user_info = $user->user_info;

	$time = time();

	// GET SERVER INFO
	$prefix = $url->url_base;

	// DECODE SUBJECT AND EMAIL FOR SENDING
	$subject = htmlspecialchars_decode( semods::get_setting('subscriber_email_subscriptioncancelled_subject'), ENT_QUOTES );
	$message = htmlspecialchars_decode( semods::get_setting('subscriber_email_subscriptioncancelled_message'), ENT_QUOTES );

    $subscription_details = $plan_info['plan_name'];
    
    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[link]',
                                 '[subscription_details]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 "<a href=\"$prefix"."user_plan.php\">$prefix"."user_plan.php</a>",
                                 $subscription_details
                                ),
                          
                          array( $message,
                                 $subject ) );


	// ENCODE SUBJECT FOR UTF8
	$subject="=?UTF-8?B?".base64_encode($subject)."?=";

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

    if(semods::get_setting('crontab_enabled') && function_exists("semods_send_mail_queued")) {
      semods_send_mail_queued( $setting['setting_email_fromname'],
                               $setting['setting_email_fromemail'],
                               $user_info['user_email'],
                               $subject,
                               $message );
    } else {

      // SET HEADERS
      $from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
      $headers = "MIME-Version: 1.0"."\n";
      $headers .= "Content-type: text/html; charset=utf-8"."\n";
      $headers .= "Content-Transfer-Encoding: 8bit"."\n";
      $headers .= "From: $from_email"."\n";
      $headers .= "Return-Path: $from_email"."\n";
      $headers .= "Reply-To: $from_email";

      @mail($user_info['user_email'], $subject, $message, $headers);
    }

	return true;
}

function subscriber_email_subscription_expired($user_id, $plan_info) {
	global $setting, $url;
	global $database;

    $user = new se_user( array( $user_id ));
    if($user->user_exists == 0)
      return;
    $user_info = $user->user_info;

	$time = time();

	// GET SERVER INFO
	$prefix = $url->url_base;

	// DECODE SUBJECT AND EMAIL FOR SENDING
	$subject = htmlspecialchars_decode( semods::get_setting('subscriber_email_subscriptionexpired_subject'), ENT_QUOTES );
	$message = htmlspecialchars_decode( semods::get_setting('subscriber_email_subscriptionexpired_message'), ENT_QUOTES );

    $subscription_details = $plan_info['plan_name'];
    
    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[link]',
                                 '[subscription_details]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 "<a href=\"$prefix"."user_plan.php\">$prefix"."user_plan.php</a>",
                                 $subscription_details
                                ),
                          
                          array( $message,
                                 $subject ) );


	// ENCODE SUBJECT FOR UTF8
	$subject="=?UTF-8?B?".base64_encode($subject)."?=";

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

    if(semods::get_setting('crontab_enabled') && function_exists("semods_send_mail_queued")) {
      semods_send_mail_queued( $setting['setting_email_fromname'],
                               $setting['setting_email_fromemail'],
                               $user_info['user_email'],
                               $subject,
                               $message );
    } else {

      // SET HEADERS
      $from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
      $headers = "MIME-Version: 1.0"."\n";
      $headers .= "Content-type: text/html; charset=utf-8"."\n";
      $headers .= "Content-Transfer-Encoding: 8bit"."\n";
      $headers .= "From: $from_email"."\n";
      $headers .= "Return-Path: $from_email"."\n";
      $headers .= "Reply-To: $from_email";

      @mail($user_info['user_email'], $subject, $message, $headers);
    }

	return true;
}

function subscriber_email_subscription_renewed($user_id, $plan_info) {
	global $setting, $url;
	global $database;

    $user = new se_user( array( $user_id ));
    if($user->user_exists == 0)
      return;
    $user_info = $user->user_info;

	$time = time();

	// GET SERVER INFO
	$prefix = $url->url_base;

	// DECODE SUBJECT AND EMAIL FOR SENDING
	$subject = htmlspecialchars_decode( semods::get_setting('subscriber_email_subscriptionrenewed_subject'), ENT_QUOTES );
	$message = htmlspecialchars_decode( semods::get_setting('subscriber_email_subscriptionrenewed_message'), ENT_QUOTES );

    $subscription_details = $plan_info['plan_name'];
    
    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[link]',
                                 '[subscription_details]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 "<a href=\"$prefix"."user_plan.php\">$prefix"."user_plan.php</a>",
                                 $subscription_details
                                ),
                          
                          array( $message,
                                 $subject ) );


	// ENCODE SUBJECT FOR UTF8
	$subject="=?UTF-8?B?".base64_encode($subject)."?=";

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

    if(semods::get_setting('crontab_enabled') && function_exists("semods_send_mail_queued")) {
      semods_send_mail_queued( $setting['setting_email_fromname'],
                               $setting['setting_email_fromemail'],
                               $user_info['user_email'],
                               $subject,
                               $message );
    } else {

      // SET HEADERS
      $from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
      $headers = "MIME-Version: 1.0"."\n";
      $headers .= "Content-type: text/html; charset=utf-8"."\n";
      $headers .= "Content-Transfer-Encoding: 8bit"."\n";
      $headers .= "From: $from_email"."\n";
      $headers .= "Return-Path: $from_email"."\n";
      $headers .= "Reply-To: $from_email";

      @mail($user_info['user_email'], $subject, $message, $headers);
    }

	return true;
}

function subscriber_email_subscription_suspended_no_payment($user_id, $plan_info) {
	global $setting, $url;
	global $database;

    $user = new se_user( array( $user_id ));
    if($user->user_exists == 0)
      return;
    $user_info = $user->user_info;

	$time = time();

	// GET SERVER INFO
	$prefix = $url->url_base;

	// DECODE SUBJECT AND EMAIL FOR SENDING
	$subject = htmlspecialchars_decode( semods::get_setting('subscriber_email_paymentfailed_subject'), ENT_QUOTES );
	$message = htmlspecialchars_decode( semods::get_setting('subscriber_email_paymentfailed_message'), ENT_QUOTES );

    $subscription_details = $plan_info['plan_name'];
    
    list( $message, $subject ) = str_replace( 
                          array( '[username]',
                                 '[email]',
                                 '[link]',
                                 '[subscription_details]'
                                ),
                          
                          array( $user_info['user_username'],
                                 $user_info['user_email'],
                                 "<a href=\"$prefix"."user_plan.php\">$prefix"."user_plan.php</a>",
                                 $subscription_details
                                ),
                          
                          array( $message,
                                 $subject ) );


	// ENCODE SUBJECT FOR UTF8
	$subject="=?UTF-8?B?".base64_encode($subject)."?=";

	// REPLACE CARRIAGE RETURNS WITH BREAKS
	$message = str_replace("\n", "<br>", $message);

    if(semods::get_setting('crontab_enabled') && function_exists("semods_send_mail_queued")) {
      semods_send_mail_queued( $setting['setting_email_fromname'],
                               $setting['setting_email_fromemail'],
                               $user_info['user_email'],
                               $subject,
                               $message );
    } else {

      // SET HEADERS
      $from_email = "$setting[setting_email_fromname] <$setting[setting_email_fromemail]>";
      $headers = "MIME-Version: 1.0"."\n";
      $headers .= "Content-type: text/html; charset=utf-8"."\n";
      $headers .= "Content-Transfer-Encoding: 8bit"."\n";
      $headers .= "From: $from_email"."\n";
      $headers .= "Return-Path: $from_email"."\n";
      $headers .= "Reply-To: $from_email";

      @mail($user_info['user_email'], $subject, $message, $headers);
    }

	return true;
}


//function subscriber_email_subscription_refunded($user_info, $plan_info) {
//
//}

//function subscriber_email_subscription_soon_expires($user_info, $plan_info) {
//
//}




/********************* BACKGROUND JOBS *********************/


function subscriber_scheduler_tasks() {
  global $database;
  
  // PROCESS ALL QUEUED TASKS
  
  $processed_tasks = array();
  
  for(;;) {
    
    $task = semods::db_query_assoc('SELECT * FROM se_semods_plantasks ORDER BY plantask_id ASC LIMIT 1');
    
    // No more tasks
    if($task === false)
      break;
    
    $task_processed = false;
      
    switch($task['plantask_type']) {
  
      case 'cancel_subscription':
        
        if($task['plantask_paymentgw'] != 0) {
          
          $paymentgw = semods_paymengtw_factory( $task['plantask_paymentgw'] );
  
          // Log Error
          if(!$paymentgw) {
            subscriber_log_error( "Error cancelling plan - Failed instantiating Payment Handler (id={$task['plantask_paymentgw']})", 1000 );
          } else {
      
            $result = $paymentgw->cancel_subscription( array( 'fast' => 0, 'metadata' => $task['plantask_metadata'] ) );
    
            // Log Error
            if(!$result) {
              subscriber_log_error( "Error cancelling plan - (id={$task['plantask_paymentgw']})", 1001 );
  
              // TODO
              // email_notify_admin(error cancelling ?  requeue task? );
            }
            
          }
          
        }
        
        if($result) {
          // email_notify(plan_cancelled);
        } else {
          // email_notify_admin(error cancelling plan id XX);
        }
  
        $task_processed = true;
        
        break;
      
    }
     
    if($task_processed) {
      $database->database_query("DELETE FROM se_semods_plantasks WHERE plantask_id = {$task['plantask_id']}");
    }
   
  } 
}




function subscriber_scheduler_daily() {
  global $database;

  // PROCESS ALL PLANS EXPIRATION
  // Possible state changes:
  // active -> expired, cancelled -> expired, active -> suspended_paymentfailed, suspended_paymentfailed -> expired
  
  // safety of 1 day
  $safety_delta = 86400;
  
  // period of no payment to cancel - 3 days
  $suspend_to_cancel_period = 259200;
  
  // take plans with state Active, Cancelled, Suspended, Suspended - payment failed and not Free for life (0 expiration date)
  $sql = 'SELECT * FROM se_semods_userplans WHERE (userplan_state = 0 OR userplan_state = 3 OR userplan_state = 4 OR userplan_state = 7) AND userplan_expiredate != 0';
  $rows = $database->database_query($sql);
  
  if ($rows === false) {
    scheduler_log_error( 'Database Error - could not query the database.' . ' MySQL Error: ' . mysql_error() );
    return false;
  }
  
  
  if($database->database_num_rows($rows) > 0) {
    
    $now = time();
    
    // TODO: make date in sql query  
    // loop through records
    while ($row = $database->database_fetch_assoc($rows)) {
  
      // if plan suspended - failed payment & waitin period is over -> cancel & expire plan
      if($now > intval($row['userplan_expiredate']) + $suspend_to_cancel_period ) {
        
        //if($row['userplan_state'] == 7) {
          
          // if plan period expired -> downgrade & change state to "suspended_payment_failed"
          $userplan = new semods_userplan( $row['userplan_id'] );
          $userplan->expire_plan();
          
        //}
        
      } elseif($now > intval($row['userplan_expiredate']) + $safety_delta) {
  
        // if plan period expired -> downgrade & change state to "suspended_payment_failed"
        $userplan = new semods_userplan( $row['userplan_id'] );
        $userplan->suspend_plan_failed_payment();
  
      }
      
    }
  
  }

}



?>