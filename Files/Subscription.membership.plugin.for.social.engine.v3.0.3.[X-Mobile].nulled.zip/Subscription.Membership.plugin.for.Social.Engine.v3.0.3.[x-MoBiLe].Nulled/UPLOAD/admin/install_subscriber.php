<?

$plugin_name = "Subscriber";
$plugin_version = "1.00";
$plugin_type = "subscriber";
$plugin_desc = "The plugin allows charging members for subscriptions.";
$plugin_icon = "subscriber16.png";
$plugin_pages_main = "View Users<!>admin_subscriber_viewusers.php<~!~>Manage Plans<!>admin_subscriber_plans.php<~!~>Dashboard<!>admin_subscriber_dashboard.php<~!~>Income Reports<!>admin_payment_reports_income.php<~!~>Clients<!>admin_payment_clients.php<~!~>Messages<!>admin_subscriber_messages.php<~!~>Payment gateways<!>admin_paymentgw.php<~!~>Global Settings<!>admin_subscriber.php<~!~>";
$plugin_pages_level = "Subscription Settings<!>admin_levels_subscribersettings.php<~!~>";
$plugin_url_htaccess = "";

if(!function_exists('chain_sql')) {
  function chain_sql( $sql ) {
	global $database;

	$rows = explode( ';', $sql);
	foreach($rows as $row) {
	  $row = trim($row);
	  if(empty($row))
		continue;
	  $database->database_query( $row );
	}

  }
}

if($install == "subscriber") {

  //######### INSERT ROW INTO se_plugins
  if($database->database_num_rows($database->database_query("SELECT plugin_id FROM se_plugins WHERE plugin_type='$plugin_type'")) == 0) {
    $database->database_query("INSERT INTO se_plugins (plugin_name,
					plugin_version,
					plugin_type,
					plugin_desc,
					plugin_icon,
					plugin_pages_main,
					plugin_pages_level,
					plugin_url_htaccess
					) VALUES (
					'$plugin_name',
					'$plugin_version',
					'$plugin_type',
					'$plugin_desc',
					'$plugin_icon',
					'$plugin_pages_main',
					'$plugin_pages_level',
					'$plugin_url_htaccess')");


  //######### UPDATE PLUGIN VERSION IN se_plugins
  } else {
    $database->database_query("UPDATE se_plugins SET plugin_name='$plugin_name',
					plugin_version='$plugin_version',
					plugin_desc='$plugin_desc',
					plugin_icon='$plugin_icon',
					plugin_pages_main='$plugin_pages_main',
					plugin_pages_level='$plugin_pages_level',
					plugin_url_htaccess='$plugin_url_htaccess' WHERE plugin_type='$plugin_type'");
  }


  //######### CREATE DATABASE STRUCTURE

  chain_sql(
<<<EOC

CREATE TABLE IF NOT EXISTS `se_semods_cart` (
  `cart_id` int(11) NOT NULL auto_increment,
  `cart_user_id` int(11) NOT NULL,
  `cart_date` int(11) NOT NULL,
  `cart_paid` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`cart_id`)
);


CREATE TABLE IF NOT EXISTS `se_semods_cartitems` (
  `cartitem_cart_id` int(11) NOT NULL,
  `cartitem_type` tinyint(4) NOT NULL default '0',
  `cartitem_name` varchar(255) NOT NULL,
  `cartitem_shortdesc` varchar(255) default NULL,
  `cartitem_number` int(11) NOT NULL default '0',
  `cartitem_quantity` int(11) NOT NULL,
  `cartitem_quantityfixed` tinyint(1) NOT NULL default '0',
  `cartitem_price` decimal(10,2) NOT NULL,
  `cartitem_metadata` text NOT NULL,
  `cartitem_callback` varchar(255) default NULL,
  `cartitem_callbackparams` text,
  `cartitem_processed` tinyint(1) NOT NULL default '0',
  UNIQUE KEY `cartitems_cart_id_2` (`cartitem_cart_id`,`cartitem_number`)
);




CREATE TABLE IF NOT EXISTS `se_semods_paypal_payment_info` (
  `txnid` varchar(30) NOT NULL default '',
  `firstname` varchar(100) NOT NULL default '',
  `lastname` varchar(100) NOT NULL default '',
  `buyer_email` varchar(100) NOT NULL default '',
  `street` varchar(100) NOT NULL default '',
  `city` varchar(50) NOT NULL default '',
  `state` char(3) NOT NULL default '',
  `zipcode` varchar(11) NOT NULL default '',
  `memo` varchar(255) default NULL,
  `itemname` varchar(255) default NULL,
  `itemnumber` varchar(50) default NULL,
  `os0` varchar(20) default NULL,
  `on0` varchar(50) default NULL,
  `os1` varchar(20) default NULL,
  `on1` varchar(50) default NULL,
  `quantity` char(3) default NULL,
  `paymentdate` varchar(50) NOT NULL default '',
  `paymenttype` varchar(10) NOT NULL default '',
  `mc_gross` varchar(6) NOT NULL default '',
  `mc_fee` varchar(5) NOT NULL default '',
  `paymentstatus` varchar(15) NOT NULL default '',
  `pendingreason` varchar(10) default NULL,
  `txntype` varchar(10) NOT NULL default '',
  `tax` varchar(10) default NULL,
  `mc_currency` varchar(5) NOT NULL default '',
  `reasoncode` varchar(20) NOT NULL default '',
  `custom` varchar(255) NOT NULL default '',
  `country` varchar(20) NOT NULL default '',
  `datecreation` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL default '1',
  `verified_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`txnid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



CREATE TABLE IF NOT EXISTS `se_semods_paypal_subscription_info` (
  `subscr_id` varchar(255) NOT NULL default '',
  `sub_event` varchar(50) NOT NULL default '',
  `subscr_date` varchar(255) NOT NULL default '',
  `subscr_effective` varchar(255) NOT NULL default '',
  `period1` varchar(255) NOT NULL default '',
  `period2` varchar(255) NOT NULL default '',
  `period3` varchar(255) NOT NULL default '',
  `amount1` varchar(255) NOT NULL default '',
  `amount2` varchar(255) NOT NULL default '',
  `amount3` varchar(255) NOT NULL default '',
  `mc_amount1` varchar(255) NOT NULL default '',
  `mc_amount2` varchar(255) NOT NULL default '',
  `mc_amount3` varchar(255) NOT NULL default '',
  `recurring` varchar(255) NOT NULL default '',
  `reattempt` varchar(255) NOT NULL default '',
  `retry_at` varchar(255) NOT NULL default '',
  `recur_times` varchar(255) NOT NULL default '',
  `username` varchar(255) NOT NULL default '',
  `password` varchar(255) default NULL,
  `txn_id` varchar(50) NOT NULL default '',
  `subscriber_emailaddress` varchar(255) NOT NULL default '',
  `datecreation` date NOT NULL default '0000-00-00'
);



CREATE TABLE IF NOT EXISTS `se_semods_plans` (
  `plan_id` int(11) NOT NULL auto_increment,
  `plan_level_id` int(11) NOT NULL,
  `plan_downgrade_level_id` int(11) NOT NULL default '1',
  `plan_name` varchar(255) NOT NULL,
  `plan_category` tinyint(3) unsigned NOT NULL default '0',
  `plan_description` text NOT NULL,
  `plan_period` int(11) NOT NULL,
  `plan_periodtype` tinyint(4) NOT NULL default '0',
  `plan_trialperiod` int(11) NOT NULL,
  `plan_trialperiodtype` tinyint(4) NOT NULL default '0',
  `plan_trialperiodprice` decimal(10,2) NOT NULL,
  `plan_price` decimal(10,2) NOT NULL,
  `plan_onetime_price` decimal(10,2) NOT NULL,
  `plan_enabled` tinyint(1) NOT NULL default '1',
  `plan_showonsignup` tinyint(1) NOT NULL default '1',
  `plan_recurring` tinyint(1) NOT NULL default '1',
  `plan_recurring_cycles` int(11) NOT NULL default '0',
  `plan_users` int(11) NOT NULL default '0',
  `plan_levels` text NOT NULL,
  `plan_upgrade_from` text NOT NULL,
  PRIMARY KEY  (`plan_id`)
);



CREATE TABLE IF NOT EXISTS `se_semods_plantasks` (
  `plantask_id` int(11) NOT NULL auto_increment,
  `plantask_type` varchar(50) NOT NULL,
  `plantask_metadata` text NOT NULL,
  `plantask_paymentgw` int(11) NOT NULL default '0',
  `plantask_notify` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`plantask_id`)
);



CREATE TABLE IF NOT EXISTS `se_semods_userpaymenthistory` (
  `userpaymenthistory_id` int(11) NOT NULL auto_increment,
  `userpaymenthistory_client_id` int(11) NOT NULL,
  `userpaymenthistory_date` int(11) NOT NULL,
  `userpaymenthistory_user_id` int(11) NOT NULL,
  `userpaymenthistory_type` int(11) NOT NULL,
  `userpaymenthistory_state` tinyint(4) NOT NULL,
  `userpaymenthistory_text` text NOT NULL,
  `userpaymenthistory_amount` decimal(10,2) NOT NULL,
  `userpaymenthistory_handler` int(11) NOT NULL,
  `userpaymenthistory_txnid` varchar(255) NOT NULL,
  PRIMARY KEY  (`userpaymenthistory_id`)
);



CREATE TABLE IF NOT EXISTS `se_semods_userplanactivity` (
  `userplanactivity_id` int(11) NOT NULL auto_increment,
  `userplanactivity_user_id` int(11) NOT NULL,
  `userplanactivity_type` int(11) NOT NULL,
  `userplanactivity_text` text NOT NULL,
  `userplanactivity_date` int(4) NOT NULL,
  PRIMARY KEY  (`userplanactivity_id`)
);



CREATE TABLE IF NOT EXISTS `se_semods_userplans` (
  `userplan_id` int(11) NOT NULL auto_increment,
  `userplan_user_id` int(11) NOT NULL,
  `userplan_plan_id` int(11) NOT NULL,
  `userplan_startdate` int(11) NOT NULL,
  `userplan_expiredate` int(11) NOT NULL,
  `userplan_state` tinyint(4) NOT NULL default '0',
  `userplan_metadata` text NOT NULL,
  `userplan_handler` int(11) NOT NULL default '0' COMMENT 'who manages the plan - paypal/manual/etc',
  `userplan_paid_cycles` int(11) NOT NULL default '0',
  `userplan_field1` varchar(50) NOT NULL,
  PRIMARY KEY  (`userplan_id`),
  UNIQUE KEY `userplan_user_id` (`userplan_user_id`,`userplan_plan_id`),
  KEY `userplan_field1` (`userplan_field1`)
);




CREATE TABLE `se_semods_clients` (
  `client_id` int(11) NOT NULL auto_increment,
  `client_user_id` int(11) NOT NULL,
  `client_firstname` varchar(100) NOT NULL,
  `client_lastname` varchar(100) NOT NULL,
  `client_email` varchar(100) NOT NULL,
  `client_street` varchar(100) NOT NULL,
  `client_city` varchar(50) NOT NULL,
  `client_state` varchar(3) NOT NULL,
  `client_zipcode` varchar(11) NOT NULL,
  `client_country` varchar(20) NOT NULL,
  PRIMARY KEY  (`client_id`)
);




ALTER TABLE se_levels
  ADD `level_subscriber_require_subscription` tinyint(1) NOT NULL default '0',
  ADD `level_subscriber_allow_profileview` tinyint(1) NOT NULL default '1';

EOC
);



  /*** SHARED ELEMENTS ***/



  //######### CREATE se_semods_settings
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_semods_settings'")) == 0) {

    $database->database_query("CREATE TABLE `se_semods_settings` (
        `setting_subscriber_allow_multiple_trials` tinyint(1) NOT NULL default '0',
        `setting_subscriber_enable_subscriptions` tinyint(1) NOT NULL default '1',
		`setting_subscriber_require_on_signup` tinyint(1) NOT NULL default '0',
        `setting_payment_currency` varchar(3) NOT NULL default 'USD',
        `setting_payment_tax` VARCHAR( 5 ) NOT NULL default '0',
        `setting_subscriber_email_newsubscription_subject` varchar(200) NOT NULL,
        `setting_subscriber_email_newsubscription_message` text NOT NULL,
        `setting_subscriber_email_subscriptionexpired_subject` varchar(200) NOT NULL,
        `setting_subscriber_email_subscriptionexpired_message` text NOT NULL,
        `setting_subscriber_email_subscriptioncancelled_subject` varchar(200) NOT NULL,
        `setting_subscriber_email_subscriptioncancelled_message` text NOT NULL,
        `setting_subscriber_email_subscriptionexpiration_subject` varchar(200) NOT NULL,
        `setting_subscriber_email_subscriptionexpiration_message` text NOT NULL,
        `setting_subscriber_email_subscriptionrenewed_subject` varchar(200) NOT NULL,
        `setting_subscriber_email_subscriptionrenewed_message` text NOT NULL,
        `setting_subscriber_email_paymentfailed_subject` varchar(200) NOT NULL,
        `setting_subscriber_email_paymentfailed_message` text NOT NULL
      )
          ");

    $database->database_query("INSERT INTO `se_semods_settings` (`setting_subscriber_allow_multiple_trials`, `setting_subscriber_enable_subscriptions`, `setting_payment_currency`, `setting_subscriber_email_newsubscription_subject`, `setting_subscriber_email_newsubscription_message`, `setting_subscriber_email_subscriptionexpired_subject`, `setting_subscriber_email_subscriptionexpired_message`, `setting_subscriber_email_subscriptioncancelled_subject`, `setting_subscriber_email_subscriptioncancelled_message`, `setting_subscriber_email_subscriptionexpiration_subject`, `setting_subscriber_email_subscriptionexpiration_message`, `setting_subscriber_email_subscriptionrenewed_subject`, `setting_subscriber_email_subscriptionrenewed_message`, `setting_subscriber_email_paymentfailed_subject`, `setting_subscriber_email_paymentfailed_message`) VALUES (0, 1, 'USD', 'New Subscription Created', 'Hello [username],\r\n\r\nYour subscription has been successfully created. \r\n\r\nSubscription details: \r\n[subscription_details]\r\n\r\nYou can view your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration', 'Subscription Expired', 'Hello [username],\r\n\r\nYour subscription for [subscription_details] has expired. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration', 'Subscription Cancelled', 'Hello [username],\r\n\r\nYour subscription for [subscription_details] has been cancelled. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration', 'Subscription Expiration', 'Hello [username],\r\n\r\nYour subscription for [subscription_details] is expiring soon. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration', 'Subscription Successfully Renewed ', 'Hello [username],\r\n\r\nYour subscription for [subscription_details] was successfully renewed. \r\n\r\nYou can view your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration\r\n', 'Subscription Suspended - Payment Failed', 'Hello [username],\r\n\r\nYour subscription for [subscription_details] was suspended because of failed payment. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration')");

  } else {

    $database->database_query("ALTER TABLE `se_semods_settings`
		 ADD `setting_subscriber_allow_multiple_trials` tinyint(1) NOT NULL default '0',
		 ADD `setting_subscriber_enable_subscriptions` tinyint(1) NOT NULL default '1',
		 ADD `setting_subscriber_require_on_signup` tinyint(1) NOT NULL default '0',
         ADD `setting_payment_currency` varchar(3) NOT NULL default 'USD',
         ADD `setting_payment_tax` VARCHAR( 5 ) NOT NULL default '0',
         ADD `setting_subscriber_email_newsubscription_subject` varchar(200) NOT NULL,
         ADD `setting_subscriber_email_newsubscription_message` text NOT NULL,
         ADD `setting_subscriber_email_subscriptionexpired_subject` varchar(200) NOT NULL,
         ADD `setting_subscriber_email_subscriptionexpired_message` text NOT NULL,
         ADD `setting_subscriber_email_subscriptioncancelled_subject` varchar(200) NOT NULL,
         ADD `setting_subscriber_email_subscriptioncancelled_message` text NOT NULL,
         ADD `setting_subscriber_email_subscriptionexpiration_subject` varchar(200) NOT NULL,
         ADD `setting_subscriber_email_subscriptionexpiration_message` text NOT NULL,
         ADD `setting_subscriber_email_subscriptionrenewed_subject` varchar(200) NOT NULL,
         ADD `setting_subscriber_email_subscriptionrenewed_message` text NOT NULL,
         ADD `setting_subscriber_email_paymentfailed_subject` varchar(200) NOT NULL,
         ADD `setting_subscriber_email_paymentfailed_message` text NOT NULL
	");

    $database->database_query("UPDATE `se_semods_settings` SET
                              `setting_subscriber_allow_multiple_trials` = 0,
                              `setting_subscriber_enable_subscriptions` = 1,
                              `setting_subscriber_require_on_signup` = 0,
                              `setting_payment_currency` = 'USD',
                              `setting_subscriber_email_newsubscription_subject` = 'New Subscription Created',
                              `setting_subscriber_email_newsubscription_message` = 'Hello [username],\r\n\r\nYour subscription has been successfully created. \r\n\r\nSubscription details: \r\n[subscription_details]\r\n\r\nYou can view your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration',
                              `setting_subscriber_email_subscriptionexpired_subject` = 'Subscription Expired',
                              `setting_subscriber_email_subscriptionexpired_message` = 'Hello [username],\r\n\r\nYour subscription for [subscription_details] has expired. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration',
                              `setting_subscriber_email_subscriptioncancelled_subject` = 'Subscription Cancelled',
                              `setting_subscriber_email_subscriptioncancelled_message` = 'Hello [username],\r\n\r\nYour subscription for [subscription_details] has been cancelled. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration',
                              `setting_subscriber_email_subscriptionexpiration_subject` = 'Subscription Expiration',
                              `setting_subscriber_email_subscriptionexpiration_message` = 'Hello [username],\r\n\r\nYour subscription for [subscription_details] is expiring soon. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration',
                              `setting_subscriber_email_subscriptionrenewed_subject` = 'Subscription Successfully Renewed',
                              `setting_subscriber_email_subscriptionrenewed_message` = 'Hello [username],\r\n\r\nYour subscription for [subscription_details] was successfully renewed. \r\n\r\nYou can view your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration\r\n',
                              `setting_subscriber_email_paymentfailed_subject` = 'Subscription Suspended - Payment Failed',
                              `setting_subscriber_email_paymentfailed_message` = 'Hello [username],\r\n\r\nYour subscription for [subscription_details] was suspended because of failed payment. \r\n\r\nYou can view and renew your current subscriptions on the following link:\r\n[link]\r\n\r\nBest Regards,\r\nSocial Network Administration'");
  }





  //######### CREATE payment gateways
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_semods_paymentgateways'")) == 0) {

    $database->database_query("CREATE TABLE IF NOT EXISTS `se_semods_paymentgateways` (
          `paymentgateway_id` int(11) NOT NULL,
          `paymentgateway_name` varchar(255) NOT NULL,
          `paymentgateway_typename` varchar(255) NOT NULL,
          `paymentgateway_metadata` text NOT NULL,
          PRIMARY KEY  (`paymentgateway_id`)
        )
          ");

    $database->database_query("INSERT INTO `se_semods_paymentgateways` (`paymentgateway_id`, `paymentgateway_name`, `paymentgateway_typename`, `paymentgateway_metadata`) VALUES (1, 'Paypal', 'paypal', 'a:0:{}')");
    $database->database_query("INSERT INTO `se_semods_paymentgateways` (`paymentgateway_id`, `paymentgateway_name`, `paymentgateway_typename`, `paymentgateway_metadata`) VALUES (2, 'Google Checkout', '', 'a:0:{}')");



  } else {


  }



  //######### BACKGROUND JOBS
  if($database->database_num_rows($database->database_query("SHOW TABLES FROM `$database_name` LIKE 'se_semods_jobs'")) == 0) {

    $database->database_query("CREATE TABLE IF NOT EXISTS `se_semods_jobs` (
          `job_id` int(11) NOT NULL auto_increment,
          `job_name` varchar(50) NOT NULL,
          `job_typename` varchar(50) NOT NULL,
          `job_type` tinyint(4) NOT NULL,
          `job_command` text NOT NULL,
          `job_metadata` text NOT NULL,
          `job_lastrun` int(11) NOT NULL default '0',
          `job_enabled` tinyint(1) NOT NULL,
          `job_period` int(11) NOT NULL,
          PRIMARY KEY  (`job_id`)
        );
        ");
  }

  $database->database_query("INSERT INTO `se_semods_jobs` (`job_name`, `job_typename`, `job_type`, `job_command`, `job_metadata`, `job_enabled`, `job_period`) VALUES ('Subscriber Daily', 'subscriber_daily', 0, 'subscriber_scheduler_daily', '', 1, 86400)");
  $database->database_query("INSERT INTO `se_semods_jobs` (`job_name`, `job_typename`, `job_type`, `job_command`, `job_metadata`, `job_enabled`, `job_period`) VALUES ('Subscriber Tasks', 'subscriber_tasks', 0, 'subscriber_scheduler_tasks', '', 1, 900)");

}

?>