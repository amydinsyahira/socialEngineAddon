<?
$page = "admin_payment_reports_income";
include "admin_header.php";

// ALLOW ACCESS TO SUPERADMIN ONLY
if( $admin->admin_info['admin_id'] != 1 ) {
  header("Location: admin_viewplugins.php");
  exit();
}

$task = semods::getpost('task', "main");
$s = semods::getpost('s', "tid");                     // sort default by transactionid
$p = semods::getpost('p', 1);
$f_user = semods::getpost('f_user', "");
$f_title = semods::getpost('f_title', "");
$f_state = intval(semods::getpost('f_state', -1));    // transaction status

$f_start_y = semods::getpost('f_start_y', "");
$f_start_m = semods::getpost('f_start_m', "");
$f_start_d = semods::getpost('f_start_d', "");

$f_end_y = semods::getpost('f_end_y', "");
$f_end_m = semods::getpost('f_end_m', "");
$f_end_d = semods::getpost('f_end_d', "");

!empty($f_start_y) && !empty($f_start_m) && !empty($f_start_d) ? 
  $f_start = mktime( 0, 0, 0, $f_start_m, $f_start_d, $f_start_y ) :
  $f_start = "";

!empty($f_end_y) && !empty($f_end_m) && !empty($f_end_d) ? 
  $f_end = mktime( 23, 59, 59, $f_end_m, $f_end_d, $f_end_y ) :
  $f_end = "";

// Filter by PAYING CLIENT email - NOT user
$f_email = semods::getpost('f_email', "");


// SET USER SORT-BY VARIABLES FOR HEADING LINKS
$u = "u";     // USER_USERNAME
$d = "d";     // Transaction Date
$st = "st";   // State
$a = "a";     // amount

// SET SORT VARIABLE FOR DATABASE QUERY
if($s == "u") {
  $sort = "user_username";
  $u = "ud";
} elseif($s == "ud") {
  $sort = "user_username DESC";
  $u = "u";
} elseif($s == "d") {
  $sort = "userpaymenthistory_date";
  $d = "dd";
} elseif($s == "dd") {
  $sort = "userpaymenthistory_date DESC";
  $d = "d";
} elseif($s == "st") {
  $sort = "userpaymenthistory_state";
  $st = "std";
} elseif($s == "std") {
  $sort = "userpaymenthistory_state DESC";
  $st = "st";
} elseif($s == "a") {
  $sort = "userpaymenthistory_amount";
  $a = "ad";
} elseif($s == "ad") {
  $sort = "userpaymenthistory_amount DESC";
  $a = "a";
} else {
  $sort = "userpaymenthistory_id DESC";
  $u = "u";
}


$sql_head = "SELECT * ";

$sql_body = "FROM se_semods_userpaymenthistory T
		LEFT JOIN se_users U ON T.userpaymenthistory_user_id = U.user_id
		LEFT JOIN se_semods_clients C ON T.userpaymenthistory_client_id = C.client_id
        LEFT JOIN se_semods_paymentgateways G ON T.userpaymenthistory_handler = G.paymentgateway_id";

$filters = array();
$f_user != ""    ? $filters[] = "user_username LIKE '%$f_user%'" :0;
$f_title != ""    ? $filters[] = "userpaymenthistory_text LIKE '%$f_title%'" :0;
$f_state != -1   ? $filters[] = "userpaymenthistory_state = $f_state" :0;
$f_email != ""    ? $filters[] = "client_email LIKE '%$f_email%'" :0;
$f_start != ""    ? $filters[] = "userpaymenthistory_date >= $f_start" :0;
$f_end != ""    ? $filters[] = "userpaymenthistory_date <= $f_end" :0;

!empty($filters)  ? $sql_body .= " WHERE " . implode( " AND ", $filters):0;

$sql_count = 'SELECT COUNT(*)' . ' ' . $sql_body;

$sql_items = $sql_head  . ' ' . $sql_body;
		

// GET TOTAL 
$total_items = semods::db_query_count( $sql_count );

// MAKE PAGES
$items_per_page = 100;
$page_vars = make_page($total_items, $items_per_page, $p);

$page_array = Array();
for($x=0;$x<=$page_vars[2]-1;$x++) {
  if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
  $page_array[$x] = Array('page' => $x+1,
						  'link' => $link);
}

$sql_items .= " ORDER BY $sort LIMIT $page_vars[0], $items_per_page";

/*

// LOOP OVER USER LEVELS
$levels = $database->database_query("SELECT level_id, level_name FROM se_levels ORDER BY level_name");
while($level_info = $database->database_fetch_assoc($levels)) {
  $level_array[$level_info[level_id]] = Array('level_id' => $level_info[level_id],
											  'level_name' => $level_info[level_name]);
}


// LOOP OVER SUBNETWORKS
$subnets = $database->database_query("SELECT subnet_id, subnet_name FROM se_subnets ORDER BY subnet_name");
$subnet_array[0] = Array('subnet_id' => 0, 'subnet_name' => $admin_userpoints_transactions[26]);
while($subnet_info = $database->database_fetch_assoc($subnets)) {
  $subnet_array[$subnet_info[subnet_id]] = Array('subnet_id' => $subnet_info[subnet_id],
												 'subnet_name' => $subnet_info[subnet_name]);
}

*/

foreach($payment_states as $key => $value) {
  $transaction_states[] = array( 'transactionstate_id'    =>  $key,
                                 'transactionstate_name'  =>  $value );
}


// PULL ITEMS INTO AN ARRAY
$items = Array();
$rows = $database->database_query($sql_items);
while($row = $database->database_fetch_assoc($rows)) {
  
  $items[] = array( 'transaction_id'	   => $row['userpaymenthistory_id'],
                    'transaction_date'     => $row['userpaymenthistory_date'],
                    'transaction_desc'     => $row['userpaymenthistory_text'],
                    'transaction_state'    => $payment_states[$row['userpaymenthistory_state']],
                    'transaction_stateid'  => $row['userpaymenthistory_state'],
                    'transaction_amount'   => $row['userpaymenthistory_amount'],
                    'transaction_user_id'  => $row['user_id'],
                    'transaction_username' => $row['user_username'],
                    'transaction_txnid'    => !empty($row['userpaymenthistory_txnid']) ? $row['userpaymenthistory_txnid'] : '&nbsp;',
                    'transaction_handler'  => !empty($row['paymentgateway_name']) ? $row['paymentgateway_name'] : $admin_payment_reports_income[30],
                    'transaction_type'     => $row['userpaymenthistory_type'],
                    'transaction_client_email'     => $row['client_email']
                  );
  
}


/* TIME RANGE */

// CONSTRUCT MONTH ARRAY
$month_format = "M";
$month_array = Array();
for($m=1;$m<=12;$m++) {
  $month_array[$m] = Array( 'name' => $datetime->cdate("$month_format", mktime(0, 0, 0, $m, 1, 1990)),
                            'value' => $m,
                            'selected' => $selected);
}


// CONSTRUCT DAY ARRAY
$day_format = "d";
$day_array = Array();
for($d=1;$d<=31;$d++) {
  $day_array[$d] = Array( 'name' => $datetime->cdate("$day_format", mktime(0, 0, 0, 1, $d, 1990)),
                          'value' => $d,
                          'selected' => $selected);
}

// CONSTRUCT YEAR ARRAY
$year_array = Array();
$year_count = 1;
$current_year = $datetime->cdate("Y", time());
for($y=$current_year+2;$y>=$current_year-3;$y--) {
  $year_array[$year_count] = Array( 'name' => $y,
                                    'value' => $y,
                                    'selected' => $selected);
  $year_count++;
}


// ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('total_items', $total_items);
$smarty->assign('pages', $page_array);
$smarty->assign('items', $items);

$smarty->assign('u', $u);
$smarty->assign('d', $d);
$smarty->assign('st', $st);
$smarty->assign('a', $a);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('s', $s);

$smarty->assign('f_user', $f_user);
$smarty->assign('f_title', $f_title);
$smarty->assign('f_email', $f_email);

$smarty->assign('f_start_y', $f_start_y);
$smarty->assign('f_start_m', $f_start_m);
$smarty->assign('f_start_d', $f_start_d);

$smarty->assign('f_end_y', $f_end_y);
$smarty->assign('f_end_m', $f_end_m);
$smarty->assign('f_end_d', $f_end_d);

$smarty->assign('f_status', $f_status);
$smarty->assign('f_state', $f_state);

$smarty->assign('year_array', $year_array);
$smarty->assign('month_array', $month_array);
$smarty->assign('day_array', $day_array);

$smarty->assign('transaction_states', $transaction_states);

$smarty->display("$page.tpl");
exit();
?>