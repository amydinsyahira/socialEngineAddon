<?
$page = "admin_subscriber_dashboard";
include "admin_header.php";

// ALLOW ACCESS TO SUPERADMIN ONLY
if( $admin->admin_info['admin_id'] != 1 ) {
  header("Location: admin_viewplugins.php");
  exit();
}

// Total Income
$total_income = sprintf( "%.2f", semods::db_query_count("SELECT SUM(userpaymenthistory_amount) FROM se_semods_userpaymenthistory") );

// Total Income Last week
$lastweek_to = mktime(0, 0, 0, date("m"), date("d") - date( "w" ) - 1,   date("Y"));
$lastweek_from = mktime(0, 0, 0, date("m"), date("d") - date( "w" ) - 7,   date("Y"));
$total_income_lastweek = sprintf( "%.2f", semods::db_query_count("SELECT SUM(userpaymenthistory_amount) FROM se_semods_userpaymenthistory WHERE userpaymenthistory_date BETWEEN $lastweek_from AND $lastweek_to") );

// Total Income Last Month
$curmonth_from = mktime(0, 0, 0, date("m"), 1,   date("Y"));

$lastmonth_from = mktime(0, 0, 0, date("m")-1, 1,   date("Y"));
$lastmonth_to = mktime(0, 0, 0, date("m")-1, date( "t", $lastmonth_from ),   date("Y"));

$total_income_lastmonth = sprintf( "%.2f", semods::db_query_count("SELECT SUM(userpaymenthistory_amount) FROM se_semods_userpaymenthistory WHERE userpaymenthistory_date BETWEEN $lastmonth_from AND $lastmonth_to"));

// Active Subscriptions
$active_subscriptions = semods::db_query_count("SELECT COUNT(*) FROM se_semods_userplans WHERE userplan_state = 0 OR userplan_state = 1");

// Expired Subscriptions
$expired_subscriptions = semods::db_query_count("SELECT COUNT(*) FROM se_semods_userplans WHERE userplan_state = 2");

// Cancelled Subscriptions
$cancelled_subscriptions = semods::db_query_count("SELECT COUNT(*) FROM se_semods_userplans WHERE userplan_state = 3");

// Latest 10 activities
$activities = array();
$rows = $database->database_query("SELECT * FROM se_semods_userplanactivity A LEFT JOIN se_users U ON A.userplanactivity_user_id = U.user_id ORDER BY userplanactivity_id DESC LIMIT 10");
while($row = $database->database_fetch_assoc($rows)) {
  $row['userplanactivity_typetext'] = $row['userplanactivity_type'] > 1000 ? $functions_subscriber[78] : $activity_msg_types[$row['userplanactivity_type']];
  $activities[] = $row;  
}

// ASSIGN VARIABLES AND SHOW EDIT USERS PAGE
$smarty->assign('error_message', $error_message);
$smarty->assign('result', $result);

$smarty->assign('total_income', $total_income);
$smarty->assign('total_income_lastweek', $total_income_lastweek);
$smarty->assign('total_income_lastmonth', $total_income_lastmonth);

$smarty->assign('active_subscriptions', $active_subscriptions);
$smarty->assign('expired_subscriptions', $expired_subscriptions);
$smarty->assign('cancelled_subscriptions', $cancelled_subscriptions);

$smarty->assign('activities', $activities);

$smarty->display("$page.tpl");
exit();
?>