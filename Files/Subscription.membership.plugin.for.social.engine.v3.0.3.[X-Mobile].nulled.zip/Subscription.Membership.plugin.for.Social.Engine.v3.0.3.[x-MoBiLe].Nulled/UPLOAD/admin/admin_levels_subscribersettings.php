<?
$page = "admin_levels_subscribersettings";
include "admin_header.php";

$task = semods::getpost('task', 'main');
$level_id = semods::getpost('level_id', 0);

// VALIDATE LEVEL ID
$level_info = semods::db_query_assoc( "SELECT * FROM se_levels WHERE level_id = $level_id" );
if(!$level_info) {
  header("Location: admin_levels.php");
  exit();
}

// SET RESULT VARIABLE
$result = 0;
$is_error = 0;
$error_message = "";


// SAVE CHANGES
if($task == "dosave") {

  $level_subscriber_require_subscription = semods::post('level_subscriber_require_subscription', 0);
  $level_subscriber_allow_profileview = semods::post('level_subscriber_allow_profileview', 0);

  $database->database_query("UPDATE se_levels SET 
		  level_subscriber_require_subscription=$level_subscriber_require_subscription,
		  level_subscriber_allow_profileview=$level_subscriber_allow_profileview
		  WHERE level_id = $level_id"
		  );

  // refresh	
  $level_info = semods::db_query_assoc( "SELECT * FROM se_levels WHERE level_id = $level_id" );
  $result = 1;

  
} // END DOSAVE TASK


// ASSIGN VARIABLES AND SHOW ALBUM SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('error_message', $error_message);
$smarty->assign('level_id', $level_info['level_id']);
$smarty->assign('level_name', $level_info['level_name']);
$smarty->assign('level_subscriber_require_subscription', $level_info['level_subscriber_require_subscription']);
$smarty->assign('level_subscriber_allow_profileview', $level_info['level_subscriber_allow_profileview']);
$smarty->display("$page.tpl");
exit();
?>