<?
$page = "admin_subscriber_editplan";
include "admin_header.php";

// shut off warnings for html_entity_decode() - older php versions
error_reporting( E_ALL ^ E_NOTICE ^ E_WARNING );

$task = semods::getpost('task');
$plan_id = semods::getpost('plan_id', 0);

// SET ERROR VARIABLES
$is_error = 0;
$error_message = "";

// Load item data for editing
if( ($task != "editplan") && ($plan_id > 0)) {
  $plan = new semods_plan( $plan_id );

  if($plan->plan_exists == 0) 
    header("Location: admin_subscriber_plans.php");

  $plan_name = $plan->plan_info['plan_name'];
  $plan_description = $plan->plan_info['plan_description'];
  $plan_enabled = $plan->plan_info['plan_enabled'];
  $plan_level_id = $plan->plan_info['plan_level_id'];
  $plan_downgrade_level_id = $plan->plan_info['plan_downgrade_level_id'];
  $plan_period = $plan->plan_info['plan_period'];
  $plan_periodtype = $plan->plan_info['plan_periodtype'];
  $plan_trialperiod = $plan->plan_info['plan_trialperiod'];
  $plan_trialperiodtype = $plan->plan_info['plan_trialperiodtype'];
  $plan_price = $plan->plan_info['plan_price'];
  $plan_onetime_price = $plan->plan_info['plan_onetime_price'];
  $plan_showonsignup = $plan->plan_info['plan_showonsignup'];
  $plan_recurring = $plan->plan_info['plan_recurring'];
  $plan_recurring_cycles = $plan->plan_info['plan_recurring_cycles'];
  $plan_levels = $plan->plan_info['plan_levels'];
  $plan_plans = $plan->plan_info['plan_upgrade_from'];

  // CONVERT HTML CHARACTERS BACK
  $plan_description = html_entity_decode( $plan_description, ENT_QUOTES, 'UTF-8' );
  
  $plan_managed_users = $plan->total_managed_users();

} else {
  // Defaults
  $plan_enabled = 1;
  $plan_level_id = 1;				// default level
  $plan_downgrade_level_id = 1; 	// default level
  $plan_period = 1;					// 1
  $plan_periodtype = 0;				// days
  $plan_trialperiod = 0;			// 0
  $plan_trialperiodtype = 1;		// days
  $plan_price = 0;
  $plan_onetime_price = 0;
  $plan_showonsignup = 1;
  $plan_recurring = 1;
  $plan_recurring_cycles = 0;

  $plan_levels = '';        // all levels
  $plan_plans = '';  // upgrade from any
}

// CREATE / EDIT
if($task == "editplan") {

  //var_dump($_POST);exit;
  
  $plan_name = semods::post('plan_name', '');
  $plan_description = semods::post('plan_description', '');
  $plan_enabled = semods::post('plan_enabled', 0);
  $plan_level_id = semods::post('plan_level_id', 1);
  $plan_downgrade_level_id = semods::post('plan_downgrade_level_id', 1);
  $plan_period = semods::post('plan_period', 1);
  $plan_periodtype = semods::post('plan_periodtype', '');
  $plan_trialperiod = semods::post('plan_trialperiod', 0);
  $plan_trialperiodtype = semods::post('plan_trialperiodtype', 0);
  $plan_price = semods::post('plan_price', 0);
  $plan_onetime_price = semods::post('plan_onetime_price', 0);
  $plan_showonsignup = semods::post('plan_showonsignup', 1);
  $plan_recurring = semods::post('plan_recurring', 1);
  $plan_recurring_cycles = intval(semods::post('plan_recurring_cycles', 0));
  $plan_levels_all = semods::post('plan_levels_all',0);
  $plan_levels = $plan_levels_all ? array() : semods::post('plan_levels',array());
  $plan_plans_all = semods::post('plan_plans_all',0);
  $plan_plans = $plan_plans_all ? array() : semods::post('plan_plans',array());

  $plan_has_managed_users = semods::post('plan_has_managed_users', 0);

  $plan_levels = implode( ',', $plan_levels );
  $plan_plans = implode( ',', $plan_plans );

  $plan_description_encoded = htmlspecialchars( $plan_description );

  for(;;) {

    if(empty($plan_name)) {
      $is_error = 1;
      $error_message = $admin_subscriber_editplan[20];
      break;
    }
    
    if($plan_has_managed_users) {
      // stop verifying if managed
      break;
    }
    
    // validate periods
    // Day 1-90
    // Week 1-52
    // Month 1-24 - recurring payments upto 12
    // Year 1-5 - recurring payments upto 1
    if($plan_period != 0) {
      if($plan_period > $plan_periodtypes[ $plan_periodtype ] ['max']) {
        $is_error = 1;
        $error_message = sprintf( $admin_subscriber_editplan[21], $plan_periodtypes[ $plan_periodtype ] ['p'], $plan_periodtypes[ $plan_periodtype ] ['max'] );
        break;
      }
    }

    if($plan_trialperiod != 0) {
      if($plan_trialperiod > $plan_periodtypes[ $plan_trialperiodtype ] ['max']) {
        $is_error = 1;
        $error_message = sprintf( $admin_subscriber_editplan[22], $plan_periodtypes[ $plan_trialperiodtype ] ['p'], $plan_periodtypes[ $plan_trialperiodtype ] ['max'] );
        break;
      }
    }
    
    break;
    
  }
  
  if($is_error == 0) {
	
	if($plan_id == 0) {
	  $database->database_query("INSERT INTO se_semods_plans(
								plan_name,
								plan_description,
								plan_level_id,
								plan_downgrade_level_id,
								plan_period,
								plan_periodtype,
								plan_trialperiod,
								plan_trialperiodtype,
								plan_price,
								plan_onetime_price,
                                plan_enabled,
                                plan_showonsignup,
								plan_recurring,
                                plan_recurring_cycles,
                                plan_levels,
                                plan_upgrade_from
								)
								VALUES(
								'$plan_name',
								'$plan_description_encoded',
								$plan_level_id,
								$plan_downgrade_level_id,
								$plan_period,
								$plan_periodtype,
								$plan_trialperiod,
								$plan_trialperiodtype,
								$plan_price,
								$plan_onetime_price,
                                $plan_enabled,
                                $plan_showonsignup,
								$plan_recurring,
                                $plan_recurring_cycles,
                                '$plan_levels',
                                '$plan_plans'
								)");
	  
	  $plan_id = $database->database_insert_id();
	  
    }
	else if($plan_has_managed_users) {
	  
      // only updated allowed stuff
	  $database->database_query("UPDATE se_semods_plans SET
								plan_name = '$plan_name',
								plan_description = '$plan_description_encoded',
								plan_level_id = $plan_level_id,
								plan_downgrade_level_id = $plan_downgrade_level_id,
								plan_enabled = $plan_enabled,
								plan_showonsignup = $plan_showonsignup,
                                plan_levels = '$plan_levels',
                                plan_upgrade_from = '$plan_plans'
								WHERE plan_id = $plan_id");

	} else {
	  
	  $database->database_query("UPDATE se_semods_plans SET
								plan_name = '$plan_name',
								plan_description = '$plan_description_encoded',
								plan_level_id = $plan_level_id,
								plan_downgrade_level_id = $plan_downgrade_level_id,
								plan_period = $plan_period,
								plan_periodtype = $plan_periodtype,
								plan_trialperiod = $plan_trialperiod,
								plan_trialperiodtype = $plan_trialperiodtype,
                                plan_price = $plan_price,
                                plan_onetime_price = $plan_onetime_price,
								plan_enabled = $plan_enabled,
								plan_showonsignup = $plan_showonsignup,
								plan_recurring = $plan_recurring,
                                plan_recurring_cycles = $plan_recurring_cycles,
                                plan_levels = '$plan_levels',
                                plan_upgrade_from = '$plan_plans'
								WHERE plan_id = $plan_id");

	}


	header("Location: admin_subscriber_plans.php");
	
  }

}


// No-action "level"
$levels[] = array(  'level_id'      => 0,
                    'level_name'    => $admin_subscriber_editplan[18],
                    'level_default' => 0 );


// LOOP OVER USER LEVELS
$rows = $database->database_query("SELECT level_id, level_name, level_default FROM se_levels ORDER BY level_id");
while($row = $database->database_fetch_assoc($rows)) {
  $levels[] = $row;
}




$plan_levels = empty($plan_levels) ? array() : explode(",", $plan_levels);

// LOOP OVER USER LEVELS, TAKE SELECTED
$rows = $database->database_query("SELECT level_id, level_name, level_default FROM se_levels ORDER BY level_id");
while($row = $database->database_fetch_assoc($rows)) {
  $row['level_selected'] = in_array($row['level_id'], $plan_levels) || $plan_id == 0 || empty($plan_levels) ? 1 : 0;
  $level_array[] = $row;
}



$plan_plans = empty($plan_plans) ? array() : explode(",", $plan_plans);

// LOOP OVER PLANS, TAKE SELECTED
$rows = $database->database_query("SELECT * FROM se_semods_plans");
while($row = $database->database_fetch_assoc($rows)) {
  $row['plan_selected'] = in_array($row['plan_id'], $plan_plans) || $plan_id == 0 || empty($plan_plans) ? 1 : 0;
  $plan_array[] = $row;
}




// ASSIGN VARIABLES AND SHOW ADMIN ADD USER LEVEL PAGE
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('error_message', $error_message);

$smarty->assign('levelsx', $level_array);
$smarty->assign('levels_all', empty($level_array) ? 1 : 0);
$smarty->assign('plans', $plan_array);
$smarty->assign('plans_all', empty($plan_array) ? 1 : 0);

$smarty->assign('levels', $levels);

$smarty->assign('plan_periodtypes', $plan_periodtypes);

$smarty->assign('plan_id', $plan_id);
$smarty->assign('plan_name', $plan_name);
$smarty->assign('plan_description', $plan_description);
$smarty->assign('plan_level_id', $plan_level_id);
$smarty->assign('plan_downgrade_level_id', $plan_downgrade_level_id);
$smarty->assign('plan_period', $plan_period);
$smarty->assign('plan_periodtype', $plan_periodtype);
$smarty->assign('plan_trialperiod', $plan_trialperiod);
$smarty->assign('plan_trialperiodtype', $plan_trialperiodtype);
$smarty->assign('plan_price', $plan_price);
$smarty->assign('plan_onetime_price', $plan_onetime_price);
$smarty->assign('plan_enabled', $plan_enabled);
$smarty->assign('plan_showonsignup', $plan_showonsignup);
$smarty->assign('plan_recurring', $plan_recurring);
$smarty->assign('plan_recurring_cycles', $plan_recurring_cycles);

$smarty->assign('plan_managed_users', $plan_managed_users);
$smarty->assign('plan_has_managed_users', $plan_managed_users > 0 );

$smarty->display("$page.tpl");
exit();
?>