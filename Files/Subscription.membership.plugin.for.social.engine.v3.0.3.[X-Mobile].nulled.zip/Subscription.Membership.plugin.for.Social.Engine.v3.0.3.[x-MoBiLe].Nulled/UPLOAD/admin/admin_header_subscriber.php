<?

// ENSURE THIS IS BEING INCLUDED IN AN SE SCRIPT
if(!defined('SE_PAGE')) { exit(); }

// INCLUDE LANGUAGE FILE
include "../lang/lang_".$global_lang."_subscriber.php";

// INCLUDE SEMODS CLASS FILE
include_once "../include/class_semods.php";

// INCLUDE CLASS FILE
include_once "../include/class_subscriber.php";

// INCLUDE FUNCTIONS FILE
include_once "../include/functions_subscriber.php";

// INCLUDE PAYMENT STUFF
include_once "../lang/lang_".$global_lang."_payment.php";
include_once "../include/functions_payment.php";
include_once "../include/class_payment.php";
include_once "../include/class_semods_cart.php";

?>