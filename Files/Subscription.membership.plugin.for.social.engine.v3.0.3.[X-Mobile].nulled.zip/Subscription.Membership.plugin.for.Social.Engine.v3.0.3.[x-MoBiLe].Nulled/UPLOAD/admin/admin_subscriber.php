<?
$page = "admin_subscriber";
include "admin_header.php";

$task = semods::getpost('task', 'main');


// SET RESULT VARIABLE
$result = 0;

// SAVE CHANGES
if($task == "dosave") {

  $setting_subscriber_enable_subscriptions = semods::post('setting_subscriber_enable_subscriptions', 0);
  $setting_subscriber_allow_multiple_trials = semods::post('setting_subscriber_allow_multiple_trials', 0);
  $setting_subscriber_require_on_signup = semods::post('setting_subscriber_require_on_signup', 0);

  $setting_subscriber_email_paymentfailed_subject = semods::post('setting_subscriber_email_paymentfailed_subject', '');
  $setting_subscriber_email_subscriptionrenewed_subject = semods::post('setting_subscriber_email_subscriptionrenewed_subject', '');
  $setting_subscriber_email_subscriptionexpiration_subject = semods::post('setting_subscriber_email_subscriptionexpiration_subject', '');
  $setting_subscriber_email_subscriptionexpired_subject = semods::post('setting_subscriber_email_subscriptionexpired_subject', '');
  $setting_subscriber_email_subscriptioncancelled_subject = semods::post('setting_subscriber_email_subscriptioncancelled_subject', '');
  $setting_subscriber_email_newsubscription_subject = semods::post('setting_subscriber_email_newsubscription_subject', '');

  $setting_subscriber_email_paymentfailed_message = semods::post('setting_subscriber_email_paymentfailed_message', '');
  $setting_subscriber_email_subscriptionrenewed_message = semods::post('setting_subscriber_email_subscriptionrenewed_message', '');
  $setting_subscriber_email_subscriptionexpiration_message = semods::post('setting_subscriber_email_subscriptionexpiration_message', '');
  $setting_subscriber_email_subscriptionexpired_message = semods::post('setting_subscriber_email_subscriptionexpired_message', '');
  $setting_subscriber_email_subscriptioncancelled_message = semods::post('setting_subscriber_email_subscriptioncancelled_message', '');
  $setting_subscriber_email_newsubscription_message = semods::post('setting_subscriber_email_newsubscription_message', '');
  
  
  $database->database_query("UPDATE se_semods_settings SET 
			setting_subscriber_enable_subscriptions = $setting_subscriber_enable_subscriptions,
            setting_subscriber_allow_multiple_trials = $setting_subscriber_allow_multiple_trials,
            setting_subscriber_require_on_signup = $setting_subscriber_require_on_signup,
            setting_payment_currency = '$setting_payment_currency',
            setting_subscriber_email_paymentfailed_subject = '$setting_subscriber_email_paymentfailed_subject', 
            setting_subscriber_email_subscriptionrenewed_subject = '$setting_subscriber_email_subscriptionrenewed_subject',
            setting_subscriber_email_subscriptionexpiration_subject = '$setting_subscriber_email_subscriptionexpiration_subject',
            setting_subscriber_email_subscriptionexpired_subject = '$setting_subscriber_email_subscriptionexpired_subject',
            setting_subscriber_email_subscriptioncancelled_subject = '$setting_subscriber_email_subscriptioncancelled_subject',
            setting_subscriber_email_newsubscription_subject = '$setting_subscriber_email_newsubscription_subject',
            setting_subscriber_email_paymentfailed_message = '$setting_subscriber_email_paymentfailed_message',
            setting_subscriber_email_subscriptionrenewed_message = '$setting_subscriber_email_subscriptionrenewed_message',
            setting_subscriber_email_subscriptionexpiration_message = '$setting_subscriber_email_subscriptionexpiration_message',
            setting_subscriber_email_subscriptionexpired_message = '$setting_subscriber_email_subscriptionexpired_message',
            setting_subscriber_email_subscriptioncancelled_message = '$setting_subscriber_email_subscriptioncancelled_message',
            setting_subscriber_email_newsubscription_message = '$setting_subscriber_email_newsubscription_message'
			");

  $result = 1;

}


// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('error', $error);

$smarty->assign('setting_subscriber_enable_subscriptions', semods::get_setting('subscriber_enable_subscriptions'));
$smarty->assign('setting_subscriber_allow_multiple_trials', semods::get_setting('subscriber_allow_multiple_trials'));
$smarty->assign('setting_subscriber_require_on_signup', semods::get_setting('subscriber_require_on_signup'));

$smarty->assign('setting_subscriber_email_paymentfailed_subject', semods::get_setting('subscriber_email_paymentfailed_subject'));
$smarty->assign('setting_subscriber_email_subscriptionrenewed_subject', semods::get_setting('subscriber_email_subscriptionrenewed_subject'));
$smarty->assign('setting_subscriber_email_subscriptionexpiration_subject', semods::get_setting('subscriber_email_subscriptionexpiration_subject'));
$smarty->assign('setting_subscriber_email_subscriptionexpired_subject', semods::get_setting('subscriber_email_subscriptionexpired_subject'));
$smarty->assign('setting_subscriber_email_subscriptioncancelled_subject', semods::get_setting('subscriber_email_subscriptioncancelled_subject'));
$smarty->assign('setting_subscriber_email_newsubscription_subject', semods::get_setting('subscriber_email_newsubscription_subject'));

$smarty->assign('setting_subscriber_email_paymentfailed_message', semods::get_setting('subscriber_email_paymentfailed_message'));
$smarty->assign('setting_subscriber_email_subscriptionrenewed_message', semods::get_setting('subscriber_email_subscriptionrenewed_message'));
$smarty->assign('setting_subscriber_email_subscriptionexpiration_message', semods::get_setting('subscriber_email_subscriptionexpiration_message'));
$smarty->assign('setting_subscriber_email_subscriptionexpired_message', semods::get_setting('subscriber_email_subscriptionexpired_message'));
$smarty->assign('setting_subscriber_email_subscriptioncancelled_message', semods::get_setting('subscriber_email_subscriptioncancelled_message'));
$smarty->assign('setting_subscriber_email_newsubscription_message', semods::get_setting('subscriber_email_newsubscription_message'));


$smarty->display("$page.tpl");
exit();
?>