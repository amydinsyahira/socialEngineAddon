<?
$page = "admin_paymentgw";
include "admin_header.php";

// ALLOW ACCESS TO SUPERADMIN ONLY
if( $admin->admin_info['admin_id'] != 1 ) {
  header("Location: admin_viewplugins.php");
  exit();
}

$task = semods::getpost('task', 'main');


// SET RESULT VARIABLE
$result = 0;

if($task == "testpaypal") {
  $paymentgw = semods_paymengtw_factory( 1 );
  //$result = $paymentgw->get_balance();
  $result = $paymentgw->get_transaction_details( '20P46879S1049380U' );
  
  if($result !== false) {
    echo $admin_paymentgw[8];
  } elseif ($paymentgw->errID == 10007) {
    // permission denied error, which is ok
    echo $admin_paymentgw[8];
  } elseif ($paymentgw->errID == 10002) {
    // "Security header is not valid" - incorrect api stuff
    echo $admin_paymentgw[9] . $paymentgw->errMsg;
  } else {
    echo $paymentgw->errMsg;
  }
  
  exit();
}

if($task == "main") {
  
  // Load data

  // Paypal GW
  $paymentgw_id = 1;

  $paymentgw = semods::db_query_assoc( "SELECT * FROM se_semods_paymentgateways WHERE paymentgateway_id = $paymentgw_id" );
  $metadata = unserialize( $paymentgw['paymentgateway_metadata'] );

  $paypal_business = $metadata['business'];
  $paypal_cert_id = $metadata['cert_id'];
  $paypal_identity_token = $metadata['identity_token'];
  $paypal_myprivkey = $metadata['ssl_myprivkey_file'];
  $paypal_mypubcert = $metadata['ssl_mypubcert_file'];
  $paypal_paypalcert = $metadata['ssl_paypalcert_file'];
  $paypal_enable_enc = $metadata['method'];

  $paypal_api_username = $metadata['api_username'];
  $paypal_api_password = $metadata['api_password'];
  $paypal_api_signature = $metadata['api_signature'];

//  $paypal_currency = $metadata['currency'];

  // Google Checkout
  $paymentgw_id = 2;

  $paymentgw = semods::db_query_assoc( "SELECT * FROM se_semods_paymentgateways WHERE paymentgateway_id = $paymentgw_id" );
  $metadata = unserialize( $paymentgw['paymentgateway_metadata'] );
  $googlech_merchant_id = $metadata['merchant_id'];
  $googlech_merchant_key = $metadata['merchant_key'];

}



// SAVE CHANGES
if($task == "dosave") {

  $setting_payment_currency = semods::post('setting_payment_currency', 'USD');
  $setting_payment_tax = floatval(semods::post('setting_payment_tax', '0'));

  // General Settings

  $database->database_query("UPDATE se_semods_settings SET 
            setting_payment_currency = '$setting_payment_currency',
            setting_payment_tax = '$setting_payment_tax'
			");


 
  // Paypal GW
  $paymentgw_id = 1;
  
  $paypal_business = trim( semods::getpost('paypal_business','') );
  $paypal_cert_id = trim( semods::getpost('paypal_cert_id','') );
  $paypal_identity_token = trim( semods::getpost('paypal_identity_token','') );
  $paypal_myprivkey = trim( semods::getpost('paypal_myprivkey','') );
  $paypal_mypubcert = trim( semods::getpost('paypal_mypubcert','') );
  $paypal_paypalcert = trim( semods::getpost('paypal_paypalcert','') );
  $paypal_enable_enc = semods::getpost('paypal_enable_enc',0);
  $paypal_api_username = trim( semods::getpost('paypal_api_username','') );
  $paypal_api_password = trim( semods::getpost('paypal_api_password','') );
  $paypal_api_signature = trim( semods::getpost('paypal_api_signature','') );
//  $paypal_currency = semods::getpost('paypal_currency','USD');
  
  $metadata = array();
  $metadata['business'] = $paypal_business;
  $metadata['cert_id'] = $paypal_cert_id;
  $metadata['identity_token'] = $paypal_identity_token;
  $metadata['ssl_myprivkey_file'] = $paypal_myprivkey;
  $metadata['ssl_mypubcert_file'] = $paypal_mypubcert;
  $metadata['ssl_paypalcert_file'] = $paypal_paypalcert;
  $metadata['method'] = $paypal_enable_enc;
  $metadata['api_username'] = $paypal_api_username;
  $metadata['api_password'] = $paypal_api_password;
  $metadata['api_signature'] = $paypal_api_signature;
//  $metadata['currency'] = $paypal_currency;
  
  $metadata = serialize( $metadata );
  $database->database_query( "UPDATE se_semods_paymentgateways  SET paymentgateway_metadata = '$metadata' WHERE paymentgateway_id = $paymentgw_id" );
  
  
  // Google Checkout
  $paymentgw_id = 2;

  $googlech_merchant_id = semods::getpost('googlech_merchant_id','');
  $googlech_merchant_key = semods::getpost('googlech_merchant_key','');
  $metadata = array();
  $metadata['merchant_id'] = $googlech_merchant_id;
  $metadata['merchant_key'] = $googlech_merchant_key;

  $metadata = serialize( $metadata );
  $database->database_query( "UPDATE se_semods_paymentgateways  SET paymentgateway_metadata = '$metadata' WHERE paymentgateway_id = $paymentgw_id" );



  $result = 1;
  


}

$paypal_ipn_url = $url->url_base . "payment_paypal.php?action=ipn";


// ASSIGN VARIABLES AND SHOW GENERAL SETTINGS PAGE
$smarty->assign('result', $result);
$smarty->assign('error', $error);

$smarty->assign('setting_payment_currency', semods::get_setting('payment_currency'));
$smarty->assign('setting_payment_tax', semods::get_setting('payment_tax'));


// Paypal GW
$smarty->assign('paypal_business', $paypal_business);
$smarty->assign('paypal_cert_id', $paypal_cert_id );
$smarty->assign('paypal_identity_token', $paypal_identity_token);
$smarty->assign('paypal_myprivkey', $paypal_myprivkey);
$smarty->assign('paypal_mypubcert', $paypal_mypubcert);
$smarty->assign('paypal_paypalcert', $paypal_paypalcert);
$smarty->assign('paypal_enable_enc', $paypal_enable_enc);

//$smarty->assign('paypal_currency', $paypal_currency);
$smarty->assign('paypal_api_username', $paypal_api_username);
$smarty->assign('paypal_api_password', $paypal_api_password);
$smarty->assign('paypal_api_signature', $paypal_api_signature);
$smarty->assign('paypal_ipn_url', $paypal_ipn_url);

// Google Checkout
$smarty->assign('googlech_merchant_id', $googlech_merchant_id);
$smarty->assign('googlech_merchant_key', $googlech_merchant_key);

$smarty->display("$page.tpl");
exit();
?>