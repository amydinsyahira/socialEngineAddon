<?
$page = "admin_subscriber_edituser";
include "admin_header.php";

$p = semods::getpost('p', 1);
$f_user = semods::getpost('f_user', "");
$f_email = semods::getpost('f_email', "");
$f_level = semods::getpost('f_level', "");
$f_subnet = semods::getpost('f_subnet', "");
$f_enabled = semods::getpost('f_enabled', "");
$task = semods::getpost('task', "main");
$user_id = semods::getpost('user_id', 0);

// VALIDATE USER ID OR RETURN TO VIEW USERS
$user = new se_user(Array($user_id));
if($user->user_exists == 0) { header("Location: admin_subscriber_viewusers.php?s=$s&p=$p&f_user=$f_user&f_email=$f_email&f_level=$f_level&f_enabled=$f_enabled"); exit(); }


// INITIALIZE ERROR VARS
$error_message = "";
$result = "";



// CANCEL / UNLINK PLAN
if($task == "cancelplan") {

  $userplan_id = semods::getpost('plan_id');
  $userplan = new semods_userplan( $userplan_id, $user_id );

  //var_dump($userplan);exit;  
  $userplan->cancel_plan();

  header("Location: admin_subscriber_edituser.php?user_id=$user_id");
  
  //header("Location: admin_subscriber_viewusers.php?s=$s&p=$p&f_user=$f_user&f_email=$f_email&f_level=$f_level&f_enabled=$f_enabled");
  //  exit();

}

// DELETE PLAN
if($task == "deleteplan") {

  $userplan_id = semods::getpost('plan_id');
  $userplan = new semods_userplan( $userplan_id, $user_id );
  
  // downgrade?
  $userplan->delete_plan();
  
  header("Location: admin_subscriber_edituser.php?user_id=$user_id");
  
//  header("Location: admin_subscriber_viewusers.php?s=$s&p=$p&f_user=$f_user&f_email=$f_email&f_level=$f_level&f_enabled=$f_enabled");
//  exit();

}


// SUBSCRIBE PLAN
if($task == "subscribeplan") {

  $plan_id = semods::getpost('plan_id');
  if(!empty($plan_id)) {
    $newplan = new semods_plan( $plan_id );
    if($newplan->plan_exists)
      $userplan = $newplan->plan_subscribe( $user_id, 0, array(), false );
  }
  
  header("Location: admin_subscriber_edituser.php?user_id=$user_id");
  
//  header("Location: admin_subscriber_viewusers.php?s=$s&p=$p&f_user=$f_user&f_email=$f_email&f_level=$f_level&f_enabled=$f_enabled");
//  exit();

}


if($task == "dosave") {

  // just touch everything with hands like a redneck
  $userplan_plan = semods::getpost('userplan_plan',0);
  $userplan_state = semods::getpost('userplan_state');
  $expdate_month = semods::getpost('expdate_month');
  $expdate_day = semods::getpost('expdate_day');
  $expdate_year =  semods::getpost('expdate_year');
  
  // Now - only one plan
  $userplan = new semods_userplan( 0, $user_id );
  
  // Changed plan?
  if($userplan->plan_info['plan_id'] != $userplan_plan) {

    $userplan->delete_plan();
    $newplan = new semods_plan( $userplan_plan );
    $userplan = $newplan->plan_subscribe( $user_id, 0, array(), false );
    
  }

  $userplan->change_state( $userplan_state );
  
  $expiration_date = mktime( 0, 0, 0, $expdate_month, $expdate_day, $expdate_year );  
  
  $userplan->set_expiration_date( $expiration_date );

  $result = $admin_subscriber_edituser[34];
  //header("Location: admin_subscriber_viewusers.php?s=$s&p=$p&f_user=$f_user&f_email=$f_email&f_level=$f_level&f_enabled=$f_enabled");
  //exit();

}









// LOAD PLANS
$rows = $database->database_query("SELECT * FROM se_semods_plans WHERE plan_enabled = 1");
while($row = $database->database_fetch_assoc($rows)) {
  $plans[] = $row;
}


// LOAD PAYMENT GATEWAYS 
$rows = $database->database_query("SELECT * FROM se_semods_paymentgateways");
while($row = $database->database_fetch_assoc($rows)) {
  $payment_gateways[$row['paymentgateway_id']] = $row;
}


// GET USER PLANS
$userplans = array();
$rows = $database->database_query("SELECT userplan_id FROM se_semods_userplans WHERE userplan_user_id = {$user->user_info['user_id']} ");
while($row = $database->database_fetch_assoc( $rows )) {
  $userplan = new semods_userplan( $row['userplan_id'] );

  $userplan->managed = $userplan->userplan_info['userplan_handler'] == 0;
  
  $field_value = $userplan->userplan_info['userplan_expiredate'];
  
  // DECONSTRUCT TIMESTAMP INTO DATE MONTH, DAY, AND YEAR
  if($field_value != $datetime->MakeTime("0", "0", "0", "0", "0", "0")) {
    $field_date = $datetime->MakeDate($field_value);
    $field_month = $field_date[0]; $field_day = $field_date[1]; $field_year = $field_date[2];
  } else {
    $field_month = 0; $field_day = 0; $field_year = 0;
  }
  
  // CONSTRUCT MONTH ARRAY
  $month_format = "M";
  $month_array = Array();
  $month_array[0] = Array('name' => "[$admin_subscriber_edituser[27]]", 'value' => "0", 'selected' => "");
  for($m=1;$m<=12;$m++) {
    if($field_month == $m) { $selected = " SELECTED"; } else { $selected = ""; }
    $month_array[$m] = Array('name' => $datetime->cdate("$month_format", mktime(0, 0, 0, $m, 1, 1990)),
            'value' => $m,
            'selected' => $selected);
  }
  
  
  // CONSTRUCT DAY ARRAY
  $day_format = "d";
  $day_array = Array();
  $day_array[0] = Array('name' => "[$admin_subscriber_edituser[28]]", 'value' => "0", 'selected' => "");
  for($d=1;$d<=31;$d++) {
    if($field_day == $d) { $selected = " SELECTED"; } else { $selected = ""; }
    $day_array[$d] = Array('name' => $datetime->cdate("$day_format", mktime(0, 0, 0, 1, $d, 1990)),
            'value' => $d,
            'selected' => $selected);
  }
  
  // CONSTRUCT YEAR ARRAY
  $year_array = Array();
  $year_count = 1;
  $current_year = $datetime->cdate("Y", time());
  $year_array[0] = Array('name' => "[$admin_subscriber_edituser[29]]", 'value' => "0", 'selected' => "");
  for($y=$current_year+10;$y>=$current_year-1;$y--) {
    if($field_year == $y) { $selected = " SELECTED"; } else { $selected = ""; }
    $year_array[$year_count] = Array('name' => $y,
                'value' => $y,
                'selected' => $selected);
  $year_count++;
  }

  // unwrap expiration date
  //$expiration_date = $datetime->timezone($userplan->userplan_info['userplan_expiredate'] , $global_timezone);
  //$plan->expdate_year = date( "Y", $expiration_date );
  //$plan->expdate_month = date( "m", $expiration_date );
  //$plan->expdate_day = date( "d", $expiration_date );

  $userplan->expdate_year = $year_array;
  $userplan->expdate_month = $month_array;
  $userplan->expdate_day = $day_array;

  $userplans[] = $userplan;


}



// ASSIGN VARIABLES AND SHOW EDIT USERS PAGE
$smarty->assign('error_message', $error_message);
$smarty->assign('result', $result);
$smarty->assign('user_id', $user_id);
$smarty->assign('user_username', $user->user_info[user_username]);

$smarty->assign('plans', $plans);
$smarty->assign('userplans', $userplans);

$smarty->assign('userplan_states', $userplan_states);

$smarty->assign('payment_gateways', $payment_gateways);


$smarty->assign('levels', $level_array);
$smarty->assign('s', $s);
$smarty->assign('p', $p);
$smarty->assign('f_user', $f_user);
$smarty->assign('f_email', $f_email);
$smarty->assign('f_level', $f_level);
$smarty->assign('f_enabled', $f_enabled);
$smarty->display("$page.tpl");
exit();
?>