<?
$page = "admin_subscriber_viewusers";
include "admin_header.php";


//$s = semods::getpost('s', "pcd");   // sort default by points count desc
$s = semods::getpost('s', "id");   // sort default by uid desc
$p = semods::getpost('p', 1);
$f_user = semods::getpost('f_user', "");
$f_email = semods::getpost('f_email', "");
$f_level = semods::getpost('f_level', "");
$f_subnet = semods::getpost('f_subnet', "");
$f_plan = semods::getpost('f_plan', "");
$f_enabled = semods::getpost('f_enabled', "");
$task = semods::getpost('task', "main");
$user_id = semods::getpost('user_id', 0);

// GET USER IF ONE IS SPECIFIED
$user = new se_user(Array($user_id));

// SET USER SORT-BY VARIABLES FOR HEADING LINKS
$i = "id";   // USER_ID
$u = "u";    // USER_USERNAME
$em = "em";  // USER_EMAIL
$v = "v";    // USER_VERIFIED
$sd = "sd";  // USER_SIGNUPDATE
//$pc = "pc";  // POINTS COUNT
//$tp = "tp";  // TOTAL POINTS EARNED
//$sip = "sip";  // SIGNUP IP

// SET SORT VARIABLE FOR DATABASE QUERY
if($s == "i") {
  $sort = "user_id";
  $i = "id";
} elseif($s == "id") {
  $sort = "user_id DESC";
  $i = "i";
} elseif($s == "u") {
  $sort = "user_username";
  $u = "ud";
} elseif($s == "ud") {
  $sort = "user_username DESC";
  $u = "u";
} elseif($s == "em") {
  $sort = "user_email";
  $em = "emd";
} elseif($s == "emd") {
  $sort = "user_email DESC";
  $em = "em";
} elseif($s == "v") {
  $sort = "user_verified, user_email";
  $v = "vd";
} elseif($s == "vd") {
  $sort = "user_verified DESC, user_email";
  $v = "v";
} elseif($s == "sd") {
  $sort = "user_signupdate";
  $sd = "sdd";
} elseif($s == "sdd") {
  $sort = "user_signupdate DESC";
  $sd = "sd";
} elseif($s == "pc") {
  $sort = "userpoints_count";
  $pc = "pcd";
} elseif($s == "pcd") {
  $sort = "userpoints_count DESC";
  $pc = "pc";
} elseif($s == "tp") {
  $sort = "userpoints_totalearned";
  $tp = "tpd";
} elseif($s == "tpd") {
  $sort = "userpoints_totalearned DESC";
  $tp = "tp";
} else {
  $sort = "user_id DESC";
  $i = "i";
}


$sql_head = "SELECT U.user_id, U.user_email, U.user_username, U.user_level_id, U.user_subnet_id, U.user_enabled,
			  P.*, P1.*
			   ";

$sql_body = "FROM se_users U
		LEFT JOIN se_semods_userplans P ON U.user_id = P.userplan_user_id
        LEFT JOIN se_semods_plans P1 ON P.userplan_plan_id = P1.plan_id";

$sql_tail = 'GROUP BY U.user_id';

$filters = array();
$f_user != ""    ? $filters[] = "user_username LIKE '%$f_user%'" :0;
$f_email != ""   ? $filters[] = "user_email LIKE '%$f_email%'" :0;
$f_level != ""   ? $filters[] = "user_level_id = '$f_level'" :0;
$f_subnet != ""  ? $filters[] = "user_subnet_id = '$f_subnet'" :0;
$f_enabled != "" ? $filters[] = "user_enabled = '$f_enabled'" :0;

if($f_plan != "") {
  
  if( $f_plan > 0 )
    $filters[] = "userplan_plan_id = '$f_plan'";
  else

/*
 * userplan_state
 * 0 - active
 * 1 - active_trial
 * 2 - expired
 * 3 - cancelled
 * 4 - suspended(?)
 * 5 - created - waiting for payment confirmation
 * 6 - future??? - subscribed but not yet activated, when previous plan is still active and "downgrading" plan
 * 7 - suspended - failed payment
 * 
 */
  
    switch($f_plan) {
      
      // Not subscribed (no plan or expired(2) )
      case -1:
        $filters[] = "(ISNULL(userplan_plan_id) OR userplan_state = 2)";
        break;
      
      // Only subscribed & active ( active(0), active_trial(1), cancelled(3), suspended(4), 5,7 )
      case -2:
        $filters[] = "userplan_state IN(0,1,3,4,5,7)";
        break;
      
      // suspended (4,7)
      case -3:
        $filters[] = "userplan_state IN(4,7)";
        break;
      
      
    }
  
}
  

!empty($filters)  ? $sql_body .= " WHERE " . implode( " AND ", $filters):0;

$sql_count = 'SELECT COUNT(*)' . ' ' . $sql_body . ' ' . $sql_tail;

$sql_users = $sql_head  . ' ' . $sql_body . ' ' . $sql_tail;
		

// GET TOTAL USERS
$total_users = semods::db_query_count( $sql_count );

// MAKE USER PAGES
$users_per_page = 100;
$page_vars = make_page($total_users, $users_per_page, $p);

$page_array = Array();
for($x=0;$x<=$page_vars[2]-1;$x++) {
  if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
  $page_array[$x] = Array('page' => $x+1,
			  'link' => $link);
}

$sql_users .= " ORDER BY $sort LIMIT $page_vars[0], $users_per_page";




// LOOP OVER USER LEVELS
$levels = $database->database_query("SELECT level_id, level_name FROM se_levels ORDER BY level_name");
while($level_info = $database->database_fetch_assoc($levels)) {
  $level_array[$level_info[level_id]] = Array('level_id' => $level_info[level_id],
			'level_name' => $level_info[level_name]);
}


// LOOP OVER SUBNETWORKS
$subnets = $database->database_query("SELECT subnet_id, subnet_name FROM se_subnets ORDER BY subnet_name");
$subnet_array[0] = Array('subnet_id' => 0, 'subnet_name' => $admin_subscriber_viewusers[26]);
while($subnet_info = $database->database_fetch_assoc($subnets)) {
  $subnet_array[$subnet_info[subnet_id]] = Array('subnet_id' => $subnet_info[subnet_id],
		       'subnet_name' => $subnet_info[subnet_name]);
}

// LOOP OVER PLANS
$rows = $database->database_query("SELECT * FROM se_semods_plans plan_name");
while($row = $database->database_fetch_assoc($rows)) {
  $plans[] = $row;
}


// PULL USERS INTO AN ARRAY
$user = Array();
$user_count = 0;
$users_dbr = $database->database_query($sql_users);
while($user_info = $database->database_fetch_assoc($users_dbr)) {

  $user_info['user_level'] = $level_array[$user_info['user_level_id']]['level_name'];
  $user_info['user_subnet'] = $subnet_array[$user_info['user_subnet_id']]['subnet_name'];
  $user_info['user_enabled'] = $user_info['user_enabled'] ? $admin_subscriber_viewusers[9] : $admin_userpoints_viewusers[10];
  
  $user_info['userplan_statetext'] = $userplan_states[ $user_info['userplan_state'] ];
  
  $users[] = $user_info;
}



// ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('total_users', $total_users);
$smarty->assign('pages', $page_array);
$smarty->assign('users', $users);
$smarty->assign('i', $i);
$smarty->assign('u', $u);
$smarty->assign('em', $em);
$smarty->assign('v', $v);
$smarty->assign('sd', $sd);
$smarty->assign('pc', $pc);
$smarty->assign('tp', $tp);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('s', $s);
$smarty->assign('f_user', $f_user);
$smarty->assign('f_email', $f_email);
$smarty->assign('f_level', $f_level);
$smarty->assign('f_subnet', $f_subnet);
$smarty->assign('f_enabled', $f_enabled);
$smarty->assign('f_plan', $f_plan);
$smarty->assign('levels', array_values($level_array));
$smarty->assign('subnets', array_values($subnet_array));
$smarty->assign('plans', $plans);
$smarty->display("$page.tpl");
exit();
?>