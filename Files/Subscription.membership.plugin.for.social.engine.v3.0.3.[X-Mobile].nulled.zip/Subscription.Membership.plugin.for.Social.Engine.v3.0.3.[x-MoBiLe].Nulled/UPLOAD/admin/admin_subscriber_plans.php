<?
$page = "admin_subscriber_plans";
include "admin_header.php";

//var_dump($_POST);exit;

$task = semods::getpost('task');
$s = semods::getpost('s');
$plan_id = semods::getpost('plan_id');

// SET RESULT VARIABLE
$result = 0;
$is_error = 0;


// MAKE SURE THERE IS NO PROBLEM WITH DELETING THE SPECIFIED PLAN
// must show confirm dlg if there are subscribed users
if($task == "delete") {

  $plan = new semods_plan( $plan_id );
  if($plan->plan_exists) {
    

    if($plan->total_users() > 0) {
      $is_error = 1;
      $error_message = $admin_subscriber_plans[18];
    } else {
      $plan->delete();
      header("Location: admin_subscriber_plans.php");
    }
  }


}

if($task == "enable") {
  $enable = semods::getpost('enable');

  $plan = new semods_plan( $plan_id );
  $plan->enable($enable);

  header("Location: admin_subscriber_plans.php");
}




// SET USER LEVEL SORT-BY VARIABLES FOR HEADING LINKS
$i = "id";   // plan_id
$n = "n";    // plan_name
$u = "ud";   // plan_users

// SET SORT VARIABLE FOR DATABASE QUERY
if($s == "i") {
  $sort = "plan_id";
  $i = "id";
} elseif($s == "id") {
  $sort = "plan_id DESC";
  $i = "i";
} elseif($s == "n") {
  $sort = "plan_name";
  $n = "nd";
} elseif($s == "nd") {
  $sort = "plan_name DESC";
  $n = "n";
} elseif($s == "u") {
  $sort = "users";
  $u = "ud";
} elseif($s == "ud") {
  $sort = "users DESC";
  $u = "u";
} else {
  $sort = "plan_id DESC";
  $i = "i";
}



// GET USER LEVEL ARRAY
$rows = $database->database_query("SELECT P.*, COUNT(UP.userplan_user_id) AS users FROM se_semods_plans P LEFT JOIN se_semods_userplans UP ON P.plan_id=UP.userplan_plan_id GROUP BY P.plan_id ORDER BY $sort");

while($row = $database->database_fetch_assoc($rows)) {
  $plans[] = $row;
}


// ASSIGN VARIABLES AND SHOW ADMIN USER LEVELS PAGE
$smarty->assign('s', $s);
$smarty->assign('i', $i);
$smarty->assign('n', $n);
$smarty->assign('u', $u);
$smarty->assign('result', $result);
$smarty->assign('is_error', $is_error);
$smarty->assign('error_message', $error_message);
$smarty->assign('plans', $plans);
$smarty->display("$page.tpl");
exit();
?>