<?
$page = "admin_payment_clients";
include "admin_header.php";

// ALLOW ACCESS TO SUPERADMIN ONLY
if( $admin->admin_info['admin_id'] != 1 ) {
  header("Location: admin_viewplugins.php");
  exit();
}

$s = semods::getpost('s', "mid");   // sort default by msgid desc
$p = semods::getpost('p', 1);
$f_user = semods::getpost('f_user', "");
$f_email = semods::getpost('f_email', "");
$f_name = semods::getpost('f_name', "");

$task = semods::getpost('task', "main");

// SET USER SORT-BY VARIABLES FOR HEADING LINKS
$i = "mid";   // MSG_ID
$u = "u";     // USER_USERNAME

// SET SORT VARIABLE FOR DATABASE QUERY
if($s == "u") {
  $sort = "user_username";
  $u = "ud";
} elseif($s == "ud") {
  $sort = "user_username DESC";
  $u = "u";
} elseif($s == "mi") {
  $sort = "client_id";
  $i = "mid";
} else {
  $sort = "client_id DESC";
  $i = "mi";
}


$sql_head = "SELECT U.user_id, U.user_username, 
			  C.*";

$sql_body = "FROM se_semods_clients C
             LEFT JOIN se_users U ON C.client_user_id = U.user_id";

$filters = array();
$f_user != ""    ? $filters[] = "user_username LIKE '%$f_user%'" :0;
$f_email != ""    ? $filters[] = "client_email LIKE '%$f_email%'" :0;
$f_name != ""    ? $filters[] = "client_firstname LIKE '%$f_name%' OR client_lastname LIKE '%$f_name%'" :0;

!empty($filters)  ? $sql_body .= " WHERE " . implode( " AND ", $filters):0;

$sql_count = 'SELECT COUNT(*)' . ' ' . $sql_body;

$sql_items = $sql_head  . ' ' . $sql_body;
		

// GET TOTAL ITEMS
$total_items = semods::db_query_count( $sql_count );

// MAKE PAGES
$items_per_page = 50;
$page_vars = make_page($total_items, $items_per_page, $p);

$page_array = Array();
for($x=0;$x<=$page_vars[2]-1;$x++) {
  if($x+1 == $page_vars[1]) { $link = "1"; } else { $link = "0"; }
  $page_array[$x] = Array( 'page' => $x+1, 'link' => $link);
}

$sql_items .= " ORDER BY $sort LIMIT $page_vars[0], $items_per_page";



// PULL ITEMS INTO AN ARRAY
$clients = Array();
$rows = $database->database_query($sql_items);
while($row = $database->database_fetch_assoc($rows)) {
  
  $clients[] = $row;
  
}


// ASSIGN VARIABLES AND SHOW VIEW USERS PAGE
$smarty->assign('total_items', $total_items);
$smarty->assign('pages', $page_array);
$smarty->assign('clients', $clients);
$smarty->assign('i', $i);
$smarty->assign('u', $u);
$smarty->assign('em', $em);
$smarty->assign('v', $v);
$smarty->assign('sd', $sd);
$smarty->assign('pc', $pc);
$smarty->assign('tp', $tp);
$smarty->assign('p', $page_vars[1]);
$smarty->assign('s', $s);
$smarty->assign('f_user', $f_user);
$smarty->assign('f_email', $f_email);
$smarty->assign('f_name', $f_name);
$smarty->display("$page.tpl");
exit();
?>