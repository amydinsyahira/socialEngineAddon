<?
$page = "user_plan";
include "header.php";

$task = semods::getpost('task', "main");


if($task == "cancelplan") {
  $userplan_id = semods::getpost('plan_id');
  $userplan = new semods_userplan( $userplan_id, $user->user_info['user_id'] );
  
  $userplan->cancel_plan();
}

$plans = array();
$rows = $database->database_query("SELECT userplan_id FROM se_semods_userplans WHERE userplan_user_id = {$user->user_info['user_id']} ");
while($row = $database->database_fetch_assoc( $rows )) {
  $plans[] = new semods_userplan( $row['userplan_id'] );
}

// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
$smarty->assign('plans', $plans);
include "footer.php";
?>