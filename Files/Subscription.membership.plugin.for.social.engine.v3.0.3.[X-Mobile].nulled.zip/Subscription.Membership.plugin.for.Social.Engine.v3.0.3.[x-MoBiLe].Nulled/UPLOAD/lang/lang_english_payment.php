<?


// SET GENERAL VARIABLES, AVAILABLE ON EVERY PAGE
$header_payment[1] = "";


// ASSIGN ALL SMARTY GENERAL VARIABLES
reset($header_payment);
while(list($key, $val) = each($header_payment)) {
  $smarty->assign("header_payment".$key, $val);
}


// FUNCTION VARIABLES

/* Transaction States */
$functions_payment[20] = "Completed";
$functions_payment[21] = "Pending";
$functions_payment[22] = "Refunded";
$functions_payment[23] = "Reversed";
$functions_payment[24] = "Failed";

/* Payment Text Items */
$functions_payment[30] = "Cart Items";
$functions_payment[31] = "Sale";


// SET LANGUAGE PAGE VARIABLES
switch ($page) {

  case "admin_paymentgw":
	$admin_paymentgw[1] = "Payment Gateways";
	$admin_paymentgw[2] = "Here you can setup parameters for various payment gateways.";
	$admin_paymentgw[3] = "Your changes have been saved.";

	$admin_paymentgw[4] = "";
	$admin_paymentgw[5] = "";
	$admin_paymentgw[6] = "";

	$admin_paymentgw[7] = "";
	$admin_paymentgw[8] = "Everything seems to be ok";
	$admin_paymentgw[9] = "ERROR - Please make sure you have correct values for API Username, API Password and Signature. \n\nPaypal said:\n";

	$admin_paymentgw[10] = "Test";
	$admin_paymentgw[11] = "(copy)";

	$admin_paymentgw[13] = "Save Changes";

	$admin_paymentgw[20] = "Paypal";
	$admin_paymentgw[21] = "Information about your paypal account for purchases. To obtain api credentials, login to your paypal account and navigate to Profile -> API Access -> Request API Credentials." ;
	$admin_paymentgw[22] = "Paypal email";
	$admin_paymentgw[23] = "Certificate ID";
	$admin_paymentgw[24] = "Identity token";
	$admin_paymentgw[25] = "My Private Key File";
	$admin_paymentgw[26] = "My Public Certificate file";
	$admin_paymentgw[27] = "Paypal Public  Certificate file";
	$admin_paymentgw[28] = "Encryption allows keeping purchasing data intact and prevent fraudulent changes during paypal transaction.";
	$admin_paymentgw[29] = "Enable encryption";
	$admin_paymentgw[30] = "API Username";
	$admin_paymentgw[31] = "API Password";
	$admin_paymentgw[32] = "Signature";
	$admin_paymentgw[33] = "IPN Callback Url - This is usually transmitted during transaction, but sometimes paypal \"forgets\" the url, so to be sure, copy&paste the following url: Login to your paypal account and navigate to Profile -> Instant Payment Notification Preferences and paste the url. Don't forget to check \"on\".";
	$admin_paymentgw[34] = "IPN Callback Url:";
    /*
     For recurring payments locale must be in US, says paypal!
	$admin_paymentgw[35] = "Locale - Locale of pages displayed by PayPal during checkout <br> Currency - Default pricing currency.";
	$admin_paymentgw[36] = "Locale:";
    */
	$admin_paymentgw[35] = "Currency - Default pricing currency.";
	$admin_paymentgw[37] = "Currency:";
	$admin_paymentgw[38] = "You can test paypal parameters by clicking test button below. The system will try to perform simple API operation using api credentials. Please SAVE before trying to test.";
    

	$admin_paymentgw[40] = "Google Checkout";
	$admin_paymentgw[41] = "Integration with google checkout";
	$admin_paymentgw[42] = "Merchant ID:";
	$admin_paymentgw[43] = "Merchant Key:";

	$admin_paymentgw[50] = "Authorize.Net";
	$admin_paymentgw[51] = "Integration with Authorize.Net payment gateway";
	$admin_paymentgw[52] = "Login ID:";
	$admin_paymentgw[53] = "Transaction Key:";
	
	$admin_paymentgw[60] = "2CheckOut.com";
	$admin_paymentgw[61] = "Integration with 2CO payment gateway";
	$admin_paymentgw[62] = "Vendor ID:";
	$admin_paymentgw[63] = "Secret Word:";
	
	$admin_paymentgw[70] = "General Settings";
	$admin_paymentgw[71] = "Default Currency - Please choose one of the available currencies from the list below";
	$admin_paymentgw[72] = "Tax, in percentage, added at checkout";

    
    break;
  
  
  
  case "admin_payment_clients":
	$admin_payment_clients[1] = "View Clients";
	$admin_payment_clients[2] = "This page lists all the clients that has made payments and associated username. Use the filter fields to find specific client based on your criteria. To view all clients, leave all the filter fields blank.";
	$admin_payment_clients[3] = "Username";
	$admin_payment_clients[4] = "Email";
	$admin_payment_clients[5] = "First Name";
	$admin_payment_clients[6] = "Last Name";
	$admin_payment_clients[7] = "Street";
	$admin_payment_clients[8] = "City";
	$admin_payment_clients[9] = "State";
	$admin_payment_clients[10] = "Zipcode";
	$admin_payment_clients[11] = "Country";
	$admin_payment_clients[12] = "Options";

	$admin_payment_clients[13] = "First Name or Last Name";
	$admin_payment_clients[14] = "Filter";
	$admin_payment_clients[15] = "ID";
	$admin_payment_clients[16] = "Clients Found";
	$admin_payment_clients[17] = "Page:";

	$admin_payment_clients[18] = "view payments";

	$admin_payment_clients[21] = "No clients were found.";

	break;



  case "admin_payment_reports_income":
	$admin_payment_reports_income[1] = "Income report";
	$admin_payment_reports_income[2] = "View payment history.";
	$admin_payment_reports_income[3] = "Username";
	$admin_payment_reports_income[4] = "Payment status:";
	$admin_payment_reports_income[5] = "No payments found.";
	$admin_payment_reports_income[6] = "Description";
	$admin_payment_reports_income[7] = "Client";
	$admin_payment_reports_income[8] = "Payer email";

	$admin_payment_reports_income[9] = "Yes";
	$admin_payment_reports_income[10] = "No";

	$admin_payment_reports_income[14] = "Filter";
	$admin_payment_reports_income[15] = "ID";
	$admin_payment_reports_income[16] = "Transactions Found";
	$admin_payment_reports_income[17] = "Page:";

	$admin_payment_reports_income[18] = "User";
	$admin_payment_reports_income[19] = "Date";
	$admin_payment_reports_income[20] = "Description";
	$admin_payment_reports_income[21] = "Status";
	$admin_payment_reports_income[22] = "Amount";

	$admin_payment_reports_income[23] = "TransactionID";


	$admin_payment_reports_income[24] = "User Level";
	$admin_payment_reports_income[25] = "Subnetwork";
	$admin_payment_reports_income[26] = "Default";

	$admin_payment_reports_income[27] = "confirm";
	$admin_payment_reports_income[28] = "cancel";

	$admin_payment_reports_income[29] = "Source";
	$admin_payment_reports_income[30] = "Manual";

	$admin_payment_reports_income[31] = "From";
	$admin_payment_reports_income[32] = "To";

    $admin_payment_reports_income[33] = "Month";
    $admin_payment_reports_income[34] = "Day";
    $admin_payment_reports_income[35] = "Year";

	break;





  
  /*** USER PAGES ***/

  
  
  case "payment":
    $payment[1] = "Checkout";;
    $payment[2] = "Description";
    $payment[3] = "Unit price";
    $payment[4] = "Quantity";
    $payment[5] = "Amount";
    $payment[6] = "Total:";
    
    $payment[10] = "There was an error during the checkout process. Please try again or contact webmaster"; 
    $payment[11] = "There was an error during the payment process. Please try again or contact webmaster"; 
    $payment[12] = "Your cart is empty"; 
    $payment[13] = "Your payment was successfully processed!"; 
    
    break;


  
}


// ASSIGN ALL SMARTY VARIABLES
if(is_array(${"$page"})) {
  reset(${"$page"});
  while(list($key, $val) = each(${"$page"})) {
    $smarty->assign($page.$key, $val);
  }
}

?>