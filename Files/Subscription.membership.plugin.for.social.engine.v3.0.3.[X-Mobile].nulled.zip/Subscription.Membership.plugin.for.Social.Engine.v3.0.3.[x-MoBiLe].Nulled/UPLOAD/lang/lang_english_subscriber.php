<?


// SET GENERAL VARIABLES, AVAILABLE ON EVERY PAGE
$header_subscriber[1] = "Subscriptions";


// ASSIGN ALL SMARTY GENERAL VARIABLES
reset($header_subscriber);
while(list($key, $val) = each($header_subscriber)) {
  $smarty->assign("header_subscriber".$key, $val);
}


// FUNCTION VARIABLES

$functions_subscriber[1] = "day(s)";
$functions_subscriber[2] = "week(s)";
$functions_subscriber[3] = "month(s)";
$functions_subscriber[4] = "year(s)";
$functions_subscriber[5] = "Payment for subscription - ";
$functions_subscriber[6] = "Initial payment (one-time) for subscription - ";
$functions_subscriber[7] = "Upgrade payment (prorate) for subscription - ";

/* Subscription States */
$functions_subscriber[10] = "Active";
$functions_subscriber[11] = "Active ( Trial period )";
$functions_subscriber[12] = "Expired";
$functions_subscriber[13] = "Cancelled";
$functions_subscriber[14] = "Suspended";
$functions_subscriber[15] = "Pending ( Waiting for payment confirmation )";
$functions_subscriber[17] = "Suspended ( Recurring payment failed )";

/* Transaction States */
$functions_subscriber[20] = "Completed";
$functions_subscriber[21] = "Pending";
$functions_subscriber[22] = "Refunded";
$functions_subscriber[23] = "Reversed";

/* Payment Text Items */
$functions_subscriber[30] = "Cart Items";
$functions_subscriber[31] = "Sale";



/* Messages - only seen by admin */
$functions_subscriber[78] = "Error";
$functions_subscriber[79] = "General";
$functions_subscriber[80] = "Plan subscribed";
$functions_subscriber[81] = "Plan cancelled";
$functions_subscriber[82] = "Plan expired";
$functions_subscriber[83] = "Plan renewed";
$functions_subscriber[84] = "Plan suspended";

$functions_subscriber[99] = "(by payment processor).";
$functions_subscriber[100] = "User subscribed to \"<a href='admin_subscriber_editplan.php?plan_id=[plan_id]'>[plan_name]</a>\".";
$functions_subscriber[101] = "Subscription to \"<a href='admin_subscriber_editplan.php?plan_id=[plan_id]'>[plan_name]</a>\" was cancelled.";
$functions_subscriber[102] = "Subscription to \"<a href='admin_subscriber_editplan.php?plan_id=[plan_id]'>[plan_name]</a>\" was expired.";
$functions_subscriber[103] = "Subscription \"<a href='admin_subscriber_editplan.php?plan_id=[plan_id]'>[plan_name]</a>\" was renewed.";
$functions_subscriber[104] = "No payment received for subscription \"<a href='admin_subscriber_editplan.php?plan_id=[plan_id]'>[plan_name]</a>\" and it was suspended.";

$functions_subscriber[1001] = "Error cancelling plan [plan_name] using [paymentgateway_name], Error Message: [err_msg]";


// SET LANGUAGE PAGE VARIABLES
switch ($page) {

  case "admin_subscriber":
	$admin_subscriber[1] = "Global Subscriber Settings";
	$admin_subscriber[2] = "Global Subscriber Settings";
	$admin_subscriber[3] = "You changes have been saved";

	$admin_subscriber[4] = "Enable subscriptions";
	$admin_subscriber[5] = "Enable or disable site wide user subscriptions";
	$admin_subscriber[6] = "Yes, Enable site wide subscriptions.";
	$admin_subscriber[7] = "No, Disable site wide subscriptions";

	$admin_subscriber[8] = "Enable Trial periods for already registered users";
	$admin_subscriber[9] = "If enabled, users with expired plans can have trial periods without any limits.";
	$admin_subscriber[10] = "Yes, Enable trial periods for already registered users.";
	$admin_subscriber[11] = "No, Only new users can have trial periods.";

    
	$admin_subscriber[13] = "Save changes";

	$admin_subscriber[14] = "Subject";
	$admin_subscriber[15] = "Message";
	$admin_subscriber[16] = "New Subscription Email";
	$admin_subscriber[17] = "This is the email that gets sent to users after successful subscription.";
	$admin_subscriber[18] = "Subscription Cancelled Email";
	$admin_subscriber[19] = "This is the email that gets sent to users after subscription has been cancelled.";
	$admin_subscriber[20] = "Subscription Expired Email";
	$admin_subscriber[21] = "This is the email that gets sent to users after subscription has been expired.";
	$admin_subscriber[22] = "Subscription Expiration Notification Email";
	$admin_subscriber[23] = "This is the email that gets sent to users to warn about soon to expire subscription.";
	$admin_subscriber[24] = "Subscription Renewal Email";
	$admin_subscriber[25] = "This is the email that gets sent to users after subscription has been successfully renewed.";
	$admin_subscriber[26] = "Subscription Suspended - Payment Failed";
	$admin_subscriber[27] = "This is the email that gets sent to users after recurring payment has failed.";

	$admin_subscriber[30] = "[username] - replaced with the username of the recepient.<br>[email] - replaced with the email address of the recepient.<br>[link] - replaced with the link to view current subscriptions.<br>[subscription_details] - replaced with the subscription details.";

	$admin_subscriber[42] = "Require subscription during signup";
	$admin_subscriber[43] = "If enabled, a list of subscription plans will be shown on the first page during signup process and a user will have to choose one. If disabled - no subscription plans will be shown during signup process. <br><br><strong> Note: </strong> Please make sure you have integrated subscription into signup process (signup.php/signup.tpl), before choosing to require subscription during signup.";
	$admin_subscriber[44] = "Yes, Require subscription during signup";
	$admin_subscriber[45] = "No, Do not require subscription during signup";


    break;


  case "admin_subscriber_reports":
	$admin_subscriber_reports[1] = "Reports";
	$admin_subscriber_reports[2] = "Reports";

	$admin_subscriber_reports[3] = "Overview";
    
    
    break;


  case "admin_subscriber_dashboard":
	$admin_subscriber_dashboard[1] = "Dashboad";
	$admin_subscriber_dashboard[2] = "Here you can see an overview of your site-wide subscriptions status";
	$admin_subscriber_dashboard[3] = "Income";
	$admin_subscriber_dashboard[4] = "Total Income";
	$admin_subscriber_dashboard[5] = "Last Week Income:";
	$admin_subscriber_dashboard[6] = "Last Month Income:";
	$admin_subscriber_dashboard[7] = "Subscriptions";
	$admin_subscriber_dashboard[8] = "Active Subscriptions:";
	$admin_subscriber_dashboard[9] = "Expired Subscriptions:";
	$admin_subscriber_dashboard[10] = "Cancelled Subscriptions:";
	$admin_subscriber_dashboard[11] = "Latest Activity";
	$admin_subscriber_dashboard[12] = "Date";
	$admin_subscriber_dashboard[13] = "Activity";
	$admin_subscriber_dashboard[14] = "No Activities";

	$admin_subscriber_dashboard[15] = "report";
	$admin_subscriber_dashboard[16] = "manage";
	$admin_subscriber_dashboard[17] = "view all";

	$admin_subscriber_dashboard[18] = "User";
	$admin_subscriber_dashboard[19] = "Type";

    
    break;


  case "admin_subscriber_plans":
	$admin_subscriber_plans[1] = "Subscription plans";
	$admin_subscriber_plans[2] = "Here you can manage subscription plans. Please note that you can <strong>NOT</strong> delete or modify subscription terms of a plan which has active subscribers and is managed by automatic services like paypal, authorize.net, etc. You can disabled it, which will prevent new subscriptions but preserve current subscribers.";
	$admin_subscriber_plans[3] = "Add Subscription Plan";
	
	$admin_subscriber_plans[4] = "ID";
	$admin_subscriber_plans[5] = "Name";
	$admin_subscriber_plans[6] = "Users";
	$admin_subscriber_plans[7] = "Options";
	$admin_subscriber_plans[8] = "Enabled";
	$admin_subscriber_plans[9] = "Yes";
	$admin_subscriber_plans[10] = "No";
	$admin_subscriber_plans[11] = "edit";
	$admin_subscriber_plans[12] = "disable";
	$admin_subscriber_plans[13] = "enable";
	$admin_subscriber_plans[14] = "delete";
	
	$admin_subscriber_plans[17] = "user(s)";
	
	$admin_subscriber_plans[18] = "You can't delete a plan with active subscriber(s) (but you can disable it)";
	
	break;


  case "admin_subscriber_editplan":
	$admin_subscriber_editplan[1] = "Add / Edit plan";
	$admin_subscriber_editplan[2] = "Please note that you can NOT delete or modify subscription terms of a plan which has active subscribers and is managed by automatic services like paypal, authorize.net, etc. You can disabled it, which will prevent new subscriptions but preserve current subscribers.";
	$admin_subscriber_editplan[3] = "Name";
	$admin_subscriber_editplan[4] = "Description";
	$admin_subscriber_editplan[5] = "Enabled?";
	$admin_subscriber_editplan[6] = "Yes";
	$admin_subscriber_editplan[7] = "No";
	$admin_subscriber_editplan[8] = "Save Plan";
	$admin_subscriber_editplan[9] = "Cancel";
	$admin_subscriber_editplan[10] = "Associated Level";
	$admin_subscriber_editplan[11] = "Downgrade Level";
	$admin_subscriber_editplan[12] = "Plan Period";
	$admin_subscriber_editplan[13] = "Trial Period";
	$admin_subscriber_editplan[14] = "Price";
	$admin_subscriber_editplan[15] = "One time price";
	$admin_subscriber_editplan[16] = "Show during signup?";
	$admin_subscriber_editplan[17] = "Recurring?";
	$admin_subscriber_editplan[18] = "No Level (user stays at the same level)";

	$admin_subscriber_editplan[20] = "Please enter a plan name";
	$admin_subscriber_editplan[21] = "Maximum possible value for period type '%s' is %d";
	$admin_subscriber_editplan[22] = "Maximum possible value for trial period type '%s' is %d";

	$admin_subscriber_editplan[23] = "recurring cycles ('0' for unlimited)";
	$admin_subscriber_editplan[24] = "and has";

	$admin_subscriber_editplan[25] = "Can upgrade from level:";
	$admin_subscriber_editplan[26] = "Select options";
	$admin_subscriber_editplan[27] = "Select All";
	$admin_subscriber_editplan[28] = "(signup default)";

	$admin_subscriber_editplan[29] = "Can be upgraded from:";

	break;
  
  
  case "admin_subscriber_viewusers":
	$admin_subscriber_viewusers[1] = "View Users";
	$admin_subscriber_viewusers[2] = "This page lists all of the users that exist on your social network together with Subscription Plan information. For more information about a specific user, click on the \"edit\" link in its row. Use the filter fields to find specific users based on your criteria. To view all users on your system, leave all the filter fields blank. ";
	$admin_subscriber_viewusers[3] = "Username";
	$admin_subscriber_viewusers[4] = "unverified";
	$admin_subscriber_viewusers[5] = "Email";
	$admin_subscriber_viewusers[6] = "Enabled";
	$admin_subscriber_viewusers[7] = "Signup Date";
	$admin_subscriber_viewusers[8] = "Options ";
	$admin_subscriber_viewusers[9] = "Yes";
	$admin_subscriber_viewusers[10] = "No";
    
	$admin_subscriber_viewusers[11] = "edit";
	$admin_subscriber_viewusers[12] = "for him";
	$admin_subscriber_viewusers[13] = "by him";

	$admin_subscriber_viewusers[14] = "Filter";
	$admin_subscriber_viewusers[15] = "ID";
	$admin_subscriber_viewusers[16] = "Users Found";
	$admin_subscriber_viewusers[17] = "Page:";

	$admin_subscriber_viewusers[18] = "Subscription";
	$admin_subscriber_viewusers[19] = "";

	$admin_subscriber_viewusers[20] = "IP Address";
    
	$admin_subscriber_viewusers[21] = "No users were found.";

	$admin_subscriber_viewusers[22] = "Subscription Plan";
	$admin_subscriber_viewusers[23] = "";

	$admin_subscriber_viewusers[24] = "User Level";
	$admin_subscriber_viewusers[25] = "Subnetwork";
	$admin_subscriber_viewusers[26] = "Default";

	$admin_subscriber_viewusers[27] = "Signup IP Address";
	$admin_subscriber_viewusers[28] = "Not Subscribed";

	$admin_subscriber_viewusers[29] = "Not Subscribed";
	$admin_subscriber_viewusers[30] = "Any (Subscribed)";
	$admin_subscriber_viewusers[31] = "Any (Suspended)";


	break;
  


  case "admin_subscriber_messages":
	$admin_subscriber_messages[1] = "View Messages";
	$admin_subscriber_messages[2] = "This page lists all the activities or any errors. Use the filter fields to find specific messages based on your criteria. To view all messages, leave all the filter fields blank.";
	$admin_subscriber_messages[3] = "Date";
	$admin_subscriber_messages[4] = "Username";
	$admin_subscriber_messages[5] = "Type";
	$admin_subscriber_messages[6] = "Message";

	$admin_subscriber_messages[14] = "Filter";
	$admin_subscriber_messages[15] = "ID";
	$admin_subscriber_messages[16] = "Messages Found";
	$admin_subscriber_messages[17] = "Page:";

	$admin_subscriber_messages[21] = "No messages were found.";

	break;
  

  case "admin_subscriber_usermessages":
	$admin_subscriber_usermessages[1] = "Edit User:";
	$admin_subscriber_usermessages[2] = "This page lists all the activities or any errors for specific user.";
	$admin_subscriber_usermessages[3] = "Date";
	$admin_subscriber_usermessages[4] = "Username";
	$admin_subscriber_usermessages[5] = "Type";
	$admin_subscriber_usermessages[6] = "Message";

    $admin_subscriber_usermessages[7] = "User Details";
    $admin_subscriber_usermessages[8] = "Payment History";
    $admin_subscriber_usermessages[9] = "Messages";
	$admin_subscriber_usermessages[10] = "Back to users";

	$admin_subscriber_usermessages[14] = "Filter";
	$admin_subscriber_usermessages[15] = "ID";
	$admin_subscriber_usermessages[16] = "Messages Found";
	$admin_subscriber_usermessages[17] = "Page:";

	$admin_subscriber_usermessages[21] = "No messages were found.";

	break;
  




  case "admin_subscriber_edituser":
	$admin_subscriber_edituser[1] = "Edit User:";
	$admin_subscriber_edituser[2] = "Edit User";
    $admin_subscriber_edituser[3] = "User Details";
    $admin_subscriber_edituser[4] = "Payment History";
	$admin_subscriber_edituser[5] = "Back to users";

	$admin_subscriber_edituser[6] = "Save Changes";
	$admin_subscriber_edituser[7] = "Cancel";

	$admin_subscriber_edituser[8] = "The user has no active plans.";

    $admin_subscriber_edituser[9] = "Cancel Subscription";
    $admin_subscriber_edituser[10] = "Are you sure you want to cancel this subscription?";
    $admin_subscriber_edituser[11] = "Delete Subscription";
    $admin_subscriber_edituser[12] = "Are you sure you want to delete this subscription? <br><strong>Note</strong>: Deleting subscription will not downgrade user's level.";

    $admin_subscriber_edituser[13] = "Subscription Plan:";
    $admin_subscriber_edituser[14] = "Status:";
    $admin_subscriber_edituser[15] = "Billing Frequency:";
    $admin_subscriber_edituser[16] = "Start Date:";
    $admin_subscriber_edituser[17] = "Next Payment Date:";
    $admin_subscriber_edituser[18] = "Price:";
    $admin_subscriber_edituser[19] = "per";
    $admin_subscriber_edituser[20] = "upgrade";
    $admin_subscriber_edituser[21] = "cancel";
    $admin_subscriber_edituser[22] = "renew";
    $admin_subscriber_edituser[23] = "Expiration Date:";
    $admin_subscriber_edituser[24] = "Last Payment Date:";
    $admin_subscriber_edituser[25] = "view payment history";
    $admin_subscriber_edituser[26] = "Managed by:";

    $admin_subscriber_edituser[27] = "Month";
    $admin_subscriber_edituser[28] = "Day";
    $admin_subscriber_edituser[29] = "Year";
    $admin_subscriber_edituser[30] = "Manual";

    $admin_subscriber_edituser[31] = "<strong>Please Note</strong>: This subscription is currently managed by automatic payment processor. You can't change any values, unless you cancel the subscription.";

    $admin_subscriber_edituser[32] = "Save changes";
    $admin_subscriber_edituser[33] = "Cancel";
    $admin_subscriber_edituser[34] = "Update Successful";
    $admin_subscriber_edituser[35] = "Delete Subscription";
    $admin_subscriber_edituser[36] = "Cancel Subscription";
    $admin_subscriber_edituser[37] = "Subscribe user";
    $admin_subscriber_edituser[38] = "Select plan:";

    $admin_subscriber_edituser[40] = "Messages";

    //$admin_subscriber_edituser[] = "";
	break;
  
  
  
  case "admin_subscriber_userhistory":
	$admin_subscriber_userhistory[1] = "Edit User:";
	$admin_subscriber_userhistory[2] = "This page lists all the payments made by specific user.";
    $admin_subscriber_userhistory[3] = "User Details";
    $admin_subscriber_userhistory[4] = "Payment History";
	$admin_subscriber_userhistory[5] = "Back to users";
    $admin_subscriber_userhistory[9] = "Messages";


	$admin_subscriber_userhistory[12] = "Search history for:";


	$admin_subscriber_userhistory[15] = "Last Page";
	$admin_subscriber_userhistory[16] = "viewing transaction";
	$admin_subscriber_userhistory[17] = "of";
	$admin_subscriber_userhistory[18] = "viewing transactions";
	$admin_subscriber_userhistory[19] = "Next Page";
	$admin_subscriber_userhistory[20] = "No entries matched your search term.";
	$admin_subscriber_userhistory[21] = "There are no transactions for this user yet.";

	$admin_subscriber_userhistory[22] = "Date";
	$admin_subscriber_userhistory[23] = "Description";
	$admin_subscriber_userhistory[24] = "Status";
	$admin_subscriber_userhistory[25] = "Amount";

	break;


  case "admin_levels_subscribersettings":
    $admin_levels_subscribersettings[1] = "Subscription Settings";
    $admin_levels_subscribersettings[2] = "You can adjust subscription requirements from this page.";

    $admin_levels_subscribersettings[3] = "Require subscription on current level?";
    $admin_levels_subscribersettings[4] = "This will disable any activity on the site until the user on this level subscribers and the level is updated.";
    $admin_levels_subscribersettings[5] = "Yes, require Subscription on this level.";
    $admin_levels_subscribersettings[6] = "No, do not require Subscription on this level.";

    $admin_levels_subscribersettings[7] = "Allow viewing profiles?";
    $admin_levels_subscribersettings[8] = "This will disable viewing any profiles besides users's own on this level.";
    $admin_levels_subscribersettings[9] = "Yes, disable viewing other users' profiles.";
    $admin_levels_subscribersettings[10] = "No, do not disable viewing other users' profiles.";


	$admin_levels_subscribersettings[14] = "Save Changes";
	$admin_levels_subscribersettings[15] = "Your changes have been saved.";

	$admin_levels_subscribersettings[35] = "Editing User Level:";
	$admin_levels_subscribersettings[36] = "You are currently editing this user level's settings. Remember, these settings only apply to the users that belong to this user level. When you're finished, you can edit the <a href='admin_levels.php'>other levels here</a>.";

	break;
  

  
  /*** USER PAGES ***/




  case "user_plan":
	$user_plan[1] = "My Plans";
	$user_plan[2] = "Payment History";
	$user_plan[3] = "Upgrade Options";

	$user_plan[10] = "My Plans";
	$user_plan[11] = "Current Subscriptions";
	$user_plan[12] = "You have no active subscriptions";
    
    $user_plan[13] = "Subscription Plan:";
    $user_plan[14] = "Status:";
    $user_plan[15] = "Billing Frequency:";
    $user_plan[16] = "Start Date:";
    $user_plan[17] = "Next Payment Date:";
    $user_plan[18] = "Price:";
    $user_plan[19] = "per";
    $user_plan[20] = "upgrade";
    $user_plan[21] = "cancel";
    $user_plan[22] = "renew";
    $user_plan[23] = "Expiration Date:";
    $user_plan[24] = "Last Payment Date:";
    $user_plan[25] = "view payment history";
    $user_plan[26] = "Cancel Subscription";
    $user_plan[27] = "Are you sure you want to cancel this subscription?";
    
    break;
  
  case "user_plan_history":
	$user_plan_history[1] = "My Plans";
	$user_plan_history[2] = "Payment History";
	$user_plan_history[3] = "Upgrade Options";


	$user_plan_history[10] = "My Payments history";
	$user_plan_history[11] = "Lists all the payments";
	$user_plan_history[12] = "Search history for:";


	$user_plan_history[15] = "Last Page";
	$user_plan_history[16] = "viewing transaction";
	$user_plan_history[17] = "of";
	$user_plan_history[18] = "viewing transactions";
	$user_plan_history[19] = "Next Page";
	$user_plan_history[20] = "No entries matched your search term.";
	$user_plan_history[21] = "You do not have any transactions.";

	$user_plan_history[22] = "Date";
	$user_plan_history[23] = "Description";
	$user_plan_history[24] = "Status";
	$user_plan_history[25] = "Amount";

	break;


  case "user_plan_upgrade":
	$user_plan_upgrade[1] = "My Plans";
	$user_plan_upgrade[2] = "Payment History";
	$user_plan_upgrade[3] = "Upgrade Options";
    
    $user_plan_upgrade[10] = "Please choose a subscription plan";
    $user_plan_upgrade[11] = "There are no available plans you can upgrade to";
    $user_plan_upgrade[12] = "Please choose a subscription plan";
    $user_plan_upgrade[13] = "Upgrade subscription";
    $user_plan_upgrade[14] = "per";
    $user_plan_upgrade[15] = "Upgrade";
    $user_plan_upgrade[16] = "Cancel";
    
    $user_plan_upgrade[17] = "Please subscribe to one of the plans below in order to receive access to the website.";
    
    
    break;


  case "user_plan_renew":
	$user_plan_renew[1] = "My Plans";
	$user_plan_renew[2] = "Payment History";

    $user_plan_renew[10] = "Renew subscription";
    
    break;
  
  

  case "profile":
    break;
  

  case "user_home":
    break;
  
  case "home":
    break;
  
  case "signup":
    $signup[800] = "Subscription Plan";
    $signup[801] = "Subscription";
    $signup[802] = "Name:";
    $signup[803] = "Description:";
    $signup[804] = "Billing Frequency:";
    $signup[805] = "Lifetime";
    $signup[806] = "Trial period:";
    $signup[807] = "Price:";
    $signup[808] = "One time payment:";
    $signup[809] = "per";
    $signup[810] = "Please choose a subscription plan";
    $signup[811] = "Please review your subscription terms and proceed to checkout.";
    $signup[812] = "Please review your subscription terms and proceed to checkout.";
    $signup[813] = "Subscription information";
  
}


// ASSIGN ALL SMARTY VARIABLES
if(is_array(${"$page"})) {
  reset(${"$page"});
  while(list($key, $val) = each(${"$page"})) {
    $smarty->assign($page.$key, $val);
  }
}

?>