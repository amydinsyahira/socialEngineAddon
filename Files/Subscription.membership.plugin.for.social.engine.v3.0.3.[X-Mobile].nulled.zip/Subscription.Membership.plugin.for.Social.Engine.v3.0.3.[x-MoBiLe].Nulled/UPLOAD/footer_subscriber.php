<?php

switch($page) {

  // SIGNUP HIJACK
  case "signup":

    if ( ($subscriber_enabled) && semods::get_setting('subscriber_require_on_signup') ) {
      
    if($task == "step1") {
      $rows = $database->database_query("SELECT * FROM se_semods_plans WHERE plan_enabled = 1 AND plan_showonsignup = 1");
      while($row = $database->database_fetch_assoc($rows)) {
        $row['plan_trialperiodtypetext'] = $plan_periodtypes[ $row['plan_trialperiodtype'] ]['f'];
        $row['plan_periodtypetext'] = $plan_periodtypes[ $row['plan_periodtype'] ]['f'];
        $plans[] = $row;
      }
  
      $smarty->assign('plans', $plans);
    }
    
    // For step1 & step2
    if( $plan_is_error != 0 ) {
      $is_error = 1;
      $error_message = $plan_error_message;
      $smarty->assign('error_message', $error_message);
      
      // ReCache values
      $signup_email = $_POST['signup_email'];
      $signup_password = $_POST['signup_password'];
      $signup_password2 = $_POST['signup_password2'];
      $step = $_POST['step'];
      if($task == "step2do" & $step != "1") {
        $signup_password = base64_decode($signup_password);
        $signup_password2 = base64_decode($signup_password2);
      }
      $signup_username = $_POST['signup_username'];
      $signup_invite = $_POST['signup_invite'];

      $smarty->assign('signup_email', $signup_email);
      $smarty->assign('signup_password', $signup_password);
      $smarty->assign('signup_password2', $signup_password2);
      $smarty->assign('signup_username', $signup_username);
      $smarty->assign('signup_invite', $signup_invite);
    }
    
    if($step == 5) {
      $plan = new semods_plan( $signup_plan );
      
      if(($plan->plan_exists == 0) || $plan->is_free_plan() ) {
        
        $plan_free = true;
        
        // And subscribe a user right away
        $plan->plan_subscribe( $new_user->user_info['user_id'], 0, array(), false );
        
      }
      else
        $plan_free = false;
        
      if(!$plan_free) {
        
        $cart = new semods_cart();
        $cart->create_cart( $new_user->user_info['user_id'] );

        $cart_item = new semods_subscription_cartitem(  $plan->plan_info['plan_name'],
                                                        $plan->plan_info['plan_id'],
                                                        $plan->plan_info['plan_price'],
                                                        array( 'uid'  => $new_user->user_info['user_id'],
                                                               'pid'  => $plan->plan_info['plan_id'] )
                                                        );

        $cart_item->set_user_id( $new_user->user_info['user_id'] );

        // plan_onetime_price - initial price
        $cart_item->set_initial_price( $plan->plan_info['plan_onetime_price'] );
        
        // Trial
        if($plan->plan_info['plan_trialperiod'] != 0) {
          $cart_item->add_trial_period( $plan->plan_info['plan_trialperiodprice'],
                                        $plan->plan_info['plan_trialperiod'],
                                        $plan->plan_info['plan_trialperiodtype'] );
        }
        
        $cart_item->add_period( $plan->plan_info['plan_price'],
                                $plan->plan_info['plan_period'],
                                $plan->plan_info['plan_periodtype'],
                                $plan->plan_info['plan_recurring'],
                                $plan->plan_info['plan_recurring_cycles'] );
        
        $cart->add_item( $cart_item );
    
      }
      
      $smarty->assign('plan_free', $plan_free);
      $smarty->assign('plan', $plan);
        
        // Reload page and loose
        setcookie("signup_plan", "", 0, "/");
          
    }
    
      $smarty->assign('currency_code', semods::get_setting('payment_currency'));

    } else {
        $smarty->assign('plan_free', 1);
    }
    break;
  
}




?>