<?
$page = "user_plan";
include "header.php";

$task = semods::getpost('task', "main");
$from_plan = intval( semods::getpost('from_plan', 0) );

$proceed_to_cart = false;

if(!empty($from_plan)) {
  $userplan = new semods_userplan( $from_plan, $user->user_info['user_id'] );
}

if($userplan->userplan_exists == 0) {
  // Now - only one plan
  // Later - multiple plans => display list to choose from
  $userplan = new semods_userplan( 0, $user->user_info['user_id'] );
}


if($userplan->userplan_exists != 0)  {
  
  if($userplan->userplan_info['plan_price'] != 0) {

    // FOR RENEWING - NO TRIAL PERIOD
    
    $cart = new semods_cart();
    $cart->create_cart( $user->user_info['user_id'] );

    $cart_item = new semods_subscription_cartitem(  $userplan->userplan_info['plan_name'],
                                                    $userplan->userplan_info['plan_id'],
                                                    $userplan->userplan_info['plan_price'],
                                                    array( 'uid'  => $user->user_info['user_id'],
                                                           'pid'  => $userplan->userplan_info['plan_id'] )
                                                    );

    $cart_item->set_user_id( $user->user_info['user_id'] );

    // plan_onetime_price - initial price
    $cart_item->set_initial_price( $userplan->userplan_info['plan_onetime_price'] );
    
    // Subscription - TBD: recurring number of times
    $cart_item->add_period( $userplan->userplan_info['plan_price'],
                            $userplan->userplan_info['plan_period'],
                            $userplan->userplan_info['plan_periodtype'],
                            $userplan->userplan_info['plan_recurring'],
                            $userplan->userplan_info['plan_recurring_cycles'] );
    
    $cart->add_item( $cart_item );

    $proceed_to_cart = true;
    
  } else {
    $error_message = "You cannot renew free plan";
  }
  
}

if($proceed_to_cart) {
  header("Location: payment.php");
} else {
  // redirect to upgrade to choose from available plans?
  //header("Location: user_plan_upgrade.php");

  header("Location: user_plan.php");
}

exit();

/*
// Find out plans that are active & manually paid / expired / cancelled 
$plans = array();
$rows = $database->database_query("SELECT * FROM se_semods_userplans WHERE userplan_user_id = {$user->user_info['user_id']}");
while($row = $database->database_fetch_assoc($rows)) {
  $plans[] = $row;
}
*/

/*
// ASSIGN VARIABLES AND INCLUDE FOOTER
$smarty->assign('result', $result);
$smarty->assign('error_message', $error_message);
$smarty->assign('plans', $plans);
include "footer.php";
*/
?>