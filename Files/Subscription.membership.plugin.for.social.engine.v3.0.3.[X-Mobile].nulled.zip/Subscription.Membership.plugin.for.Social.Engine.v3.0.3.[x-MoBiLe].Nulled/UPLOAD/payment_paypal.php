<?php
include 'header.php';

include_once "./include/class_semods_paypal.php";

$gwdata = semods::db_query_count( "SELECT paymentgateway_metadata FROM se_semods_paymentgateways WHERE paymentgateway_id = 1" );

$gwdata = unserialize( $gwdata );

$paypal = new Paypal( array(
                             'business'             => $gwdata['business'],
                             'cert_id'              => $gwdata['cert_id'],
                             'identity_token'       => $gwdata['identity_token'],
                             'currency_code'        => $gwdata['currency_code'],
                             'ssl_myprivkey_file'   => $gwdata['ssl_myprivkey_file'],
                             'ssl_mypubcert_file'   => $gwdata['ssl_mypubcert_file'],
                             'ssl_paypalcert_file'  => $gwdata['ssl_paypalcert_file'],
                             'sandbox'              => $gwdata['sandbox']

                            ) );

$action = semods::getpost('action');


switch( $action ) {
    
    case 'ipn':
      
        // TBD: log requests

        $_POST = security($_POST);
        
        /*
         * txn_type
         * subscr_signup: subscription sign-up.
         * subscr_cancel: subscription cancellation.
         * subscr_failed: subscription payment failure.
         * subscr_payment: subscription payment.
         * subscr_eot: subscription's end-of-term.
         * subscr_modify: subscription modification.
         *
         * 
         *
         * Pending => Complete -> same transaction
         * Reversed -> new transaction, previous transaction -> "Canceled_Revers"
         * Refund ->  new transaction
         * Denied -> same transaction
         * 
         */
          
          
          
          // TBD: refunds for recurring_payment arrive without txn_type !!!
        if( $paypal->process_ipn() ) {
          
          
          switch($paypal->tx_data['txn_type']) {


            // express checkout cart
            case "express_checkout":

              $cart_id = $paypal->tx_data['custom'];
               
              $cart = new semods_cart( $cart_id );
              
              // WTF? - somebody made manual payment? etc
              if($cart->cart_exists != false) {
                $cart->on_cart_paid();
              }
              
              // Transaction -> cart_id (as invoice / details)
              
              break;



 

            // IPN after creating recurring_payment_profile via API (not subscription)
            case "recurring_payment_profile_created":

              // only to invoice if there were initial amount.
              if($paypal->tx_data['initial_payment_status'] == "Completed") {

                // find out user_id for this profile  
                $profile_id = $paypal->tx_data['recurring_payment_id'];
                $userplan = new semods_userplan( null, null, null, null, $profile_id );
                
                if($userplan->userplan_exists) {
    
                  // TBD: paypal date is in PDT -> convert to GMT?
                  $payment_type = 2;  // initial subscription / recurring payment
                  $payment_state = 0; // completed
                  $payment_date = strtotime( $paypal->tx_data['time_created'] );  // use profile creation as time for initial payment
                  $payment_text = $functions_subscriber[6] . ' ' . $userplan->userplan_info['plan_name'];
                  $payment_amount = sprintf( "%.2f", $paypal->tx_data['initial_payment_amount'] );
                  
                  semods_payment_invoice( $userplan->userplan_info['userplan_user_id'],
                                          $payment_date,
                                          $payment_type,
                                          $payment_state,
                                          $payment_text,
                                          $payment_amount,
                                          $paypal->tx_data['initial_payment_txn_id'],
                                          1,  // handler - paypal
                                          $paypal->tx_data['first_name'],
                                          $paypal->tx_data['last_name'],
                                          $paypal->tx_data['payer_email'],
                                          $paypal->tx_data['address_street'],
                                          $paypal->tx_data['address_city'],
                                          $paypal->tx_data['address_state'],
                                          $paypal->tx_data['address_zip'],
                                          $paypal->tx_data['address_country']
                                          );
                  
                } else {
                  subscriber_log_error( "[Paypal] Received recurring_payment_profile_created with profile refid '$profile_id' but no associated userplan" );
                }
                
              }

              break;
            
            

            
            

            // IPN after for recurring payment
            case "recurring_payment":

/*
 * Actions:
 *
 * need userid
 * need planid
 * 
 * create plan if none
 * extend plan if already active
 *
 * when upgrading -
 * cancel current plan (if active)
 * pay via EC -
 *  pro-rate
 *  recurring payment - create new profile
 * 
 */
          
            if($paypal->tx_status() == "Completed") {

              $profile_id = $paypal->tx_data['recurring_payment_id'];
              $userplan = new semods_userplan( null, null, null, null, $profile_id );
              
              if($userplan->userplan_exists) {
                
                if(trim($paypal->tx_data['period_type']) == 'Trial' ) {
                  $userplan->extend_plan( 1 );
                } else {
                  $userplan->extend_plan( 0 );
                }
  
  
                // TBD: paypal date is in PDT -> convert to GMT?
                $payment_type = 1;  // recurring payment
                $payment_state = 0; // completed
                $payment_date = strtotime( $paypal->tx_data['payment_date'] );
                $payment_text = $functions_subscriber[5] . ' ' . $userplan->userplan_info['plan_name'];
                $payment_amount = sprintf( "%.2f", $paypal->tx_data['payment_gross'] );
                
                semods_payment_invoice( $userplan->userplan_info['userplan_user_id'],
                                        $payment_date,
                                        $payment_type,
                                        $payment_state,
                                        $payment_text,
                                        $payment_amount,
                                        $paypal->tx_data['txn_id'],
                                        1,  // handler - paypal
                                        $paypal->tx_data['first_name'],    //$client_firstname,
                                        $paypal->tx_data['last_name'],
                                        $paypal->tx_data['payer_email'],
                                        $paypal->tx_data['address_street'],
                                        $paypal->tx_data['address_city'],
                                        $paypal->tx_data['address_state'],
                                        $paypal->tx_data['address_zip'],
                                        $paypal->tx_data['address_country']
                                        );
              } else {
                  subscriber_log_error( "[Paypal] Received recurring_payment with profile refid '$profile_id' but no associated userplan" );
              }
              
            }
            
              break;



 

            case 'recurring_payment_profile_cancel':
              
              $profile_id = $paypal->tx_data['recurring_payment_id'];
              $userplan = new semods_userplan( null, null, null, null, $profile_id );
              
              if($userplan->userplan_exists) {
                
                  $userplan->cancel_plan( 0, 0, 1 );
                
              } else {
                  subscriber_log_error( "[Paypal] Received recurring_payment_profile_cancel with profile refid '$profile_id' but no associated userplan" );
              }
              
              break;
            
            
            
            
            

            

            
            // just payment
            case "payment":
              
              /*
               
              $cart_id = $paypal->tx_data['custom'];
              
              $cart = new semods_cart( $cart_id );
              
              // WTF? - somebody made manual payment, etc
              if($cart->cart_exists != false) {
                foreach($cart->cart_items as $cart_item) {
                  if( !empty($cart_item['cartitem_callback']) && is_callable($cart_item['cartitem_callback'])) ) {
                    // TBD: also push all cart item params? e.g. quantity, etc
                    call_user_func_array( $cart_item['cartitem_callback'], unserialize($cart_item['cartitem_callbackparams']));
                  }
                }
              }
              
              */
              
              break;

              
               
              
                
                
            // Payment for subscription
            case "subscr_payment":
                
              break;


            // Start of subscription period
            case "subscr_signup":
              
              //$plan->plan_subscribe( $user_id, $paypal->tx_data['subscr_id'] );
            
              break;

            
            // Cancel subscription 
            case "subscr_cancel":

                //$plan->plan_cancel( $user_id, $paypal->tx_data['subscr_id'] );

              break;


            // Failure of payment / subscription 
            case "subscr_failed":
             
                //$plan->plan_suspend( $user_id, $paypal->tx_data['subscr_id'] );

              break;


            // End of subscription - expiration
            case "subscr_eot":
              
                //$plan->plan_end( $user_id, $paypal->tx_data['subscr_id'] );

              break;


            // Subscription details modified
            case "subscr_modify":

              break;
            
          }
          
        } else {
          // log failed process
        }
        
        break;
    
    
    case 'success':

    
        header( "Location: user_home.php" );
        exit();

        break;
    
    case 'cancel':
        
        header( "Location: user_home.php" );
        exit();
       
        break;
    
    default;
        header("Location: user_home.php");
        
}

?>